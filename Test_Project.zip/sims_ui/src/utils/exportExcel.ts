const xlsx = require("xlsx");

export const handleExport = (data: any, fileName: string) => {
  try {
    const workbook = xlsx.utils.book_new();
    const worksheet = xlsx.utils.json_to_sheet(data);
    xlsx.utils.book_append_sheet(workbook, worksheet, "Sheet 1");
    xlsx.writeFile(workbook, fileName);
  } catch (err) {
    throw err;
  }
};
