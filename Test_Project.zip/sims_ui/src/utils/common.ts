// @ts-nocheck
import { ISelectionOption } from "../models";

export const getNewLangAfterToggle = (currentLang) =>
  currentLang === "de" ? "en" : "de";

export const descendingComparator = (a, b, orderBy) => {
  if (`${b[orderBy]}`.toLowerCase() < `${a[orderBy]}`.toLowerCase()) {
    return -1;
  }
  if (`${b[orderBy]}`.toLowerCase() > `${a[orderBy]}`.toLowerCase()) {
    return 1;
  }
  return 0;
};

export const getComparator = (order, orderBy) => {
  return order === "desc"
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
};

export const getCurrentSelectedLanguage = () => {
  const langauge = localStorage.getItem("language");
  if (langauge) {
    return langauge;
  }
  return "de";
};

export const getCurrentDateAndTime = () => {
  const date = new Date();
  const dateAndTime = `${date.getFullYear()}-${
    date.getUTCMonth() + 1
  }-${date.getDate()}_${date.getUTCHours()}${date.getUTCMinutes()}${date.getUTCSeconds()}`;
  return dateAndTime;
};

export const returnSelectOption = (obj: any): ISelectionOption[] => {
  return Object.entries<string>(obj).map(([id, label]) => {
    return { label, id };
  });
};

export const REACT_BASE_URL = process.env.REACT_APP_BASE;

export const sortDropDown = (options) => {
  options.sort((a, b) => {
    const labelA = a?.label?.toString().toUpperCase(); // Ignore case sensitivity
    const labelB = b?.label?.toString().toUpperCase();
    if (labelA < labelB) {
      return -1;
    }
    if (labelA > labelB) {
      return 1;
    }
    return 0; // If labels are equal
  });
  return options;
};
