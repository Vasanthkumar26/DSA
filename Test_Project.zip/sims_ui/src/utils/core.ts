import axios, { AxiosResponse } from "axios";
import { Method } from "../models";
import { store } from "../redux/store";
import { showHighPriorityFailureSnackbar } from "../redux/actions/snackbarAction";

/**
 * The CORE API connectivity
 * It has an abstraction from the actual implementation
 */

/**
 * Creating own axios instance
 * Primarily because if we need to send some custom headers or request parameters
 */
const axiosInstance = axios.create({
  withCredentials: true,
  baseURL: process.env.REACT_APP_BASE
  // baseURL: BASE_URL,
});

axiosInstance.interceptors.response.use(
  (response: AxiosResponse) => {
    return response;
  },
  (error) => {
    store.dispatch(
      showHighPriorityFailureSnackbar(
        error?.response?.data?.reason || error?.message
      )
    );
    return Promise.reject(error);
  }
);

/**
 *
 * @param {*} method - The name of the method
 * @param {*} resource - the API end point[NOT BASE URL INCLUDED]
 * @param {*} data - The data which needs to be send in the body of the request
 * @param {*} responseType - The response type of the API (blob or json)
 * @returns - A promise
 */
export const CoreApi = (
  method: Method,
  resource: string,
  data: any | null,
  responseType: "blob" | "json" = "json"
) => {
  switch (method) {
    case Method.GET:
      return get(resource, responseType);
    case Method.POST:
      return post(resource, data);
    case Method.PUT:
      return put(resource, data);
    case Method.PATCH:
      return patch(resource, data);
    case Method.DELETE:
      return remove(resource, data);
    default:
      return null;
  }
};

/**
 *
 * @param {*} resource - the API url endpoint
 * @param {*} responseType - blob or json
 * @returns API response using promise
 */
const get = async (resource: string, responseType: "blob" | "json") => {
  try {
    return await axiosInstance.get(resource, { responseType: responseType });
  } catch (error: any) {
    throw new Error(error?.response?.data?.reason || error.message);
  }
};

const post = async (resource: string, data: any) => {
  try {
    return await axiosInstance.post(resource, data);
  } catch (error: any) {
    throw new Error(error?.response?.data?.reason || error.message);
  }
};

const put = async (resource: string, data: any) => {
  try {
    return await axiosInstance.put(resource, data);
  } catch (error: any) {
    throw new Error(error?.response?.data?.reason || error.message);
  }
};

const patch = async (resource: string, data: any) => {
  try {
    return await axiosInstance.patch(resource, data);
  } catch (error: any) {
    throw new Error(error?.response?.data?.reason || error.message);
  }
};

const remove = async (resource: string, data: any) => {
  try {
    return await axiosInstance.delete(resource, data);
  } catch (error: any) {
    throw new Error(error?.response?.data?.reason || error.message);
  }
};
