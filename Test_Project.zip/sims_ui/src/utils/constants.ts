export const BASE_URL = "http://localhost:3100";
export const PLACEHOLDER_IMG_URL =
  "https://images.unsplash.com/photo-1606857521015-7f9fcf423740?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fG9mZmljZXxlbnwwfHwwfHw%3D&w=1000&q=80";
export const IMSI_DIGIT_GREEN = ["262-03", "262-77"];
export const IMSI_DIGIT_BLUE = ["262-07", "262-08", "262-11", "901-85"];
export const ICCID_DIGIT = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
