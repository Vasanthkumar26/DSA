// @ts-nocheck
import { render } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { rest } from "msw";
import { setupServer } from "msw/node";
import { Provider } from "react-redux";
import configureStore from "../redux/store/configureStore";
import { createTheme, ThemeProvider } from "@mui/material";

interface HandlerConfig {
  method?: "get" | "post" | "put" | "patch" | "delete";
  path: string;
  status?: number;
  res: (req, res, ctx) => any;
}

const theme = createTheme();
const store = configureStore();

export const renderWithAllWrappers = (
  component,
  { route = "/", ...renderOptions } = {}
) => {
  const wrapper = ({ children }) => (
    <Provider store={store}>
      <ThemeProvider theme={theme}>
        <MemoryRouter initialEntries={[route]}>{children}</MemoryRouter>
      </ThemeProvider>
    </Provider>
  );
  return render(component, { wrapper, ...renderOptions });
};

export const renderWithReduxThemeWrappers = (
  component,
  { route = "/", ...renderOptions } = {}
) => {
  const wrapper = ({ children }) => (
    <Provider store={store}>
      <ThemeProvider theme={theme}>{children}</ThemeProvider>
    </Provider>
  );
  return render(component, { wrapper, ...renderOptions });
};

export const createServer = (handlersConfig: Array<HandlerConfig>) => {
  const handlers = (handlersConfig ?? []).map((handler) => {
    return rest[handler.method ?? "get"](handler.path, (req, res, ctx) => {
      return res(
        ctx.status(handler.status ?? 200),
        ctx.json(handler.res(req, res, ctx))
      );
    });
  });
  const server = setupServer(...handlers);
  beforeAll(() => server.listen());
  afterEach(() => server.resetHandlers());
  afterAll(() => server.close());

  return server;
};
