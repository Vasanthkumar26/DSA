// @ts-nocheck
import { Method } from "../../models";
import { CoreApi } from "../core";
import { createServer } from "../testUtils";

describe("core", () => {
  const input = [
    {
      id: 1,
      name: "get",
    },
  ];
  const postInput = { id: 2, name: "post" };
  const putInput = { id: 1, name: "put" };
  const patchInput = { id: 1, name: "patch" };

  createServer([
    {
      path: "http://example.com",
      res: () => input,
    },
    {
      method: "post",
      path: "http://example.com",
      res: () => postInput,
    },
    {
      method: "put",
      path: "http://example.com",
      res: () => putInput,
    },
    {
      method: "patch",
      path: "http://example.com",
      res: () => patchInput,
    },
    {
      method: "delete",
      path: "http://example.com",
      res: () => "delete successful",
    },
  ]);
  test("GET", async () => {
    const { data } = await CoreApi(Method.GET, "http://example.com", {});

    expect(data).toStrictEqual(input);
  });

  test("POST", async () => {
    const { data } = await CoreApi(
      Method.POST,
      "http://example.com",
      postInput
    );

    expect(data).toStrictEqual(postInput);
  });

  test("PUT", async () => {
    const { data } = await CoreApi(Method.PUT, "http://example.com", {});

    expect(data).toStrictEqual(putInput);
  });

  test("PATCH", async () => {
    const { data } = await CoreApi(Method.PATCH, "http://example.com", {});

    expect(data).toStrictEqual(patchInput);
  });

  test("DELETE", async () => {
    const { data } = await CoreApi(Method.DELETE, "http://example.com", {});

    expect(data).toBe("delete successful");
  });
});
