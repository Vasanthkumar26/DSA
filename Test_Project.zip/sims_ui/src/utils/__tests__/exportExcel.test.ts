import { handleExport } from "../exportExcel";

const XLSX = require('xlsx');
const fs = require('fs');

describe('handleExport', () => {
  it('should create and save an Excel file', () => {
    // Mock data
    const data = [
      { name: 'John', age: 25 },
      { name: 'Jane', age: 30 },
      { name: 'Bob', age: 35 },
    ];
    const fileName = 'example.xlsx';

    // Call the function
    handleExport(data, fileName);

    // Assert that the file was created and saved
    const fileExists = fs.existsSync(fileName);
    expect(fileExists).toBe(true);

    // Read the file and validate its content
    const workbook = XLSX.readFile(fileName);
    const worksheet = workbook.Sheets[workbook.SheetNames[0]];
    const parsedData = XLSX.utils.sheet_to_json(worksheet);

    expect(parsedData).toEqual(data);

    // Clean up: delete the file
    fs.unlinkSync(fileName);
  });
});
