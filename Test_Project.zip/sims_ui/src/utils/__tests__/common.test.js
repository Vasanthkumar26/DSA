import {
  getNewLangAfterToggle,
  descendingComparator,
  getComparator,
  getCurrentDateAndTime,
  getCurrentSelectedLanguage,
} from "../common";

describe("getNewLangAfterToggle function", () => {
  test('should return "en" if currentLang is "de"', () => {
    expect(getNewLangAfterToggle("de")).toBe("en");
  });

  test('should return "de" if currentLang is not "de"', () => {
    expect(getNewLangAfterToggle("en")).toBe("de");
    expect(getNewLangAfterToggle("fr")).toBe("de");
  });
});

describe("descendingComparator function", () => {
  const a = { name: "John", age: 30 };
  const b = { name: "Jane", age: 25 };

  test("should return -1 if b[orderBy] < a[orderBy]", () => {
    expect(descendingComparator(a, b, "age")).toBe(-1);
    expect(descendingComparator(a, b, "name")).toBe(-1);
  });

  test("should return 1 if b[orderBy] > a[orderBy]", () => {
    expect(descendingComparator(b, a, "age")).toBe(1);
    expect(descendingComparator(b, a, "name")).toBe(1);
  });

  test("should return 0 if b[orderBy] === a[orderBy]", () => {
    expect(descendingComparator(a, a, "age")).toBe(0);
    expect(descendingComparator(a, a, "name")).toBe(0);
  });
});

describe("getComparator function", () => {
  const a = { name: "John", age: 30 };
  const b = { name: "Jane", age: 25 };

  test('should return descending comparator function if order is "desc"', () => {
    const result = getComparator("desc", "age");
    expect(result(a, b)).toBe(-1);
  });

  test('should return ascending comparator function if order is not "desc"', () => {
    const result = getComparator("asc", "name");
    expect(result(a, b)).toBe(1);
  });
});

describe("getCurrentTimeAndDate", () => {
  test("should return the correct dateAndTime", () => {
    const result = getCurrentDateAndTime();
    const date = new Date();
    const dateAndTime = `${date.getFullYear()}-${
      date.getUTCMonth() + 1
    }-${date.getDate()}_${date.getUTCHours()}${date.getUTCMinutes()}${date.getUTCSeconds()}`;
    expect(result).toBe(dateAndTime);
  });
});

describe("getCurrentSelectedLanguage", () => {
  test("should return the current language", () => {
    const result = getCurrentSelectedLanguage();
    expect(result).toBe("de");
  });
});
