import { BASE_URL } from "../constants";

describe("constants", () => {
  test("should export constants", () => {
    expect(BASE_URL).toEqual("http://localhost:3100");
  });
});
