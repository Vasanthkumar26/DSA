// @ts-nocheck
import { createTheme } from "@mui/material/styles";

export const simsTheme = createTheme({
  components: {
    MuiFormLabel: {
      styleOverrides: {
        asterisk: { color: "#db3131" },
        root: { paddingLeft: "3px" }
      }
    },
    MuiFormHelperText: {
      styleOverrides: {
        root: {
          color: "#db3131"
        }
      }
    },
    MuiInputBase: {
      styleOverrides: {
        root: {
          backgroundColor: "#ffffff"
        }
      }
    },
    MuiSnackbar: {
      variants: [
        {
          props: { variant: "error" },
          style: {
            "& .MuiSnackbarContent-root": {
              background: "#db3131"
            }
          }
        }
      ]
    },
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: "none"
        }
      }
    }
  }
});
