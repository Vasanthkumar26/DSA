import "@testing-library/jest-dom";
import App from "./App";
import { renderWithAllWrappers } from "./utils/testUtils";

describe("App", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<App />);
    expect(container).toBeInTheDocument();
  });
});
