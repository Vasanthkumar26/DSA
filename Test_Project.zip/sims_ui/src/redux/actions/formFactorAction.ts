import { Dispatch } from "redux";
import { FormFactorActionTypes } from "./types";
import {
  FormFactorPayload,
  FormFactorAction,
  FormFactor
} from "../../models/formFactor.model";
import {
  handleArchiveFormFactor,
  handleDeleteFormFactor,
  handleFetchFormFactor,
  handleFormFactorCreate,
  handleFormFactorExport,
  handleFormFactorUpdate
} from "../../services/FormFactorApi";

export const fetchFormFactor =
  (isArchive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.FETCH_FORM_FACTOR_REQUEST
      });
      const formFactor = await handleFetchFormFactor(isArchive);
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.FETCH_FORM_FACTOR_SUCCESS,
        payload: formFactor
      });
    } catch (error: any) {
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.FETCH_FORM_FACTOR_FAILURE,
        payload: error
      });
    }
  };

export const setSelectedFormFactor =
  (data: FormFactor | null) => async (dispatch: Dispatch) => {
    dispatch<FormFactorAction>({
      type: FormFactorActionTypes.SET_SELECTED_FORM_FACTOR,
      payload: data
    });
  };

export const createFormFactor =
  (data: FormFactorPayload) => async (dispatch: Dispatch) => {
    try {
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.CREATE_FORM_FACTOR_REQUEST
      });
      await handleFormFactorCreate(data);
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.CREATE_FORM_FACTOR_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.CREATE_FORM_FACTOR_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };
export const updateFormFactor =
  (data: FormFactorPayload, id: string) => async (dispatch: Dispatch) => {
    try {
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.UPDATE_FORM_FACTOR_REQUEST
      });
      await handleFormFactorUpdate(data, id);
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.UPDATE_FORM_FACTOR_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.UPDATE_FORM_FACTOR_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const resetFormFactorErr = () => async (dispatch: Dispatch) => {
  dispatch<FormFactorAction>({
    type: FormFactorActionTypes.RESET_FORMFACTOR_ERR
  });
};

export const deleteFormFactor =
  (formFactorId: number) => async (dispatch: Dispatch) => {
    try {
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.DELETE_SELECTED_FORM_FACTOR_REQUEST
      });
      const response = await handleDeleteFormFactor(formFactorId);
      if (response) {
        dispatch<FormFactorAction>({
          type: FormFactorActionTypes.DELETE_SELECTED_FORM_FACTOR_SUCCESS,
          payload: formFactorId
        });
      }
    } catch (error: any) {
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.DELETE_SELECTED_FORM_FACTOR_FAILURE,
        payload: "Sorry! Request failed, please try again." || error?.message
      });
    }
  };

export const archiveFormFactor =
  (id: number, archive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.ARCHIVE_SELECTED_FORM_FACTOR_REQUEST
      });
      const response = await handleArchiveFormFactor(id, archive);
      if (response) {
        dispatch<FormFactorAction>({
          type: FormFactorActionTypes.ARCHIVE_SELECTED_FORM_FACTOR_SUCCESS,
          payload: { id: id, archive: archive }
        });
      }
    } catch (error: any) {
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.ARCHIVE_SELECTED_FORM_FACTOR_FAILURE,
        payload: error
      });
    }
  };

export const fetchFormFactorExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.FETCH_FORM_FACTOR_EXPORT_REQUEST
      });
      const response = await handleFormFactorExport(isArchived);
      if (response) {
        dispatch<FormFactorAction>({
          type: FormFactorActionTypes.FETCH_FORM_FACTOR_EXPORT_SUCCESS,
          payload: response
        });
      }
    } catch (error: any) {
      dispatch<FormFactorAction>({
        type: FormFactorActionTypes.FETCH_FORM_FACTOR_EXPORT_FAILURE,
        payload: error?.message
      });
    }
  };

export const resetFormFactor = () => async (dispatch: Dispatch) => {
  dispatch<FormFactorAction>({
    type: FormFactorActionTypes.RESET_FORM_FACTOR
  });
};
