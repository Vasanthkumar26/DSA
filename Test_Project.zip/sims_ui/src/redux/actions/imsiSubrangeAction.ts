import { Dispatch } from "redux";
import { ImsiSubrange, ImsiSubrangeAction } from "../../models";
import { ImsiSubrangeActionTypes } from "./types";
import { ImsiSubAndMainRangeStatusRequestPayload } from "../../models/global.model";
import {
  handleFetchImsiSubranges,
  handleDeleteImsiSubrange,
  handleArchiveImsiSubrange,
  handleIMSISubrangeExport,
  handleFetchMainRangesProductType,
  handleCreateImsiSubrange,
  handleUpdateImsiSubrange,
  handleFetchIMSISubrangeStatusTable
} from "../../services/ImsiSubrangeApi";

export const setSelectedImsiSubrange =
  (imsiSubranges: ImsiSubrange | null) => (dispatch: Dispatch) => {
    dispatch<ImsiSubrangeAction>({
      type: ImsiSubrangeActionTypes.SET_SELECTED_IMSI_SUBRANGE,
      payload: imsiSubranges
    });
  };

export const fetchImsiSubranges =
  (isArchive: boolean, predefinedImsiMainRange: string, showArchived: string) =>
  async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_REQUEST
      });
      const imsiSubranges = await handleFetchImsiSubranges(
        isArchive,
        predefinedImsiMainRange,
        showArchived
      );
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_SUCCESS,
        payload: imsiSubranges
      });
    } catch (error: any) {
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_FAILURE,
        payload: error
      });
    }
  };

export const fetchMainRangeProductType = () => async (dispatch: Dispatch) => {
  try {
    dispatch<ImsiSubrangeAction>({
      type: ImsiSubrangeActionTypes.FETCH_DDL_DATA_REQUEST
    });
    const response = await handleFetchMainRangesProductType();
    dispatch<ImsiSubrangeAction>({
      type: ImsiSubrangeActionTypes.FETCH_DDL_DATA_SUCCESS,
      payload: response
    });
  } catch (error: any) {
    dispatch<ImsiSubrangeAction>({
      type: ImsiSubrangeActionTypes.FETCH_DDL_DATA_ERROR,
      payload: error
    });
  }
};

export const createImsiSubrange =
  (data: ImsiSubrange) => async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.CREATE_REQUEST
      });
      await handleCreateImsiSubrange(data);

      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.CREATE_SUCCESS,
        payload: { data, message: "success" }
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.CREATE_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const updateImsiSubrange =
  (data: ImsiSubrange, id: string) => async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.CREATE_REQUEST
      });

      await handleUpdateImsiSubrange(data, id);

      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.CREATE_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.CREATE_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const resetImsiSubrangeError = () => async (dispatch: Dispatch) => {
  dispatch<ImsiSubrangeAction>({
    type: ImsiSubrangeActionTypes.RESET_ERROR
  });
};

export const resetImsiSubrangeForm = () => async (dispatch: Dispatch) => {
  dispatch<ImsiSubrangeAction>({
    type: ImsiSubrangeActionTypes.RESET_FORM
  });
};

export const archiveImsiSubRange =
  (imsiId: number, archive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.ARCHIVE_IMSI_SUBRANGE_REQUEST
      });
      await handleArchiveImsiSubrange(imsiId, archive);
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.ARCHIVE_IMSI_SUBRANGE_SUCCESS,
        payload: { imsiId: imsiId, archive: archive }
      });
    } catch (error: any) {
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.ARCHIVE_IMSI_SUBRANGE_FAILURE,
        payload: error
      });
    }
  };

export const deleteImsiSubrange =
  (imsiId: number) => async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.DELETE_IMSI_SUBRANGE_REQUEST
      });
      const response = await handleDeleteImsiSubrange(imsiId);
      if (response) {
        dispatch<ImsiSubrangeAction>({
          type: ImsiSubrangeActionTypes.DELETE_IMSI_SUBRANGE_SUCCESS,
          payload: imsiId
        });
      }
    } catch (error: any) {
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.DELETE_IMSI_SUBRANGE_FAILURE,
        payload: error
      });
    }
  };

export const fetchImsiSubrangeExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_REQUEST
      });
      const reponse = await handleIMSISubrangeExport(isArchived);
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_SUCCESS,
        payload: reponse
      });
    } catch (error: any) {
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_FAILURE,
        payload: error?.message
      });
    }
  };

export const fetchImsiSubrangeStatusTable =
  (payload: ImsiSubAndMainRangeStatusRequestPayload) =>
  async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_STATUS_REQUEST
      });
      const response = await handleFetchIMSISubrangeStatusTable(payload);
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_STATUS_SUCCESS,
        payload: response
      });
    } catch (err: any) {
      dispatch<ImsiSubrangeAction>({
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_STATUS_FAILURE,
        payload: err?.message
      });
    }
  };

export const resetImsiSubrange = () => async (dispatch: Dispatch) => {
  dispatch<ImsiSubrangeAction>({
    type: ImsiSubrangeActionTypes.RESET_IMSI_SUBRANGE
  });
};
