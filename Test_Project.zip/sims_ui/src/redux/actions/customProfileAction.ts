import { Dispatch } from "redux";
import {
  CustomProfile,
  CustomProfileAction
} from "../../models/customProfile.model";
import { CustomProfileActionTypes } from "./types";
import {
  handleCustomProfileCreate,
  handleCustomProfileUpdate,
  handleDeleteCustomProfile,
  handleFetchCustomProfile,
  handleCustomProfileExport,
  handleArchiveCustomProfile
} from "../../services/customProfileApi";

export const fetchCustomProfiles =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.FETCH_CUSTOM_PROFILE_REQUEST
      });

      const response = await handleFetchCustomProfile(isArchived);
      if (response) {
        dispatch<CustomProfileAction>({
          type: CustomProfileActionTypes.FETCH_CUSTOM_PROFILE_SUCCESS,
          payload: response
        });
      }
    } catch (error: any) {
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.FETCH_CUSTOM_PROFILE_FAILURE
      });
    }
  };

export const setSelectedCustomProfile =
  (data: CustomProfile | null) => async (dispatch: Dispatch) => {
    dispatch<CustomProfileAction>({
      type: CustomProfileActionTypes.SET_SELECTED_CUSTOM_PROFILE,
      payload: data
    });
  };

export const createCustomProfile =
  (data: FormData) => async (dispatch: Dispatch) => {
    try {
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.CREATE_CUSTOM_PROFILE_REQUEST
      });
      await handleCustomProfileCreate(data);
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.CREATE_CUSTOM_PROFILE_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.CREATE_CUSTOM_PROFILE_FAILURE,
        payload: errMsg
      });
    }
  };

export const updateCustomProfile =
  (data: FormData) => async (dispatch: Dispatch) => {
    try {
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.UPDATE_CUSTOM_PROFILE_REQUEST
      });
      await handleCustomProfileUpdate(data);
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.UPDATE_CUSTOM_PROFILE_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.UPDATE_CUSTOM_PROFILE_FAILURE,
        payload: errMsg
      });
    }
  };

export const deleteCustomProfile =
  (id: number) => async (dispatch: Dispatch) => {
    try {
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.DELETE_CUSTOM_PROFILE_REQUEST
      });
      const response = await handleDeleteCustomProfile(id);
      if (response) {
        dispatch<CustomProfileAction>({
          type: CustomProfileActionTypes.DELETE_CUSTOM_PROFILE_SUCCESS,
          payload: id
        });
      }
    } catch (error: any) {
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.DELETE_CUSTOM_PROFILE_FAILURE,
        payload: "Sorry! Request failed, please try again." || error?.message
      });
    }
  };

export const archiveCustomProfile =
  (id: number, archive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.ARCHIVE_CUSTOM_PROFILE_REQUEST
      });
      const response = await handleArchiveCustomProfile(id, archive);
      if (response) {
        dispatch<CustomProfileAction>({
          type: CustomProfileActionTypes.ARCHIVE_CUSTOM_PROFILE_SUCCESS,
          payload: { id: id, archive: archive }
        });
      }
    } catch (error: any) {
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.ARCHIVE_CUSTOM_PROFILE_FAILURE,
        payload: error
      });
    }
  };
export const fetchCustomProfilerExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.EXPORT_CUSTOM_PROFILE_REQUEST
      });
      const response = await handleCustomProfileExport(isArchived);
      if (response) {
        dispatch<CustomProfileAction>({
          type: CustomProfileActionTypes.EXPORT_CUSTOM_PROFILE_SUCCESS,
          payload: response
        });
      }
    } catch (error: any) {
      dispatch<CustomProfileAction>({
        type: CustomProfileActionTypes.EXPORT_CUSTOM_PROFILE_FAILURE,
        payload: error?.message
      });
    }
  };

export const resetCustomProfile = () => async (dispatch: Dispatch) => {
  dispatch<CustomProfileAction>({
    type: CustomProfileActionTypes.RESET_CUSTOM_PROFILE
  });
};
