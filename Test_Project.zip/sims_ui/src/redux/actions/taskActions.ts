import { Dispatch } from "redux";
import { TaskActionTypes } from "./types";
import { TaskAction } from "../../models/task.model";
import {
  handleFetchTasks,
  handleDownload,
  handleDeleteTask,
  handleFetchOrders
} from "../../services/TasksApi";

export const fetchOrders = () => async (dispatch: Dispatch) => {
  try {
    dispatch<TaskAction>({ type: TaskActionTypes.FETCH_ORDER_REQUEST });
    const orders = await handleFetchOrders();
    dispatch<TaskAction>({
      type: TaskActionTypes.FETCH_ORDER_SUCCESS,
      payload: orders
    });
  } catch (error: any) {
    dispatch<TaskAction>({
      type: TaskActionTypes.FETCH_ORDER_FAILURE,
      payload: error
    });
  }
};

export const fetchTasks =
  (isArchive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<TaskAction>({ type: TaskActionTypes.FETCH_TASK_REQUEST });
      const tasks = await handleFetchTasks(isArchive);
      dispatch<TaskAction>({
        type: TaskActionTypes.FETCH_TASK_SUCCESS,
        payload: tasks
      });
    } catch (error: any) {
      dispatch<TaskAction>({
        type: TaskActionTypes.FETCH_TASK_FAILURE,
        payload: error
      });
    }
  };

export const downlaodTask =
  (archiveId: string, fileExtension: string) => async (dispatch: Dispatch) => {
    try {
      dispatch<TaskAction>({
        type: TaskActionTypes.DOWNLOAD_TASK_REQUEST
      });
      const response = await handleDownload(archiveId, fileExtension);
      dispatch<TaskAction>({
        type: TaskActionTypes.DOWNLOAD_TASK_SUCCESS,
        payload: response
      });
    } catch (error: any) {
      dispatch<TaskAction>({
        type: TaskActionTypes.DOWNLOAD_TASK_ERROR,
        payload: error?.message
      });
    }
  };

export const deleteTask = (Id: number) => async (dispatch: Dispatch) => {
  try {
    dispatch<TaskAction>({
      type: TaskActionTypes.DELETE_TASK_REQUEST
    });
    const response = await handleDeleteTask(Id);
    if (response) {
      dispatch<TaskAction>({
        type: TaskActionTypes.DELETE_TASK_SUCCESS,
        payload: Id
      });
    }
  } catch (error: any) {
    dispatch<TaskAction>({
      type: TaskActionTypes.DELETE_TASK_FAILURE,
      payload: "Sorry! Request failed, please try again." || error?.message
    });
  }
};
