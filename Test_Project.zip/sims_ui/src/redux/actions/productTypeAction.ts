import { Dispatch } from "redux";
import {
  ProductTypeData,
  ProductTypeAction,
  productTypePayload,
  productTypeUpdatePayload
} from "../../models";
import { ProductTypeActionTypes } from "./types";
import {
  handleDeleteProductType,
  handleFetchProductType,
  handleProductTypeCreate,
  handleProductTypeUpdate,
  handleProductTypesExport,
  handleArchiveProductType,
  loadAssignedImsiSubRanges,
  loadAllImsiSubRanges
} from "../../services/productTypeApi";

export const setSelectedProductType =
  (productType: ProductTypeData | null) => (dispatch: Dispatch) => {
    dispatch<ProductTypeAction>({
      type: ProductTypeActionTypes.SET_SELECTED_PRODUCT_TYPE,
      payload: productType
    });
  };

export const fetchProductType =
  (isArchive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.FETCH_PRODUCT_TYPE_REQUEST
      });
      const productType = await handleFetchProductType(isArchive);
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.FETCH_PRODUCT_TYPE_SUCCESS,
        payload: productType
      });
    } catch (error: any) {
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.FETCH_PRODUCT_TYPE_FAILURE,
        payload: error?.message
      });
    }
  };

export const fetchProductTypesExport =
  (isArchived: boolean) => async (dispatch: Dispatch<ProductTypeAction>) => {
    try {
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.FETCH_PRODUCT_TYPES_EXPORT_REQUEST
      });
      const response = await handleProductTypesExport(isArchived);
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.FETCH_PRODUCT_TYPES_EXPORT_SUCCESS,
        payload: response
      });
    } catch (err: any) {
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.FETCH_PRODUCT_TYPES_EXPORT_FAILURE,
        payload: err
      });
    }
  };

export const deleteProductType = (Id: number) => async (dispatch: Dispatch) => {
  try {
    dispatch<ProductTypeAction>({
      type: ProductTypeActionTypes.PRODUCT_TYPE_DELETE_REQUEST
    });
    const response = await handleDeleteProductType(Id);
    if (response) {
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.PRODUCT_TYPE_DELETE_SUCCESS,
        payload: Id
      });
    }
  } catch (error: any) {
    dispatch<ProductTypeAction>({
      type: ProductTypeActionTypes.PRODUCT_TYPE_DELETE_FAILURE,
      payload: "Sorry! Request failed, please try again." || error?.message
    });
  }
};

export const createProductType =
  (data: productTypePayload) =>
  async (dispatch: Dispatch<ProductTypeAction>) => {
    try {
      dispatch({
        type: ProductTypeActionTypes.CREATE_PRODUCT_TYPE_REQUEST
      });
      await handleProductTypeCreate(data);
      dispatch({
        type: ProductTypeActionTypes.CREATE_PRODUCT_TYPE_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.reason || "Sorry! Create Request failed, please try again.";
      dispatch({
        type: ProductTypeActionTypes.CREATE_PRODUCT_TYPE_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const updateProductType =
  (data: productTypeUpdatePayload) =>
  async (dispatch: Dispatch<ProductTypeAction>) => {
    try {
      dispatch({
        type: ProductTypeActionTypes.UPDATE_PRODUCT_TYPE_REQUEST
      });
      await handleProductTypeUpdate(data);
      dispatch({
        type: ProductTypeActionTypes.UPDATE_PRODUCT_TYPE_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.reason || "Sorry! Update Request failed, please try again.";
      dispatch({
        type: ProductTypeActionTypes.UPDATE_PRODUCT_TYPE_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const resetProductType = () => async (dispatch: Dispatch) => {
  dispatch<ProductTypeAction>({
    type: ProductTypeActionTypes.RESET_PRODUCT_TYPE
  });
};

export const archiveProductType =
  (id: number, archive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.ARCHIVE_PRODUCT_TYPE_REQUEST
      });
      const response = await handleArchiveProductType(id, archive);
      if (response) {
        dispatch<ProductTypeAction>({
          type: ProductTypeActionTypes.ARCHIVE_PRODUCT_TYPE_SUCCESS,
          payload: archive ? "Successfully Archived" : "Successfully Activated"
        });
      }
    } catch (error: any) {
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.ARCHIVE_PRODUCT_TYPE_FAILURE,
        payload: error
      });
    }
  };

export const fetchAssignedImsiSubRanges =
  (productId: number) => async (dispatch: Dispatch) => {
    try {
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.FETCH_ASSIGNED_IMSI_SUBRANGES_REQUEST
      });
      const response = await loadAssignedImsiSubRanges(productId);
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.FETCH_ASSIGNED_IMSI_SUBRANGES_SUCCESS,
        payload: response
      });
    } catch (error: any) {
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.FETCH_ASSIGNED_IMSI_SUBRANGES_FAILURE,
        payload: error
      });
    }
  };

export const fetchAllImsiSubRanges =
  (greenIcicd: boolean, serviceProviderId: number) =>
  async (dispatch: Dispatch) => {
    try {
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.FETCH_ALL_IMSI_SUBRANGES_REQUEST
      });
      const response = await loadAllImsiSubRanges(
        greenIcicd,
        serviceProviderId
      );
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.FETCH_ALL_IMSI_SUBRANGES_SUCCESS,
        payload: response
      });
    } catch (error: any) {
      dispatch<ProductTypeAction>({
        type: ProductTypeActionTypes.FETCH_ALL_IMSI_SUBRANGES_FAILURE,
        payload: error
      });
    }
  };
