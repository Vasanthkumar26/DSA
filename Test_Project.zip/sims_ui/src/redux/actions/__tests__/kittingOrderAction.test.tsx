//@ts-nocheck
import {
  KittingOrder_Failure_API_HANDLERS,
  KittingOrder_SUCCESS_API_HANDLERS
} from "../../../_mocks_/kittingOrderApiHandlers";
import { createServer } from "../../../utils/testUtils";
import { initialState } from "../../reducers/kittingOrderReducer";
import { store } from "../../store";
import {
  createkittingOrderManual,
  resetKittingOrderState
} from "../kittingOrderAction";

describe("kitting order action test", () => {
  const payload: KittingOrderPayload = {
    orderNumber: 1,
    kittingArticleNumber: 22,
    noOfSimCard: 49,
    orderDate: "Wed Aug 09 2023 13:49:09 GMT+0530 (India Standard Time)",
    deliveryDate: "Wed Aug 09 2023 13:49:09 GMT+0530 (India Standard Time)"
  };
  describe("success action", () => {
    createServer(KittingOrder_SUCCESS_API_HANDLERS);

    test("should dispath correct action for create", async () => {
      await store.dispatch(createkittingOrderManual(payload));
      expect(store.getState().kittingOrder.successCreate).toBe("Successfull");
    });
    test("should dispaptch correct action for setKittingOrder", async () => {
      await store.dispatch(resetKittingOrderState());
      expect(store.getState().kittingOrder).toStrictEqual(initialState);
    });
  });

  describe("Failure action", () => {
    createServer(KittingOrder_Failure_API_HANDLERS);
    test("should dispatch the failed action", async () => {
      await store.dispatch(createkittingOrderManual(payload));
      expect(store.getState().kittingOrder.errorCreate).toBe(
        "Request failed with status code 400"
      );
    });
  });
});
