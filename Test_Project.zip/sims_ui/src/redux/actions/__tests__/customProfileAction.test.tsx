//@ts-nocheck

import {
  CustomProfile_FAILURE_API_HANDLERS,
  CustomProfile_SUCCESS_API_HANDLERS,
  customProfileData
} from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import {
  fetchCustomProfiles,
  setSelectedCustomProfile
} from "../customProfileAction";

describe("CustomProfileAction test", () => {
  describe("SUCCESS ACTION", () => {
    createServer(CustomProfile_SUCCESS_API_HANDLERS);

    test("should dispatch the correct action for fetch", async () => {
      await store.dispatch(fetchCustomProfiles(true));
      expect(store.getState().customProfile.customProfiles).toHaveLength(2);
    });

    test("shoudl change state for selectedCustomProfile", async () => {
      await store.dispatch(setSelectedCustomProfile(customProfileData[0]));
      expect(store.getState().customProfile.selectedCustomProfile).toEqual(
        customProfileData[0]
      );
    });
  });

  describe("FAILURE ACTION", () => {
    createServer(CustomProfile_FAILURE_API_HANDLERS);

    test("Should change the state if there is api failure", async () => {
      await store.dispatch(fetchCustomProfiles(true));
      expect(store.getState().customProfile.isLoadingFetch).toBe(false);
    });
  });
});
