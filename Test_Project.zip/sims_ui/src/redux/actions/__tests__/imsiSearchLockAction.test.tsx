// @ts-nocheck
import { ISL_SUCCESS_API_HANDLERS } from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import { fetchImsiRanges } from "../imsiSearchLockAction";

describe("imsiSearchLockAction", () => {
  createServer(ISL_SUCCESS_API_HANDLERS);

  test("Should dispatch correct action for fetchImsiRanges", async () => {
    await store.dispatch(fetchImsiRanges());

    expect(store.getState().imsiSearchLock.imsiRanges).toHaveLength(1);
  });
});
