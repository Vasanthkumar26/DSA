import {
  LanguageActionType,
  FETCH_KITTING_ARTICLES_REQUEST,
  FETCH_KITTING_ARTICLES_SUCCESS,
  FETCH_KITTING_ARTICLES_FAILURE,
  SET_SELECTED_KITTING_ARTICLE,
  FETCH_KITTING_ARTICLES_EXPORT_REQUEST,
  FETCH_KITTING_ARTICLES_EXPORT_SUCCESS,
  FETCH_KITTING_ARTICLES_EXPORT_FAILURE,
  ARCHIVE_KITTING_ARTICLES_REQUEST,
  ARCHIVE_KITTING_ARTICLES_SUCCESS,
  ARCHIVE_KITTING_ARTICLES_FAILURE,
  AuthActionTypes,
  HlrActionTypes,
  ImsiMainrangeActionTypes,
  ImsiSubrangeActionTypes,
  SimVendorActionTypes,
} from "../types";

describe("constants", () => {
  test("should export the Auth constants", () => {
    expect(AuthActionTypes.LOGIN_REQUEST).toEqual("LOGIN_REQUEST");
    expect(AuthActionTypes.LOGIN_SUCCESS).toEqual("LOGIN_SUCCESS");
    expect(AuthActionTypes.LOGIN_FAILURE).toEqual("LOGIN_FAILURE");
    expect(AuthActionTypes.LOGOUT_REQUEST).toEqual("LOGOUT_REQUEST");
    expect(AuthActionTypes.LOGOUT_SUCCESS).toEqual("LOGOUT_SUCCESS");
    expect(AuthActionTypes.LOGOUT_FAILURE).toEqual("LOGOUT_FAILURE");
  });

  test("should export the Language constants", () => {
    expect(LanguageActionType.TOGGLE_LANGUAGE).toEqual("TOGGLE_LANGUAGE");
  });

  test("should export the Kitting Article constants", () => {
    expect(FETCH_KITTING_ARTICLES_REQUEST).toEqual(
      "FETCH_KITTING_ARTICLES_REQUEST"
    );
    expect(FETCH_KITTING_ARTICLES_SUCCESS).toEqual(
      "FETCH_KITTING_ARTICLES_SUCCESS"
    );
    expect(FETCH_KITTING_ARTICLES_FAILURE).toEqual(
      "FETCH_KITTING_ARTICLES_FAILURE"
    );
    expect(SET_SELECTED_KITTING_ARTICLE).toEqual(
      "SET_SELECTED_KITTING_ARTICLE"
    );
    expect(FETCH_KITTING_ARTICLES_EXPORT_REQUEST).toEqual(
      "FETCH_KITTING_ARTICLES_EXPORT_REQUEST"
    );
    expect(FETCH_KITTING_ARTICLES_EXPORT_SUCCESS).toEqual(
      "FETCH_KITTING_ARTICLES_EXPORT_SUCCESS"
    );
    expect(FETCH_KITTING_ARTICLES_EXPORT_FAILURE).toEqual(
      "FETCH_KITTING_ARTICLES_EXPORT_FAILURE"
    );
    expect(ARCHIVE_KITTING_ARTICLES_REQUEST).toEqual(
      "ARCHIVE_KITTING_ARTICLES_REQUEST"
    );
    expect(ARCHIVE_KITTING_ARTICLES_SUCCESS).toEqual(
      "ARCHIVE_KITTING_ARTICLES_SUCCESS"
    );
    expect(ARCHIVE_KITTING_ARTICLES_FAILURE).toEqual(
      "ARCHIVE_KITTING_ARTICLES_FAILURE"
    );
  });

  test("should export the HLR contants", () => {
    expect(HlrActionTypes.FETCH_HLR_EXPORT_SUCCESS).toEqual(
      "FETCH_HLR_EXPORT_SUCCESS"
    );
    expect(HlrActionTypes.FETCH_HLR_EXPORT_REQUEST).toEqual(
      "FETCH_HLR_EXPORT_REQUEST"
    );
    expect(HlrActionTypes.FETCH_HLR_EXPORT_FAILURE).toEqual(
      "FETCH_HLR_EXPORT_FAILURE"
    );
  });

  test("should export the ImsiMainrange constants", () => {
    expect(
      ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_FAILURE
    ).toEqual("FETCH_IMSI_MAINRANGE_EXPORT_FAILURE");
    expect(
      ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_REQUEST
    ).toEqual("FETCH_IMSI_MAINRANGE_EXPORT_REQUEST");
    expect(
      ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_SUCCESS
    ).toEqual("FETCH_IMSI_MAINRANGE_EXPORT_SUCCESS");
  });

  test("should export the ImsiSubRange constants", () => {
    expect(ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_REQUEST).toEqual(
      "FETCH_IMSI_SUBRANGE_EXPORT_REQUEST"
    );
    expect(ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_SUCCESS).toEqual(
      "FETCH_IMSI_SUBRANGE_EXPORT_SUCCESS"
    );
    expect(ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_FAILURE).toEqual(
      "FETCH_IMSI_SUBRANGE_EXPORT_FAILURE"
    );
  });

  test("should export the SimVendor constants", () => {
    expect(SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_ERROR).toEqual(
      "FETCH_SIM_VENDOR_EXPORT_ERROR"
    );
    expect(SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_REQUEST).toEqual(
      "FETCH_SIM_VENDOR_EXPORT_REQUEST"
    );
    expect(SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_SUCCESS).toEqual(
      "FETCH_SIM_VENDOR_EXPORT_SUCCESS"
    );
  });
});
