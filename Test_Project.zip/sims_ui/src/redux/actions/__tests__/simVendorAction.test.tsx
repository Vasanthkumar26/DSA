// @ts-nocheck
import {
  SV_FAILURE_API_HANDLERS,
  SV_SUCCESS_API_HANDLERS
} from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import {
  fetchSimVendorExport,
  fetchSimVendors,
  createSimVendor,
  updateSimVendor,
  deleteSimVendor
} from "../simVendorAction";

describe("simVendorAction", () => {
  createServer(SV_SUCCESS_API_HANDLERS);

  test("Should dispatch correct action for fetch", async () => {
    await store.dispatch(fetchSimVendors(true));

    expect(store.getState().simVendor.simVendros).toHaveLength(1);
  });

  test("should dispatch the correct actions", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    await store.dispatch(fetchSimVendorExport(true));
    expect(store.getState().simVendor.exportSuccessMsg).toEqual("successful");
  });

  test("Should dispatch correct action for create", async () => {
    await store.dispatch(createSimVendor({ payload: "dummy" }));

    expect(store.getState().simVendor.isLoadingCreate).toBeFalsy();
  });

  test("Should dispatch correct action for update", async () => {
    await store.dispatch(updateSimVendor({ payload: "dummy" }, "testId"));

    expect(store.getState().simVendor.isLoadingUpdate).toBeFalsy();
  });

  test("Should dispatch correct delete actions", async () => {
    // @ts-ignore
    await store.dispatch(deleteSimVendor(123));
    expect(store.getState().simVendor.deleteSuccessMsgFlag).toEqual(true);
  });
});

describe("simVendorAction export failure", () => {
  createServer(SV_FAILURE_API_HANDLERS);

  test("Should dispatch correct action for fetch when api failed", async () => {
    await store.dispatch(fetchSimVendors(true));

    expect(store.getState().simVendor.isLoadingFetch).toBeFalsy();
  });

  test("should dispatch the correct action failure", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    await store.dispatch(fetchSimVendorExport(true));
    expect(store.getState().simVendor.errorExport).toEqual(
      "Request failed with status code 404"
    );
  });
  test("Should dispatch correct action for create", async () => {
    // eslint-disable-next-line jest/valid-expect
    expect(
      store.dispatch(createSimVendor({ payload: "dummy" }))
    ).rejects.toThrowError();
  });

  test("Should dispatch correct action for update", async () => {
    // eslint-disable-next-line jest/valid-expect
    expect(
      store.dispatch(updateSimVendor({ payload: "dummy" }))
    ).rejects.toThrowError();
  });

  test("Should dispatch correct delete actions", async () => {
    // @ts-ignore
    await store.dispatch(deleteSimVendor(123));
    expect(store.getState().simVendor.deleteErrorMsg).toEqual(
      "Sorry! Request failed, please try again."
    );
  });
});
