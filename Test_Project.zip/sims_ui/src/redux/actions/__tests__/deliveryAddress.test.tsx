// @ts-nocheck
import {
  DeliveryAddress_SUCCESS_API_HANDLERS,
  DeliveryAddress_FAILURE_API_HANDLERS,
  deliverAddress
} from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import {
  fetchDeliverAddresses,
  fetchDeliveryAddressExport,
  deleteDeliveryAddress,
  createDeliveryAddress,
  updateDeliveryAddress
} from "../deliveryAddressAction";
jest.setTimeout(10000);

describe.skip("deliveryAddress Action test", () => {
  describe("Success Action", () => {
    createServer(DeliveryAddress_SUCCESS_API_HANDLERS);

    test("should dispatch correct action for fetch delivery Address", async () => {
      await store.dispatch(fetchDeliverAddresses(true));
      expect(store.getState().deliverAddress.deliveryAddresses).toEqual(
        deliverAddress
      );
    });

    test("Should dispatch the correct action for export", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();

      await store.dispatch(fetchDeliveryAddressExport(true));
      expect(store.getState().deliverAddress.exportSuccessMsg).toEqual(
        "successful"
      );
    });

    test("Should dispatch correct action for create", async () => {
      await store.dispatch(createDeliveryAddress({ payload: "dummy" }));

      expect(store.getState().deliverAddress.isLoadingCreate).toBeFalsy();
    });

    test("Should dispatch correct action for update", async () => {
      await store.dispatch(
        updateDeliveryAddress({ payload: "dummy" }, "testId")
      );

      expect(store.getState().deliverAddress.isLoadingUpdate).toBeFalsy();
    });

    test("Should dispatch correct actions", async () => {
      // @ts-ignore
      await store.dispatch(deleteDeliveryAddress(123));
      expect(store.getState().deliverAddress.deleteSuccessMsgFlag).toEqual(
        true
      );
    });
  });

  describe.skip("Failure Action", () => {
    createServer(DeliveryAddress_FAILURE_API_HANDLERS);

    test("should dispatch correct action if there is api failure", async () => {
      await store.dispatch(fetchDeliverAddresses(true));
      expect(store.getState().deliverAddress.isLoadingFetch).toBeFalsy();
    });
    test("should show the error message if there is failure", async () => {
      await store.dispatch(fetchDeliverAddresses(true));
      expect(store.getState().deliverAddress.errorFetch).toEqual(
        "Error: Network Error"
      );
    });

    test("should dispatch the correct action when export api is failed", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      await store.dispatch(fetchDeliveryAddressExport(true));
      expect(store.getState().deliverAddress.errorExport).toEqual(
        "Network Error"
      );
    });

    test("Should dispatch correct action for create", async () => {
      // eslint-disable-next-line jest/valid-expect
      expect(
        store.dispatch(createDeliveryAddress({ payload: "dummy" }))
      ).rejects.toThrowError();
    });

    test("Should dispatch correct action for update", async () => {
      // eslint-disable-next-line jest/valid-expect
      expect(
        store.dispatch(updateDeliveryAddress({ payload: "dummy" }))
      ).rejects.toThrowError();
    });

    test("Should dispatch correct actions", async () => {
      // @ts-ignore
      await store.dispatch(deleteDeliveryAddress(123));
      expect(store.getState().deliverAddress.deleteErrorMsg).toEqual(
        "Sorry! Request failed, please try again."
      );
    });
  });
});
