// @ts-nocheck
import { PRODUCT_TYPE_SUCCESS_HANDLERS } from "../../../_mocks_";
import {
  PRODUCT_TYPE_FAILURE_HANDLERS,
  productTypeDataMock
} from "../../../_mocks_/productTypesApiHandlers";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import {
  createProductType,
  fetchProductType,
  updateProductType
} from "../productTypeAction";

describe("product Type Action", () => {
  describe("SUCCESS", () => {
    createServer(PRODUCT_TYPE_SUCCESS_HANDLERS);

    test("Should dispatch correct action for create", async () => {
      await store.dispatch(createProductType({ payload: "dummy" }));

      expect(store.getState().productType.isCreating).toBeFalsy();
    });

    test("Should dispatch correct action for update", async () => {
      await store.dispatch(updateProductType({ payload: "dummy" }, "testId"));

      expect(store.getState().productType.isUpdating).toBeFalsy();
    });

    test("Should modify the correct state for table load", async () => {
      await store.dispatch(fetchProductType(true));
      expect(store.getState().productType.productTypes).toEqual(
        productTypeDataMock
      );
    });
  });

  describe("FAILURE", () => {
    createServer(PRODUCT_TYPE_FAILURE_HANDLERS);

    test("Should modify the state for failure message", async () => {
      await store.dispatch(fetchProductType(true));
      expect(store.getState().productType.errorFetch).toEqual(
        "Request failed with status code 404"
      );
    });
  });
});
