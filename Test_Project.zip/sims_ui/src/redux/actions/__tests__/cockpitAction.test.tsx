// @ts-nocheck
import {
  COCKPIT_FAILURE_API_HANDLERS,
  COCKPIT_SUCCESS_API_HANDLERS
} from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import {
  fetchCockpit,
  fetchDocumentTable,
  cancelCockpit
} from "../cockpitAction";

describe("cockpitAction", () => {
  createServer(COCKPIT_SUCCESS_API_HANDLERS);

  test("Should dispatch correct action for handleFetchCockpit", async () => {
    await store.dispatch(fetchCockpit());

    expect(store.getState().cockpit.cockpits).toHaveLength(1);
  });

  test("Should dispatch correct action for document list", async () => {
    await store.dispatch(fetchDocumentTable(3));

    expect(store.getState().cockpit.documentList).toHaveLength(2);
  });
  test("Should dispatch correct cancel action", async () => {
    // @ts-ignore
    await store.dispatch(cancelCockpit(123));
    expect(store.getState().cockpit.isLoadingFetch).toBeFalsy();
  });
});

describe("API failure", () => {
  createServer(COCKPIT_FAILURE_API_HANDLERS);

  test("Should dispatch correct action for handleFetchCockpit when api failed", async () => {
    await store.dispatch(fetchCockpit());

    expect(store.getState().externalSystem.isLoadingFetch).toBeFalsy();
  });

  test("Should dispatch correct action for fetchDocumentTable when api failed", async () => {
    await store.dispatch(fetchDocumentTable(3));

    expect(store.getState().cockpit.isLoadingDocument).toBeFalsy();
  });
});
