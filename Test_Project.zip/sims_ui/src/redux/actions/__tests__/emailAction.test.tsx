// @ts-nocheck
import {
  EM_FAILURE_API_HANDLERS,
  EM_SUCCESS_API_HANDLERS
} from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import { fetchEmail } from "../emailAction";

describe("emailAction", () => {
  createServer(EM_SUCCESS_API_HANDLERS);

  test("Should dispatch correct action for fetch", async () => {
    await store.dispatch(fetchEmail(true));

    expect(store.getState().email.emails).toHaveLength(1);
  });

  // test("Should dispatch correct action for update", async () => {
  //   await store.dispatch(updateEmail({ payload: "dummy" }, "testId"));

  //   expect(store.getState().email.isLoadingUpdate).toBeFalsy();
  // });

  describe("API failure", () => {
    createServer(EM_FAILURE_API_HANDLERS);

    test("Should dispatch correct action for fetch when api failed", async () => {
      await store.dispatch(fetchEmail(true));

      expect(store.getState().email.isLoadingFetch).toBeFalsy();
    });
  });
});
