// @ts-nocheck
import { CARDTYPES_SUCCESS_HANDLERS } from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import { createCardType, updateCardType } from "../cardTypesAction";

describe("cardTypesAction API Success", () => {
  createServer(CARDTYPES_SUCCESS_HANDLERS);

  test("Should dispatch correct action for create", async () => {
    await store.dispatch(createCardType({ payload: "dummy" }));

    expect(store.getState().cardType.isLoadingCreate).toBeFalsy();
  });

  test("Should dispatch correct action for update", async () => {
    await store.dispatch(updateCardType({ payload: "dummy" }));

    expect(store.getState().cardType.isLoadingUpdate).toBeFalsy();
  });
});
