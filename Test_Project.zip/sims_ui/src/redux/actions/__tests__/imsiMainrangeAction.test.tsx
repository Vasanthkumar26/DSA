// @ts-nocheck
import {
  MAINRANGE_FAILURE_API_HANDLERS,
  MAINRANGE_SUCCESS_API_HANDLERS,
  mainRangeStatusData
} from "../../../_mocks_/mainrangeApiHandlers";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import {
  fetchImsiMainranges,
  fetchimsiMainRangeExport,
  deleteImsiMainrange,
  fetchIMSIMainRangeStatusTable
} from "../imsiMainrangeAction";

describe("imsiMainrangeAction", () => {
  describe("mainrange success", () => {
    createServer(MAINRANGE_SUCCESS_API_HANDLERS);

    test("Should dispatch correct actions", async () => {
      await store.dispatch(fetchImsiMainranges(true));
      expect(store.getState().imsiMainrange.imsiMainranges).toHaveLength(2);
    });

    test("Should dispatch correct actions for export", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      await store.dispatch(fetchimsiMainRangeExport(true));
      expect(store.getState().imsiMainrange.exportSuccessMsg).toEqual(
        "successful"
      );
    });

    test("Should dispatch correct actions for delete", async () => {
      // @ts-ignore
      await store.dispatch(deleteImsiMainrange(123));
      expect(store.getState().imsiMainrange.deleteSuccessMsgFlag).toEqual(true);
    });

    test("should have correct state to loadstatus table", async () => {
      await store.dispatch(
        fetchIMSIMainRangeStatusTable({
          startIMSIForSearch: "123",
          endIMSIForSearch: "342334"
        })
      );
      expect(store.getState().imsiMainrange.mainrangeStatusDetail).toEqual(
        mainRangeStatusData
      );
    });
  });

  describe("mainrange failure", () => {
    createServer(MAINRANGE_FAILURE_API_HANDLERS);
    test("Should dispatch correct actions", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      await store.dispatch(fetchimsiMainRangeExport(true));
      expect(store.getState().imsiMainrange.errorExport).toEqual(
        "Request failed with status code 400"
      );
    });

    test("shoudl change the error status for loadstatus table", async () => {
      await store.dispatch(
        fetchIMSIMainRangeStatusTable({
          startIMSIForSearch: "1232",
          endIMSIForSearch: "2323"
        })
      );
      expect(store.getState().imsiMainrange.isLoadingStatusTable).toBe(false);
    });
  });
});
