// @ts-nocheck
import {
  FF_FAILURE_API_HANDLERS,
  FF_SUCCESS_API_HANDLERS
} from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import {
  createFormFactor,
  fetchFormFactor,
  updateFormFactor
} from "../formFactorAction";

describe("formFactorAction", () => {
  createServer(FF_SUCCESS_API_HANDLERS);

  test("Should dispatch correct action for fetch", async () => {
    await store.dispatch(fetchFormFactor(true));

    expect(store.getState().formFactor.formFactors).toHaveLength(1);
  });

  test("Should dispatch correct action for create", async () => {
    await store.dispatch(createFormFactor({ payload: "dummy" }));

    expect(store.getState().formFactor.isLoadingCreate).toBeFalsy();
  });

  test("Should dispatch correct action for update", async () => {
    await store.dispatch(updateFormFactor({ payload: "dummy" }, "testId"));

    expect(store.getState().formFactor.isLoadingUpdate).toBeFalsy();
  });

  describe("API failure", () => {
    createServer(FF_FAILURE_API_HANDLERS);

    test("Should dispatch correct action for fetch when api failed", async () => {
      await store.dispatch(fetchFormFactor(true));

      expect(store.getState().formFactor.isLoadingFetch).toBeFalsy();
    });
  });
});
