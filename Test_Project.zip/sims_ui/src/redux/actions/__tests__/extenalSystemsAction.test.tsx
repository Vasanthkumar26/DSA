// @ts-nocheck
import {
  ES_FAILURE_API_HANDLERS,
  ES_SUCCESS_API_HANDLERS
} from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import {
  createExternalSystem,
  fetchExternalSystems,
  fetchExtertnalSystemExport,
  updateExternalSystem,
  deleteExternalSystem
} from "../extenalSystemsAction";

describe("extenalSystemsAction", () => {
  createServer(ES_SUCCESS_API_HANDLERS);

  test("Should dispatch correct action for fetch", async () => {
    await store.dispatch(fetchExternalSystems(true));

    expect(store.getState().externalSystem.externalSystems).toHaveLength(1);
  });

  test("Should dispatch correct action for create", async () => {
    await store.dispatch(createExternalSystem({ payload: "dummy" }));

    expect(store.getState().externalSystem.isLoadingCreate).toBeFalsy();
  });

  test("Should dispatch correct action for update", async () => {
    await store.dispatch(updateExternalSystem({ payload: "dummy" }, "testId"));

    expect(store.getState().externalSystem.isLoadingUpdate).toBeFalsy();
  });

  test("Should dispatch correct action for export", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    await store.dispatch(fetchExtertnalSystemExport(true));
    expect(store.getState().externalSystem.exportSuccessMsg).toEqual(
      "successful"
    );
  });

  test("Should dispatch correct delete actions", async () => {
    // @ts-ignore
    await store.dispatch(deleteExternalSystem(123));
    expect(store.getState().externalSystem.deleteSuccessMsgFlag).toEqual(true);
  });
});

describe("API failure", () => {
  createServer(ES_FAILURE_API_HANDLERS);

  test("Should dispatch correct action for fetch when api failed", async () => {
    await store.dispatch(fetchExternalSystems(true));

    expect(store.getState().externalSystem.isLoadingFetch).toBeFalsy();
  });

  test("Should dispatch correct actions for export when api failed", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    await store.dispatch(fetchExtertnalSystemExport(true));
    expect(store.getState().externalSystem.errorExport).toEqual(
      "Request failed with status code 404"
    );
  });

  test("Should dispatch correct delete actions", async () => {
    // @ts-ignore
    await store.dispatch(deleteExternalSystem(123));
    expect(store.getState().externalSystem.deleteErrorMsg).toEqual(
      "Sorry! Request failed, please try again."
    );
  });
});
