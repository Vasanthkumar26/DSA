// @ts-nocheck
import { TASK_API_SUCCESS, TASK_API_FAILURE } from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import { deleteTask, downlaodTask } from "../taskActions";
jest.setTimeout(10000);
describe("TaskAction", () => {
  createServer(TASK_API_SUCCESS);

  test("Should dispatch correct delete actions", async () => {
    // @ts-ignore
    await store.dispatch(deleteTask(123));
    expect(store.getState().task.deleteSuccessMsgFlag).toEqual(true);
  });
  test("Should dispatch the correct action for export", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    await store.dispatch(downlaodTask(true));
    expect(store.getState().task.isLoadingCreate).toEqual(false);
  });
});
describe("TASK_API_FAILURE  failure", () => {
  createServer(TASK_API_FAILURE);
  test("Should dispatch correct action for deleteTask", async () => {
    await store.dispatch(deleteTask(123));
    expect(store.getState().task.deleteSuccessMsgFlag).toBeTruthy();
  });
});
