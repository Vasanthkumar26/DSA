// @ts-nocheck
import {
  TaskEscalation_SUCCESS_API_HANDLERS,
  TaskEscalation_FAILURE_API_HANDLERS
} from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import { fetchTaskEscalationExport } from "../taskEscalationAction";
jest.setTimeout(10000);

describe("Success Action", () => {
  createServer(TaskEscalation_SUCCESS_API_HANDLERS);
  test("Should dispatch the correct action for export", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();

    await store.dispatch(fetchTaskEscalationExport(true));
    expect(store.getState().taskEscalation.exportSuccessMsg).toEqual(
      "successful"
    );
  });
});

describe("Failure Action", () => {
  createServer(TaskEscalation_FAILURE_API_HANDLERS);
  test("should dispatch the correct action when export api is failed", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    await store.dispatch(fetchTaskEscalationExport(true));
    expect(store.getState().taskEscalation.errorExport).toEqual(
      "Request failed with status code 404"
    );
  });
});
