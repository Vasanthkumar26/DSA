// @ts-nocheck
import {
  SimArticle_SUCCESS_API_HANDLERS,
  SimArticle_FAILURE_API_HANDLERS
} from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import { fetchSimArticleExport, archiveSimArticle } from "../simArticleAction";
jest.setTimeout(10000);

//describe.skip("deliveryAddress Action test", () => {
describe("Success Action", () => {
  createServer(SimArticle_SUCCESS_API_HANDLERS);
  test("Should dispatch the correct action for export", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();

    await store.dispatch(fetchSimArticleExport(true));
    expect(store.getState().simArticle.exportSuccessMsg).toEqual("successful");
  });

  test("should dispatch archive actions", async () => {
    await store.dispatch(archiveSimArticle(123, true, "test1"));
    expect(store.getState().simArticle.archiveMsg).toEqual(
      `test1 archived successfully`
    );
  });
});

describe("Failure Action", () => {
  createServer(SimArticle_FAILURE_API_HANDLERS);
  test("should dispatch the correct action when export api is failed", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    await store.dispatch(fetchSimArticleExport(true));
    expect(store.getState().simArticle.errorExport).toEqual("Network Error");
  });

  test("should archiving be failed", async () => {
    await store.dispatch(archiveSimArticle(123, true, "test1"));
    expect(store.getState().simArticle.archiveMsg).toEqual(
      `Archiving test1 failed`
    );
  });
});
//});
