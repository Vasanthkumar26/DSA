// @ts-nocheck
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import {
  fetchElectricalProfileExport,
  deleteElectricalProfile
} from "../electricalProfileAction";
import {
  EP_FAILURE_API_HANDLERS,
  EP_SUCCESS_API_HANDLERS
} from "../../../_mocks_";

describe("Electrical profile  fetchExport", () => {
  createServer(EP_SUCCESS_API_HANDLERS);

  test("Should dispatch correct actions", async () => {
    // @ts-ignore
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    await store.dispatch(fetchElectricalProfileExport(true));
    expect(store.getState().electricalProfile.exportSuccessMsg).toEqual(
      "successful"
    );
  });

  test("Should dispatch correct delete actions", async () => {
    // @ts-ignore
    await store.dispatch(deleteElectricalProfile(123));
    expect(store.getState().electricalProfile.deleteSuccessMsgFlag).toEqual(
      true
    );
  });
});

describe("hlr export failure", () => {
  createServer(EP_FAILURE_API_HANDLERS);

  test("Should dispatch correct actions", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    await store.dispatch(fetchElectricalProfileExport(true));
    expect(store.getState().electricalProfile.errorExport).toEqual(
      "Request failed with status code 404"
    );
  });

  test("Should dispatch correct delete actions", async () => {
    // @ts-ignore
    await store.dispatch(deleteElectricalProfile(123));
    expect(store.getState().electricalProfile.deleteErrorMsg).toEqual(
      "Sorry! Request failed, please try again."
    );
  });
});
