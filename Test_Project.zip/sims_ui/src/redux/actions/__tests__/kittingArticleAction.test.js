import configureMockStore from "redux-mock-store";
import thunk from "redux-thunk";
import {
  handleFetchKittingArticles,
  handleKittingArticleExport,
  handleDeleteKittingArticle
} from "../../../services/kittingArticleApi";
import {
  fetchKittingArticles,
  fetchKittingArticlesFailure,
  fetchKittingArticlesRequest,
  fetchKittingArticlesSuccess,
  setSelectedKittingArticle,
  fetchKittingArticleExportFailure,
  fetchKittingArticleExportRequest,
  fetchKittingArticleExportSuccess,
  fetchKittingArticlesExport,
  deleteKittingArticlesRequest,
  deleteKittingArticlesSuccess,
  deleteKittingArticlesFailure,
} from "../kittingArticleAction";
import {
  FETCH_KITTING_ARTICLES_FAILURE,
  FETCH_KITTING_ARTICLES_REQUEST,
  FETCH_KITTING_ARTICLES_SUCCESS,
  SET_SELECTED_KITTING_ARTICLE,
  FETCH_KITTING_ARTICLES_EXPORT_FAILURE,
  FETCH_KITTING_ARTICLES_EXPORT_SUCCESS,
  FETCH_KITTING_ARTICLES_EXPORT_REQUEST,
  DELETE_KITTING_ARTICLES_REQUEST,
  DELETE_KITTING_ARTICLES_SUCCESS,
  DELETE_KITTING_ARTICLES_FAILURE
} from "../types";

jest.mock("../../../services/kittingArticleApi", () => ({
  handleFetchKittingArticles: jest.fn(),
  handleKittingArticleExport: jest.fn(),
  handleDeleteKittingArticle: jest.fn()
}));

const mockStore = configureMockStore([thunk]);

describe("kitting articles actions", () => {
  let store;
  beforeEach(() => {
    store = mockStore({});
  });

  afterEach(() => {
    jest.resetAllMocks();
    store.clearActions();
  });
  describe("fetchKittingArticles", () => {
    test("fetchKittingArticlesRequest action creator", () => {
      const expectedAction = {
        type: FETCH_KITTING_ARTICLES_REQUEST,
      };

      expect(fetchKittingArticlesRequest()).toEqual(expectedAction);
    });

    test("fetchKittingArticlesSuccess action creator", () => {
      const kittingArticles = [{ id: 1, name: "Article 1" }];
      const expectedAction = {
        type: FETCH_KITTING_ARTICLES_SUCCESS,
        payload: { kittingArticles },
      };

      expect(fetchKittingArticlesSuccess(kittingArticles)).toEqual(
        expectedAction
      );
    });

    test("fetchKittingArticlesFailure action creator", () => {
      const error = "Error fetching kitting articles";
      const expectedAction = {
        type: FETCH_KITTING_ARTICLES_FAILURE,
        payload: { errorFetch:error },
      };

      expect(fetchKittingArticlesFailure(error)).toEqual(expectedAction);
    });

    test("setSelectedKittingArticle action creator", () => {
      const kittingArticle = { id: 1, name: "Article 1" };
      const expectedAction = {
        type: SET_SELECTED_KITTING_ARTICLE,
        payload: { kittingArticle },
      };

      expect(setSelectedKittingArticle(kittingArticle)).toEqual(expectedAction);
    });

    test("dispatches FETCH_KITTING_ARTICLES_REQUEST and FETCH_KITTING_ARTICLES_SUCCESS when fetching kitting articles is successful", async () => {
      const expectedActions = [
        { type: FETCH_KITTING_ARTICLES_REQUEST },
        {
          type: FETCH_KITTING_ARTICLES_SUCCESS,
          payload: { kittingArticles: [{ id: 1, name: "article 1" }] },
        },
      ];
      handleFetchKittingArticles.mockResolvedValue([
        { id: 1, name: "article 1" },
      ]);

      await store.dispatch(fetchKittingArticles());

      expect(store.getActions()).toEqual(expectedActions);
    });

    test("dispatches FETCH_KITTING_ARTICLES_REQUEST and FETCH_KITTING_ARTICLES_FAILURE when fetching kitting articles fails", async () => {
      const errorFetch = new Error("Failed to fetch kitting articles");
      const expectedActions = [
        { type: FETCH_KITTING_ARTICLES_REQUEST },
        { type: FETCH_KITTING_ARTICLES_FAILURE, payload: { errorFetch } },
      ];
      handleFetchKittingArticles.mockRejectedValue(errorFetch);

      await store.dispatch(fetchKittingArticles());

      expect(store.getActions()).toEqual(expectedActions);
    });
  });
  describe("deleteKittingArticle", () => {
    test("deleteKittingArticleRequest action creator", () => {
      const expectedAction = {
        type: DELETE_KITTING_ARTICLES_REQUEST,
      };
      expect(deleteKittingArticlesRequest()).toEqual(expectedAction);
    });

    test("deleteKittingArticleSuccess action creator", async () => {
      const kittingArticles = { id: 123, name: "Article 123",msg:"Article 123 deleted successfully" };
      const expectedAction = [{
        type: DELETE_KITTING_ARTICLES_SUCCESS,
        payload: { deletekittingArticles:kittingArticles },
      }];
      handleDeleteKittingArticle.mockResolvedValue(kittingArticles);
      await store.dispatch(deleteKittingArticlesSuccess(kittingArticles));
      expect(store.getActions()).toEqual(expectedAction);
    });

    test("deleteKittingArticleFailure action creator", () => {
      const error = "Error deleting kitting article";
      const expectedAction = {
        type: DELETE_KITTING_ARTICLES_FAILURE,
        payload: { error },
      };

      expect(deleteKittingArticlesFailure(error)).toEqual(expectedAction);
    });

    test("setSelectedKittingArticle action creator", () => {
      const kittingArticle = { id: 1, name: "Article 1" };
      const expectedAction = {
        type: SET_SELECTED_KITTING_ARTICLE,
        payload: { kittingArticle },
      };

      expect(setSelectedKittingArticle(kittingArticle)).toEqual(expectedAction);
    });

    test("dispatches FETCH_KITTING_ARTICLES_REQUEST and FETCH_KITTING_ARTICLES_SUCCESS when fetching kitting articles is successful", async () => {
      const expectedActions = [
        { type: FETCH_KITTING_ARTICLES_REQUEST },
        {
          type: FETCH_KITTING_ARTICLES_SUCCESS,
          payload: { kittingArticles: [{ id: 1, name: "article 1" }] },
        },
      ];
      handleFetchKittingArticles.mockResolvedValue([
        { id: 1, name: "article 1" },
      ]);

      await store.dispatch(fetchKittingArticles());

      expect(store.getActions()).toEqual(expectedActions);
    });

    test("dispatches FETCH_KITTING_ARTICLES_REQUEST and FETCH_KITTING_ARTICLES_FAILURE when fetching kitting articles fails", async () => {
      const errorFetch = new Error("Failed to fetch kitting articles");
      const expectedActions = [
        { type: FETCH_KITTING_ARTICLES_REQUEST },
        { type: FETCH_KITTING_ARTICLES_FAILURE, payload: { errorFetch } },
      ];
      handleFetchKittingArticles.mockRejectedValue(errorFetch);

      await store.dispatch(fetchKittingArticles());

      expect(store.getActions()).toEqual(expectedActions);
    });
  });

  describe("fetchKittingArticlesExport", () => {
    test("fetchKittingArticleExportRequest action creator", () => {
      const expectedAction = {
        type: FETCH_KITTING_ARTICLES_EXPORT_REQUEST,
      };

      expect(fetchKittingArticleExportRequest()).toEqual(expectedAction);
    });

    test("fetchKittingArticlesExportSuccess action creator", () => {
      const expectedAction = {
        type: FETCH_KITTING_ARTICLES_EXPORT_SUCCESS,
        payload: { message: "successfull" },
      };

      expect(fetchKittingArticleExportSuccess("successfull")).toEqual(
        expectedAction
      );
    });

    test("fetchKittingArticlesExportFailure action creator", () => {
      const errorFetch = "Error fetching kitting article export";
      const expectedAction = {
        type: FETCH_KITTING_ARTICLES_EXPORT_FAILURE,
        payload: { error: errorFetch },
      };

      expect(fetchKittingArticleExportFailure(errorFetch)).toEqual(
        expectedAction
      );
    });

    test("dispatches FETCH_KITTING_ARTICLE_EXPORT_REQUEST and FETCH_KITTING_ARTICLE_EXPORT_SUCCESS when fetching kitting article export is successful", async () => {
      const expectedActions = [
        {
          type: FETCH_KITTING_ARTICLES_EXPORT_REQUEST,
        },
        {
          type: FETCH_KITTING_ARTICLES_EXPORT_SUCCESS,
          payload: { message: "successfull" },
        },
      ];

      handleKittingArticleExport.mockResolvedValue("successfull");

      await store.dispatch(fetchKittingArticlesExport());
      expect(store.getActions()).toEqual(expectedActions);
    });

    test("dispatches FETCH_KITTING_ARTICLE_EXPORT_REQUEST and FETCH_KITTING_ARTICLE_EXPORT_FAILURE when fetching kitting article export is fails", async () => {
      const error = new Error("Failed to fetch the kitting article export");

      const expectedActions = [
        { type: FETCH_KITTING_ARTICLES_EXPORT_REQUEST },
        { type: FETCH_KITTING_ARTICLES_EXPORT_FAILURE, payload: { error } },
      ];

      handleKittingArticleExport.mockRejectedValue(error);
      await store.dispatch(fetchKittingArticlesExport());
      expect(store.getActions()).toEqual(expectedActions);
    });
  });
});
