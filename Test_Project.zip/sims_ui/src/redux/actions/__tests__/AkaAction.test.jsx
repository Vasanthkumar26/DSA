import {
  AKA_FAILURE_API_HANDLERS,
  AKA_SUCCESS_API_HANDLERS
} from "../../../_mocks_";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import { fetchAkaExport, deleteAka, archiveAka } from "../akaAction";

describe("AKA API success", () => {
  createServer(AKA_SUCCESS_API_HANDLERS);
  test("Should dispatch Delete correct actions", async () => {
    // @ts-ignore
    await store.dispatch(deleteAka(123));
    expect(store.getState().aka.deleteSuccessMsgFlag).toEqual(true);
  });

  test("Should dispatch correct actions", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    await store.dispatch(fetchAkaExport(true));
    expect(store.getState().aka.exportSuccessMsg).toEqual("successful");
  });

  test("should dispatch archive actions", async () => {
    await store.dispatch(archiveAka(123, true, "test1"));
    expect(store.getState().aka.archiveMsg).toEqual(
      `test1 archived successfully`
    );
  });
});

describe("AKA API Failure", () => {
  createServer(AKA_FAILURE_API_HANDLERS);
  test("Should dispatch Delete correct actions", async () => {
    // @ts-ignore
    await store.dispatch(deleteAka(123));
    expect(store.getState().aka.deleteErrorMsg).toEqual(
      "Sorry! Request failed, please try again."
    );
  });

  test("Should dispatch correct actions", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    await store.dispatch(fetchAkaExport(true));
    expect(store.getState().aka.errorExport).toEqual(
      "Request failed with status code 404"
    );
  });
  test("should archiving be failed", async () => {
    await store.dispatch(archiveAka(123, true, "test1"));
    expect(store.getState().aka.archiveMsg).toEqual(`archiving test1 failed`);
  });
});
