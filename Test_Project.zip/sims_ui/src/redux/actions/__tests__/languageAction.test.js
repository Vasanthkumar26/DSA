import { toggleLanguage } from "../languageActions";
import { LanguageActionType } from "../types";
import { getNewLangAfterToggle } from "../../../utils/common";

jest.mock("../../../utils/common", () => ({
  getNewLangAfterToggle: jest.fn(),
}));

const localStorageMock = {
  getItem: jest.fn(),
  setItem: jest.fn(),
  clear: jest.fn(),
};

describe("Language Actions", () => {
  beforeAll(() => {
    Object.defineProperty(window, "localStorage", {
      value: localStorageMock,
    });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test("toggleLanguage action creator", () => {
    const currentLang = "en";
    const newLang = "fr";
    getNewLangAfterToggle.mockReturnValue(newLang);

    const expectedAction = {
      type: LanguageActionType.TOGGLE_LANGUAGE,
    };

    const action = toggleLanguage(currentLang);

    expect(localStorageMock.setItem).toHaveBeenCalledWith("language", newLang);
    expect(getNewLangAfterToggle).toHaveBeenCalledWith(currentLang);
    expect(action).toEqual(expectedAction);
  });
});
