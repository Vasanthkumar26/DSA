import { REACT_BASE_URL } from "../../../utils/common";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import { fetchHLRExport, fetchHlrs, deleteHLR } from "../hlrAction";

describe("hlrAction", () => {
  createServer([
    {
      path: `${REACT_BASE_URL}/hlr/loadHLR`,
      res: () => [
        {
          id: 1,
          hlrName: "HLRDaimlar",
          description: "foreign:notOperated",
          greenICCID: "Nein",
          imsiDigit: "262-11",
          iccidDigit: "5",
          archived: false,
        },
        {
          id: 2,
          hlrName: "HLRDaimlar",
          description: "foreign:notOperated",
          greenICCID: "Nein",
          imsiDigit: "262-11",
          iccidDigit: "5",
          archived: false,
        },
      ],
    },
  ]);

  test("Should dispatch correct actions", async () => {
    // @ts-ignore
    await store.dispatch(fetchHlrs(true));

    expect(store.getState().hlr.hlrs).toHaveLength(2);
  });
});

describe("HLR action fetchExport", () => {
  createServer([
    {
      path: `${REACT_BASE_URL}/hlr/hlr/download?archived=true`,
      status: 200,
      res: () =>
        new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" }),
    },
  ]);

  test("Should dispatch correct actions", async () => {
    // @ts-ignore
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
     // @ts-ignore
    await store.dispatch(fetchHLRExport(true));
    expect(store.getState().hlr.exportSuccessMsg).toEqual("successful");
  });
});

describe("hlr export failure", () => {
  createServer([
    {
      path: `${REACT_BASE_URL}/hlr/hlr/download?archived=true`,
      status: 400,
      res: () => ({ error: "something went wrong" }),
    },
  ]);

  test("Should dispatch correct actions", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    // @ts-ignore
    await store.dispatch(fetchHLRExport(true));
    expect(store.getState().hlr.errorExport).toEqual(
      "Request failed with status code 400"
    );
  });
});
describe("hlrDelete", () => {
  createServer([
    {
      path: `${REACT_BASE_URL}/hlr/deleteHLR/123`,
      res: () => [],
      method: "delete",
    },
  ]);
  test("Should dispatch correct actions", async () => {
    // @ts-ignore
    await store.dispatch(deleteHLR(123));
    expect(store.getState().hlr.deleteSuccessMsgFlag).toEqual(true);
  });
});
