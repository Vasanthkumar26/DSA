// @ts-nocheck
import {
  SUBRANGE_API_FAILURE,
  SUBRANGE_API_SUCCESS,
  subrangeStatusData
} from "../../../_mocks_/subrangeApiHandlers";
import { createServer } from "../../../utils/testUtils";
import { store } from "../../store";
import {
  fetchImsiSubrangeExport,
  fetchImsiSubranges,
  deleteImsiSubrange,
  fetchImsiSubrangeStatusTable
} from "../imsiSubrangeAction";

describe("imsiSubrangeAction", () => {
  describe("SUCCESS ACTION", () => {
    createServer(SUBRANGE_API_SUCCESS);

    test("Should dispatch correct actions", async () => {
      await store.dispatch(fetchImsiSubranges(true, "", ""));
      expect(store.getState().imsiSubrange.imsiSubranges).toHaveLength(2);
    });

    test("Should dispatch correct actions for export", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      await store.dispatch(fetchImsiSubrangeExport(true));
      expect(store.getState().imsiSubrange.exportSuccessMsg).toEqual(
        "successful"
      );
    });
    test("Should dispatch correct actions for delete", async () => {
      // @ts-ignore
      await store.dispatch(deleteImsiSubrange(123));
      expect(store.getState().imsiSubrange.deleteSuccessMsgFlag).toEqual(true);
    });

    test("should dispatch the correct state for status table", async () => {
      await store.dispatch(
        fetchImsiSubrangeStatusTable({
          startIMSIForSearch: "23",
          endIMSIForSearch: "123"
        })
      );
      expect(store.getState().imsiSubrange.subrangestatusdetail).toEqual(
        subrangeStatusData
      );
    });
  });

  describe("FAILURE ACTION", () => {
    createServer(SUBRANGE_API_FAILURE);

    test("Should dispatch correct actions", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      await store.dispatch(fetchImsiSubrangeExport(true));
      expect(store.getState().imsiSubrange.errorExport).toEqual(
        "Request failed with status code 404"
      );
    });

    test("Should dispatch the error state", async () => {
      await store.dispatch(
        fetchImsiSubrangeStatusTable({
          startIMSIForSearch: "23",
          endIMSIForSearch: "123"
        })
      );
      expect(store.getState().imsiSubrange.errorFetchStatusTable).toBe(
        "Request failed with status code 404"
      );
    });
  });
});
