import { Dispatch } from "redux";
import { ServiceProviderAction } from "../../models";
import { handleFetchServiceProviders } from "../../services/serviceProviderApi";
import { ServiceProviderActionTypes } from "./types";

export const fetchServiceProviders =
  (isArchive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ServiceProviderAction>({
        type: ServiceProviderActionTypes.FETCH_SERVICE_PROVIDER_REQUEST,
      });
      const serviceProviders = await handleFetchServiceProviders(isArchive);
      dispatch<ServiceProviderAction>({
        type: ServiceProviderActionTypes.FETCH_SERVICE_PROVIDER_SUCCESS,
        payload: serviceProviders,
      });
    } catch (error: any) {
      dispatch<ServiceProviderAction>({
        type: ServiceProviderActionTypes.FETCH_SERVICE_PROVIDER_FAILURE,
        payload: error,
      });
    }
  };
