import { Dispatch } from "redux";
import { TaskEscalationActionTypes } from "./types";

import {
  handleCreateTaskEscalation,
  handleFetchTaskEscalations,
  handleTaskEscalationExport,
  handleUpdateTaskEscalation,
  handleDeleteTaskEscalation
} from "../../services/taskEscalationApi";
import {
  TaskEscalationAction,
  TaskEscalations
} from "../../models/taskEscalation.model";

export const fetchTaskEscalationExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<TaskEscalationAction>({
        type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_REQUEST
      });
      const response = await handleTaskEscalationExport(isArchived);
      if (response) {
        dispatch<TaskEscalationAction>({
          type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_SUCCESS,
          payload: response
        });
      }
    } catch (error: any) {
      dispatch<TaskEscalationAction>({
        type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_FAILURE,
        payload: error?.message
      });
    }
  };

export const fetchTaskEscalations =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<TaskEscalationAction>({
        type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_REQUEST
      });
      const taskEscalations = await handleFetchTaskEscalations(isArchived);
      dispatch<TaskEscalationAction>({
        type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_SUCCESS,
        payload: taskEscalations
      });
    } catch (error: any) {
      dispatch<TaskEscalationAction>({
        type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_FAILURE,
        payload: error?.message
      });
    }
  };

export const createTaskEscalation =
  (data: any) => async (dispatch: Dispatch) => {
    try {
      dispatch<TaskEscalationAction>({
        type: TaskEscalationActionTypes.CREATE_TASK_ESCALATION_REQUEST
      });
      const res = await handleCreateTaskEscalation(data);
      if (res) {
        dispatch<TaskEscalationAction>({
          type: TaskEscalationActionTypes.CREATE_TASK_ESCALATION_SUCCESS,
          payload: res
        });
      }
    } catch (error: any) {
      dispatch<TaskEscalationAction>({
        type: TaskEscalationActionTypes.RESET_MESSAGE
      });
    }
  };

export const updateTaskEscalation =
  (id: number, data: any) => async (dispatch: Dispatch) => {
    try {
      dispatch<TaskEscalationAction>({
        type: TaskEscalationActionTypes.UPDATE_TASK_ESCALATION_REQUEST
      });
      const res = await handleUpdateTaskEscalation(id, data);
      if (res) {
        dispatch<TaskEscalationAction>({
          type: TaskEscalationActionTypes.UPDATE_TASK_ESCALATION_SUCCESS,
          payload: res
        });
      }
    } catch (error: any) {
      dispatch<TaskEscalationAction>({
        type: TaskEscalationActionTypes.RESET_MESSAGE
      });
    }
  };

export const deleteTaskEscalation =
  (id: number) => async (dispatch: Dispatch) => {
    try {
      dispatch<TaskEscalationAction>({
        type: TaskEscalationActionTypes.DELETE_TASK_ESCALATION_REQUEST
      });
      const response = await handleDeleteTaskEscalation(id);
      if (response) {
        dispatch<TaskEscalationAction>({
          type: TaskEscalationActionTypes.DELETE_TASK_ESCALATION_SUCCESS,
          payload: id
        });
      }
    } catch (error: any) {
      dispatch<TaskEscalationAction>({
        type: TaskEscalationActionTypes.DELETE_TASK_ESCALATION_FAILURE,
        payload: "Sorry! Request failed, please try again." || error?.message
      });
      throw new Error(error);
    }
  };

export const setSelectedTaskEscalation =
  (data: TaskEscalations | null) => async (dispatch: Dispatch) => {
    dispatch<TaskEscalationAction>({
      type: TaskEscalationActionTypes.SET_SELECTED_TASK_ESCALATION,
      payload: data
    });
  };
