import { Dispatch } from "redux";
import { AuthAction, User } from "../../models";
import { BASE_URL } from "../../utils/constants";
import { AuthActionTypes } from "./types";

/*
============== Action Creators ==============
*/

export const login = (credentials: User) => async (dispatch: Dispatch) => {
  try {
    dispatch<AuthAction>({
      type: AuthActionTypes.LOGIN_REQUEST,
    });

    const response = await fetch(`${BASE_URL}/api/authenticate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(credentials),
    });
    const user = await response.json();

    dispatch<AuthAction>({
      type: AuthActionTypes.LOGIN_SUCCESS,
      payload: user,
    });
  } catch (err: any) {
    dispatch<AuthAction>({
      type: AuthActionTypes.LOGIN_FAILURE,
      payload: err,
    });
  }
};

export const logout = () => async (dispatch: Dispatch) => {
  try {
    dispatch<AuthAction>({
      type: AuthActionTypes.LOGOUT_REQUEST,
    });
    setTimeout(
      () =>
        dispatch<AuthAction>({
          type: AuthActionTypes.LOGOUT_SUCCESS,
        }),
      500
    );
  } catch (err: any) {
    dispatch<AuthAction>({
      type: AuthActionTypes.LOGOUT_FAILURE,
      payload: err,
    });
  }
};
