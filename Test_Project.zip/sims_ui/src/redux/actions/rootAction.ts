import { Dispatch } from "redux";
import { ResetPageAction, ResetReduxStoreAction } from "../../models";
import { ResetPageActionType, ResetReduxActionType } from "./types";

export const resetReduxStore = () => (dispatch: Dispatch) => {
  dispatch<ResetReduxStoreAction>({
    type: ResetReduxActionType.RESET_REDUX_STORE
  });
};

export const resetPage = () => (dispatch: Dispatch) => {
  dispatch<ResetPageAction>({
    type: ResetPageActionType.RESET_PAGE
  });
};
