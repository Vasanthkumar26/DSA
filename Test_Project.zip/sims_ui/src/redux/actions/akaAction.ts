import { Dispatch } from "redux";
import { AkaActionTypes } from "./types";
import { Aka, AkaAction, akaCreatePayload } from "../../models/aka.model";
import {
  handleAkaExport,
  handleFetchAkas,
  handleDeleteAka,
  handleCreateAka,
  handleUpdateAka,
  handleArchiveAka
} from "../../services/AkaApi";

export const fetchAkas = (isArchive: boolean) => async (dispatch: Dispatch) => {
  try {
    dispatch<AkaAction>({ type: AkaActionTypes.FETCH_AKA_REQUEST });
    const akas = await handleFetchAkas(isArchive);
    dispatch<AkaAction>({
      type: AkaActionTypes.FETCH_AKA_SUCCESS,
      payload: akas
    });
  } catch (error: any) {
    dispatch<AkaAction>({
      type: AkaActionTypes.FETCH_AKA_FAILURE,
      payload: error
    });
  }
};

export const resetAka = () => async (dispatch: Dispatch) => {
  dispatch<AkaAction>({ type: AkaActionTypes.RESET_AKA });
};

export const setSelectedAKA =
  (data: Aka | null) => async (dispatch: Dispatch) => {
    dispatch<AkaAction>({
      type: AkaActionTypes.SET_SELECTED_AKA,
      payload: data
    });
  };

export const fetchAkaExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<AkaAction>({
        type: AkaActionTypes.FETCH_AKA_EXPORT_REQUEST
      });
      const response = await handleAkaExport(isArchived);
      dispatch<AkaAction>({
        type: AkaActionTypes.FETCH_AKA_EXPORT_SUCCESS,
        payload: response
      });
    } catch (error: any) {
      dispatch<AkaAction>({
        type: AkaActionTypes.FETCH_AKA_EXPORT_ERROR,
        payload: error?.message
      });
    }
  };
export const deleteAka = (Id: number) => async (dispatch: Dispatch) => {
  try {
    dispatch<AkaAction>({
      type: AkaActionTypes.DELETE_AKA_REQUEST
    });
    const response = await handleDeleteAka(Id);
    if (response) {
      dispatch<AkaAction>({
        type: AkaActionTypes.DELETE_AKA_SUCCESS,
        payload: Id
      });
    }
  } catch (error: any) {
    dispatch<AkaAction>({
      type: AkaActionTypes.DELETE_AKA_FAILURE,
      payload: "Sorry! Request failed, please try again." || error?.message
    });
  }
};

export const createAka =
  (payload: akaCreatePayload) => async (dispatch: Dispatch) => {
    try {
      dispatch<AkaAction>({
        type: AkaActionTypes.CREATE_AKA_REQUEST
      });
      const response = await handleCreateAka(payload);
      if (response) {
        dispatch<AkaAction>({
          type: AkaActionTypes.CREATE_AKA_SUCCESS,
          payload: []
        });
      }
    } catch (error: any) {
      dispatch<AkaAction>({
        type: AkaActionTypes.CREATE_AKA_FAILURE,
        payload: error
      });
    }
  };

export const updateAka =
  (payload: akaCreatePayload) => async (dispatch: Dispatch) => {
    try {
      dispatch<AkaAction>({
        type: AkaActionTypes.UPDATE_AKA_REQUEST
      });
      const response = await handleUpdateAka(payload);
      if (response) {
        dispatch<AkaAction>({
          type: AkaActionTypes.UPDATE_AKA_SUCCESS,
          payload: []
        });
      }
    } catch (error: any) {
      dispatch<AkaAction>({
        type: AkaActionTypes.UPDATE_AKA_FAILURE,
        payload: error
      });
    }
  };

export const archiveAka =
  (hlrId: number, isArchived: boolean, name: string) =>
  async (dispatch: Dispatch) => {
    try {
      dispatch<AkaAction>({
        type: AkaActionTypes.ARCHIVE_AKA_REQUEST
      });
      await handleArchiveAka(hlrId, isArchived);
      dispatch<AkaAction>({
        type: AkaActionTypes.ARCHIVE_AKA_SUCCESS,
        payload: { id: hlrId, archived: !isArchived, akaName: name }
      });
    } catch (error: any) {
      dispatch<AkaAction>({
        type: AkaActionTypes.ARCHIVE_AKA_FAILURE,
        payload: { error: error, akaName: name }
      });
    }
  };
