import { Dispatch } from "redux";
import { SnackbarAction } from "../../models";
import { SnackBarActionType } from "./types";

export const showSuccessSnackbar =
  (message: string) => async (dispatch: Dispatch) => {
    dispatch<SnackbarAction>({
      type: SnackBarActionType.SHOW_SNACK_BAR_SUCCESS,
      payload: message
    });
  };

export const showHighPrioritySuccessSnackbar =
  (message: string) => async (dispatch: Dispatch) => {
    dispatch<SnackbarAction>({
      type: SnackBarActionType.SHOW_HIGH_SNACK_BAR_SUCCESS,
      payload: message
    });
  };

export const showFailureSnackbar =
  (message: string) => async (dispatch: Dispatch) => {
    dispatch<SnackbarAction>({
      type: SnackBarActionType.SHOW_SNACK_BAR_FAILURE,
      payload: message
    });
  };

export const showHighPriorityFailureSnackbar =
  (message: string) => async (dispatch: Dispatch) => {
    dispatch<SnackbarAction>({
      type: SnackBarActionType.SHOW_HIGH_SNACK_BAR_FAILURE,
      payload: message
    });
  };

export const hideSnackbar = () => async (dispatch: Dispatch) => {
  dispatch<SnackbarAction>({ type: SnackBarActionType.HIDE_SNACK_BAR });
};
