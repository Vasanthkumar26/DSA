import { Dispatch } from "redux";
import {
  CardTypesAction,
  CardTypeData,
  CardTypesPayload,
  updateCardTypePayload
} from "../../models/cardTypes.model";
import {
  handleFetchCardTypes,
  loadAllAkaHLR,
  handleCardTypesExport,
  handleCreateCardType,
  fetchManufacturers,
  handleUpdateCardType,
  handleCardTypesDelete,
  handleArchiveCardType
} from "../../services/cardTypesApi";
import { CardTypeActionTypes } from "./types";
/*
============== Action Creators ==============
*/
export const fetchCardTypes =
  (isArchive: boolean) => async (dispatch: Dispatch<CardTypesAction>) => {
    try {
      dispatch({
        type: CardTypeActionTypes.CARD_TYPES_REQUEST
      });
      const cardDetails = await handleFetchCardTypes(isArchive);
      dispatch({
        type: CardTypeActionTypes.CARD_TYPES_SUCCESS,
        payload: cardDetails
      });
    } catch (error: any) {
      dispatch({
        type: CardTypeActionTypes.CARD_TYPES_FAILURE,
        payload: error
      });
    }
  };

export const loadAllAkaHLRValues =
  () => async (dispatch: Dispatch<CardTypesAction>) => {
    try {
      dispatch({
        type: CardTypeActionTypes.ALL_AKA_HLR_REQUEST
      });
      const allAkaHlrDetails = await loadAllAkaHLR();
      dispatch({
        type: CardTypeActionTypes.ALL_AKA_HLR_SUCCESS,
        payload: allAkaHlrDetails
      });
    } catch (error: any) {
      dispatch({
        type: CardTypeActionTypes.ALL_AKA_HLR_FAILURE,
        payload: error
      });
    }
  };

export const fetchCardTypesExport =
  (isArchived: boolean) => async (dispatch: Dispatch<CardTypesAction>) => {
    try {
      dispatch<CardTypesAction>({
        type: CardTypeActionTypes.FETCH_CARD_TYPES_EXPORT_REQUEST
      });
      const response = await handleCardTypesExport(isArchived);
      dispatch<CardTypesAction>({
        type: CardTypeActionTypes.FETCH_CARD_TYPES_EXPORT_SUCCESS,
        payload: response
      });
    } catch (err: any) {
      dispatch<CardTypesAction>({
        type: CardTypeActionTypes.FETCH_CARD_TYPES_EXPORT_FAILURE,
        payload: err
      });
    }
  };

export const createCardType =
  (data: CardTypesPayload) => async (dispatch: Dispatch<CardTypesAction>) => {
    try {
      dispatch({
        type: CardTypeActionTypes.CREATE_CARD_TYPE_REQUEST
      });
      await handleCreateCardType(data);
      dispatch({
        type: CardTypeActionTypes.CREATE_CARD_TYPE_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Create Request failed, please try again.";

      dispatch({
        type: CardTypeActionTypes.CREATE_CARD_TYPE_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const setSelectedCardType =
  (data: CardTypeData | null) =>
  async (dispatch: Dispatch<CardTypesAction>) => {
    dispatch({
      type: CardTypeActionTypes.SET_SELECTED_CARD_TYPE,
      payload: data
    });
  };

export const loadManufacturers =
  () => async (dispatch: Dispatch<CardTypesAction>) => {
    try {
      dispatch({
        type: CardTypeActionTypes.FETCH_MANUFACTURERS_REQUEST
      });
      const manufacturerDetails = await fetchManufacturers();
      dispatch({
        type: CardTypeActionTypes.FETCH_MANUFACTURERS_SUCCESS,
        payload: manufacturerDetails
      });
    } catch (error: any) {
      dispatch({
        type: CardTypeActionTypes.FETCH_MANUFACTURERS_FAILURE,
        payload:
          error ||
          "Sorry! Fetch Manufacturers Request failed, please try again."
      });
    }
  };

export const updateCardType =
  (data: updateCardTypePayload) =>
  async (dispatch: Dispatch<CardTypesAction>) => {
    try {
      dispatch({
        type: CardTypeActionTypes.UPDATE_CARD_TYPE_REQUEST
      });
      await handleUpdateCardType(data);
      dispatch({
        type: CardTypeActionTypes.UPDATE_CARD_TYPE_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Update Request failed, please try again.";

      dispatch({
        type: CardTypeActionTypes.UPDATE_CARD_TYPE_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const DeleteCardTypes = (id: number) => async (dispatch: Dispatch) => {
  try {
    dispatch<CardTypesAction>({
      type: CardTypeActionTypes.DELETE_CARD_TYPES_REQUEST
    });
    const response = await handleCardTypesDelete(id);
    if (response) {
      dispatch<CardTypesAction>({
        type: CardTypeActionTypes.DELETE_CARD_TYPES_SUCCESS,
        payload: id
      });
    }
  } catch (err: any) {
    dispatch<CardTypesAction>({
      type: CardTypeActionTypes.DELETE_CARD_TYPES_FAILURE,
      payload: err.message
    });
  }
};
export const resetCardTypesErr = () => async (dispatch: Dispatch) => {
  dispatch<CardTypesAction>({
    type: CardTypeActionTypes.RESET_CARD_TYPES_ERR
  });
};

export const ArchiveCardTypes =
  (id: number | undefined, archiveState: boolean | undefined) =>
  async (dispatch: Dispatch) => {
    try {
      dispatch<CardTypesAction>({
        type: CardTypeActionTypes.ARCHIVE_CARD_TYPES_REQUEST
      });
      const response = await handleArchiveCardType(id, archiveState);
      if (response) {
        dispatch<CardTypesAction>({
          type: CardTypeActionTypes.ARCHIVE_CARD_TYPES_SUCCESS
        });
      }
    } catch (err: any) {
      dispatch<CardTypesAction>({
        type: CardTypeActionTypes.ARCHIVE_CARD_TYPES_FAILURE,
        payload: err.message
      });
    }
  };

export const resetCardTypes = () => async (dispatch: Dispatch) => {
  dispatch<CardTypesAction>({
    type: CardTypeActionTypes.RESET_CARD_TYPES
  });
};
