import { Dispatch } from "redux";
import { ExternalSystemsActionTypes } from "./types";
import {
  ExternalSystem,
  ExternalSystemPayload,
  ExternalSystemsAction
} from "../../models/externalSystems.model";
import {
  handleFetchExternalSystems,
  handleDeleteExternalSystem,
  handleArchiveExternalSystem,
  handleExternalSystemsCreate,
  handleExternalSystemsUpdate,
  handleExternalSystemExport
} from "../../services/ExternalSystemsApi";

export const fetchExternalSystems =
  (isArchive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEMS_REQUEST
      });
      const externalSystems = await handleFetchExternalSystems(isArchive);
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEMS_SUCCESS,
        payload: externalSystems
      });
    } catch (error: any) {
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEMS_FAILURE,
        payload: error
      });
    }
  };

export const setSelectedExternalSystem =
  (data: ExternalSystem | null) => async (dispatch: Dispatch) => {
    dispatch<ExternalSystemsAction>({
      type: ExternalSystemsActionTypes.SET_SELECTED_EXTERNAL_SYSTEMS,
      payload: data
    });
  };

export const createExternalSystem =
  (data: ExternalSystemPayload) => async (dispatch: Dispatch) => {
    try {
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.CREATE_EXTERNAL_SYSTEMS_REQUEST
      });
      await handleExternalSystemsCreate(data);
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.CREATE_EXTERNAL_SYSTEMS_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.CREATE_EXTERNAL_SYSTEMS_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const updateExternalSystem =
  (data: ExternalSystemPayload, id: string) => async (dispatch: Dispatch) => {
    try {
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.UPDATE_EXTERNAL_SYSTEMS_REQUEST
      });
      await handleExternalSystemsUpdate(data, id);
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.UPDATE_EXTERNAL_SYSTEMS_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.UPDATE_EXTERNAL_SYSTEMS_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const deleteExternalSystem =
  (imsiId: number) => async (dispatch: Dispatch) => {
    try {
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.DELETE_SELECTED_EXTERNAL_REQUEST
      });
      const response = await handleDeleteExternalSystem(imsiId);
      if (response) {
        dispatch<ExternalSystemsAction>({
          type: ExternalSystemsActionTypes.DELETE_SELECTED_EXTERNAL_SUCCESS,
          payload: imsiId
        });
      }
    } catch (error: any) {
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.DELETE_SELECTED_EXTERNAL_FAILURE,
        payload: "Sorry! Request failed, please try again." || error?.message
      });
    }
  };

export const archiveExternalSystem =
  (id: number, archive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.ARCHIVE_SELECTED_EXTERNAL_REQUEST
      });
      const response = await handleArchiveExternalSystem(id, archive);
      if (response) {
        dispatch<ExternalSystemsAction>({
          type: ExternalSystemsActionTypes.ARCHIVE_SELECTED_EXTERNAL_SUCCESS,
          payload: { id: id, archive: archive }
        });
      }
    } catch (error: any) {
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.ARCHIVE_SELECTED_EXTERNAL_FAILURE,
        payload: error
      });
    }
  };

export const fetchExtertnalSystemExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_REQUEST
      });
      const response = await handleExternalSystemExport(isArchived);
      if (response) {
        dispatch<ExternalSystemsAction>({
          type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_SUCCESS,
          payload: response
        });
      }
    } catch (error: any) {
      dispatch<ExternalSystemsAction>({
        type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_FAILURE,
        payload: error?.message
      });
    }
  };

export const resetExtertnalSystemErr = () => async (dispatch: Dispatch) => {
  dispatch<ExternalSystemsAction>({
    type: ExternalSystemsActionTypes.RESET_ExtertnalSystem_ERR
  });
};

export const resetExternalSystem = () => async (dispatch: Dispatch) => {
  dispatch<ExternalSystemsAction>({
    type: ExternalSystemsActionTypes.RESET_EXTERNAL_SYSTEM
  });
};
