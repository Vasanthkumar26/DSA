// @ts-nocheck
import { KittingArticle } from "../../models/kittingArticle.model";
import {
  handleFetchKittingArticles,
  handleKittingArticleExport,
  handleDeleteKittingArticle,
  handleArchiveKittingArticle,
  handleFetchOffers,
  handleCreateArticle,
  handleUpdateArticle
} from "../../services/kittingArticleApi";
import {
  FETCH_KITTING_ARTICLES_FAILURE,
  FETCH_KITTING_ARTICLES_REQUEST,
  FETCH_KITTING_ARTICLES_SUCCESS,
  SET_SELECTED_KITTING_ARTICLE,
  FETCH_KITTING_ARTICLES_EXPORT_FAILURE,
  FETCH_KITTING_ARTICLES_EXPORT_REQUEST,
  FETCH_KITTING_ARTICLES_EXPORT_SUCCESS,
  DELETE_KITTING_ARTICLES_REQUEST,
  DELETE_KITTING_ARTICLES_SUCCESS,
  DELETE_KITTING_ARTICLES_FAILURE,
  ARCHIVE_KITTING_ARTICLES_REQUEST,
  ARCHIVE_KITTING_ARTICLES_SUCCESS,
  ARCHIVE_KITTING_ARTICLES_FAILURE,
  ADD_ARTICLE_REQUEST,
  ADD_ARTICLE_SUCCESS,
  ADD_ARTICLE_FAILURE,
  ADD_ARTICLE_IN_STATE,
  ARTICLE_RESET,
  ARTICLE_ERROR_RESET,
  GET_OFFERS_REQUEST,
  GET_OFFERS_SUCCESS,
  GET_OFFERS_FAILURE,
  UPDATE_ARTICLE_IN_STATE,
  DELETE_KITTING_IN_STATE,
  RESET_DELETE_ARTICLE
} from "./types";

export const fetchKittingArticlesRequest = () => ({
  type: FETCH_KITTING_ARTICLES_REQUEST
});

export const fetchKittingArticlesSuccess = (
  kittingArticles: Array<KittingArticle>
) => ({
  type: FETCH_KITTING_ARTICLES_SUCCESS,
  payload: { kittingArticles }
});

export const fetchKittingArticlesFailure = (errorFetch) => ({
  type: FETCH_KITTING_ARTICLES_FAILURE,
  payload: { errorFetch }
});

export const setSelectedKittingArticle = (kittingArticle) => ({
  type: SET_SELECTED_KITTING_ARTICLE,
  payload: { kittingArticle }
});

export const deleteKittingArticlesRequest = () => ({
  type: DELETE_KITTING_ARTICLES_REQUEST
});

export const deleteKittingArticlesSuccess = (deletekittingArticles) => ({
  type: DELETE_KITTING_ARTICLES_SUCCESS,
  payload: { deletekittingArticles }
});

export const deleteKittingArticlesFailure = (error) => ({
  type: DELETE_KITTING_ARTICLES_FAILURE,
  payload: { error }
});

export const archiveKittingArticleRequest = () => ({
  type: ARCHIVE_KITTING_ARTICLES_REQUEST
});

export const archiveKittingArticlesSuccess = (archiveKittingArticles, id) => ({
  type: ARCHIVE_KITTING_ARTICLES_SUCCESS,
  payload: { archiveKittingArticles, id }
});

export const archiveKittingArticleFailure = (error) => ({
  type: ARCHIVE_KITTING_ARTICLES_FAILURE,
  payload: { error }
});

export const fetchKittingArticleExportRequest = () => ({
  type: FETCH_KITTING_ARTICLES_EXPORT_REQUEST
});

export const fetchKittingArticleExportSuccess = (message) => ({
  type: FETCH_KITTING_ARTICLES_EXPORT_SUCCESS,
  payload: { message: message }
});

export const fetchKittingArticleExportFailure = (error) => ({
  type: FETCH_KITTING_ARTICLES_EXPORT_FAILURE,
  payload: { error }
});

/*
============== Kitting Article Creation ==============
*/
export const addArticleRequest = () => ({
  type: ADD_ARTICLE_REQUEST
});

export const addArticleSuccess = (message) => ({
  type: ADD_ARTICLE_SUCCESS,
  payload: { message }
});

export const addArticleFailure = (error) => ({
  type: ADD_ARTICLE_FAILURE,
  payload: { error }
});

export const getOffersRequest = () => ({
  type: GET_OFFERS_REQUEST
});
export const getOffersSuccess = (offers) => ({
  type: GET_OFFERS_SUCCESS,
  payload: { offers }
});

export const getOffersFailure = (error) => ({
  type: GET_OFFERS_FAILURE,
  payload: { error }
});

export const articleReset = () => ({
  type: ARTICLE_RESET
});

export const errorReset = () => ({
  type: ARTICLE_ERROR_RESET
});

export const deleteReset = () => ({
  type: RESET_DELETE_ARTICLE
});

export const addKittingArticleInState = (kittingArticle) => ({
  type: ADD_ARTICLE_IN_STATE,
  payload: kittingArticle
});

export const updateKittingArticleInState = (kittingArticle) => ({
  type: UPDATE_ARTICLE_IN_STATE,
  payload: kittingArticle
});

export const deleteKittingArticleInState = (id) => ({
  type: DELETE_KITTING_IN_STATE,
  payload: { id }
});

export const deleteKittingArticleSuccess = (message) => ({
  type: DELETE_KITTING_ARTICLES_SUCCESS,
  payload: { message }
});
/*
============== Action Creators ==============
*/

export const fetchKittingArticles =
  (isArchived: boolean) => async (dispatch) => {
    try {
      dispatch(fetchKittingArticlesRequest());
      const kittingArticles = await handleFetchKittingArticles(isArchived);
      dispatch(fetchKittingArticlesSuccess(kittingArticles));
    } catch (error) {
      dispatch(fetchKittingArticlesFailure(error));
    }
  };

export const deleteKittingArticles = (kittingArticleId) => async (dispatch) => {
  try {
    dispatch(deleteKittingArticlesRequest());
    await handleDeleteKittingArticle(kittingArticleId);
    dispatch(deleteKittingArticleInState(kittingArticleId));
  } catch (err) {
    dispatch(deleteKittingArticlesFailure(err));
  }
};

export const archiveKittingArticle =
  (archive, kittingArticleId) => async (dispatch) => {
    try {
      dispatch(archiveKittingArticleRequest());
      await handleArchiveKittingArticle(archive, kittingArticleId);
      dispatch(archiveKittingArticlesSuccess(archive, kittingArticleId));
    } catch (err) {
      dispatch(archiveKittingArticleFailure(err));
    }
  };

export const fetchKittingArticlesExport =
  (isArchive: boolean) => async (dispatch) => {
    try {
      dispatch(fetchKittingArticleExportRequest());
      const response = await handleKittingArticleExport(isArchive);
      dispatch(
        fetchKittingArticleExportSuccess(response) // TODO: pass proper message
      );
    } catch (err) {
      dispatch(fetchKittingArticleExportFailure(err));
    }
  };

/*
============== Kitting Article Creation ==============
*/

export const createArticle = (data) => async (dispatch) => {
  try {
    dispatch(addArticleRequest());
    await handleCreateArticle(data);
    dispatch(addArticleSuccess("Added Successfully"));
  } catch (error) {
    if (error?.message) dispatch(addArticleFailure(error?.message));
    else dispatch(addArticleFailure("Error Ocurred"));
  }
};
export const updateArticle = (data, id) => async (dispatch) => {
  try {
    dispatch(addArticleRequest());
    await handleUpdateArticle(data, id);
    dispatch(addArticleSuccess("Updated Sucessfully"));
  } catch (error) {
    if (error?.message) dispatch(addArticleFailure(error?.message));
    else dispatch(addArticleFailure("Error Ocurred"));
  }
};

export const fetchOffers = (serviceProviderId) => async (dispatch) => {
  try {
    dispatch(getOffersRequest());
    const data = await handleFetchOffers(serviceProviderId);
    dispatch(getOffersSuccess(data));
  } catch (error) {
    dispatch(getOffersFailure("Error Ocurred"));
  }
};
