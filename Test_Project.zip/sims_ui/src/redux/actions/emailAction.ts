import { Dispatch } from "redux";
import { EmailActionTypes } from "./types";
import { EmailPayload, EmailAction, Email } from "../../models/email.model";

import {
  handleEmailExport,
  handleFetchEmail,
  handleEmailUpdate
} from "../../services/emailApi";

export const fetchEmail =
  (isArchive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<EmailAction>({
        type: EmailActionTypes.FETCH_EMAIL_REQUEST
      });
      const formFactor = await handleFetchEmail(isArchive);
      dispatch<EmailAction>({
        type: EmailActionTypes.FETCH_EMAIL_SUCCESS,
        payload: formFactor
      });
    } catch (error: any) {
      dispatch<EmailAction>({
        type: EmailActionTypes.FETCH_EMAIL_FAILURE,
        payload: error
      });
    }
  };

export const setSelectedEmail =
  (data: Email | null) => async (dispatch: Dispatch) => {
    dispatch<EmailAction>({
      type: EmailActionTypes.SET_SELECTED_EMAIL,
      payload: data
    });
  };

export const updateEmail =
  (data: EmailPayload, id: string) => async (dispatch: Dispatch) => {
    try {
      dispatch<EmailAction>({
        type: EmailActionTypes.UPDATE_EMAIL_REQUEST
      });
      await handleEmailUpdate(data, id);
      dispatch<EmailAction>({
        type: EmailActionTypes.UPDATE_EMAIL_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<EmailAction>({
        type: EmailActionTypes.UPDATE_EMAIL_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const resetEmailErr = () => async (dispatch: Dispatch) => {
  dispatch<EmailAction>({
    type: EmailActionTypes.RESET_EMAIL_ERR
  });
};

export const fetchEmailExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<EmailAction>({
        type: EmailActionTypes.FETCH_EMAIL_EXPORT_REQUEST
      });
      const response = await handleEmailExport(isArchived);
      if (response) {
        dispatch<EmailAction>({
          type: EmailActionTypes.FETCH_EMAIL_EXPORT_SUCCESS,
          payload: response
        });
      }
    } catch (error: any) {
      dispatch<EmailAction>({
        type: EmailActionTypes.FETCH_EMAIL_EXPORT_FAILURE,
        payload: error?.message
      });
    }
  };

export const resetEmail = () => async (dispatch: Dispatch) => {
  dispatch<EmailAction>({
    type: EmailActionTypes.RESET_EMAIL
  });
};
