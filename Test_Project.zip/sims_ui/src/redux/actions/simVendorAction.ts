import { Dispatch } from "redux";
import { SimVendorActionTypes } from "./types";
import { SimVendor, SimVendorAction } from "../../models/simVendor.model";
import {
  handleFetchSimVendors,
  handleDeleteSimVendor,
  handleSimVendorExport,
  handleCreateSimVendor,
  handleUpdateSimVendor,
  loadExternalName,
  handleArchiveSimVendor
} from "../../services/SimVendorApi";

export const fetchSimVendors =
  (isArchive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_REQUEST
      });
      const simVendors = await handleFetchSimVendors(isArchive);
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_SUCCESS,
        payload: simVendors
      });
    } catch (error: any) {
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_FAILURE,
        payload: error
      });
    }
  };

export const setSelectedSimVendor =
  (data: SimVendor | null) => async (dispatch: Dispatch) => {
    dispatch<SimVendorAction>({
      type: SimVendorActionTypes.SET_SELECTED_SIM_VENDOR,
      payload: data
    });
  };
export const loadExternalNameList =
  () => async (dispatch: Dispatch<SimVendorAction>) => {
    try {
      dispatch({
        type: SimVendorActionTypes.FETCH_EXTERNAL_REQUEST
      });
      const manufacturerDetails = await loadExternalName();
      dispatch({
        type: SimVendorActionTypes.FETCH_EXTERNAL_SUCCESS,
        payload: manufacturerDetails
      });
    } catch (error: any) {
      dispatch({
        type: SimVendorActionTypes.FETCH_EXTERNAL_FAILURE,
        payload: error
      });
    }
  };

export const deleteSimVendor = (Id: number) => async (dispatch: Dispatch) => {
  try {
    dispatch<SimVendorAction>({
      type: SimVendorActionTypes.DELETE_SIM_VENDOR_REQUEST
    });
    const response = await handleDeleteSimVendor(Id);
    if (response) {
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.DELETE_SIM_VENDOR_SUCCESS,
        payload: Id
      });
    }
  } catch (error: any) {
    dispatch<SimVendorAction>({
      type: SimVendorActionTypes.DELETE_SIM_VENDOR_FAILURE,
      payload: "Sorry! Request failed, please try again." || error?.message
    });
  }
};

export const archiveSimVendor =
  (id: number, archive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.ARCHIVE_SIM_VENDOR_REQUEST
      });
      const response = await handleArchiveSimVendor(id, archive);
      if (response) {
        dispatch<SimVendorAction>({
          type: SimVendorActionTypes.ARCHIVE_SIM_VENDOR_SUCCESS
        });
      }
    } catch (error: any) {
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.DELETE_SIM_VENDOR_FAILURE,
        payload: "Sorry! Request failed, please try again." || error?.message
      });
    }
  };

export const fetchSimVendorExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_REQUEST
      });
      const reponse = await handleSimVendorExport(isArchived);
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_SUCCESS,
        payload: reponse
      });
    } catch (error: any) {
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_ERROR,
        payload: error?.message
      });
    }
  };
export const createSimVendor =
  (data: SimVendor) => async (dispatch: Dispatch) => {
    try {
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.CREATE_SIM_VENDOR_REQUEST
      });
      await handleCreateSimVendor(data);
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.CREATE_SIM_VENDOR_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.CREATE_SIM_VENDOR_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const updateSimVendor =
  (data: SimVendor) => async (dispatch: Dispatch) => {
    try {
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.UPDATE_ISIM_VENDORE_REQUEST
      });
      await handleUpdateSimVendor(data);
      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.UPDATE_SIM_VENDOR_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<SimVendorAction>({
        type: SimVendorActionTypes.UPDATE_SIM_VENDORE_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };
export const resetSimVendorError = () => async (dispatch: Dispatch) => {
  dispatch<SimVendorAction>({
    type: SimVendorActionTypes.RESET_ERROR
  });
};
export const resetSimVendorForm = () => async (dispatch: Dispatch) => {
  dispatch<SimVendorAction>({
    type: SimVendorActionTypes.RESET_FORM
  });
};

export const resetSimVendor = () => async (dispatch: Dispatch) => {
  dispatch<SimVendorAction>({
    type: SimVendorActionTypes.RESET_SIM_VENDOR
  });
};
