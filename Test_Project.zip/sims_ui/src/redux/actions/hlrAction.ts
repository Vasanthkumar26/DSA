import { Dispatch } from "redux";
import { CreateHLRRequestBody, Hlr, HlrAction } from "../../models";
import {
  handleFetchHlrs,
  handleHLRCreate,
  handleHLRExport,
  handleDeleteHLRArticle,
  handleHLRUpdate,
  handleArchiveHLR
} from "../../services/HLRApi";
import { HlrActionTypes } from "./types";

export const fetchHlrs = (isArchive: boolean) => async (dispatch: Dispatch) => {
  try {
    dispatch<HlrAction>({ type: HlrActionTypes.FETCH_HLR_REQUEST });
    const hlrs = await handleFetchHlrs(isArchive);
    dispatch<HlrAction>({
      type: HlrActionTypes.FETCH_HLR_SUCCESS,
      payload: hlrs
    });
  } catch (error: any) {
    dispatch<HlrAction>({
      type: HlrActionTypes.FETCH_HLR_FAILURE,
      payload: error
    });
  }
};

export const fetchHLRExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<HlrAction>({ type: HlrActionTypes.FETCH_HLR_EXPORT_REQUEST });
      const response = await handleHLRExport(isArchived);
      dispatch<HlrAction>({
        type: HlrActionTypes.FETCH_HLR_EXPORT_SUCCESS,
        payload: response
      });
    } catch (error: any) {
      dispatch<HlrAction>({
        type: HlrActionTypes.FETCH_HLR_EXPORT_FAILURE,
        payload: error.message
      });
    }
  };

export const deleteHLR =
  (hlrArticleId: number) => async (dispatch: Dispatch) => {
    try {
      dispatch<HlrAction>({ type: HlrActionTypes.DELETE_HLR_REQUEST });
      const response = await handleDeleteHLRArticle(hlrArticleId);
      if (response) {
        dispatch<HlrAction>({
          type: HlrActionTypes.DELETE_HLR_SUCCESS,
          payload: hlrArticleId
        });
      }
    } catch (error: any) {
      dispatch<HlrAction>({
        type: HlrActionTypes.DELETE_HLR_FAILURE,
        payload: error
      });
    }
  };

export const createHLR =
  (data: CreateHLRRequestBody) => async (dispatch: Dispatch) => {
    try {
      dispatch<HlrAction>({ type: HlrActionTypes.CREATE_HLR_REQUEST });
      const response: Hlr = await handleHLRCreate(data);
      dispatch<HlrAction>({
        type: HlrActionTypes.CREATE_HLR_SUCCESS,
        payload: response
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<HlrAction>({
        type: HlrActionTypes.CREATE_HLR_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const archiveHlrs =
  (hlrId: number, isArchive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<HlrAction>({
        type: HlrActionTypes.ARCHIVE_HLR_REQUEST
      });
      await handleArchiveHLR(hlrId, isArchive);
      dispatch<HlrAction>({
        type: HlrActionTypes.ARCHIVE_HLR_SUCCESS,
        payload: { id: hlrId, archived: !isArchive }
      });
    } catch (error: any) {
      dispatch<HlrAction>({
        type: HlrActionTypes.ARCHIVE_HLR_FAILURE,
        payload: error
      });
    }
  };

export const updateHLR =
  (data: CreateHLRRequestBody, id: string) => async (dispatch: Dispatch) => {
    try {
      dispatch<HlrAction>({ type: HlrActionTypes.UPDATE_HLR_REQUEST });
      await handleHLRUpdate(data, id);
      dispatch<HlrAction>({
        type: HlrActionTypes.UPDATE_HLR_SUCCESS,
        payload: { id, ...data }
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<HlrAction>({
        type: HlrActionTypes.UPDATE_HLR_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const resetHLRErr = () => async (dispatch: Dispatch) => {
  dispatch<HlrAction>({ type: HlrActionTypes.RESET_HLR_ERR });
};

export const resetHLR = () => async (dispatch: Dispatch) => {
  dispatch<HlrAction>({ type: HlrActionTypes.RESET_HLR });
};

export const setSelectedHLR =
  (data: Hlr | null) => async (dispatch: Dispatch) => {
    dispatch<HlrAction>({
      type: HlrActionTypes.SET_SELECTED_HLR,
      payload: data
    });
  };
