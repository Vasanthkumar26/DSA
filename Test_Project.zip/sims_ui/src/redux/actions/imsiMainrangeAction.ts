import { Dispatch } from "redux";
import {
  ICreateIMSIMainRangeRequestBody,
  ImsiMainrange,
  ImsiMainrangeAction,
  ImsiSubAndMainRangeStatusRequestPayload
} from "../../models";
import { ImsiMainrangeActionTypes } from "./types";

import {
  handleFetchImsiMainranges,
  handleIMSIMainRangeCreate,
  handleIMSIMainRangeUpdate,
  handleDeleteImsiMainrange,
  handleIMSIMainRangeExport,
  handleArchiveImsiMainrange,
  handleFetchImsiMainRangeStatusTable
} from "../../services/ImsiMainrangeApi";

export const setSelectedImsiMainrange =
  (imsiMainranges: ImsiMainrange | null) => (dispatch: Dispatch) => {
    dispatch<ImsiMainrangeAction>({
      type: ImsiMainrangeActionTypes.SET_SELECTED_IMSI_MAINRANGE,
      payload: imsiMainranges
    });
  };

export const fetchImsiMainranges =
  (isArchive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_REQUEST
      });
      const imsiMainranges = await handleFetchImsiMainranges(isArchive);
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_SUCCESS,
        payload: imsiMainranges
      });
    } catch (error: any) {
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_FAILURE,
        payload: error
      });
    }
  };
export const deleteImsiMainrange =
  (imsiId: number) => async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.DELETE_IMSI_REQUEST
      });
      const response = await handleDeleteImsiMainrange(imsiId);
      if (response) {
        dispatch<ImsiMainrangeAction>({
          type: ImsiMainrangeActionTypes.DELETE_IMSI_SUCCESS,
          payload: imsiId
        });
      }
    } catch (error: any) {
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.DELETE_IMSI_FAILURE,
        payload: error
      });
    }
  };

export const archiveImsiMainrange =
  (imsiMainRangeId: number, archive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.ARCHIVE_IMSI_MAINRANGE_REQUEST
      });
      await handleArchiveImsiMainrange(imsiMainRangeId, archive);
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.ARCHIVE_IMSI_MAINRANGE_SUCCESS,
        payload: { imsiMainRangeId: imsiMainRangeId, archive: archive }
      });
    } catch (error: any) {
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.ARCHIVE_IMSI_MAINRANGE_FAILURE,
        payload: error
      });
    }
  };

export const createIMSIMainRange =
  (data: ICreateIMSIMainRangeRequestBody) => async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.CREATE_IMSI_MAINRANGE_REQUEST
      });
      await handleIMSIMainRangeCreate(data);
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.CREATE_IMSI_MAINRANGE_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.CREATE_IMSI_MAINRANGE_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const updateIMSIMainRange =
  (data: ICreateIMSIMainRangeRequestBody, id: string) =>
  async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.UPDATE_IMSI_MAINRANGE_REQUEST
      });
      await handleIMSIMainRangeUpdate(data, id);
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.UPDATE_IMSI_MAINRANGE_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.UPDATE_IMSI_MAINRANGE_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const resetIMSIMainRangeErr = () => async (dispatch: Dispatch) => {
  dispatch<ImsiMainrangeAction>({
    type: ImsiMainrangeActionTypes.RESET_IMSI_MAINRANGE_ERR
  });
};

export const fetchimsiMainRangeExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_REQUEST
      });
      const reponse = await handleIMSIMainRangeExport(isArchived);
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_SUCCESS,
        payload: reponse
      });
    } catch (error: any) {
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_FAILURE,
        payload: error.message
      });
    }
  };

export const resetIMSIMainRange = () => async (dispatch: Dispatch) => {
  dispatch<ImsiMainrangeAction>({
    type: ImsiMainrangeActionTypes.RESET_IMSI_MAINRANGE
  });
};

export const fetchIMSIMainRangeStatusTable =
  (payload: ImsiSubAndMainRangeStatusRequestPayload) =>
  async (dispatch: Dispatch) => {
    try {
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_STATUS_REQUEST
      });
      const res = await handleFetchImsiMainRangeStatusTable(payload);
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_STATUS_SUCCESS,
        payload: res
      });
    } catch (error: any) {
      dispatch<ImsiMainrangeAction>({
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_STATUS_FAILURE
      });
    }
  };
