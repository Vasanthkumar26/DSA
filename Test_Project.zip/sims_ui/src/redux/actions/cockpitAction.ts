import { Dispatch } from "redux";
import { CockpitActionTypes } from "./types";
import { Cockpit, CockpitAction } from "../../models";
import {
  handleCancelKittingOrder,
  handleFetchAllDocumentList,
  handleFetchCockpit,
  handleCancelSimOrder
} from "../../services/cockpitApi";

export const fetchCockpit = () => async (dispatch: Dispatch) => {
  try {
    dispatch<CockpitAction>({
      type: CockpitActionTypes.FETCH_COCKPIT_REQUEST
    });
    const cockpits = await handleFetchCockpit();
    dispatch<CockpitAction>({
      type: CockpitActionTypes.FETCH_COCKPIT_SUCCESS,
      payload: cockpits
    });
  } catch (error: any) {
    dispatch<CockpitAction>({
      type: CockpitActionTypes.FETCH_COCKPIT_FAILURE,
      payload: error
    });
  }
};

export const setSelectedCockpit =
  (data: Cockpit | null) => async (dispatch: Dispatch) => {
    dispatch<CockpitAction>({
      type: CockpitActionTypes.SET_SELECTED_COCKPIT,
      payload: data
    });
  };

export const cancelCockpit =
  (Id: number, StopMessage: string) => async (dispatch: Dispatch) => {
    try {
      dispatch<CockpitAction>({
        type: CockpitActionTypes.CANCEL_COCKPIT_REQUEST
      });
      const response = await handleCancelKittingOrder(Id, StopMessage);
      if (response) {
        dispatch<CockpitAction>({
          type: CockpitActionTypes.CANCEL_COCKPIT_SUCCESS,
          payload: Id
        });
      }
    } catch (error: any) {
      dispatch<CockpitAction>({
        type: CockpitActionTypes.CANCEL_COCKPIT_FAILURE,
        payload: "Sorry! Request failed, please try again." || error?.message
      });
    }
  };

export const fetchDocumentTable =
  (id: number) => async (dispatch: Dispatch) => {
    try {
      dispatch<CockpitAction>({
        type: CockpitActionTypes.FETCH_DOCUMENT_TABLE_REQUEST
      });
      const response = await handleFetchAllDocumentList(id);
      if (response) {
        dispatch<CockpitAction>({
          type: CockpitActionTypes.FETCH_DOCUMENT_TABLE_SUCCESS,
          payload: response
        });
      }
    } catch (error) {
      dispatch<CockpitAction>({
        type: CockpitActionTypes.FETCH_DOCUMENT_TABLE_FAILURE
      });
    }
  };

export const cancelSimOrders =
  (Id: number, StopMessage: string, cancelType: number) =>
  async (dispatch: Dispatch) => {
    try {
      dispatch<CockpitAction>({
        type: CockpitActionTypes.CANCEL_SIM_REQUEST
      });
      const response = await handleCancelSimOrder(Id, StopMessage, cancelType);
      if (response) {
        dispatch<CockpitAction>({
          type: CockpitActionTypes.CANCEL_SIM_SUCCESS,
          payload: Id
        });
      }
    } catch (error: any) {
      dispatch<CockpitAction>({
        type: CockpitActionTypes.CANCEL_SIM_FAILURE,
        payload: "Sorry! Request failed, please try again." || error?.message
      });
    }
  };
