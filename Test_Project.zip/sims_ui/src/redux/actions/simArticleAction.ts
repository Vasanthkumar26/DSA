import { Dispatch } from "redux";
import { SimArticleAction, SimArticles } from "../../models/simArticle.model";
import { SimArticleActionTypes } from "./types";
import {
  handleArchiveSimArticle,
  handleCreateSimArticle,
  handleFetchSimArticles,
  handleSimArticleExport,
  handleDeleteSimArticle,
  handleUpdateSimArticle
} from "../../services/simArticleApi";

export const fetchSimArticleExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<SimArticleAction>({
        type: SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_REQUEST
      });
      const response = await handleSimArticleExport(isArchived);
      if (response) {
        dispatch<SimArticleAction>({
          type: SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_SUCCESS,
          payload: response
        });
      }
    } catch (error: any) {
      dispatch<SimArticleAction>({
        type: SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_FAILURE,
        payload: error?.message
      });
    }
  };

export const fetchSimArticles =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<SimArticleAction>({
        type: SimArticleActionTypes.FETCH_SIM_ARTICLES_REQUEST
      });
      const simArticles = await handleFetchSimArticles(isArchived);
      dispatch<SimArticleAction>({
        type: SimArticleActionTypes.FETCH_SIM_ARTICLES_SUCCESS,
        payload: simArticles
      });
    } catch (error: any) {
      dispatch<SimArticleAction>({
        type: SimArticleActionTypes.FETCH_SIM_ARTICLES_FAILURE,
        payload: error?.message
      });
    }
  };

export const archiveSimArticle =
  (id: number, archive: boolean, name: string) =>
  async (dispatch: Dispatch) => {
    try {
      dispatch<SimArticleAction>({
        type: SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_REQUEST
      });

      //await mockArchiveSimArticle(archive);
      await handleArchiveSimArticle(id, archive);
      dispatch<SimArticleAction>({
        type: SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_SUCCESS,
        payload: { id: id, archived: !archive, name: name }
      });
    } catch (error: any) {
      dispatch<SimArticleAction>({
        type: SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_FAILURE,
        payload: { name: name }
      });
    }
  };

export const deleteSimArticle = (id: number) => async (dispatch: Dispatch) => {
  try {
    dispatch<SimArticleAction>({
      type: SimArticleActionTypes.DELETE_SIM_ARTICLES_REQUEST
    });
    const response = await handleDeleteSimArticle(id);
    if (response) {
      dispatch<SimArticleAction>({
        type: SimArticleActionTypes.DELETE_SIM_ARTICLES_SUCCESS,
        payload: id
      });
    }
  } catch (error: any) {
    dispatch<SimArticleAction>({
      type: SimArticleActionTypes.DELETE_SIM_ARTICLES_FAILURE,
      payload: "Sorry! Request failed, please try again." || error?.message
    });
  }
};

export const setSelectedSimArticle =
  (data: SimArticles | null) => async (dispatch: Dispatch) => {
    dispatch<SimArticleAction>({
      type: SimArticleActionTypes.SET_SIM_ARTICLE,
      payload: data
    });
  };

export const createSimArticle = (data: any) => async (dispatch: Dispatch) => {
  try {
    dispatch<SimArticleAction>({
      type: SimArticleActionTypes.CREATE_UPDATE_SIM_ARTICLE_REQUEST
    });
    const res = await handleCreateSimArticle(data);
    if (res) {
      dispatch<SimArticleAction>({
        type: SimArticleActionTypes.CREATE_UPDATE_SIM_ARTICLE_SUCCESS,
        payload: res
      });
    }
  } catch (error: any) {
    dispatch<SimArticleAction>({
      type: SimArticleActionTypes.RESET_MESSAGE
    });
  }
};

export const updateSimArticle =
  (id: number, data: any) => async (dispatch: Dispatch) => {
    try {
      dispatch<SimArticleAction>({
        type: SimArticleActionTypes.CREATE_UPDATE_SIM_ARTICLE_REQUEST
      });
      const res = await handleUpdateSimArticle(id, data);
      if (res) {
        dispatch<SimArticleAction>({
          type: SimArticleActionTypes.CREATE_UPDATE_SIM_ARTICLE_SUCCESS,
          payload: res
        });
      }
    } catch (error: any) {
      dispatch<SimArticleAction>({
        type: SimArticleActionTypes.RESET_MESSAGE
      });
    }
  };

export const resetSimArticle = () => async (dispatch: Dispatch) => {
  dispatch<SimArticleAction>({
    type: SimArticleActionTypes.RESET_MESSAGE
  });
};
