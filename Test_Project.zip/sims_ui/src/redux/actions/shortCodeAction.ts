import { Dispatch } from "redux";
import { ShortCodeActionTypes } from "./types";
import {
  ShortCode,
  ShortCodePayload,
  ShortCodeAction
} from "../../models/shortCode.model";
import {
  handleFetchShortCode,
  handleShortCodeCreate,
  handleShortCodeUpdate,
  handleDeleteShortCode,
  handleArchiveShortCode,
  handleShortCodeExport,
  loadShortCodeSPID
} from "../../services/ShortCodeApi";

export const fetchShortCode =
  (isArchive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.FETCH_SHORT_CODE_REQUEST
      });
      const shortCode = await handleFetchShortCode(isArchive);
      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.FETCH_SHORT_CODE_SUCCESS,
        payload: shortCode
      });
    } catch (error: any) {
      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.FETCH_SHORT_CODE_FAILURE,
        payload: error
      });
    }
  };

export const setSelectedShortCode =
  (data: ShortCode | null) => async (dispatch: Dispatch) => {
    dispatch<ShortCodeAction>({
      type: ShortCodeActionTypes.SET_SELECTED_SHORT_CODE,
      payload: data
    });
  };

export const createShortCode =
  (data: ShortCodePayload) => async (dispatch: Dispatch) => {
    try {
      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.CREATE_SHORT_CODE_REQUEST
      });
      await handleShortCodeCreate(data);
      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.CREATE_SHORT_CODE_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.CREATE_SHORT_CODE_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const updateShortCode =
  (data: ShortCodePayload, id: string) => async (dispatch: Dispatch) => {
    try {
      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.UPDATE_SHORT_CODE_REQUEST
      });
      await handleShortCodeUpdate(data, id);
      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.UPDATE_SHORT_CODE_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.UPDATE_SHORT_CODE_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const deleteShortCode = (spid: string) => async (dispatch: Dispatch) => {
  try {
    dispatch<ShortCodeAction>({
      type: ShortCodeActionTypes.DELETE_SELECTED_SHORTCODE_REQUEST
    });
    const response = await handleDeleteShortCode(spid);
    if (response) {
      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.DELETE_SELECTED_SHORTCODE_SUCCESS,
        payload: spid
      });
    }
  } catch (error: any) {
    dispatch<ShortCodeAction>({
      type: ShortCodeActionTypes.DELETE_SELECTED_SHORTCODE_FAILURE,
      payload: "Sorry! Request failed, please try again." || error?.message
    });
  }
};

export const archiveShortCode =
  (id: string, archive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.ARCHIVE_SELECTED_SHORTCODE_REQUEST
      });
      const response = await handleArchiveShortCode(id, archive);
      if (response) {
        dispatch<ShortCodeAction>({
          type: ShortCodeActionTypes.ARCHIVE_SELECTED_SHORTCODE_SUCCESS,
          payload: { id: id, archive: archive }
        });
      }
    } catch (error: any) {
      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.ARCHIVE_SELECTED_SHORTCODE_FAILURE,
        payload: error
      });
    }
  };

export const fetchShortCodeExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.FETCH_SHORT_CODE_EXPORT_REQUEST
      });
      const response = await handleShortCodeExport(isArchived);
      if (response) {
        dispatch<ShortCodeAction>({
          type: ShortCodeActionTypes.FETCH_SHORT_CODE_EXPORT_SUCCESS,
          payload: response
        });
      }
    } catch (error: any) {
      dispatch<ShortCodeAction>({
        type: ShortCodeActionTypes.FETCH_SHORT_CODE_EXPORT_FAILURE,
        payload: error?.message
      });
    }
  };

export const resetShortCodeErr = () => async (dispatch: Dispatch) => {
  dispatch<ShortCodeAction>({
    type: ShortCodeActionTypes.RESET_SHORTCODE_ERR
  });
};

export const resetShortCode = () => async (dispatch: Dispatch) => {
  dispatch<ShortCodeAction>({
    type: ShortCodeActionTypes.RESET_SHORT_CODE
  });
};

export const loadShortCodeSPIDList =
  () => async (dispatch: Dispatch<ShortCodeAction>) => {
    try {
      dispatch({
        type: ShortCodeActionTypes.FETCH_ShortCode_REQUEST
      });
      const response = await loadShortCodeSPID();
      dispatch({
        type: ShortCodeActionTypes.FETCH_ShortCode_SUCCESS,
        payload: response
      });
    } catch (error: any) {
      dispatch({
        type: ShortCodeActionTypes.FETCH_ShortCode_FAILURE,
        payload: error
      });
    }
  };
