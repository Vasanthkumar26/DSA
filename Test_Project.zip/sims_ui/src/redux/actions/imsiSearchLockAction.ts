import { Dispatch } from "redux";
import { ImsiRangesActionTypes } from "./types";
import { ImsiRange, ImsiRangesAction } from "../../models/imsiSearchLock";
import { handleFetchImsiRanges } from "../../services/imsiSearchLockApi";

export const fetchImsiRanges = () => async (dispatch: Dispatch) => {
  try {
    dispatch<ImsiRangesAction>({
      type: ImsiRangesActionTypes.FETCH_IMSI_RANGES_REQUEST
    });
    const imsiRanges = await handleFetchImsiRanges();
    dispatch<ImsiRangesAction>({
      type: ImsiRangesActionTypes.FETCH_IMSI_RANGES_SUCCESS,
      payload: imsiRanges
    });
  } catch (error: any) {
    dispatch<ImsiRangesAction>({
      type: ImsiRangesActionTypes.FETCH_IMSI_RANGES_FAILURE,
      payload: error
    });
  }
};

export const setSelectedImsiRange =
  (data: ImsiRange | null) => async (dispatch: Dispatch) => {
    dispatch<ImsiRangesAction>({
      type: ImsiRangesActionTypes.SET_SELECTED_IMSI_RANGES,
      payload: data
    });
  };
