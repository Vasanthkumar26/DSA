import { getNewLangAfterToggle } from "../../utils/common";
import { LanguageActionType } from "./types";

export const toggleLanguage = (currentLang: string) => {
  localStorage.setItem("language", getNewLangAfterToggle(currentLang));
  return {
    type: LanguageActionType.TOGGLE_LANGUAGE,
  };
};
