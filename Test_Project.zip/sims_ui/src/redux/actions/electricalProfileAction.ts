import { Dispatch } from "redux";
import {
  ElectricalProfileAction,
  ElectricalProfile,
  ElectricalProfileRequestPayload
} from "../../models";
import { ElectricalProfileActionTypes } from "./types";
import {
  handleCreateElectricalProfile,
  handleDeleteElectricalProfile,
  handleElectricalProfileExport,
  handleFetchElectricalProfile,
  handleUpdateElectricalProfile,
  handleArchiveElectricalProfile
} from "../../services/electricalProfileApi";

export const setSelectedElectricProfile =
  (electricalProfile: ElectricalProfile | null) => (dispatch: Dispatch) => {
    dispatch<ElectricalProfileAction>({
      type: ElectricalProfileActionTypes.SET_SELECTED_EP,
      payload: electricalProfile
    });
  };

export const resetEPCreateUpdateState = () => (dispatch: Dispatch) => {
  dispatch<ElectricalProfileAction>({
    type: ElectricalProfileActionTypes.RESET_EP_CREATE_UPDATE_STATE
  });
};

export const fetchElectricalProfiles =
  (isArchive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.FETCH_REQUEST
      });
      const electricalProfile = await handleFetchElectricalProfile(isArchive);
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.FETCH_SUCCESS,
        payload: electricalProfile
      });
    } catch (error: any) {
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.FETCH_FAILURE,
        payload: error
      });
    }
  };

export const fetchElectricalProfileExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.FETCH_EP_EXPORT_REQUEST
      });
      const response = await handleElectricalProfileExport(isArchived);
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.FETCH_EP_EXPORT_SUCCESS,
        payload: response
      });
    } catch (error: any) {
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.FETCH_EP_EXPORT_FAILURE,
        payload: error?.message
      });
    }
  };
export const deleteElectricalProfile =
  (id: number) => async (dispatch: Dispatch) => {
    try {
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.EP_DELETE_REQUEST
      });
      const response = await handleDeleteElectricalProfile(id);
      if (response) {
        dispatch<ElectricalProfileAction>({
          type: ElectricalProfileActionTypes.EP_DELETE_SUCCESS,
          payload: id
        });
      }
    } catch (error: any) {
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.EP_DELETE_FAILURE,
        payload: "Sorry! Request failed, please try again." || error?.message
      });
    }
  };

export const createElectricalProfile =
  (payload: ElectricalProfileRequestPayload) => async (dispatch: Dispatch) => {
    try {
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.CREATE_EP_REQUEST
      });
      const res = await handleCreateElectricalProfile(payload);
      if (res) {
        dispatch<ElectricalProfileAction>({
          type: ElectricalProfileActionTypes.CREATE_EP_SUCCESS,
          payload: res
        });
      }
    } catch (error: any) {
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.CREATE_EP_ERROR,
        payload: error?.message || "something went wrong"
      });
    }
  };

export const archiveElectricalProfile =
  (id: number, archive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.ARCHIVE_EP_REQUEST
      });
      const response = await handleArchiveElectricalProfile(id, archive);
      if (response) {
        dispatch<ElectricalProfileAction>({
          type: ElectricalProfileActionTypes.ARCHIVE_EP_SUCCESS,
          payload: !archive ? "Successfully Archived" : "Successfully Activated"
        });
      }
    } catch (error: any) {
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.ARCHIVE_EP_ERROR,
        payload: error
      });
    }
  };

export const updateElectricalProfile =
  (payload: ElectricalProfileRequestPayload) => async (dispatch: Dispatch) => {
    try {
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.UPDATE_EP_REQUEST
      });
      const res = await handleUpdateElectricalProfile(payload);
      if (res) {
        dispatch<ElectricalProfileAction>({
          type: ElectricalProfileActionTypes.UPDATE_EP_SUCCESS,
          payload: res
        });
      }
    } catch (error: any) {
      dispatch<ElectricalProfileAction>({
        type: ElectricalProfileActionTypes.UPDATE_EP_FAILURE,
        payload: error?.message
      });
    }
  };

export const resetElectricalProfile = () => async (dispatch: Dispatch) => {
  dispatch<ElectricalProfileAction>({
    type: ElectricalProfileActionTypes.RESET_EP
  });
};
