import { Dispatch } from "redux";
import {
  DeliveryAddress,
  DeliveryAddressAction
} from "../../models/deliveryAddress.model";
import { DeliveryAddressActionTypes } from "./types";
import {
  handleFetchDeliveryAddress,
  handleCreateDeliveryAddress,
  handleDeleteDeliveryAddress,
  handleArchiveDeliveryAddress,
  handleUpdateDeliveryAddress,
  handleDeliveryAddressExport,
  loadPartnerAddress
} from "../../services/deliveryAddressApi";
import { ISelectionOption } from "../../models";

export const fetchDeliverAddresses =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_REQUEST
      });
      const deliveryAddresses = await handleFetchDeliveryAddress(isArchived);
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_SUCCESS,
        payload: deliveryAddresses
      });
    } catch (error: any) {
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_FAILURE,
        payload: error?.message
      });
    }
  };

export const setSelectedDeliveryAddress =
  (data: DeliveryAddress | null) => async (dispatch: Dispatch) => {
    dispatch<DeliveryAddressAction>({
      type: DeliveryAddressActionTypes.SET_SELECTED_DELIVERY_ADDRESS,
      payload: data
    });
  };
export const deleteDeliveryAddress =
  (id: number) => async (dispatch: Dispatch) => {
    try {
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.DELETE_DELIVERY_ADDRESS_REQUEST
      });
      const response = await handleDeleteDeliveryAddress(id);
      if (response) {
        dispatch<DeliveryAddressAction>({
          type: DeliveryAddressActionTypes.DELETE_DELIVERY_ADDRESS_SUCCESS,
          payload: id
        });
      }
    } catch (error: any) {
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.DELETE_DELIVERY_ADDRESS_FAILURE,
        payload: "Sorry! Request failed, please try again." || error?.message
      });
      throw new Error(error);
    }
  };
export const loadPartnerAddressList =
  () => async (dispatch: Dispatch<DeliveryAddressAction>) => {
    try {
      dispatch({
        type: DeliveryAddressActionTypes.FETCH_PartnerAddress_REQUEST
      });
      const manufacturerDetails: ISelectionOption[] =
        await loadPartnerAddress();
      dispatch({
        type: DeliveryAddressActionTypes.FETCH_PartnerAddress_SUCCESS,
        payload: manufacturerDetails
      });
    } catch (error: any) {
      dispatch({
        type: DeliveryAddressActionTypes.FETCH_PartnerAddress_FAILURE,
        payload: error
      });
    }
  };
export const archiveDeliveryAddress =
  (id: number, archive: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.ARCHIVE_DELIVERY_ADDRESS_REQUEST
      });
      const response = await handleArchiveDeliveryAddress(id, archive);
      if (response) {
        dispatch<DeliveryAddressAction>({
          type: DeliveryAddressActionTypes.ARCHIVE_DELIVERY_ADDRESS_SUCCESS,
          payload: { id: id, archive: archive }
        });
      }
    } catch (error: any) {
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.ARCHIVE_DELIVERY_ADDRESS_FAILURE,
        payload: error
      });
      throw new Error(error);
    }
  };

export const createDeliveryAddress =
  (data: DeliveryAddress) => async (dispatch: Dispatch) => {
    try {
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.CREATE_DELIVERY_ADDRESS_REQUEST
      });
      await handleCreateDeliveryAddress(data);
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.CREATE_DELIVERY_ADDRESS_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.CREATE_DELIVERY_ADDRESS_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };

export const updateDeliveryAddress =
  (data: DeliveryAddress) => async (dispatch: Dispatch) => {
    try {
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.UPDATE_IDELIVERY_ADDRESSE_REQUEST
      });
      await handleUpdateDeliveryAddress(data);
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.UPDATE_DELIVERY_ADDRESS_SUCCESS
      });
    } catch (error: any) {
      const errMsg =
        error?.message || "Sorry! Request failed, please try again.";

      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.UPDATE_DELIVERY_ADDRESSE_FAILURE,
        payload: errMsg
      });
      throw new Error(errMsg);
    }
  };
export const resetDeliveryAddressError = () => async (dispatch: Dispatch) => {
  dispatch<DeliveryAddressAction>({
    type: DeliveryAddressActionTypes.RESET_ERROR
  });
};
export const resetDeliveryAddressForm = () => async (dispatch: Dispatch) => {
  dispatch<DeliveryAddressAction>({
    type: DeliveryAddressActionTypes.RESET_FORM
  });
};

export const fetchDeliveryAddressExport =
  (isArchived: boolean) => async (dispatch: Dispatch) => {
    try {
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_REQUEST
      });
      const response = await handleDeliveryAddressExport(isArchived);
      if (response) {
        dispatch<DeliveryAddressAction>({
          type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_SUCCESS,
          payload: response
        });
      }
    } catch (error: any) {
      dispatch<DeliveryAddressAction>({
        type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_FAILURE,
        payload: error?.message
      });
    }
  };

export const resetDeliveryAddress = () => async (dispatch: Dispatch) => {
  dispatch<DeliveryAddressAction>({
    type: DeliveryAddressActionTypes.RESET_DELIVERY_ADDRESS
  });
};
