import { Dispatch } from "redux";
import { KittingOrderAction, KittingOrderPayload } from "../../models";
import { KittingOrderManualActionTypes } from "./types";
import { handleCreateKittingOrderManual } from "../../services/kittingOrderManualApi";

export const resetKittingOrderState = () => (dispatch: Dispatch) => {
  dispatch<KittingOrderAction>({
    type: KittingOrderManualActionTypes.KITTING_ORDER_RESET_STATE
  });
};

export const createkittingOrderManual =
  (data: KittingOrderPayload) => async (dispatch: Dispatch) => {
    try {
      dispatch<KittingOrderAction>({
        type: KittingOrderManualActionTypes.CREATE_KITTING_ORDER_MANUAL_REQUEST
      });
      const response = await handleCreateKittingOrderManual(data);
      dispatch<KittingOrderAction>({
        type: KittingOrderManualActionTypes.CREATE_KITTING_ORDER_MANUAL_SUCCESS,
        payload: response
      });
    } catch (err: any) {
      dispatch<KittingOrderAction>({
        type: KittingOrderManualActionTypes.CREATE_KITTING_ORDER_MANUAL_FAILURE,
        payload: err?.message
      });
    }
  };
