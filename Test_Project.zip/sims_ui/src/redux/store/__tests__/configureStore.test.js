import configureStore from "../configureStore";
import rootReducer from "../../reducers";

describe("configureStore", () => {
  test("should return a valid Redux store with middlewares", () => {
    const store = configureStore();
    expect(store).toBeDefined();
    expect(store.getState()).toBeDefined();
    expect(store.dispatch).toBeDefined();
    expect(store.subscribe).toBeDefined();
    expect(store.replaceReducer).toBeDefined();
    expect(store.getState()).toEqual(rootReducer(undefined, {}));
  });
});
