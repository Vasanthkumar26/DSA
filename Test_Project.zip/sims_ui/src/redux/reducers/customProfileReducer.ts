import {
  CustomProfileAction,
  CustomProfileState
} from "../../models/customProfile.model";
import { CustomProfileActionTypes } from "../actions/types";

export const initialState: CustomProfileState = {
  isLoadingFetch: false,
  customProfiles: [],
  cpNames: [],
  selectedCustomProfile: null,
  isLoadingCreate: false,
  errorCreate: null,
  isLoadingUpdate: false,
  errorUpdate: null
};

const customProfileReducer = (
  state: CustomProfileState = initialState,
  action: CustomProfileAction
) => {
  switch (action.type) {
    case CustomProfileActionTypes.FETCH_CUSTOM_PROFILE_REQUEST:
      return {
        ...state,
        isLoadingFetch: true
      };
    case CustomProfileActionTypes.FETCH_CUSTOM_PROFILE_SUCCESS:
      return {
        ...state,
        isLoadingFetch: false,
        customProfiles: action.payload,
        cpNames: (action?.payload ?? []).map((x) => x?.name ?? "")
      };
    case CustomProfileActionTypes.FETCH_CUSTOM_PROFILE_FAILURE:
      return {
        ...state,
        isLoadingFetch: false,
        customProfiles: []
      };
    case CustomProfileActionTypes.DELETE_CUSTOM_PROFILE_SUCCESS:
      const updated = state.customProfiles?.filter(
        (customProfiles) => customProfiles.id !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        customProfiles: updated ? updated : state.customProfiles,
        deleteSuccessMsgFlag: true
      };
    case CustomProfileActionTypes.DELETE_CUSTOM_PROFILE_FAILURE:
      return { ...state, deleteErrorMsg: action.payload };
    case CustomProfileActionTypes.SET_SELECTED_CUSTOM_PROFILE:
      return {
        ...state,
        selectedCustomProfile: action.payload
      };
    case CustomProfileActionTypes.ARCHIVE_CUSTOM_PROFILE_SUCCESS:
      const updatedExternSys = state.customProfiles?.map((cusProfile) => {
        if (cusProfile.id === action?.payload?.id) {
          cusProfile.archived = !action?.payload?.archive;
        }
        return cusProfile;
      });
      return {
        ...state,
        externalSystems: updatedExternSys
          ? updatedExternSys
          : state.customProfiles
      };
    case CustomProfileActionTypes.CREATE_CUSTOM_PROFILE_REQUEST:
      return { ...state, isLoadingCreate: true, errorCreate: null };
    case CustomProfileActionTypes.CREATE_CUSTOM_PROFILE_SUCCESS:
      return { ...state, isLoadingCreate: false, errorCreate: null };
    case CustomProfileActionTypes.CREATE_CUSTOM_PROFILE_FAILURE:
      return { ...state, isLoadingCreate: false, errorCreate: action.payload };
    case CustomProfileActionTypes.UPDATE_CUSTOM_PROFILE_REQUEST:
      return { ...state, isLoadingUpdate: true, errorUpdate: null };
    case CustomProfileActionTypes.UPDATE_CUSTOM_PROFILE_SUCCESS:
      return { ...state, isLoadingUpdate: false, errorUpdate: null };
    case CustomProfileActionTypes.UPDATE_CUSTOM_PROFILE_FAILURE:
      return { ...state, isLoadingUpdate: false, errorUpdate: action.payload };
    case CustomProfileActionTypes.RESET_CUSTOM_PROFILE:
      return { ...initialState };
    default:
      return state;
  }
};

export default customProfileReducer;
