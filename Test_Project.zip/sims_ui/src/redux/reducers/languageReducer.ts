import { LanguageActionType } from "../actions/types";
import { getNewLangAfterToggle } from "../../utils/common";
import { LanguageAction, LanguageState } from "../../models/language.model";

const getDefaultLangFromLocalStorage = () => {
  // default language is German if English not found in localstorage
  const currentLang = localStorage.getItem("language") === "en" ? "en" : "de";
  localStorage.setItem("language", currentLang);
  return currentLang;
};

const initialState: LanguageState = {
  language: getDefaultLangFromLocalStorage(),
};

const languageReducer = (
  state: LanguageState = initialState,
  action: LanguageAction
): LanguageState => {
  switch (action.type) {
    case LanguageActionType.TOGGLE_LANGUAGE:
      return {
        ...state,
        language: getNewLangAfterToggle(state.language), // toggle between English and German
      };
    default:
      return state;
  }
};

export default languageReducer;
