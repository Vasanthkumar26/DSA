import { SnackbarAction, SnackbarState } from "../../models";
import { SnackBarActionType } from "../actions/types";

export const initialState: SnackbarState = {
  priority: "low",
  severity: null,
  message: ""
};

export const snackbarReducer = (
  state: SnackbarState = initialState,
  action: SnackbarAction
): SnackbarState => {
  switch (action.type) {
    case SnackBarActionType.SHOW_SNACK_BAR_SUCCESS:
      return state.priority === "low"
        ? {
            ...state,
            priority: "low",
            severity: "success",
            message: action.payload
          }
        : state;
    case SnackBarActionType.SHOW_HIGH_SNACK_BAR_SUCCESS:
      return {
        ...state,
        priority: "high",
        severity: "success",
        message: action.payload
      };
    case SnackBarActionType.SHOW_SNACK_BAR_FAILURE:
      return state.priority === "low"
        ? {
            ...state,
            priority: "low",
            severity: "error",
            message: action.payload
          }
        : state;
    case SnackBarActionType.SHOW_HIGH_SNACK_BAR_FAILURE:
      return {
        ...state,
        priority: "high",
        severity: "error",
        message: action.payload
      };
    case SnackBarActionType.HIDE_SNACK_BAR:
      return { ...state, priority: "low", severity: null, message: "" };
    default:
      return state;
  }
};
