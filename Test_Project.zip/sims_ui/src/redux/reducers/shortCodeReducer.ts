import { ShortCodeState, ShortCodeAction } from "../../models/shortCode.model";
import { ShortCodeActionTypes } from "../actions/types";

export const initialState: ShortCodeState = {
  isLoadingFetch: false,
  shortCodes: [],
  // esNames: [],
  scSpid: [],
  errorFetch: null,
  selectedShortCode: null,
  isLoadingCreate: false,
  errorCreate: null,
  isLoadingUpdate: false,
  errorUpdate: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null,
  shortCodeValue: []
};

const shortCodeReducer = (
  state: ShortCodeState = initialState,
  action: ShortCodeAction
): ShortCodeState => {
  switch (action.type) {
    case ShortCodeActionTypes.FETCH_SHORT_CODE_REQUEST:
      return {
        ...state,
        shortCodes: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case ShortCodeActionTypes.FETCH_SHORT_CODE_SUCCESS:
      return {
        ...state,
        shortCodes: action.payload,
        scSpid: (action.payload ?? []).map((x) => x.spid ?? ""),
        isLoadingFetch: false,
        errorFetch: null
      };
    case ShortCodeActionTypes.FETCH_SHORT_CODE_FAILURE:
      return {
        ...state,
        shortCodes: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };

    case ShortCodeActionTypes.FETCH_ShortCode_SUCCESS:
      return {
        ...state,
        shortCodeValue: action.payload
      };
    case ShortCodeActionTypes.SET_SELECTED_SHORT_CODE:
      return {
        ...state,
        selectedShortCode: action.payload
      };
    case ShortCodeActionTypes.DELETE_SELECTED_SHORTCODE_SUCCESS:
      const updated = state.shortCodes?.filter(
        (imsiMainrange) => imsiMainrange.shortCodeId !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        shortCodes: updated ? updated : state.shortCodes,
        deleteSuccessMsgFlag: true
      };
    case ShortCodeActionTypes.ARCHIVE_SELECTED_SHORTCODE_SUCCESS:
      const updatedShortCods = state.shortCodes?.map((shotCods) => {
        if (shotCods.shortCodeId === action?.payload?.id) {
          shotCods.archived = !action?.payload?.archive;
        }
        return shotCods;
      });
      return {
        ...state,
        shortCodes: updatedShortCods ? updatedShortCods : state.shortCodes,
        deleteSuccessMsgFlag: true
      };
    case ShortCodeActionTypes.DELETE_SELECTED_SHORTCODE_FAILURE:
      return { ...state, deleteErrorMsg: action.payload };
    case ShortCodeActionTypes.RESET_SHORTCODE_ERR:
      return {
        ...state,
        deleteSuccessMsgFlag: false
      };
    case ShortCodeActionTypes.CREATE_SHORT_CODE_REQUEST:
      return { ...state, isLoadingCreate: true, errorCreate: null };
    case ShortCodeActionTypes.CREATE_SHORT_CODE_SUCCESS:
      return { ...state, isLoadingCreate: false, errorCreate: null };
    case ShortCodeActionTypes.CREATE_SHORT_CODE_FAILURE:
      return { ...state, isLoadingCreate: false, errorCreate: action.payload };
    case ShortCodeActionTypes.UPDATE_SHORT_CODE_REQUEST:
      return { ...state, isLoadingUpdate: true, errorUpdate: null };
    case ShortCodeActionTypes.UPDATE_SHORT_CODE_SUCCESS:
      return { ...state, isLoadingUpdate: false, errorUpdate: null };
    case ShortCodeActionTypes.UPDATE_SHORT_CODE_FAILURE:
      return { ...state, isLoadingUpdate: false, errorUpdate: action.payload };
    case ShortCodeActionTypes.FETCH_SHORT_CODE_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case ShortCodeActionTypes.FETCH_SHORT_CODE_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case ShortCodeActionTypes.FETCH_SHORT_CODE_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case ShortCodeActionTypes.RESET_SHORT_CODE:
      return { ...initialState };
    default:
      return state;
  }
};

export default shortCodeReducer;
