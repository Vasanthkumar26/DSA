import { AkaAction, AkaState } from "../../models/aka.model";
import { AkaActionTypes } from "../actions/types";

export const initialState: AkaState = {
  isLoadingFetch: false,
  akas: [],
  errorFetch: null,
  selectedAka: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null,
  isLoadingCreate: false,
  isLoadingUpdate: false,
  isArchiveRequestSuccessful: null,
  archiveMsg: null
};

const akaReducer = (
  state: AkaState = initialState,
  action: AkaAction
): AkaState => {
  switch (action.type) {
    case AkaActionTypes.FETCH_AKA_REQUEST:
      return {
        ...state,
        akas: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case AkaActionTypes.FETCH_AKA_SUCCESS:
      return {
        ...state,
        akas: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case AkaActionTypes.FETCH_AKA_FAILURE:
      return {
        ...state,
        akas: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };

    case AkaActionTypes.SET_SELECTED_AKA:
      return {
        ...state,
        selectedAka: action.payload
      };
    case AkaActionTypes.FETCH_AKA_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case AkaActionTypes.FETCH_AKA_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case AkaActionTypes.FETCH_AKA_EXPORT_ERROR:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case AkaActionTypes.DELETE_AKA_SUCCESS:
      const updatedHlrs = state.akas?.filter(
        (data) => data.id !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        akas: updatedHlrs ? updatedHlrs : state.akas,
        deleteSuccessMsgFlag: true
      };
    case AkaActionTypes.DELETE_AKA_FAILURE:
      return { ...state, deleteErrorMsg: action.payload };

    case AkaActionTypes.ARCHIVE_AKA_REQUEST:
      return {
        ...state,
        archiveMsg: null,
        isArchiveRequestSuccessful: null
      };
    case AkaActionTypes.ARCHIVE_AKA_SUCCESS:
      const updatedAkas = [...state.akas];
      const updatedAka = updatedAkas.find(
        (aka) => aka.id === action.payload.id
      );
      updatedAka && (updatedAka.archived = action.payload.archived);

      return {
        ...state,
        akas: updatedAkas,
        archiveMsg: `${action.payload.akaName} archived successfully`,
        isArchiveRequestSuccessful: true
      };
    case AkaActionTypes.ARCHIVE_AKA_FAILURE:
      return {
        ...state,
        archiveMsg: `archiving ${action.payload.akaName} failed`,
        isArchiveRequestSuccessful: false
      };
    case AkaActionTypes.RESET_AKA:
      return { ...initialState };

    default:
      return state;
  }
};

export default akaReducer;
