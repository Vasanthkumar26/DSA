import {
  SimArticleAction,
  SimArticleState
} from "../../models/simArticle.model";
import { SimArticleActionTypes } from "../actions/types";

export const initialState: SimArticleState = {
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null,
  isLoadingFetch: false,
  simArticles: [],
  errorFetch: null,
  selectedSimArticle: null,
  isCreateOrUpdate: false,
  createOrUpdateSuccess: null,
  isLoadingArchive: null,
  archiveMsg: null
};

const simArticleReducer = (
  state: SimArticleState = initialState,
  action: SimArticleAction
): SimArticleState => {
  switch (action.type) {
    case SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case SimArticleActionTypes.FETCH_SIM_ARTICLES_REQUEST:
      return {
        ...state,
        simArticles: [],
        exportSuccessMsg: null,
        errorFetch: null
      };
    case SimArticleActionTypes.FETCH_SIM_ARTICLES_SUCCESS:
      return {
        ...state,
        simArticles: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case SimArticleActionTypes.FETCH_SIM_ARTICLES_FAILURE:
      return {
        ...state,
        simArticles: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case SimArticleActionTypes.SET_SIM_ARTICLE:
      return {
        ...state,
        selectedSimArticle: action.payload
      };
    case SimArticleActionTypes.CREATE_UPDATE_SIM_ARTICLE_REQUEST:
      return {
        ...state,
        isCreateOrUpdate: true,
        createOrUpdateSuccess: null
      };
    case SimArticleActionTypes.CREATE_UPDATE_SIM_ARTICLE_SUCCESS:
      return {
        ...state,
        isCreateOrUpdate: false,
        createOrUpdateSuccess: action.payload
      };
    case SimArticleActionTypes.RESET_MESSAGE:
      return {
        ...state,
        isCreateOrUpdate: false,
        createOrUpdateSuccess: null
      };
    case SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_REQUEST:
      return {
        ...state,
        isLoadingArchive: true,
        archiveMsg: null
      };
    case SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_SUCCESS:
      return {
        ...state,

        isLoadingArchive: false,
        archiveMsg: `${action.payload.name} archived successfully`
      };
    case SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_FAILURE:
      return {
        ...state,

        isLoadingArchive: false,
        archiveMsg: `Archiving ${action.payload.name} failed`
      };
    default:
      return state;
  }
};

export default simArticleReducer;
