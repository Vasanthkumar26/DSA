import { ImsiMainrangeAction, ImsiMainrangeState } from "../../models";
import { ImsiMainrangeActionTypes } from "../actions/types";

export const initialState: ImsiMainrangeState = {
  isLoadingFetch: false,
  imsiMainranges: [],
  selectedImsiMainrange: null,
  errorFetch: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null,
  isLoadingCreate: false,
  errorCreate: null,
  isLoadingUpdate: false,
  errorUpdate: null,
  isLoadingStatusTable: false,
  mainrangeStatusDetail: []
};

const ImsiMainrangeReducer = (
  state: ImsiMainrangeState = initialState,
  action: ImsiMainrangeAction
): ImsiMainrangeState => {
  switch (action.type) {
    case ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_REQUEST:
      return {
        ...state,
        imsiMainranges: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_SUCCESS:
      return {
        ...state,
        imsiMainranges: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_FAILURE:
      return {
        ...state,
        imsiMainranges: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case ImsiMainrangeActionTypes.SET_SELECTED_IMSI_MAINRANGE:
      return {
        ...state,
        selectedImsiMainrange: action.payload
      };
    case ImsiMainrangeActionTypes.CREATE_IMSI_MAINRANGE_REQUEST:
      return { ...state, isLoadingCreate: true, errorCreate: null };
    case ImsiMainrangeActionTypes.CREATE_IMSI_MAINRANGE_SUCCESS:
      return { ...state, isLoadingCreate: false, errorCreate: null };
    case ImsiMainrangeActionTypes.CREATE_IMSI_MAINRANGE_FAILURE:
      return { ...state, isLoadingCreate: false, errorCreate: action.payload };
    case ImsiMainrangeActionTypes.UPDATE_IMSI_MAINRANGE_REQUEST:
      return { ...state, isLoadingUpdate: true, errorUpdate: null };
    case ImsiMainrangeActionTypes.UPDATE_IMSI_MAINRANGE_SUCCESS:
      return { ...state, isLoadingUpdate: false, errorUpdate: null };
    case ImsiMainrangeActionTypes.UPDATE_IMSI_MAINRANGE_FAILURE:
      return { ...state, isLoadingUpdate: false, errorUpdate: action.payload };
    case ImsiMainrangeActionTypes.RESET_IMSI_MAINRANGE_ERR:
      return {
        ...state,
        errorCreate: null,
        errorUpdate: null,
        deleteSuccessMsgFlag: false,
        archiveSuccessMsgFlag: false
      };
    case ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        errorExport: null,
        exportSuccessMsg: null
      };
    case ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        errorExport: null,
        exportSuccessMsg: action.payload
      };
    case ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        errorExport: action.payload,
        exportSuccessMsg: null
      };
    case ImsiMainrangeActionTypes.DELETE_IMSI_SUCCESS:
      const updatedHlrs = state.imsiMainranges?.filter(
        (imsiMainrange) => imsiMainrange.imsiMainRangeId !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        imsiMainranges: updatedHlrs ? updatedHlrs : state.imsiMainranges,
        deleteSuccessMsgFlag: true
      };
    case ImsiMainrangeActionTypes.ARCHIVE_IMSI_MAINRANGE_SUCCESS:
      return {
        ...state,
        imsiMainranges: state.imsiMainranges
      };
    case ImsiMainrangeActionTypes.RESET_IMSI_MAINRANGE:
      return { ...state, ...initialState };
    case ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_STATUS_REQUEST:
      return {
        ...state,
        isLoadingStatusTable: true,
        mainrangeStatusDetail: []
      };
    case ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_STATUS_SUCCESS:
      return {
        ...state,
        isLoadingStatusTable: false,
        mainrangeStatusDetail: action.payload
      };
    case ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_STATUS_FAILURE:
      return {
        ...state,
        isLoadingStatusTable: false,
        mainrangeStatusDetail: []
      };
    default:
      return state;
  }
};

export default ImsiMainrangeReducer;
