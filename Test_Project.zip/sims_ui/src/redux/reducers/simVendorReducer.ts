import { SimVendorAction, SimVendorState } from "../../models/simVendor.model";
import { SimVendorActionTypes } from "../actions/types";

export const initialState: SimVendorState = {
  isLoadingFetch: false,
  simVendros: [],
  errorFetch: null,
  selectedSimVendor: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null,
  isLoadingCreate: false,
  isLoadingUpdate: false,
  errorCreate: null,
  errorUpdate: null,
  externalName: [],
  inputFile: [
    {
      name: "SFTP",
      value: 1
    },
    {
      name: "NONE",
      value: 0
    }
  ]
};

const SimVendorReducer = (
  state: SimVendorState = initialState,
  action: SimVendorAction
): SimVendorState => {
  switch (action.type) {
    case SimVendorActionTypes.FETCH_SIM_VENDOR_REQUEST:
      return {
        ...state,
        simVendros: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case SimVendorActionTypes.FETCH_SIM_VENDOR_SUCCESS:
      return {
        ...state,
        simVendros: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case SimVendorActionTypes.FETCH_SIM_VENDOR_FAILURE:
      return {
        ...state,
        simVendros: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case SimVendorActionTypes.SET_SELECTED_SIM_VENDOR:
      return {
        ...state,
        selectedSimVendor: action.payload
      };
    case SimVendorActionTypes.FETCH_EXTERNAL_SUCCESS:
      return {
        ...state,
        externalName: action.payload
      };
    case SimVendorActionTypes.RESET_ERROR:
      return { ...state, errorCreate: null, deleteSuccessMsgFlag: false };
    case SimVendorActionTypes.RESET_FORM:
      return {
        ...state,
        errorCreate: null,
        errorUpdate: null,
        selectedSimVendor: null
      };
    case SimVendorActionTypes.CREATE_SIM_VENDOR_REQUEST:
      return { ...state, isLoadingCreate: true, errorCreate: null };
    case SimVendorActionTypes.CREATE_SIM_VENDOR_SUCCESS:
      return { ...state, isLoadingCreate: false, errorCreate: null };
    case SimVendorActionTypes.CREATE_SIM_VENDOR_FAILURE:
      return { ...state, isLoadingCreate: false, errorCreate: action.payload };
    case SimVendorActionTypes.UPDATE_ISIM_VENDORE_REQUEST:
      return { ...state, isLoadingUpdate: true, errorUpdate: null };
    case SimVendorActionTypes.UPDATE_SIM_VENDOR_SUCCESS:
      return { ...state, isLoadingUpdate: false, errorUpdate: null };
    case SimVendorActionTypes.UPDATE_SIM_VENDORE_FAILURE:
      return { ...state, isLoadingUpdate: false, errorUpdate: action.payload };
    case SimVendorActionTypes.DELETE_SIM_VENDOR_SUCCESS:
      const updated = state.simVendros?.filter(
        (data) => data.id !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        simVendros: updated ? updated : state.simVendros,
        deleteSuccessMsgFlag: true
      };
    case SimVendorActionTypes.DELETE_SIM_VENDOR_FAILURE:
      return { ...state, deleteErrorMsg: action.payload };
    case SimVendorActionTypes.ARCHIVE_SIM_VENDOR_SUCCESS:
      return {
        ...state
      };
    case SimVendorActionTypes.ARCHIVE_SIM_VENDOR_FAILURE:
      return { ...state, deleteErrorMsg: action.payload };
    case SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_ERROR:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case SimVendorActionTypes.RESET_SIM_VENDOR:
      return { ...initialState };
    default:
      return state;
  }
};

export default SimVendorReducer;
