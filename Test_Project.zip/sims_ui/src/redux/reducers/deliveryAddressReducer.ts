import {
  DeliveryAddressAction,
  DeliveryAddressState
} from "../../models/deliveryAddress.model";
import { DeliveryAddressActionTypes } from "../actions/types";

export const initialState: DeliveryAddressState = {
  isLoadingFetch: false,
  deliveryAddresses: [],
  selectedDeliveryAddress: null,
  errorFetch: null,
  isLoadingCreate: false,
  errorCreate: null,
  isLoadingUpdate: false,
  errorUpdate: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null,
  externalName: [
    {
      name: "Yes",
      value: "true"
    },
    {
      name: "No",
      value: "false"
    }
  ],
  inputFile: [
    {
      name: "Email",
      value: 0
    },
    {
      name: "REST",
      value: 1
    },
    {
      name: "NONE",
      value: 2
    }
  ],
  timing: [
    {
      name: "before provisioning",
      value: 1
    },
    {
      name: "after provisioning",
      value: 0
    }
  ],
  partnerAddress: []
};

const deliverAddressReducer = (
  state: DeliveryAddressState = initialState,
  action: DeliveryAddressAction
): DeliveryAddressState => {
  switch (action.type) {
    case DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_REQUEST:
      return {
        ...state,
        deliveryAddresses: [],
        isLoadingFetch: true,
        errorFetch: null
      };

    case DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_SUCCESS:
      return {
        ...state,
        deliveryAddresses: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_FAILURE:
      return {
        ...state,
        deliveryAddresses: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case DeliveryAddressActionTypes.SET_SELECTED_DELIVERY_ADDRESS:
      return {
        ...state,
        selectedDeliveryAddress: action.payload
      };
    case DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case DeliveryAddressActionTypes.FETCH_PartnerAddress_SUCCESS:
      return {
        ...state,
        partnerAddress: action.payload
      };
    case DeliveryAddressActionTypes.CREATE_DELIVERY_ADDRESS_REQUEST:
      return { ...state, isLoadingCreate: true, errorCreate: null };
    case DeliveryAddressActionTypes.CREATE_DELIVERY_ADDRESS_SUCCESS:
      return { ...state, isLoadingCreate: false, errorCreate: null };
    case DeliveryAddressActionTypes.CREATE_DELIVERY_ADDRESS_FAILURE:
      return { ...state, isLoadingCreate: false, errorCreate: action.payload };
    case DeliveryAddressActionTypes.UPDATE_IDELIVERY_ADDRESSE_REQUEST:
      return { ...state, isLoadingUpdate: true, errorUpdate: null };
    case DeliveryAddressActionTypes.UPDATE_DELIVERY_ADDRESS_SUCCESS:
      return { ...state, isLoadingUpdate: false, errorUpdate: null };
    case DeliveryAddressActionTypes.UPDATE_DELIVERY_ADDRESSE_FAILURE:
      return { ...state, isLoadingUpdate: false, errorUpdate: action.payload };
    case DeliveryAddressActionTypes.DELETE_DELIVERY_ADDRESS_SUCCESS:
      const updated = state.deliveryAddresses?.filter(
        (data) => data.id !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        deliveryAddresses: updated ? updated : state.deliveryAddresses,
        deleteSuccessMsgFlag: true
      };
    case DeliveryAddressActionTypes.DELETE_DELIVERY_ADDRESS_FAILURE:
      return { ...state, deleteErrorMsg: action.payload };
    default:
      return state;
  }
};

export default deliverAddressReducer;
