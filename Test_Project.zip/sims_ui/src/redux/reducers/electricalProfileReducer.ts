import { ElectricalProfileAction, ElectricalProfileState } from "../../models";
import { ElectricalProfileActionTypes } from "../actions/types";

export const initialState: ElectricalProfileState = {
  isLoadingFetch: false,
  electricalProfiles: [],
  selectedElectricalProfile: null,
  errorFetch: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null,
  isLoadingCreate: false,
  errorCreate: null,
  successCreate: null,
  isLoadingUpdate: false,
  successUpdate: null,
  errorUpdate: null,
  archiveSuccess: null
};

const ElectricalProfileReducer = (
  state: ElectricalProfileState = initialState,
  action: ElectricalProfileAction
): ElectricalProfileState => {
  switch (action.type) {
    case ElectricalProfileActionTypes.FETCH_REQUEST:
      return {
        ...state,
        electricalProfiles: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case ElectricalProfileActionTypes.FETCH_SUCCESS:
      return {
        ...state,
        electricalProfiles: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };

    case ElectricalProfileActionTypes.FETCH_FAILURE:
      return {
        ...state,
        electricalProfiles: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case ElectricalProfileActionTypes.SET_SELECTED_EP:
      return {
        ...state,
        selectedElectricalProfile: action.payload
      };
    case ElectricalProfileActionTypes.FETCH_EP_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        errorExport: null,
        exportSuccessMsg: null
      };
    case ElectricalProfileActionTypes.FETCH_EP_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case ElectricalProfileActionTypes.FETCH_EP_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case ElectricalProfileActionTypes.EP_DELETE_SUCCESS:
      const updated = state.electricalProfiles?.filter(
        (data) => data.itemId !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        electricalProfiles: updated ? updated : state.electricalProfiles,
        deleteSuccessMsgFlag: true
      };

    case ElectricalProfileActionTypes.ARCHIVE_EP_SUCCESS:
      return {
        ...state,
        archiveSuccess: action.payload
      };

    case ElectricalProfileActionTypes.EP_DELETE_FAILURE:
      return { ...state, deleteErrorMsg: action.payload };
    case ElectricalProfileActionTypes.CREATE_EP_REQUEST:
      return {
        ...state,
        isLoadingCreate: true,
        errorCreate: null,
        successCreate: null
      };
    case ElectricalProfileActionTypes.CREATE_EP_SUCCESS:
      return {
        ...state,
        isLoadingCreate: false,
        successCreate: action.payload,
        errorCreate: null
      };
    case ElectricalProfileActionTypes.CREATE_EP_ERROR:
      return {
        ...state,
        isLoadingCreate: false,
        successCreate: null,
        errorCreate: action.payload
      };
    case ElectricalProfileActionTypes.UPDATE_EP_REQUEST:
      return {
        ...state,
        isLoadingUpdate: true,
        successUpdate: null,
        errorUpdate: null
      };
    case ElectricalProfileActionTypes.UPDATE_EP_SUCCESS:
      return {
        ...state,
        isLoadingUpdate: false,
        successUpdate: action.payload,
        errorUpdate: null
      };
    case ElectricalProfileActionTypes.UPDATE_EP_FAILURE:
      return {
        ...state,
        isLoadingUpdate: false,
        successUpdate: null,
        errorUpdate: action.payload
      };
    case ElectricalProfileActionTypes.RESET_EP_CREATE_UPDATE_STATE:
      return {
        ...state,
        errorCreate: null,
        errorUpdate: null,
        successCreate: null,
        archiveSuccess: null,
        successUpdate: null,
        isLoadingCreate: false,
        isLoadingUpdate: false
      };
    default:
      return state;
  }
};
export default ElectricalProfileReducer;
