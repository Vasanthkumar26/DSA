import { combineReducers } from "redux";
import authReducer from "./authReducer";
import kittingArticlesReducer from "./kittingArticlesReducer";
import languageReducer from "./languageReducer";
import hlrReducer from "./hlrReducer";
import ImsiMainrangeReducer from "./ImsiMainrangeReducer";
import ImsiSubrangeReducer from "./ImsiSubrangeReducer";
import serviceProviderReducer from "./serviceProviderReducer";
import SimVendorReducer from "./simVendorReducer";
import akaReducer from "./akaReducer";
import externalSystemsReducer from "./externalSystemsReducer";
import ElectricalProfileReducer from "./electricalProfileReducer";
import { snackbarReducer } from "./snackbarReducer";
import cockpitReducer from "./cockpitReducer";
import deliverAddressReducer from "./deliveryAddressReducer";
import cardTypesReducer from "./cardTypesReducer";
import imsiSearchLockReducer from "./imsiSearchLockReducer";
import productTypeReducer from "./productTypeReducer";
import formFactorReducer from "./formFactorReducer";
import kittingOrderReducer from "./kittingOrderReducer";
import { ResetReduxActionType } from "../actions/types";
import appReducer from "./appReducer";
import shortCodeReducer from "./shortCodeReducer";
import customProfileReducer from "./customProfileReducer";
import taskReducer from "./taskReducer";
import simArticleReducer from "./simArticleReducer";
import taskEscalationReducer from "./taskEscalationReducer";
import emailReducer from "./emailReducer";

const simsReducer = combineReducers({
  app: appReducer,
  snackbar: snackbarReducer,
  auth: authReducer,
  lang: languageReducer,
  kittingArticles: kittingArticlesReducer,
  hlr: hlrReducer,
  imsiMainrange: ImsiMainrangeReducer,
  imsiSubrange: ImsiSubrangeReducer,
  serviceProvider: serviceProviderReducer,
  simVendor: SimVendorReducer,
  aka: akaReducer,
  externalSystem: externalSystemsReducer,
  electricalProfile: ElectricalProfileReducer,
  cockpit: cockpitReducer,
  deliverAddress: deliverAddressReducer,
  cardType: cardTypesReducer,
  formFactor: formFactorReducer,
  imsiSearchLock: imsiSearchLockReducer,
  productType: productTypeReducer,
  kittingOrder: kittingOrderReducer,
  shortCode: shortCodeReducer,
  customProfile: customProfileReducer,
  task: taskReducer,
  simArticle: simArticleReducer,
  taskEscalation: taskEscalationReducer,
  email: emailReducer
});

const rootReducer = (state: any, action: any) => {
  if (action.type === ResetReduxActionType.RESET_REDUX_STORE) {
    return simsReducer(undefined, action);
  }
  return simsReducer(state, action);
};

export default rootReducer;
