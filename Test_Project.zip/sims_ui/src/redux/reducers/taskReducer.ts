import { TaskAction, TaskState } from "../../models/task.model";
import { TaskActionTypes } from "../actions/types";

export const initialState: TaskState = {
  isLoadingFetch: false,
  tasks: [],
  orders: [],
  errorFetch: null,
  selectedTask: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null,
  isLoadingCreate: false,
  isLoadingUpdate: false
};

const taskReducer = (
  state: TaskState = initialState,
  action: TaskAction
): TaskState => {
  switch (action.type) {
    case TaskActionTypes.FETCH_TASK_REQUEST:
      return {
        ...state,
        tasks: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case TaskActionTypes.FETCH_TASK_SUCCESS:
      return {
        ...state,
        tasks: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case TaskActionTypes.FETCH_TASK_FAILURE:
      return {
        ...state,
        tasks: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case TaskActionTypes.FETCH_ORDER_REQUEST:
      return {
        ...state,
        orders: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case TaskActionTypes.FETCH_ORDER_SUCCESS:
      return {
        ...state,
        orders: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case TaskActionTypes.FETCH_ORDER_FAILURE:
      return {
        ...state,
        orders: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case TaskActionTypes.DELETE_TASK_SUCCESS:
      const updatedHlrs = state.tasks?.filter(
        (data) => data.id !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        tasks: updatedHlrs ? updatedHlrs : state.tasks,
        deleteSuccessMsgFlag: true
      };

    default:
      return state;
  }
};

export default taskReducer;
