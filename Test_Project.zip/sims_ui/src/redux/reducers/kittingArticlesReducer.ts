import {
  FETCH_KITTING_ARTICLES_FAILURE,
  FETCH_KITTING_ARTICLES_REQUEST,
  FETCH_KITTING_ARTICLES_SUCCESS,
  SET_SELECTED_KITTING_ARTICLE,
  FETCH_KITTING_ARTICLES_EXPORT_FAILURE,
  FETCH_KITTING_ARTICLES_EXPORT_REQUEST,
  FETCH_KITTING_ARTICLES_EXPORT_SUCCESS,
  DELETE_KITTING_ARTICLES_REQUEST,
  DELETE_KITTING_ARTICLES_SUCCESS,
  DELETE_KITTING_ARTICLES_FAILURE,
  ADD_ARTICLE_REQUEST,
  ADD_ARTICLE_SUCCESS,
  ADD_ARTICLE_FAILURE,
  GET_OFFERS_REQUEST,
  GET_OFFERS_SUCCESS,
  GET_OFFERS_FAILURE,
  ARTICLE_RESET,
  ARTICLE_ERROR_RESET,
  ADD_ARTICLE_IN_STATE,
  DELETE_KITTING_IN_STATE,
  RESET_DELETE_ARTICLE,
  ARCHIVE_KITTING_ARTICLES_REQUEST,
  ARCHIVE_KITTING_ARTICLES_SUCCESS,
  ARCHIVE_KITTING_ARTICLES_FAILURE
} from "../actions/types";

import { KittingArticle, StarterPack } from "../../models";
import { Reducer } from "react";

interface KittingArticleState {
  isLoading: boolean;
  isLoadingFetch: boolean;
  isLoadingExport: boolean;
  isLoadingDelete: boolean;
  isLoadingArch: boolean;
  exportSuccessMsg: string | null;
  deleteSuccessMsg: string | null;
  archSuccessMsg: string | null;
  errorFetch: string | null;
  errorExport: string | null;
  errorDelete: string | null;
  error: string | null;
  successMsg: string | null;
  selectedKittingArticle: Partial<KittingArticle> | null;
  kittingArticles: Array<Partial<KittingArticle>> | null;
  startPack: Array<StarterPack> | null;
}

interface Action {
  type: string;
  payload: any;
}

type KittingArticleStateRO = Readonly<KittingArticleState>;
type ActionRO = Readonly<Action>;

export const initialState: KittingArticleState = {
  isLoading: false,
  isLoadingFetch: false,
  isLoadingExport: false,
  isLoadingDelete: false,
  isLoadingArch: false,
  kittingArticles: [],
  exportSuccessMsg: null,
  deleteSuccessMsg: null,
  archSuccessMsg: null,
  selectedKittingArticle: null,
  startPack: [{ value: "1", label: "WhatsAll 4000" }],
  errorFetch: null,
  errorExport: null,
  errorDelete: null,
  error: null,
  successMsg: null
};

const kittingArticlesReducer: Reducer<KittingArticleStateRO, ActionRO> = (
  state = initialState,
  action
) => {
  switch (action.type) {
    case FETCH_KITTING_ARTICLES_REQUEST:
      return {
        ...state,
        kittingArticles: [],
        isLoadingFetch: true,
        errorFetch: null,
        selectedKittingArticle: null
      };
    case FETCH_KITTING_ARTICLES_SUCCESS:
      return {
        ...state,
        kittingArticles: action.payload.kittingArticles,
        isLoadingFetch: false,
        errorFetch: null,
        selectedKittingArticle: null
      };
    case FETCH_KITTING_ARTICLES_FAILURE:
      return {
        ...state,
        kittingArticles: [],
        isLoadingFetch: false,
        errorFetch: action.payload.errorFetch,
        selectedKittingArticle: null
      };
    case SET_SELECTED_KITTING_ARTICLE:
      return {
        ...state,
        selectedKittingArticle: action.payload.kittingArticle
      };
    case DELETE_KITTING_ARTICLES_REQUEST:
      return {
        ...state,
        isLoadingDelete: true,
        errorDelete: null
      };
    case DELETE_KITTING_ARTICLES_SUCCESS:
      return {
        ...state,
        deleteSuccessMsg: action.payload.message,
        isLoadingDelete: false,
        errorDelete: null
      };
    case DELETE_KITTING_ARTICLES_FAILURE:
      return {
        ...state,
        isLoadingDelete: false,
        errorDelete: action.payload.error
      };
    case DELETE_KITTING_IN_STATE:
      const updatedArticles = state.kittingArticles?.filter(
        (article) => article.id !== action.payload.id
      );
      return {
        ...state,
        kittingArticles: updatedArticles
          ? updatedArticles
          : state.kittingArticles
      };

    case ARCHIVE_KITTING_ARTICLES_REQUEST:
      return {
        ...state,
        isLoadingArch: true,
        errorArch: null
      };
    case ARCHIVE_KITTING_ARTICLES_SUCCESS:
      const kittingArticleArch = state.kittingArticles?.map((article) => {
        if (article.id === action.payload.id) {
          article.archived = !action.payload.archiveKittingArticles;
        }
        return article;
      });

      return {
        ...state,
        kittingArticles: kittingArticleArch
          ? kittingArticleArch
          : state.kittingArticles,
        archSuccessMsg: !action.payload.archiveKittingArticles
          ? "Successfully Archived"
          : "Successfully Activated",
        isLoadingArch: false,
        errorArch: null
      };
    case ARCHIVE_KITTING_ARTICLES_FAILURE:
      return {
        ...state,
        isLoadingArch: false,
        errorArch: action.payload.error
          ? action.payload.error
          : "Internal server error"
      };

    case RESET_DELETE_ARTICLE:
      return {
        ...state,
        deleteSuccessMsg: null,
        archSuccessMsg: null,
        isLoadingDelete: false,
        selectedKittingArticle: null
      };
    case FETCH_KITTING_ARTICLES_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case FETCH_KITTING_ARTICLES_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload.message,
        errorExport: null
      };
    case FETCH_KITTING_ARTICLES_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload.error
      };
    case GET_OFFERS_REQUEST:
      return {
        ...state,
        isLoading: true,
        error: null
      };
    case ADD_ARTICLE_REQUEST:
      return {
        ...state,
        isLoading: true
      };
    case ADD_ARTICLE_SUCCESS:
      return {
        ...state,
        isLoading: false,
        successMsg: action.payload.message,
        error: null
      };
    case ADD_ARTICLE_IN_STATE:
      return {
        ...state,
        kittingArticles: state.kittingArticles
          ? [action.payload, ...state.kittingArticles]
          : state.kittingArticles
      };
    case GET_OFFERS_SUCCESS:
      return {
        ...state,
        isLoading: false,
        offers: action.payload.offers,
        error: null
      };
    case ADD_ARTICLE_FAILURE:
    case GET_OFFERS_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.payload.error,
        offers: []
      };
    case ARTICLE_RESET:
      return {
        ...state,
        ...initialState
      };
    case ARTICLE_ERROR_RESET:
      return {
        ...state,
        error: null,
        successMsg: null,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: null
      };
    default:
      return state;
  }
};

export default kittingArticlesReducer;
