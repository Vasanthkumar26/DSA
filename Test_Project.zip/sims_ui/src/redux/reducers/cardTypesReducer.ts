import { CardTypesAction, CardTypesState } from "../../models";
import { CardTypeActionTypes } from "../actions/types";

export const initialState: CardTypesState = {
  cardTypes: [],
  selectedCardType: null,
  isLoadingFetch: false,
  errorFetch: null,
  hlrValues: [],
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null,
  errorCreate: null,
  errorUpdate: null,
  isLoadingCreate: false,
  isLoadingUpdate: false,
  isLoadingManufacturer: false,
  errorManufacturerList: null,
  manufacturersDetails: [],
  severity: "success"
};

const cardTypesReducer = (
  state: CardTypesState = initialState,
  action: CardTypesAction
): CardTypesState => {
  switch (action.type) {
    case CardTypeActionTypes.CARD_TYPES_REQUEST:
      return {
        ...state,
        cardTypes: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case CardTypeActionTypes.CARD_TYPES_SUCCESS:
      return {
        ...state,
        cardTypes: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case CardTypeActionTypes.CARD_TYPES_FAILURE:
      return {
        ...state,
        cardTypes: [],
        isLoadingFetch: false,
        errorFetch: "Error Occured"
      };
    case CardTypeActionTypes.ALL_AKA_HLR_SUCCESS:
      return {
        ...state,
        hlrValues: action.payload
      };
    case CardTypeActionTypes.FETCH_CARD_TYPES_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case CardTypeActionTypes.FETCH_CARD_TYPES_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case CardTypeActionTypes.FETCH_CARD_TYPES_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case CardTypeActionTypes.CREATE_CARD_TYPE_REQUEST:
      return { ...state, isLoadingCreate: true, errorCreate: null };
    case CardTypeActionTypes.CREATE_CARD_TYPE_SUCCESS:
      return { ...state, isLoadingCreate: false, errorCreate: null };
    case CardTypeActionTypes.CREATE_CARD_TYPE_FAILURE:
      return { ...state, isLoadingCreate: false, errorCreate: action.payload };
    case CardTypeActionTypes.SET_SELECTED_CARD_TYPE:
      return {
        ...state,
        selectedCardType: action.payload
      };
    case CardTypeActionTypes.FETCH_MANUFACTURERS_REQUEST:
      return {
        ...state,
        isLoadingManufacturer: true
      };
    case CardTypeActionTypes.FETCH_MANUFACTURERS_SUCCESS:
      return {
        ...state,
        isLoadingManufacturer: false,
        manufacturersDetails: action.payload
      };
    case CardTypeActionTypes.FETCH_MANUFACTURERS_FAILURE:
      return {
        ...state,
        isLoadingManufacturer: false,
        errorManufacturerList: action.payload
      };
    case CardTypeActionTypes.UPDATE_CARD_TYPE_REQUEST:
      return { ...state, isLoadingUpdate: true, errorUpdate: null };
    case CardTypeActionTypes.UPDATE_CARD_TYPE_SUCCESS:
      return { ...state, isLoadingUpdate: false, errorUpdate: null };
    case CardTypeActionTypes.UPDATE_CARD_TYPE_FAILURE:
      return { ...state, isLoadingUpdate: false, errorUpdate: action.payload };

    case CardTypeActionTypes.DELETE_CARD_TYPES_SUCCESS:
      const updated = state.cardTypes?.filter(
        (card) => card.id !== action.payload
      );
      return {
        ...state,
        cardTypes: updated ? updated : state.cardTypes,
        deleteSuccessMsg: `${action.payload} deleted successfully`,
        deleteSuccessMsgFlag: true,
        severity: "success"
      };
    case CardTypeActionTypes.RESET_CARD_TYPES_ERR:
      return {
        ...state,
        deleteSuccessMsgFlag: false,
        severity: "error"
      };
    case CardTypeActionTypes.DELETE_CARD_TYPES_FAILURE:
      return {
        ...state,
        deleteSuccessMsgFlag: true,
        deleteSuccessMsg: `${action.payload}`,
        severity: "error"
      };
    case CardTypeActionTypes.RESET_CARD_TYPES:
      return { ...initialState };
    default:
      return state;
  }
};

export default cardTypesReducer;
