import { ProductTypeAction, ProductTypeState } from "../../models";
import { ProductTypeActionTypes } from "../actions/types";

export const initialState: ProductTypeState = {
  isLoadingFetch: false,
  productTypes: [],
  errorFetch: null,
  selectedProductType: null,
  isCreating: false,
  isUpdating: false,
  errorCreate: null,
  errorUpdate: null,
  productDropDown: [
    {
      name: "Yes",
      value: true
    },
    {
      name: "No",
      value: false
    }
  ],
  productSimType: [
    {
      name: "Kommerzielle SIM",
      value: 5
    },
    {
      name: "Prototyping SIM",
      value: 6
    },
    {
      name: "Test SIM",
      value: 7
    }
  ],
  isLoadingAssignedImsiSubrange: false,
  assignedImsiSubranges: [],
  errorFetchAssignedImsiSubrange: null,
  isLoadingAllImsiSubrange: false,
  allImsiSubranges: [],
  errorFetchAllImsiSubrange: null
};

const productTypeReducer = (
  state: ProductTypeState = initialState,
  action: ProductTypeAction
): ProductTypeState => {
  switch (action.type) {
    case ProductTypeActionTypes.FETCH_PRODUCT_TYPE_REQUEST:
      return {
        ...state,
        productTypes: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case ProductTypeActionTypes.FETCH_PRODUCT_TYPE_SUCCESS:
      return {
        ...state,
        productTypes: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case ProductTypeActionTypes.FETCH_PRODUCT_TYPE_FAILURE:
      return {
        ...state,
        productTypes: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };

    case ProductTypeActionTypes.CREATE_PRODUCT_TYPE_REQUEST:
      return { ...state, isCreating: true, errorCreate: null };
    case ProductTypeActionTypes.CREATE_PRODUCT_TYPE_SUCCESS:
      return { ...state, isCreating: false, errorCreate: null };
    case ProductTypeActionTypes.CREATE_PRODUCT_TYPE_FAILURE:
      return { ...state, isCreating: false, errorCreate: action.payload };
    case ProductTypeActionTypes.UPDATE_PRODUCT_TYPE_REQUEST:
      return { ...state, isUpdating: true, errorUpdate: null };
    case ProductTypeActionTypes.UPDATE_PRODUCT_TYPE_SUCCESS:
      return { ...state, isUpdating: false, errorUpdate: null };
    case ProductTypeActionTypes.UPDATE_PRODUCT_TYPE_FAILURE:
      return { ...state, isUpdating: false, errorUpdate: action.payload };

    case ProductTypeActionTypes.SET_SELECTED_PRODUCT_TYPE:
      return {
        ...state,
        selectedProductType: action.payload
      };
    case ProductTypeActionTypes.PRODUCT_TYPE_DELETE_SUCCESS:
      const updated = state.productTypes?.filter(
        (data) => data.productTypeId !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        productTypes: updated ? updated : state.productTypes,
        deleteSuccessMsgFlag: true
      };
    case ProductTypeActionTypes.ARCHIVE_PRODUCT_TYPE_SUCCESS:
      return {
        ...state,
        deleteSuccessMsg: action?.payload ?? ""
      };
    case ProductTypeActionTypes.PRODUCT_TYPE_DELETE_FAILURE:
      return { ...state, deleteErrorMsg: action.payload };
    case ProductTypeActionTypes.RESET_PRODUCT_TYPE:
      return { ...initialState };
    case ProductTypeActionTypes.FETCH_ASSIGNED_IMSI_SUBRANGES_REQUEST:
      return {
        ...state,
        isLoadingAssignedImsiSubrange: true,
        assignedImsiSubranges: [],
        errorFetchAssignedImsiSubrange: null
      };
    case ProductTypeActionTypes.FETCH_ASSIGNED_IMSI_SUBRANGES_SUCCESS:
      return {
        ...state,
        isLoadingAssignedImsiSubrange: false,
        assignedImsiSubranges: action.payload,
        errorFetchAssignedImsiSubrange: null
      };
    case ProductTypeActionTypes.FETCH_ASSIGNED_IMSI_SUBRANGES_FAILURE:
      return {
        ...state,
        isLoadingAssignedImsiSubrange: false,
        assignedImsiSubranges: [],
        errorFetchAssignedImsiSubrange: action.payload
      };
    case ProductTypeActionTypes.FETCH_ALL_IMSI_SUBRANGES_REQUEST:
      return {
        ...state,
        isLoadingAllImsiSubrange: true,
        allImsiSubranges: [],
        errorFetchAllImsiSubrange: null
      };
    case ProductTypeActionTypes.FETCH_ALL_IMSI_SUBRANGES_SUCCESS:
      return {
        ...state,
        isLoadingAllImsiSubrange: false,
        allImsiSubranges: action.payload,
        errorFetchAllImsiSubrange: null
      };
    case ProductTypeActionTypes.FETCH_ALL_IMSI_SUBRANGES_FAILURE:
      return {
        ...state,
        isLoadingAllImsiSubrange: false,
        allImsiSubranges: [],
        errorFetchAllImsiSubrange: action.payload
      };
    default:
      return state;
  }
};

export default productTypeReducer;
