import { EmailState, EmailAction } from "../../models/email.model";
import { EmailActionTypes } from "../actions/types";

export const initialState: EmailState = {
  isLoadingFetch: false,
  emNames: [],
  emails: [],
  errorFetch: null,
  selectedEmail: null,
  isLoadingUpdate: false,
  errorUpdate: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null
};

const emailReducer = (
  state: EmailState = initialState,
  action: EmailAction
): EmailState => {
  switch (action.type) {
    case EmailActionTypes.FETCH_EMAIL_REQUEST:
      return {
        ...state,
        emails: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case EmailActionTypes.FETCH_EMAIL_SUCCESS:
      return {
        ...state,
        emails: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case EmailActionTypes.FETCH_EMAIL_FAILURE:
      return {
        ...state,
        emails: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case EmailActionTypes.UPDATE_EMAIL_REQUEST:
      return { ...state, isLoadingUpdate: true, errorUpdate: null };
    case EmailActionTypes.UPDATE_EMAIL_SUCCESS:
      return { ...state, isLoadingUpdate: false, errorUpdate: null };
    case EmailActionTypes.UPDATE_EMAIL_FAILURE:
      return { ...state, isLoadingUpdate: false, errorUpdate: action.payload };
    case EmailActionTypes.SET_SELECTED_EMAIL:
      return {
        ...state,
        selectedEmail: action.payload
      };
    case EmailActionTypes.FETCH_EMAIL_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case EmailActionTypes.FETCH_EMAIL_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case EmailActionTypes.FETCH_EMAIL_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case EmailActionTypes.RESET_EMAIL_ERR:
      return {
        ...state
      };
    case EmailActionTypes.RESET_EMAIL:
      return { ...initialState };
    default:
      return state;
  }
};

export default emailReducer;
