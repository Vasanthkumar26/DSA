import { ResetPageAction, ResetPageState } from "../../models";
import { ResetPageActionType } from "../actions/types";

export const initialState: ResetPageState = {
  resetCounter: 0
};

const appReducer = (
  state: ResetPageState = initialState,
  action: ResetPageAction
): ResetPageState => {
  if (action.type === ResetPageActionType.RESET_PAGE) {
    return {
      ...state,
      resetCounter: state.resetCounter + 1
    };
  }
  return state;
};

export default appReducer;
