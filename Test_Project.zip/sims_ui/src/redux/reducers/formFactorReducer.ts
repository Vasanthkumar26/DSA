import {
  FormFactorState,
  FormFactorAction
} from "../../models/formFactor.model";
import { FormFactorActionTypes } from "../actions/types";

export const initialState: FormFactorState = {
  isLoadingFetch: false,
  formFactors: [],
  errorFetch: null,
  selectedFormFactor: null,
  isLoadingCreate: false,
  errorCreate: null,
  isLoadingUpdate: false,
  errorUpdate: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null
};

const formFactorReducer = (
  state: FormFactorState = initialState,
  action: FormFactorAction
): FormFactorState => {
  switch (action.type) {
    case FormFactorActionTypes.FETCH_FORM_FACTOR_REQUEST:
      return {
        ...state,
        formFactors: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case FormFactorActionTypes.FETCH_FORM_FACTOR_SUCCESS:
      return {
        ...state,
        formFactors: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case FormFactorActionTypes.FETCH_FORM_FACTOR_FAILURE:
      return {
        ...state,
        formFactors: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case FormFactorActionTypes.SET_SELECTED_FORM_FACTOR:
      return {
        ...state,
        selectedFormFactor: action.payload
      };
    case FormFactorActionTypes.DELETE_SELECTED_FORM_FACTOR_SUCCESS:
      const updated = state.formFactors?.filter(
        (fFactor) => fFactor.FormFactorId !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        formFactors: updated ? updated : state.formFactors,
        deleteSuccessMsgFlag: true
      };
    case FormFactorActionTypes.ARCHIVE_SELECTED_FORM_FACTOR_SUCCESS:
      const updatedFFactor = state.formFactors?.map((fFactor) => {
        if (fFactor.FormFactorId === action?.payload?.id) {
          fFactor.archived = !action?.payload?.archive;
        }
        return fFactor;
      });
      return {
        ...state,
        formFactors: updatedFFactor ? updatedFFactor : state.formFactors
      };
    case FormFactorActionTypes.DELETE_SELECTED_FORM_FACTOR_FAILURE:
      return { ...state, deleteErrorMsg: action.payload };
    case FormFactorActionTypes.RESET_FORMFACTOR_ERR:
      return {
        ...state,
        deleteSuccessMsgFlag: false
      };
    case FormFactorActionTypes.CREATE_FORM_FACTOR_REQUEST:
      return { ...state, isLoadingCreate: true, errorCreate: null };
    case FormFactorActionTypes.CREATE_FORM_FACTOR_SUCCESS:
      return { ...state, isLoadingCreate: false, errorCreate: null };
    case FormFactorActionTypes.CREATE_FORM_FACTOR_FAILURE:
      return { ...state, isLoadingCreate: false, errorCreate: action.payload };
    case FormFactorActionTypes.UPDATE_FORM_FACTOR_REQUEST:
      return { ...state, isLoadingUpdate: true, errorUpdate: null };
    case FormFactorActionTypes.UPDATE_FORM_FACTOR_SUCCESS:
      return { ...state, isLoadingUpdate: false, errorUpdate: null };
    case FormFactorActionTypes.UPDATE_FORM_FACTOR_FAILURE:
      return { ...state, isLoadingUpdate: false, errorUpdate: action.payload };
    case FormFactorActionTypes.FETCH_FORM_FACTOR_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case FormFactorActionTypes.FETCH_FORM_FACTOR_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case FormFactorActionTypes.FETCH_FORM_FACTOR_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case FormFactorActionTypes.RESET_FORM_FACTOR:
      return { ...initialState };
    default:
      return state;
  }
};

export default formFactorReducer;
