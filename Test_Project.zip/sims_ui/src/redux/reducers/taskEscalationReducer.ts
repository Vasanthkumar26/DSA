import {
  TaskEscalationAction,
  TaskEscalationState
} from "../../models/taskEscalation.model";
import { TaskEscalationActionTypes } from "../actions/types";

export const initialState: TaskEscalationState = {
  isLoadingFetch: false,
  taskEscalations: [],
  errorFetch: null,
  isCreated: false,
  createdSuccess: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null
};

const taskEscalationReducer = (
  state: TaskEscalationState = initialState,
  action: TaskEscalationAction
): TaskEscalationState => {
  switch (action.type) {
    case TaskEscalationActionTypes.FETCH_TASK_ESCALATION_REQUEST:
      return {
        ...state,
        taskEscalations: [],
        errorFetch: null
      };
    case TaskEscalationActionTypes.FETCH_TASK_ESCALATION_SUCCESS:
      return {
        ...state,
        taskEscalations: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case TaskEscalationActionTypes.FETCH_TASK_ESCALATION_FAILURE:
      return {
        ...state,
        taskEscalations: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case TaskEscalationActionTypes.CREATE_TASK_ESCALATION_REQUEST:
      return {
        ...state,
        isCreated: true,
        createdSuccess: null
      };
    case TaskEscalationActionTypes.CREATE_TASK_ESCALATION_SUCCESS:
      return {
        ...state,
        isCreated: true,
        createdSuccess: action.payload
      };
    case TaskEscalationActionTypes.RESET_MESSAGE:
      return {
        ...state,
        isCreated: false,
        createdSuccess: null
      };
    case TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case TaskEscalationActionTypes.UPDATE_TASK_ESCALATION_REQUEST:
      return { ...state, isLoadingFetch: true, errorFetch: null };
    case TaskEscalationActionTypes.UPDATE_TASK_ESCALATION_SUCCESS:
      return { ...state, isLoadingFetch: false, errorFetch: null };
    case TaskEscalationActionTypes.UPDATE_TASK_ESCALATION_FAILURE:
      return { ...state, isLoadingFetch: false, errorFetch: action.payload };
    case TaskEscalationActionTypes.SET_SELECTED_TASK_ESCALATION:
      return {
        ...state,
        selectedTaskEscalation: action.payload
      };
    default:
      return state;
  }
};

export default taskEscalationReducer;
