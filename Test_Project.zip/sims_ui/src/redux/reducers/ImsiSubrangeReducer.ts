import { ImsiSubrangeAction, ImsiSubrangeState } from "../../models";
import { ImsiSubrangeActionTypes } from "../actions/types";

export const initialState: ImsiSubrangeState = {
  isLoadingFetch: false,
  imsiSubranges: [],
  selectedImsiSubrange: null,
  errorFetch: null,
  isLoading: false,
  error: null,
  imsiMainRangeList: [],
  productTypeList: [
    { productTypeId: "1", name: "pack-1" },
    { productTypeId: "2", name: "pack2-2" }
  ],
  successMsg: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null,
  isLoadingFetchStatusTable: false,
  errorFetchStatusTable: null,
  subrangestatusdetail: []
};
const ImsiSubrangeReducer = (
  state: ImsiSubrangeState = initialState,
  action: ImsiSubrangeAction
): ImsiSubrangeState => {
  switch (action.type) {
    case ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_REQUEST:
      return {
        ...state,
        imsiSubranges: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_SUCCESS:
      return {
        ...state,
        imsiSubranges: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_FAILURE:
      return {
        ...state,
        imsiSubranges: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };

    case ImsiSubrangeActionTypes.FETCH_DDL_DATA_REQUEST:
      return {
        ...state,
        isLoading: true,
        error: null
      };
    case ImsiSubrangeActionTypes.FETCH_DDL_DATA_SUCCESS:
      return {
        ...state,
        imsiMainRangeList: action.payload?.allImsiMainRanges,
        productTypeList: action.payload?.allProductTypes,
        isLoading: false,
        error: null
      };
    case ImsiSubrangeActionTypes.FETCH_DDL_DATA_ERROR:
      return {
        ...state,
        imsiMainRangeList: [
          { imsiMainRangeId: "1", mainRangeCombinedName: "CombinedName-1" },
          { imsiMainRangeId: "2", mainRangeCombinedName: "CombinedName-2" }
        ],
        productTypeList: [
          { productTypeId: "1", name: "ProductType-1" },
          { productTypeId: "2", name: "ProductType-2" }
        ],
        isLoading: false,
        error: action.payload
      };
    case ImsiSubrangeActionTypes.CREATE_REQUEST:
      return {
        ...state,
        isLoading: true
      };
    case ImsiSubrangeActionTypes.CREATE_SUCCESS:
      return {
        ...state,
        isLoading: false,
        // imsiSubranges: [action.payload?.data, ...state.imsiSubranges],
        // successMsg: action.payload?.message,
        error: null
      };
    case ImsiSubrangeActionTypes.CREATE_FAILURE:
      return {
        ...state,
        isLoading: false,
        error: action.payload
      };
    case ImsiSubrangeActionTypes.SET_SELECTED_IMSI_SUBRANGE:
      return {
        ...state,
        selectedImsiSubrange: action.payload
      };
    case ImsiSubrangeActionTypes.RESET_ERROR:
      return {
        ...state,
        error: null,
        deleteSuccessMsgFlag: false,
        archSuccessMsgFlag: false
      };
    case ImsiSubrangeActionTypes.RESET_FORM:
      return { ...state, error: null, selectedImsiSubrange: null };

    case ImsiSubrangeActionTypes.DELETE_IMSI_SUBRANGE_SUCCESS:
      const updatedHlrs = state.imsiSubranges?.filter(
        (imsiMainrange) => imsiMainrange.imsisubRangeId !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        imsiSubranges: updatedHlrs ? updatedHlrs : state.imsiSubranges,
        deleteSuccessMsgFlag: true
      };
    case ImsiSubrangeActionTypes.ARCHIVE_IMSI_SUBRANGE_SUCCESS:
      return {
        ...state,
        imsiSubranges: state.imsiSubranges
      };
    case ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_STATUS_REQUEST:
      return {
        ...state,
        isLoadingFetchStatusTable: true,
        subrangestatusdetail: [],
        errorFetchStatusTable: null
      };
    case ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_STATUS_SUCCESS:
      return {
        ...state,
        isLoadingFetchStatusTable: false,
        subrangestatusdetail: action.payload,
        errorFetchStatusTable: null
      };
    case ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_STATUS_FAILURE:
      return {
        ...state,
        isLoadingFetchStatusTable: false,
        subrangestatusdetail: [],
        errorFetchStatusTable: action.payload
      };
    case ImsiSubrangeActionTypes.RESET_IMSI_SUBRANGE:
      return { ...initialState };
    default:
      return state;
  }
};

export default ImsiSubrangeReducer;
