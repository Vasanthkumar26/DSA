import { ImsiRangesAction, ImsiRangesState } from "../../models";
import { ImsiRangesActionTypes } from "../actions/types";

export const initialState: ImsiRangesState = {
  isLoadingFetch: false,
  imsiRanges: [],
  selectedImsiRange: null,
  errorFetch: null
};

const imsiSearchLockReducer = (
  state: ImsiRangesState = initialState,
  action: ImsiRangesAction
): ImsiRangesState => {
  switch (action.type) {
    case ImsiRangesActionTypes.FETCH_IMSI_RANGES_REQUEST:
      return {
        ...state,
        imsiRanges: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case ImsiRangesActionTypes.FETCH_IMSI_RANGES_SUCCESS:
      return {
        ...state,
        imsiRanges: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };

    case ImsiRangesActionTypes.FETCH_IMSI_RANGES_FAILURE:
      return {
        ...state,
        imsiRanges: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case ImsiRangesActionTypes.SET_SELECTED_IMSI_RANGES:
      return {
        ...state,
        selectedImsiRange: action.payload
      };
    default:
      return state;
  }
};
export default imsiSearchLockReducer;
