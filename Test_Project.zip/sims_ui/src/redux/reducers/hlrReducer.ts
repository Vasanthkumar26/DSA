import { Hlr, HlrAction, HlrState } from "../../models";
import { HlrActionTypes } from "../actions/types";

export const initialState: HlrState = {
  isLoadingFetch: false,
  hlrs: [],
  errorFetch: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null,
  isLoadingCreate: false,
  errorCreate: null,
  isLoadingUpdate: false,
  errorUpdate: null,
  archiveSuccessMsg: null,
  errorArchive: null,
  selectedHLR: null
};

const hlrReducer = (
  state: HlrState = initialState,
  action: HlrAction
): HlrState => {
  switch (action.type) {
    case HlrActionTypes.FETCH_HLR_REQUEST:
      return {
        ...state,
        hlrs: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case HlrActionTypes.FETCH_HLR_SUCCESS:
      return {
        ...state,
        hlrs: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };
    case HlrActionTypes.FETCH_HLR_FAILURE:
      return {
        ...state,
        hlrs: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case HlrActionTypes.FETCH_HLR_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case HlrActionTypes.FETCH_HLR_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case HlrActionTypes.FETCH_HLR_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case HlrActionTypes.CREATE_HLR_REQUEST:
      return { ...state, isLoadingCreate: true, errorCreate: null };
    case HlrActionTypes.CREATE_HLR_SUCCESS:
      return {
        ...state,
        isLoadingCreate: false,
        errorCreate: null,
        hlrs: [action.payload as Hlr, ...state.hlrs]
      };
    case HlrActionTypes.CREATE_HLR_FAILURE:
      return { ...state, isLoadingCreate: false, errorCreate: action.payload };
    case HlrActionTypes.UPDATE_HLR_REQUEST:
      return { ...state, isLoadingUpdate: true, errorUpdate: null };
    case HlrActionTypes.UPDATE_HLR_SUCCESS:
      const { payload } = action;

      const updatedHLR = state.hlrs?.map((hlr) => {
        if (`${hlr.id}` === `${payload.id}`) {
          hlr.archived = payload.archived;
          hlr.description = payload.description;
          hlr.greenIccidImsi = payload.greenSim;
          hlr.hlrName = payload.hlrName;
          hlr.iccid = Number(payload.iccidDigit12);
          hlr.imsiDigits12345 = `${payload.imsiDigit123}-${payload.imsiDigit45}`;
          hlr.lastUpdateDate = payload.lastUpdatedDate;
        }

        return hlr;
      });

      return {
        ...state,
        isLoadingUpdate: false,
        errorUpdate: null,
        hlrs: updatedHLR ? updatedHLR : state.hlrs
      };
    case HlrActionTypes.UPDATE_HLR_FAILURE:
      return { ...state, isLoadingUpdate: false, errorUpdate: action.payload };
    case HlrActionTypes.RESET_HLR_ERR:
      return {
        ...state,
        errorCreate: null,
        errorUpdate: null,
        deleteSuccessMsgFlag: false,
        archiveSuccessMsg: null
      };
    case HlrActionTypes.ARCHIVE_HLR_REQUEST:
      return {
        ...state,
        archiveSuccessMsg: null,
        errorArchive: null
      };
    case HlrActionTypes.ARCHIVE_HLR_SUCCESS:
      const updatedHlr = state.hlrs?.map((hlr) => {
        if (`${hlr.id}` === `${payload?.id}`) {
          hlr.archived = payload?.archived;
          hlr.lastUpdateDate = payload?.lastUpdatedDate;
        }
        return hlr;
      });
      return {
        ...state,
        archiveSuccessMsg: `Successfully Archived`,
        hlrs: updatedHlr ? updatedHlr : state.hlrs
      };
    case HlrActionTypes.ARCHIVE_HLR_FAILURE:
      return {
        ...state,
        archiveSuccessMsg: null,
        errorArchive: action.payload
      };
    case HlrActionTypes.SET_SELECTED_HLR:
      return {
        ...state,
        selectedHLR: action.payload
      };
    case HlrActionTypes.DELETE_HLR_SUCCESS:
      const updatedHlrs = state.hlrs?.filter(
        (hlr) => hlr.id !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        deleteSuccessMsgFlag: true,
        hlrs: updatedHlrs ? updatedHlrs : state.hlrs
      };
    case HlrActionTypes.RESET_HLR:
      return { ...state, ...initialState };
    default:
      return state;
  }
};

export default hlrReducer;
