import {
  ExternalSystemState,
  ExternalSystemsAction
} from "../../models/externalSystems.model";
import { ExternalSystemsActionTypes } from "../actions/types";

export const initialState: ExternalSystemState = {
  isLoadingFetch: false,
  externalSystems: [],
  esNames: [],
  errorFetch: null,
  selectedExternalSystem: null,
  isLoadingCreate: false,
  errorCreate: null,
  isLoadingUpdate: false,
  errorUpdate: null,
  isLoadingExport: false,
  exportSuccessMsg: null,
  errorExport: null
};

const externalSystemsReducer = (
  state: ExternalSystemState = initialState,
  action: ExternalSystemsAction
): ExternalSystemState => {
  switch (action.type) {
    case ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEMS_REQUEST:
      return {
        ...state,
        externalSystems: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEMS_SUCCESS:
      return {
        ...state,
        externalSystems: action.payload,
        esNames: (action.payload ?? []).map((x) => x.name ?? ""),
        isLoadingFetch: false,
        errorFetch: null
      };
    case ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEMS_FAILURE:
      return {
        ...state,
        externalSystems: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case ExternalSystemsActionTypes.SET_SELECTED_EXTERNAL_SYSTEMS:
      return {
        ...state,
        selectedExternalSystem: action.payload
      };
    case ExternalSystemsActionTypes.DELETE_SELECTED_EXTERNAL_SUCCESS:
      const updated = state.externalSystems?.filter(
        (imsiMainrange) => imsiMainrange.externalSystemId !== action.payload
      );
      return {
        ...state,
        deleteSuccessMsg: `Successfully deleted ${action.payload}`,
        externalSystems: updated ? updated : state.externalSystems,
        deleteSuccessMsgFlag: true
      };
    case ExternalSystemsActionTypes.ARCHIVE_SELECTED_EXTERNAL_SUCCESS:
      const updatedExternSys = state.externalSystems?.map((externSys) => {
        if (externSys.externalSystemId === action?.payload?.id) {
          externSys.archived = !action?.payload?.archive;
        }
        return externSys;
      });
      return {
        ...state,
        externalSystems: updatedExternSys
          ? updatedExternSys
          : state.externalSystems
      };
    case ExternalSystemsActionTypes.DELETE_SELECTED_EXTERNAL_FAILURE:
      return { ...state, deleteErrorMsg: action.payload };
    case ExternalSystemsActionTypes.RESET_ExtertnalSystem_ERR:
      return {
        ...state,
        deleteSuccessMsgFlag: false
      };
    case ExternalSystemsActionTypes.CREATE_EXTERNAL_SYSTEMS_REQUEST:
      return { ...state, isLoadingCreate: true, errorCreate: null };
    case ExternalSystemsActionTypes.CREATE_EXTERNAL_SYSTEMS_SUCCESS:
      return { ...state, isLoadingCreate: false, errorCreate: null };
    case ExternalSystemsActionTypes.CREATE_EXTERNAL_SYSTEMS_FAILURE:
      return { ...state, isLoadingCreate: false, errorCreate: action.payload };
    case ExternalSystemsActionTypes.UPDATE_EXTERNAL_SYSTEMS_REQUEST:
      return { ...state, isLoadingUpdate: true, errorUpdate: null };
    case ExternalSystemsActionTypes.UPDATE_EXTERNAL_SYSTEMS_SUCCESS:
      return { ...state, isLoadingUpdate: false, errorUpdate: null };
    case ExternalSystemsActionTypes.UPDATE_EXTERNAL_SYSTEMS_FAILURE:
      return { ...state, isLoadingUpdate: false, errorUpdate: action.payload };
    case ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_REQUEST:
      return {
        ...state,
        isLoadingExport: true,
        exportSuccessMsg: null,
        errorExport: null
      };
    case ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_SUCCESS:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: action.payload,
        errorExport: null
      };
    case ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_FAILURE:
      return {
        ...state,
        isLoadingExport: false,
        exportSuccessMsg: null,
        errorExport: action.payload
      };
    case ExternalSystemsActionTypes.RESET_EXTERNAL_SYSTEM:
      return { ...initialState };
    default:
      return state;
  }
};

export default externalSystemsReducer;
