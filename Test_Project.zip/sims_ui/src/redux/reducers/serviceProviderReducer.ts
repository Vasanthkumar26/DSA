import { ServiceProviderAction, ServiceProviderState } from "../../models";
import { ServiceProviderActionTypes } from "../actions/types";

export const initialState: ServiceProviderState = {
  isLoadingFetch: false,
  serviceProviders: [],
  errorFetch: null,
};

const serviceProviderReducer = (
  state: ServiceProviderState = initialState,
  action: ServiceProviderAction
): ServiceProviderState => {
  switch (action.type) {
    case ServiceProviderActionTypes.FETCH_SERVICE_PROVIDER_REQUEST:
      return {
        ...state,
        serviceProviders: [],
        isLoadingFetch: true,
        errorFetch: null,
      };
    case ServiceProviderActionTypes.FETCH_SERVICE_PROVIDER_SUCCESS:
      return {
        ...state,
        serviceProviders: action.payload,
        isLoadingFetch: false,
        errorFetch: null,
      };
    case ServiceProviderActionTypes.FETCH_SERVICE_PROVIDER_FAILURE:
      return {
        ...state,
        serviceProviders: [],
        isLoadingFetch: false,
        errorFetch: action.payload,
      };
    default:
      return state;
  }
};

export default serviceProviderReducer;
