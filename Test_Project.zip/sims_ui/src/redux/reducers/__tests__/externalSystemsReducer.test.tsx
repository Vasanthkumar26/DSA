// @ts-nocheck
import { ExternalSystemsActionTypes } from "../../actions/types";
import externalSystemsReducer, {
  initialState
} from "../externalSystemsReducer";

describe("externalSystemsReducer", () => {
  test("should return the initial state", () => {
    expect(externalSystemsReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_EXTERNAL_SYSTEMS_REQUEST", () => {
    expect(
      externalSystemsReducer(undefined, {
        type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEMS_REQUEST
      })
    ).toEqual({
      ...initialState,
      externalSystems: [],
      esNames: [],
      isLoadingFetch: true,
      errorFetch: null
    });
  });

  test("should handle FETCH_EXTERNAL_SYSTEMS_SUCCESS", () => {
    expect(
      externalSystemsReducer(undefined, {
        type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEMS_SUCCESS,
        payload: [{ id: 1, emailAddress: "abc_1@outlook" }]
      })
    ).toEqual({
      ...initialState,
      externalSystems: [{ id: 1, emailAddress: "abc_1@outlook" }],
      esNames: [""],
      isLoadingFetch: false,
      errorFetch: null
    });
  });

  test("should handle FETCH_EXTERNAL_SYSTEMS_FAILURE", () => {
    expect(
      externalSystemsReducer(undefined, {
        type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEMS_FAILURE,
        payload: "Something went wrong"
      })
    ).toEqual({
      ...initialState,
      externalSystems: [],
      isLoadingFetch: false,
      errorFetch: "Something went wrong"
    });
  });
  test("should handle FETCH_EXTERNAL_SYSTEM_EXPORT_REQUEST", () => {
    expect(
      externalSystemsReducer(undefined, {
        type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: true,
      exportSuccessMsg: null,
      errorExport: null
    });
  });
  test("should handle FETCH_EXTERNAL_SYSTEM_EXPORT_SUCCESS", () => {
    expect(
      externalSystemsReducer(undefined, {
        type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_SUCCESS,
        payload: "successful"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: "successful",
      errorExport: null
    });
  });

  test("should handle FETCH_EXTERNAL_SYSTEM_EXPORT_FAILURE", () => {
    expect(
      externalSystemsReducer(undefined, {
        type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_FAILURE,
        payload: "Something went wrong"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: null,
      errorExport: "Something went wrong"
    });
  });

  test("should handle DELETE_EXTERNAL_SUCCESS", () => {
    expect(
      externalSystemsReducer(undefined, {
        type: ExternalSystemsActionTypes.DELETE_SELECTED_EXTERNAL_SUCCESS,
        payload: "123"
      })
    ).toEqual({
      ...initialState,
      deleteSuccessMsg: "Successfully deleted 123",
      deleteSuccessMsgFlag: true
    });
  });
});
