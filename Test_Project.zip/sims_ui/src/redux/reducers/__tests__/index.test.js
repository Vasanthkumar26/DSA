import rootReducer from "../../reducers";
import ImsiMainrangeReducer from "../ImsiMainrangeReducer";
import ImsiSubrangeReducer from "../ImsiSubrangeReducer";
import SimVendorReducer from "../simVendorReducer";
import authReducer from "../authReducer";
import hlrReducer from "../hlrReducer";
import kittingArticlesReducer from "../kittingArticlesReducer";
import languageReducer from "../languageReducer";
import serviceProviderReducer from "../serviceProviderReducer";
import akaReducer from "../akaReducer";
import externalSystemsReducer from "../externalSystemsReducer";
import ElectricalProfileReducer from "../electricalProfileReducer";
import { snackbarReducer } from "../snackbarReducer";
import cockpitReducer from "../cockpitReducer";
import deliverAddressReducer from "../deliveryAddressReducer";
import cardTypesReducer from "../cardTypesReducer";
import imsiSearchLockReducer from "../imsiSearchLockReducer";
import productTypeReducer from "../productTypeReducer";
import kittingOrderReducer from "../kittingOrderReducer";
import formFactorReducer from "../formFactorReducer";
import appReducer from "../appReducer";
import shortCodeReducer from "../shortCodeReducer";
import customProfileReducer from "../customProfileReducer";
import taskReducer from "../taskReducer";
import simArticleReducer from "../simArticleReducer";
import taskEscalationReducer from "../taskEscalationReducer";
import emailReducer from "../emailReducer";

describe("rootReducer", () => {
  test("should return the initial state", () => {
    expect(rootReducer({}, {})).toEqual({
      app: appReducer(undefined, {}),
      snackbar: snackbarReducer(undefined, {}),
      auth: authReducer(undefined, {}),
      lang: languageReducer(undefined, {}),
      kittingArticles: kittingArticlesReducer(undefined, {}),
      hlr: hlrReducer(undefined, {}),
      imsiMainrange: ImsiMainrangeReducer(undefined, {}),
      imsiSubrange: ImsiSubrangeReducer(undefined, {}),
      serviceProvider: serviceProviderReducer(undefined, {}),
      simVendor: SimVendorReducer(undefined, {}),
      aka: akaReducer(undefined, {}),
      externalSystem: externalSystemsReducer(undefined, {}),
      electricalProfile: ElectricalProfileReducer(undefined, {}),
      cockpit: cockpitReducer(undefined, {}),
      deliverAddress: deliverAddressReducer(undefined, {}),
      cardType: cardTypesReducer(undefined, {}),
      imsiSearchLock: imsiSearchLockReducer(undefined, {}),
      productType: productTypeReducer(undefined, {}),
      kittingOrder: kittingOrderReducer(undefined, {}),
      shortCode: shortCodeReducer(undefined, {}),
      formFactor: formFactorReducer(undefined, {}),
      customProfile: customProfileReducer(undefined, {}),
      task: taskReducer(undefined, {}),
      simArticle: simArticleReducer(undefined, {}),
      taskEscalation: taskEscalationReducer(undefined, {}),
      email: emailReducer(undefined, {})
    });
  });

  test.skip("should handle actions", () => {
    const state = {
      auth: { isLoggedIn: false },
      lang: { language: "en" },
      kittingArticles: { articles: [] },
      hlr: { hlrs: [] },
      imsiMainrange: { imsiMainranges: [] },
      imsiSubrange: { imsiSubranges: [] }
    };
    const action = { type: "SET_LANGUAGE", payload: "fr" };

    expect(rootReducer(state, action)).toEqual({
      auth: authReducer(state.auth, action),
      lang: languageReducer(state.lang, action),
      kittingArticles: kittingArticlesReducer(state.kittingArticles, action),
      hlr: hlrReducer(state.hlrs, action),
      imsiMainrange: ImsiMainrangeReducer(state.imsiMainranges, action),
      imsiSubrange: ImsiSubrangeReducer(state.imsiSubranges, action)
    });
  });
});
