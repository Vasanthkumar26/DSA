// @ts-nocheck
import ElectricalProfileReducer, {
  initialState
} from "../electricalProfileReducer";
import { ElectricalProfileActionTypes } from "../../actions/types";

describe("Electrical profile Reducer", () => {
  test("should return the initial State", () => {
    expect(ElectricalProfileReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_EP_EXPORT_REQUEST", () => {
    expect(
      ElectricalProfileReducer(undefined, {
        type: ElectricalProfileActionTypes.FETCH_EP_EXPORT_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: true,
      exportSuccessMsg: null,
      errorExport: null
    });
  });

  test("should handle FETCH_EP_EXPORT_SUCCESS", () => {
    expect(
      ElectricalProfileReducer(undefined, {
        type: ElectricalProfileActionTypes.FETCH_EP_EXPORT_SUCCESS,
        payload: "successfull"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: "successfull",
      errorExport: null
    });
  });

  test("should handle FETCH_EP_EXPORT_FAILURE", () => {
    expect(
      ElectricalProfileReducer(undefined, {
        type: ElectricalProfileActionTypes.FETCH_EP_EXPORT_FAILURE,
        payload: "something went wrong"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: null,
      errorExport: "something went wrong"
    });
  });

  test("should handle DELETE_ELECTRIC_SUCCESS", () => {
    expect(
      ElectricalProfileReducer(undefined, {
        type: ElectricalProfileActionTypes.EP_DELETE_SUCCESS,
        payload: "123"
      })
    ).toEqual({
      ...initialState,
      deleteSuccessMsg: "Successfully deleted 123",
      deleteSuccessMsgFlag: true
    });
  });
});
