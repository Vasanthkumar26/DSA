// @ts-nocheck
import { mainRangeStatusData } from "../../../_mocks_";
import { ImsiMainrangeActionTypes } from "../../actions/types";
import ImsiMainrangeReducer, { initialState } from "../ImsiMainrangeReducer";

describe("ImsiMainrange", () => {
  test("should return the initial state", () => {
    expect(ImsiMainrangeReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_IMSI_MAINRANGE_REQUEST", () => {
    expect(
      ImsiMainrangeReducer(undefined, {
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_REQUEST
      })
    ).toEqual({
      ...initialState,
      imsiMainranges: [],
      isLoadingFetch: true,
      errorFetch: null
    });
  });

  test("should handle FETCH_IMSI_MAINRANGE_SUCCESS", () => {
    expect(
      ImsiMainrangeReducer(undefined, {
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_SUCCESS,
        payload: [
          {
            imsiName: "testImsi6",
            hlrCombinedName: "HLRBLACK - 123-45",
            imsiDigits678: "234",
            serviceProvider: "BCS (SP995)"
          }
        ]
      })
    ).toEqual({
      ...initialState,
      imsiMainranges: [
        {
          imsiName: "testImsi6",
          hlrCombinedName: "HLRBLACK - 123-45",
          imsiDigits678: "234",
          serviceProvider: "BCS (SP995)"
        }
      ],
      isLoadingFetch: false,
      errorFetch: null
    });
  });

  test("should handle FETCH_IMSI_MAINRANGE_FAILURE", () => {
    expect(
      ImsiMainrangeReducer(undefined, {
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_FAILURE,
        payload: "Something went wrong"
      })
    ).toEqual({
      ...initialState,
      imsiMainranges: [],
      isLoadingFetch: false,
      errorFetch: "Something went wrong"
    });
  });
  test("should handle FETCH_IMSI_MAINRANGE_EXPORT_REQUEST", () => {
    expect(
      ImsiMainrangeReducer(undefined, {
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: true,
      exportSuccessMsg: null,
      errorExport: null
    });
  });
  test("should handle FETCH_IMSI_MAINRANGE_EXPORT_SUCCESS", () => {
    expect(
      ImsiMainrangeReducer(undefined, {
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_SUCCESS,
        payload: "successfull"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: "successfull",
      errorExport: null
    });
  });
  test("should handle FETCH_IMSI_MAINRANGE_EXPORT_FAILURE", () => {
    expect(
      ImsiMainrangeReducer(undefined, {
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_FAILURE,
        payload: "something went wrong"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: null,
      errorExport: "something went wrong"
    });
  });
  test("should handle DELETE_IMSI_MAINRANGE_SUCCESS", () => {
    expect(
      ImsiMainrangeReducer(undefined, {
        type: ImsiMainrangeActionTypes.DELETE_IMSI_SUCCESS,
        payload: "123"
      })
    ).toEqual({
      ...initialState,
      deleteSuccessMsg: "Successfully deleted 123",
      deleteSuccessMsgFlag: true
    });
  });

  test("should handle FETCH_IMSI_MAINRANGE_STATUS_REQUEST", () => {
    expect(
      ImsiMainrangeReducer(undefined, {
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_STATUS_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingStatusTable: true,
      mainrangeStatusDetail: []
    });
  });

  test("should handle FETCH_IMSI_MAINRANGE_STATUS_SUCCESS", () => {
    expect(
      ImsiMainrangeReducer(undefined, {
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_STATUS_SUCCESS,
        payload: mainRangeStatusData
      })
    ).toEqual({
      ...initialState,
      isLoadingStatusTable: false,
      mainrangeStatusDetail: mainRangeStatusData
    });
  });

  test("should handle FETCH_IMSI_MAINRANGE_STATUS_FAILURE", () => {
    expect(
      ImsiMainrangeReducer(undefined, {
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_STATUS_FAILURE
      })
    ).toEqual({
      ...initialState,
      isLoadingStatusTable: false,
      mainrangeStatusDetail: []
    });
  });
});
