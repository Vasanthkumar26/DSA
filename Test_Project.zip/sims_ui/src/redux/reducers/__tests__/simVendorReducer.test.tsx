// @ts-nocheck
import { SimVendorActionTypes } from "../../actions/types";
import SimVendorReducer, { initialState } from "../simVendorReducer";

describe("SimVendorReducer", () => {
  test("should return the initial state", () => {
    expect(SimVendorReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_SIM_VENDOR_REQUEST", () => {
    expect(
      SimVendorReducer(undefined, {
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_REQUEST
      })
    ).toEqual({
      ...initialState,
      simVendros: [],
      isLoadingFetch: true,
      errorFetch: null
    });
  });

  test("should handle FETCH_SIM_VENDOR_SUCCESS", () => {
    expect(
      SimVendorReducer(undefined, {
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_SUCCESS,
        payload: [{ id: 1, emailAddress: "abc_1@outlook" }]
      })
    ).toEqual({
      ...initialState,
      simVendros: [{ id: 1, emailAddress: "abc_1@outlook" }],
      isLoadingFetch: false,
      errorFetch: null
    });
  });

  test("should handle FETCH_SIM_VENDOR_FAILURE", () => {
    expect(
      SimVendorReducer(undefined, {
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_FAILURE,
        payload: "Something went wrong"
      })
    ).toEqual({
      ...initialState,
      simVendros: [],
      isLoadingFetch: false,
      errorFetch: "Something went wrong"
    });
  });

  test("should handle FETCH_SIM_VENDOR_EXPORT_REQUEST", () => {
    expect(
      SimVendorReducer(undefined, {
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: true,
      exportSuccessMsg: null,
      errorExport: null
    });
  });

  test("should handle FETCH_SIM_VENDOR_EXPORT_SUCCESS", () => {
    expect(
      SimVendorReducer(undefined, {
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_SUCCESS,
        payload: "successful"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: "successful",
      errorExport: null
    });
  });

  test("should handle FETCH_SIM_VENDOR_EXPORT_ERROR", () => {
    expect(
      SimVendorReducer(undefined, {
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_ERROR,
        payload: "Something went wrong"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: null,
      errorExport: "Something went wrong"
    });
  });

  test("should handle DELETE_SIM_SUCCESS", () => {
    expect(
      SimVendorReducer(undefined, {
        type: SimVendorActionTypes.DELETE_SIM_VENDOR_SUCCESS,
        payload: "123"
      })
    ).toEqual({
      ...initialState,
      deleteSuccessMsg: "Successfully deleted 123",
      deleteSuccessMsgFlag: true
    });
  });
});
