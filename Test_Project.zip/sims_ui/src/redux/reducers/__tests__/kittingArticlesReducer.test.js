import kittingArticlesReducer, {
  initialState
} from "../kittingArticlesReducer";
import {
  FETCH_KITTING_ARTICLES_REQUEST,
  FETCH_KITTING_ARTICLES_SUCCESS,
  FETCH_KITTING_ARTICLES_FAILURE,
  SET_SELECTED_KITTING_ARTICLE,
  FETCH_KITTING_ARTICLES_EXPORT_FAILURE,
  FETCH_KITTING_ARTICLES_EXPORT_REQUEST,
  FETCH_KITTING_ARTICLES_EXPORT_SUCCESS,
  ADD_ARTICLE_IN_STATE,
  DELETE_KITTING_IN_STATE
} from "../../actions/types";

describe("kittingArticlesReducer", () => {
  test("should return the initial state", () => {
    expect(kittingArticlesReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_KITTING_ARTICLES_REQUEST", () => {
    expect(
      kittingArticlesReducer(undefined, {
        type: FETCH_KITTING_ARTICLES_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingFetch: true,
      kittingArticles: [],
      selectedKittingArticle: null,
      errorFetch: null
    });
  });

  test("should handle FETCH_KITTING_ARTICLES_SUCCESS", () => {
    expect(
      kittingArticlesReducer(undefined, {
        type: FETCH_KITTING_ARTICLES_SUCCESS,
        payload: {
          kittingArticles: [{ id: 1, name: "Article 1" }]
        }
      })
    ).toEqual({
      ...initialState,
      isLoadingFetch: false,
      kittingArticles: [{ id: 1, name: "Article 1" }],
      selectedKittingArticle: null,
      errorFetch: null
    });
  });

  test("should handle FETCH_KITTING_ARTICLES_FAILURE", () => {
    expect(
      kittingArticlesReducer(undefined, {
        type: FETCH_KITTING_ARTICLES_FAILURE,
        payload: {
          errorFetch: "Something went wrong"
        }
      })
    ).toEqual({
      ...initialState,
      isLoadingFetch: false,
      kittingArticles: [],
      selectedKittingArticle: null,
      errorFetch: "Something went wrong"
    });
  });

  test("should handle SET_SELECTED_KITTING_ARTICLE", () => {
    expect(
      kittingArticlesReducer(undefined, {
        type: SET_SELECTED_KITTING_ARTICLE,
        payload: {
          kittingArticle: { id: 1, name: "Article 1" }
        }
      })
    ).toEqual({
      ...initialState,
      isLoadingFetch: false,
      kittingArticles: [],
      selectedKittingArticle: { id: 1, name: "Article 1" },
      errorFetch: null
    });
  });

  test("should handle FETCH_KITTING_ARTICLES_EXPORT_REQUEST", () => {
    expect(
      kittingArticlesReducer(undefined, {
        type: FETCH_KITTING_ARTICLES_EXPORT_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: true,
      exportSuccessMsg: null,
      errorExport: null
    });
  });

  test("should handle FETCH_KITTING_ARTICLES_EXPORT_SUCCESS", () => {
    expect(
      kittingArticlesReducer(undefined, {
        type: FETCH_KITTING_ARTICLES_EXPORT_SUCCESS,
        payload: { message: "successfull" }
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: "successfull",
      errorExport: null
    });
  });
  test("should handle FETCH_KITTING_ARTICLES_EXPORT_FAILURE", () => {
    expect(
      kittingArticlesReducer(undefined, {
        type: FETCH_KITTING_ARTICLES_EXPORT_FAILURE,
        payload: { error: "someting went wrong" }
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: null,
      errorExport: "someting went wrong"
    });
  });
  test("should handle ADD_IN_STATE", () => {
    expect(
      kittingArticlesReducer(undefined, {
        type: ADD_ARTICLE_IN_STATE,
        payload: { id: 1, name: "Article 1" }
      })
    ).toEqual({
      ...initialState,
      kittingArticles: [{ id: 1, name: "Article 1" }]
    });
  });

  test("should handle DELETE_KITTING_IN_STATE", () => {
    const initialStates = Object.assign(initialState, {
      kittingArticles: [
        {
          id: 1,
          description: "Article 1",
          comment: "",
          lastUpdateDate: "",
          systemStackId: "",
          startPackType: "",
          userName: ""
        },
        {
          id: 2,
          description: "Article 2",
          comment: "",
          lastUpdateDate: "",
          systemStackId: "",
          startPackType: "",
          userName: ""
        }
      ]
    });
    const action = {
      type: DELETE_KITTING_IN_STATE,
      payload: {
        id: 1
      }
    };
    // Act
    const updatedState = kittingArticlesReducer(initialStates, action);
    // Assert
    expect(updatedState.kittingArticles).toEqual([
      {
        id: 2,
        description: "Article 2",
        comment: "",
        lastUpdateDate: "",
        systemStackId: "",
        startPackType: "",
        userName: ""
      }
    ]);
  });
});
