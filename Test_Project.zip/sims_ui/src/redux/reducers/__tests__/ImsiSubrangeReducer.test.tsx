// @ts-nocheck
import { subrangeStatusData } from "../../../_mocks_";
import { ImsiSubrangeActionTypes } from "../../actions/types";
import ImsiSubrangeReducer, { initialState } from "../ImsiSubrangeReducer";

describe("ImsiSubrangeReducer", () => {
  test("should return the initial state", () => {
    expect(ImsiSubrangeReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_IMSI_SUBRANGE_REQUEST", () => {
    expect(
      ImsiSubrangeReducer(undefined, {
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_REQUEST
      })
    ).toEqual({
      ...initialState,
      imsiSubranges: [],
      isLoadingFetch: true,
      errorFetch: null
    });
  });

  test("should handle FETCH_IMSI_SUBRANGE_SUCCESS", () => {
    expect(
      ImsiSubrangeReducer(undefined, {
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_SUCCESS,
        payload: [
          {
            id: 0,
            name: "test",
            imsiDigits12345678: "test",
            startImsi: "test",
            endImsi: "test",
            ismiMainrange: "test",
            imsisubRangeId: "test",
            productType: "test",
            archived: false
          }
        ]
      })
    ).toEqual({
      ...initialState,
      imsiSubranges: [
        {
          id: 0,
          name: "test",
          imsiDigits12345678: "test",
          startImsi: "test",
          endImsi: "test",
          ismiMainrange: "test",
          imsisubRangeId: "test",
          productType: "test",
          archived: false
        }
      ],
      isLoadingFetch: false,
      errorFetch: null
    });
  });

  test("should handle FETCH_IMSI_SUBRANGE_FAILURE", () => {
    expect(
      ImsiSubrangeReducer(undefined, {
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_FAILURE,
        payload: "Something went wrong"
      })
    ).toEqual({
      ...initialState,
      imsiSubranges: [],
      isLoadingFetch: false,
      errorFetch: "Something went wrong"
    });
  });
  test("should handle FETCH_IMSI_SUBRANGE_EXPORT_REQUEST", () => {
    expect(
      ImsiSubrangeReducer(undefined, {
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: true,
      exportSuccessMsg: null,
      errorExport: null
    });
  });

  test("should handle FETCH_IMSI_SUBRANGE_EXPORT_SUCCESS", () => {
    expect(
      ImsiSubrangeReducer(undefined, {
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_SUCCESS,
        payload: "successfull"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: "successfull",
      errorExport: null
    });
  });

  test("should handle FETCH_IMSI_SUBRANGE_EXPORT_FAILURE", () => {
    expect(
      ImsiSubrangeReducer(undefined, {
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_FAILURE,
        payload: "something went wrong"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: null,
      errorExport: "something went wrong"
    });
  });
  test("should handle DELETE_IMSI_SUBRANGE_SUCCESS", () => {
    expect(
      ImsiSubrangeReducer(undefined, {
        type: ImsiSubrangeActionTypes.DELETE_IMSI_SUBRANGE_SUCCESS,
        payload: "123"
      })
    ).toEqual({
      ...initialState,
      deleteSuccessMsg: "Successfully deleted 123",
      deleteSuccessMsgFlag: true
    });
  });
  test("should handle FETCH_IMSI_SUBRANGE_STATUS_REQUEST", () => {
    expect(
      ImsiSubrangeReducer(undefined, {
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_STATUS_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingFetchStatusTable: true,
      subrangestatusdetail: [],
      errorFetchStatusTable: null
    });
  });

  test("should handle FETCH_IMSI_SUBRANGE_STATUS_SUCCESS", () => {
    expect(
      ImsiSubrangeReducer(undefined, {
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_STATUS_SUCCESS,
        payload: subrangeStatusData
      })
    ).toEqual({
      ...initialState,
      isLoadingFetchStatusTable: false,
      subrangestatusdetail: subrangeStatusData,
      errorFetchStatusTable: null
    });
  });
  test("should handle FETCH_IMSI_SUBRANGE_STATUS_FAILURE", () => {
    expect(
      ImsiSubrangeReducer(undefined, {
        type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_STATUS_FAILURE,
        payload: "failed"
      })
    ).toEqual({
      ...initialState,
      isLoadingFetchStatusTable: false,
      subrangestatusdetail: [],
      errorFetchStatusTable: "failed"
    });
  });
});
