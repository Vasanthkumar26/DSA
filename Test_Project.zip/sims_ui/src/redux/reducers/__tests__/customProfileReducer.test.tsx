// @ts-nocheck

import { customProfileData } from "../../../_mocks_";
import { CustomProfileActionTypes } from "../../actions/types";
import customProfileReducer, { initialState } from "../customProfileReducer";

describe("Custom Profile Reducer", () => {
  test("shoud return the initial State", () => {
    expect(customProfileReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_CUSTOM_PROFILE_REQUEST", () => {
    expect(
      customProfileReducer(undefined, {
        type: CustomProfileActionTypes.FETCH_CUSTOM_PROFILE_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingFetch: true,
      customProfiles: []
    });
  });

  test("should handle FETCH_CUSTOM_PROFILE_SUCCESS", () => {
    expect(
      customProfileReducer(undefined, {
        type: CustomProfileActionTypes.FETCH_CUSTOM_PROFILE_SUCCESS,
        payload: customProfileData
      })
    ).toEqual({
      ...initialState,
      isLoadingFetch: false,
      customProfiles: customProfileData,
      cpNames: customProfileData.map((x) => x.name ?? "")
    });
  });

  test("should handle FETCH_CUSTOM_PROFILE_FAILURE", () => {
    expect(
      customProfileReducer(undefined, {
        type: CustomProfileActionTypes.FETCH_CUSTOM_PROFILE_FAILURE
      })
    ).toEqual({
      ...initialState,
      isLoadingFetch: false,
      customProfiles: []
    });
  });

  test("should handle SET_SELECTED_CUSTOM_PROFILE", () => {
    expect(
      customProfileReducer(undefined, {
        type: CustomProfileActionTypes.SET_SELECTED_CUSTOM_PROFILE,
        payload: customProfileData[0]
      })
    ).toEqual({
      ...initialState,
      selectedCustomProfile: customProfileData[0]
    });
  });
});
