// @ts-nocheck

import { deliverAddress } from "../../../_mocks_";
import { DeliveryAddressActionTypes } from "../../actions/types";
import deliverAddressReducer, { initialState } from "../deliveryAddressReducer";

describe("deliveryAddressReducer", () => {
  test("should return the inital state", () => {
    expect(deliverAddressReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_DELIVERY_ADDRESS_REQUEST", () => {
    expect(
      deliverAddressReducer(undefined, {
        type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_REQUEST
      })
    ).toEqual({
      ...initialState,
      deliveryAddresses: [],
      isLoadingFetch: true,
      errorFetch: null
    });
  });

  test("should handle FETCH_DELIVERY_ADDRESS_SUCCESS", () => {
    expect(
      deliverAddressReducer(undefined, {
        type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_SUCCESS,
        payload: deliverAddress
      })
    ).toEqual({
      ...initialState,
      deliveryAddresses: deliverAddress,
      isLoadingFetch: false,
      errorFetch: null
    });
  });

  test("should handle FETCH_DELIVERY_ADDRESS_FAILURE", () => {
    expect(
      deliverAddressReducer(undefined, {
        type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_FAILURE,
        payload: "Something went wrong"
      })
    ).toEqual({
      ...initialState,
      deliveryAddresses: [],
      isLoadingFetch: false,
      errorFetch: "Something went wrong"
    });
  });

  test("should handle SET_SELECTED_DELIVERY_ADDRESS", () => {
    expect(
      deliverAddressReducer(undefined, {
        type: DeliveryAddressActionTypes.SET_SELECTED_DELIVERY_ADDRESS,
        payload: deliverAddress[0]
      })
    ).toEqual({
      ...initialState,
      selectedDeliveryAddress: deliverAddress[0]
    });
  });

  test("should handle FETCH_DELIVERY_ADDRESS_EXPORT_REQUEST", () => {
    expect(
      deliverAddressReducer(undefined, {
        type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: true,
      exportSuccessMsg: null,
      errorExport: null
    });
  });

  test("should handle FETCH_DELIVERY_ADDRESS_EXPORT_SUCCESS", () => {
    expect(
      deliverAddressReducer(undefined, {
        type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_SUCCESS,
        payload: "successfull"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: "successfull",
      errorExport: null
    });
  });

  test("should handle FETCH_DELIVERY_ADDRESS_EXPORT_FAILURE", () => {
    expect(
      deliverAddressReducer(undefined, {
        type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_FAILURE,
        payload: "something went wrong"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: null,
      errorExport: "something went wrong"
    });
  });
});
