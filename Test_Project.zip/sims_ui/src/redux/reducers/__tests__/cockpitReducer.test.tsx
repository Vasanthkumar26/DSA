// @ts-nocheck
import { documentTableData } from "../../../_mocks_/cockpitApiHandlers";
import { CockpitActionTypes } from "../../actions/types";
import cockpitReducer, { initialState } from "../cockpitReducer";

describe("cockpitReducer", () => {
  test("should return the initial state", () => {
    expect(cockpitReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_COCKPIT_REQUEST", () => {
    expect(
      cockpitReducer(undefined, {
        type: CockpitActionTypes.FETCH_COCKPIT_REQUEST
      })
    ).toEqual({
      ...initialState,
      cockpits: [],
      isLoadingFetch: true,
      errorFetch: null
    });
  });

  test("should handle FETCH_COCKPIT_SUCCESS", () => {
    expect(
      cockpitReducer(undefined, {
        type: CockpitActionTypes.FETCH_COCKPIT_SUCCESS,
        payload: [{ id: 1, emailAddress: "abc_1@outlook" }]
      })
    ).toEqual({
      ...initialState,
      cockpits: [{ id: 1, emailAddress: "abc_1@outlook" }],
      isLoadingFetch: false,
      errorFetch: null
    });
  });

  test("should handle FETCH_COCKPIT_FAILURE", () => {
    expect(
      cockpitReducer(undefined, {
        type: CockpitActionTypes.FETCH_COCKPIT_FAILURE,
        payload: "Something went wrong"
      })
    ).toEqual({
      ...initialState,
      cockpits: [],
      isLoadingFetch: false,
      errorFetch: "Something went wrong"
    });
  });

  test("should handle FETCH_DOCUMENT_TABLE_REQUEST", () => {
    expect(
      cockpitReducer(undefined, {
        type: CockpitActionTypes.FETCH_DOCUMENT_TABLE_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingDocument: true,
      documentList: []
    });
  });

  test("should handle FETCH_DOCUMENT_TABLE_SUCCESS", () => {
    expect(
      cockpitReducer(undefined, {
        type: CockpitActionTypes.FETCH_DOCUMENT_TABLE_SUCCESS,
        payload: documentTableData
      })
    ).toEqual({
      ...initialState,
      isLoadingDocument: false,
      documentList: documentTableData
    });
  });

  test("should handle FETCH_DOCUMENT_TABLE_FAILURE", () => {
    expect(
      cockpitReducer(undefined, {
        type: CockpitActionTypes.FETCH_DOCUMENT_TABLE_FAILURE
      })
    ).toEqual({
      ...initialState,
      isLoadingDocument: false,
      documentList: []
    });
  });
});
