// @ts-nocheck
import { HlrActionTypes } from "../../actions/types";
import hlrReducer, { initialState } from "../hlrReducer";

describe("hlrReducer", () => {
  test("should return the initial state", () => {
    expect(hlrReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_HLR_REQUEST", () => {
    expect(
      hlrReducer(undefined, {
        type: HlrActionTypes.FETCH_HLR_REQUEST,
      })
    ).toEqual({
      ...initialState,
      hlrs: [],
      isLoadingFetch: true,
      errorFetch: null,
    });
  });

  test("should handle FETCH_HLR_SUCCESS", () => {
    expect(
      hlrReducer(undefined, {
        type: HlrActionTypes.FETCH_HLR_SUCCESS,
        payload: [{ id: 1, hlrName: "hlr 1" }],
      })
    ).toEqual({
      ...initialState,
      hlrs: [{ id: 1, hlrName: "hlr 1" }],
      isLoadingFetch: false,
      errorFetch: null,
    });
  });

  test("should handle FETCH_HLR_FAILURE", () => {
    expect(
      hlrReducer(undefined, {
        type: HlrActionTypes.FETCH_HLR_FAILURE,
        payload: "Something went wrong",
      })
    ).toEqual({
      ...initialState,
      hlrs: [],
      isLoadingFetch: false,
      errorFetch: "Something went wrong",
    });
  });

  test("should handle FETCH_HLR_EXPORT_REQUEST", () => {
    expect(
      hlrReducer(undefined, {
        type: HlrActionTypes.FETCH_HLR_EXPORT_REQUEST,
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: true,
      exportSuccessMsg: null,
      errorExport: null,
    });
  });

  test("should handle FETCH_HLR_EXPORT_SUCCESS", () => {
    expect(
      hlrReducer(undefined, {
        type: HlrActionTypes.FETCH_HLR_EXPORT_SUCCESS,
        payload: "successfull",
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: "successfull",
      errorExport: null,
    });
  });

  test("should handle FETCH_HLR_EXPORT_FAILURE", () => {
    expect(
      hlrReducer(undefined, {
        type: HlrActionTypes.FETCH_HLR_EXPORT_FAILURE,
        payload: "Something went wrong",
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: null,
      errorExport: "Something went wrong",
    });
  });

  test("should handle DELETE_HLR__SUCCESS", () => {
    expect(
      hlrReducer(undefined, {
        type: HlrActionTypes.DELETE_HLR_SUCCESS,
        payload: "123",
      })
    ).toEqual({
      ...initialState,
      deleteSuccessMsg: "Successfully deleted 123",
      deleteSuccessMsgFlag: true,
    });
  });
});
