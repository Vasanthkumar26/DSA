// @ts-nocheck
import { CardTypeActionTypes } from "../../actions/types";
import cardTypesReducer, { initialState } from "../cardTypesReducer";
import { cardType } from "../../../_mocks_";

describe("cardTypesReducer", () => {
  test("should return the initial state", () => {
    expect(cardTypesReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle CREATE_CARD_TYPE_REQUEST", () => {
    expect(
      cardTypesReducer(undefined, {
        type: CardTypeActionTypes.CREATE_CARD_TYPE_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingCreate: true,
      errorCreate: null
    });
  });

  test("should handle CREATE_CARD_TYPE_SUCCESS", () => {
    expect(
      cardTypesReducer(undefined, {
        type: CardTypeActionTypes.CREATE_CARD_TYPE_SUCCESS,
        payload: "dummy"
      })
    ).toEqual({
      ...initialState,
      isLoadingCreate: false,
      errorCreate: null
    });
  });

  test("should handle CREATE_CARD_TYPE_FAILURE", () => {
    expect(
      cardTypesReducer(undefined, {
        type: CardTypeActionTypes.CREATE_CARD_TYPE_FAILURE,
        payload: "Sorry! Create Request failed, please try again."
      })
    ).toEqual({
      ...initialState,
      isLoadingCreate: false,
      errorCreate: "Sorry! Create Request failed, please try again."
    });
  });

  test("should handle UPDATE_CARD_TYPE_REQUEST", () => {
    expect(
      cardTypesReducer(undefined, {
        type: CardTypeActionTypes.UPDATE_CARD_TYPE_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingUpdate: true,
      errorUpdate: null
    });
  });

  test("should handle UPDATE_CARD_TYPE_SUCCESS", () => {
    expect(
      cardTypesReducer(undefined, {
        type: CardTypeActionTypes.UPDATE_CARD_TYPE_SUCCESS,
        payload: "dummy"
      })
    ).toEqual({
      ...initialState,
      isLoadingUpdate: false,
      errorUpdate: null
    });
  });

  test("should handle UPDATE_CARD_TYPE_FAILURE", () => {
    expect(
      cardTypesReducer(undefined, {
        type: CardTypeActionTypes.UPDATE_CARD_TYPE_FAILURE,
        payload: "Sorry! Update Request failed, please try again."
      })
    ).toEqual({
      ...initialState,
      isLoadingUpdate: false,
      errorUpdate: "Sorry! Update Request failed, please try again."
    });
  });

  test("should handle FETCH_MANUFACTURERS_REQUEST", () => {
    expect(
      cardTypesReducer(undefined, {
        type: CardTypeActionTypes.FETCH_MANUFACTURERS_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingManufacturer: true
    });
  });

  test("should handle FETCH_MANUFACTURERS_SUCCESS", () => {
    expect(
      cardTypesReducer(undefined, {
        type: CardTypeActionTypes.FETCH_MANUFACTURERS_SUCCESS,
        payload: [
          {
            manufacturerName: "test_manufacturer",
            iccIdDigit7: 1,
            id: 1
          }
        ]
      })
    ).toEqual({
      ...initialState,
      isLoadingManufacturer: false,
      manufacturersDetails: [
        {
          manufacturerName: "test_manufacturer",
          iccIdDigit7: 1,
          id: 1
        }
      ]
    });
  });

  test("should handle FETCH_MANUFACTURERS_FAILURE", () => {
    expect(
      cardTypesReducer(undefined, {
        type: CardTypeActionTypes.FETCH_MANUFACTURERS_FAILURE,
        payload: "Sorry! Fetch Manufacturers Request failed, please try again."
      })
    ).toEqual({
      ...initialState,
      isLoadingManufacturer: false,
      errorManufacturerList:
        "Sorry! Fetch Manufacturers Request failed, please try again."
    });
  });

  test("should handle SET_SELECTED_CARD_TYPE", () => {
    expect(
      cardTypesReducer(undefined, {
        type: CardTypeActionTypes.SET_SELECTED_CARD_TYPE,
        payload: cardType[0]
      })
    ).toEqual({
      ...initialState,
      selectedCardType: cardType[0]
    });
  });
});
