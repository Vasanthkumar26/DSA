// @ts-nocheck
import { SimArticleActionTypes } from "../../actions/types";
import simArticleReducer, { initialState } from "../simArticleReducer";

describe("SimArticleReducer", () => {
  test("should return the inital state", () => {
    expect(simArticleReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_SIM_ARTICLE_EXPORT_REQUEST", () => {
    expect(
      simArticleReducer(undefined, {
        type: SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: true,
      exportSuccessMsg: null,
      errorExport: null
    });
  });

  test("should handle FETCH_SIM_ARTICLE_EXPORT_SUCCESS", () => {
    expect(
      simArticleReducer(undefined, {
        type: SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_SUCCESS,
        payload: "successfull"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: "successfull",
      errorExport: null
    });
  });

  test("should handle FETCH_SIM_ARTICLE_EXPORT_FAILURE", () => {
    expect(
      simArticleReducer(undefined, {
        type: SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_FAILURE,
        payload: "something went wrong"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: null,
      errorExport: "something went wrong"
    });
  });

  test("should handle ARCHIVE_SIM_ARTICLE_SUCCESS", () => {
    const payload = {
      name: "test"
    };
    expect(
      simArticleReducer(undefined, {
        type: SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_SUCCESS,
        payload: payload
      })
    ).toEqual({
      ...initialState,
      isLoadingArchive: false,
      archiveMsg: `test archived successfully`
    });
  });
  test("should handle ARCHIVE_SIM_ARTICLE_FAILURE", () => {
    const payload = {
      name: "test"
    };
    expect(
      simArticleReducer(undefined, {
        type: SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_FAILURE,
        payload: payload
      })
    ).toEqual({
      ...initialState,
      isLoadingArchive: false,
      archiveMsg: `Archiving test failed`
    });
  });
});
