import languageReducer from "../languageReducer";
import { LanguageActionType } from "../../actions/types";
import { getNewLangAfterToggle } from "../../../utils/common";

describe("languageReducer", () => {
  test("should return the initial state", () => {
    expect(languageReducer(undefined, {})).toEqual({
      language: "de",
    });
  });

  test("should handle TOGGLE_LANGUAGE", () => {
    const initialState = {
      language: "en",
    };
    const expectedState = {
      language: getNewLangAfterToggle(initialState.language),
    };
    expect(
      languageReducer(initialState, {
        type: LanguageActionType.TOGGLE_LANGUAGE,
      })
    ).toEqual(expectedState);
  });

  test("should handle TOGGLE_LANGUAGE from initial state", () => {
    expect(
      languageReducer(undefined, {
        type: LanguageActionType.TOGGLE_LANGUAGE,
      })
    ).toEqual({
      language: getNewLangAfterToggle("de"),
    });
  });
});
