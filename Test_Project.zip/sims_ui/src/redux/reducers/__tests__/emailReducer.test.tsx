// @ts-nocheck
import { EmailActionTypes } from "../../actions/types";
import emailReducer, { initialState } from "../emailReducer";

describe("emailReducer", () => {
  test("should return the initial state", () => {
    expect(emailReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_EMAIL_REQUEST", () => {
    expect(
      emailReducer(undefined, {
        type: EmailActionTypes.FETCH_EMAIL_REQUEST
      })
    ).toEqual({
      ...initialState,
      emails: [],
      emNames: [],
      isLoadingFetch: true,
      errorFetch: null
    });
  });

  test("should handle FETCH_EMAIL_FAILURE", () => {
    expect(
      emailReducer(undefined, {
        type: EmailActionTypes.FETCH_EMAIL_FAILURE,
        payload: "Something went wrong"
      })
    ).toEqual({
      ...initialState,
      emails: [],
      isLoadingFetch: false,
      errorFetch: "Something went wrong"
    });
  });
  test("should handle FETCH_EMAIL_EXPORT_REQUEST", () => {
    expect(
      emailReducer(undefined, {
        type: EmailActionTypes.FETCH_EMAIL_EXPORT_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: true,
      exportSuccessMsg: null,
      errorExport: null
    });
  });
  test("should handle FETCH_EMAIL_EXPORT_SUCCESS", () => {
    expect(
      emailReducer(undefined, {
        type: EmailActionTypes.FETCH_EMAIL_EXPORT_SUCCESS,
        payload: "successful"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: "successful",
      errorExport: null
    });
  });

  test("should handle FETCH_EMAIL_EXPORT_FAILURE", () => {
    expect(
      emailReducer(undefined, {
        type: EmailActionTypes.FETCH_EMAIL_EXPORT_FAILURE,
        payload: "Something went wrong"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: null,
      errorExport: "Something went wrong"
    });
  });
});
