// @ts-nocheck
import { productTypeDataMock } from "../../../_mocks_/productTypesApiHandlers";
import { ProductTypeActionTypes } from "../../actions/types";
import productTypeReducer, { initialState } from "../productTypeReducer";

describe("productTypeReducer", () => {
  test("should return the initial state", () => {
    expect(productTypeReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle CREATE_PRODUCT_TYPE_REQUEST", () => {
    expect(
      productTypeReducer(undefined, {
        type: ProductTypeActionTypes.CREATE_PRODUCT_TYPE_REQUEST
      })
    ).toEqual({
      ...initialState,
      isCreating: true,
      errorCreate: null
    });
  });

  test("should handle CREATE_PRODUCT_TYPE_SUCCESS", () => {
    expect(
      productTypeReducer(undefined, {
        type: ProductTypeActionTypes.CREATE_PRODUCT_TYPE_SUCCESS,
        payload: "dummy"
      })
    ).toEqual({
      ...initialState,
      isCreating: false,
      errorCreate: null
    });
  });

  test("should handle CREATE_PRODUCT_TYPE_FAILURE", () => {
    expect(
      productTypeReducer(undefined, {
        type: ProductTypeActionTypes.CREATE_PRODUCT_TYPE_FAILURE,
        payload: "Sorry! Create Request failed, please try again."
      })
    ).toEqual({
      ...initialState,
      isCreating: false,
      errorCreate: "Sorry! Create Request failed, please try again."
    });
  });

  test("should handle UPDATE_PRODUCT_TYPE_REQUEST", () => {
    expect(
      productTypeReducer(undefined, {
        type: ProductTypeActionTypes.UPDATE_PRODUCT_TYPE_REQUEST
      })
    ).toEqual({
      ...initialState,
      isUpdating: true,
      errorUpdate: null
    });
  });

  test("should handle UPDATE_PRODUCT_TYPE_SUCCESS", () => {
    expect(
      productTypeReducer(undefined, {
        type: ProductTypeActionTypes.UPDATE_PRODUCT_TYPE_SUCCESS,
        payload: "dummy"
      })
    ).toEqual({
      ...initialState,
      isUpdating: false,
      errorUpdate: null
    });
  });

  test("should handle UPDATE_PRODUCT_TYPE_FAILURE", () => {
    expect(
      productTypeReducer(undefined, {
        type: ProductTypeActionTypes.UPDATE_PRODUCT_TYPE_FAILURE,
        payload: "Sorry! Update Request failed, please try again."
      })
    ).toEqual({
      ...initialState,
      isUpdating: false,
      errorUpdate: "Sorry! Update Request failed, please try again."
    });
  });

  test("shoudl handle FETCH_PRODUCT_TYPE_REQUEST", () => {
    expect(
      productTypeReducer(undefined, {
        type: ProductTypeActionTypes.FETCH_PRODUCT_TYPE_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingFetch: true,
      productTypes: [],
      errorFetch: null
    });
  });

  test("should handle FETCH_PRODUCT_TYPE_SUCCESS", () => {
    expect(
      productTypeReducer(undefined, {
        type: ProductTypeActionTypes.FETCH_PRODUCT_TYPE_SUCCESS,
        payload: productTypeDataMock
      })
    ).toEqual({
      ...initialState,
      isLoadingFetch: false,
      productTypes: productTypeDataMock,
      errorFetch: null
    });
  });

  test("should handle FETCH_PRODUCT_TYPE_FAILURE", () => {
    expect(
      productTypeReducer(undefined, {
        type: ProductTypeActionTypes.FETCH_PRODUCT_TYPE_FAILURE,
        payload: "failed"
      })
    ).toEqual({
      ...initialState,
      isLoadingFetch: false,
      productTypes: [],
      errorFetch: "failed"
    });
  });
});
