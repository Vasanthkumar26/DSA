// @ts-nocheck
import { ImsiRangesActionTypes } from "../../actions/types";
import imsiSearchLockReducer, { initialState } from "../imsiSearchLockReducer";

describe("imsiSearchLockReducer", () => {
  test("should return the initial state", () => {
    expect(imsiSearchLockReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_IMSI_RANGES_REQUEST", () => {
    expect(
      imsiSearchLockReducer(undefined, {
        type: ImsiRangesActionTypes.FETCH_IMSI_RANGES_REQUEST
      })
    ).toEqual({
      ...initialState,
      imsiRanges: [],
      isLoadingFetch: true,
      errorFetch: null
    });
  });

  test("should handle FETCH_IMSI_RANGES_SUCCESS", () => {
    expect(
      imsiSearchLockReducer(undefined, {
        type: ImsiRangesActionTypes.FETCH_IMSI_RANGES_SUCCESS,
        payload: [{ id: 1, emailAddress: "abc_1@outlook" }]
      })
    ).toEqual({
      ...initialState,
      imsiRanges: [{ id: 1, emailAddress: "abc_1@outlook" }],
      isLoadingFetch: false,
      errorFetch: null
    });
  });

  test("should handle FETCH_IMSI_RANGES_FAILURE", () => {
    expect(
      imsiSearchLockReducer(undefined, {
        type: ImsiRangesActionTypes.FETCH_IMSI_RANGES_FAILURE,
        payload: "Something went wrong"
      })
    ).toEqual({
      ...initialState,
      imsiRanges: [],
      isLoadingFetch: false,
      errorFetch: "Something went wrong"
    });
  });
});
