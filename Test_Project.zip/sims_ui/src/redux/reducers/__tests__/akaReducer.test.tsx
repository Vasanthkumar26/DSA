import { AkaActionTypes } from "../../actions/types";
import akaReducer, { initialState } from "../akaReducer";

describe("AkaReducer", () => {
  test("should return the initial state", () => {
    // @ts-ignore:next-line
    expect(akaReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_AKA_EXPORT_REQUEST", () => {
    expect(
      akaReducer(undefined, {
        type: AkaActionTypes.FETCH_AKA_EXPORT_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: true,
      exportSuccessMsg: null,
      errorExport: null
    });
  });

  test("should handle FETCH_AKA_EXPORT_SUCCESS", () => {
    expect(
      akaReducer(undefined, {
        type: AkaActionTypes.FETCH_AKA_EXPORT_SUCCESS,
        payload: "successfull"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: "successfull",
      errorExport: null
    });
  });

  test("should handle FETCH_AKA_EXPORT_ERROR", () => {
    expect(
      akaReducer(undefined, {
        type: AkaActionTypes.FETCH_AKA_EXPORT_ERROR,
        payload: "something went wrong"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: null,
      errorExport: "something went wrong"
    });
  });

  test("should handle DELETE_AKA_SUCCESS", () => {
    expect(
      akaReducer(undefined, {
        type: AkaActionTypes.DELETE_AKA_SUCCESS,
        payload: 123
      })
    ).toEqual({
      ...initialState,
      deleteSuccessMsg: "Successfully deleted 123",
      deleteSuccessMsgFlag: true
    });
  });
});
