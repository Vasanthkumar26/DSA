// @ts-nocheck
import { TaskEscalationActionTypes } from "../../actions/types";
import taskEscalationReducer, { initialState } from "../taskEscalationReducer";

describe("TaskEscalationReducer", () => {
  test("should return the inital state", () => {
    expect(taskEscalationReducer(undefined, {})).toEqual(initialState);
  });

  test("should handle FETCH_TASK_ESCALATION_EXPORT_REQUEST", () => {
    expect(
      taskEscalationReducer(undefined, {
        type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: true,
      exportSuccessMsg: null,
      errorExport: null
    });
  });

  test("should handle FETCH_TASK_ESCALATION_EXPORT_SUCCESS", () => {
    expect(
      taskEscalationReducer(undefined, {
        type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_SUCCESS,
        payload: "successfull"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: "successfull",
      errorExport: null
    });
  });

  test("should handle FETCH_TASK_ESCALATION_EXPORT_FAILURE", () => {
    expect(
      taskEscalationReducer(undefined, {
        type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_FAILURE,
        payload: "something went wrong"
      })
    ).toEqual({
      ...initialState,
      isLoadingExport: false,
      exportSuccessMsg: null,
      errorExport: "something went wrong"
    });
  });
});
