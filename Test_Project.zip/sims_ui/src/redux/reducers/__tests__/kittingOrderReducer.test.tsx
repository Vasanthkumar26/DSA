//@ts-nocheck

import { KittingOrderManualActionTypes } from "../../actions/types";
import kittingOrderReducer, { initialState } from "../kittingOrderReducer";

describe("kittingOrder Reducer", () => {
  test("should return the initial state", () => {
    expect(kittingOrderReducer(undefined, {})).toEqual(initialState);
  });

  test("should hanlde CREATE_KITTING_ORDER_MANUAL_REQUEST", () => {
    expect(
      kittingOrderReducer(undefined, {
        type: KittingOrderManualActionTypes.CREATE_KITTING_ORDER_MANUAL_REQUEST
      })
    ).toEqual({
      ...initialState,
      isLoadingCreate: true,
      errorCreate: null,
      successCreate: null
    });
  });

  test("should handle CREATE_KITTING_ORDER_MANUAL_SUCCESS", () => {
    expect(
      kittingOrderReducer(undefined, {
        type: KittingOrderManualActionTypes.CREATE_KITTING_ORDER_MANUAL_SUCCESS,
        payload: "successfull"
      })
    ).toEqual({
      ...initialState,
      isLoadingCreate: false,
      errorCreate: null,
      successCreate: "successfull"
    });
  });

  test("should handle CREATE_KITTING_ORDER_MANUAL_FAILURE", () => {
    expect(
      kittingOrderReducer(undefined, {
        type: KittingOrderManualActionTypes.CREATE_KITTING_ORDER_MANUAL_FAILURE,
        payload: "something went wrong"
      })
    ).toEqual({
      ...initialState,
      isLoadingCreate: false,
      errorCreate: "something went wrong",
      successCreate: null
    });
  });
});
