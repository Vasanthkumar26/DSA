import { KittingOrderAction, KittingOrderState } from "../../models";
import { KittingOrderManualActionTypes } from "../actions/types";

export const initialState: KittingOrderState = {
  isLoadingCreate: false,
  successCreate: null,
  errorCreate: null
};

const kittingOrderReducer = (
  state: KittingOrderState = initialState,
  action: KittingOrderAction
): KittingOrderState => {
  switch (action.type) {
    case KittingOrderManualActionTypes.CREATE_KITTING_ORDER_MANUAL_REQUEST:
      return {
        ...state,
        isLoadingCreate: true,
        successCreate: null,
        errorCreate: null
      };
    case KittingOrderManualActionTypes.CREATE_KITTING_ORDER_MANUAL_SUCCESS:
      return {
        ...state,
        isLoadingCreate: false,
        successCreate: action.payload,
        errorCreate: null
      };
    case KittingOrderManualActionTypes.CREATE_KITTING_ORDER_MANUAL_FAILURE:
      return {
        ...state,
        isLoadingCreate: false,
        successCreate: null,
        errorCreate: action.payload
      };
    case KittingOrderManualActionTypes.KITTING_ORDER_RESET_STATE:
      return {
        isLoadingCreate: false,
        successCreate: null,
        errorCreate: null
      };
    default:
      return state;
  }
};

export default kittingOrderReducer;
