import { CockpitAction, CockpitState } from "../../models";
import { CockpitActionTypes } from "../actions/types";

export const initialState: CockpitState = {
  isLoadingFetch: false,
  cockpits: [],
  selectedCockpit: null,
  errorFetch: null,
  isLoadingDocument: false,
  documentList: []
};

const cockpitReducer = (
  state: CockpitState = initialState,
  action: CockpitAction
): CockpitState => {
  switch (action.type) {
    case CockpitActionTypes.FETCH_COCKPIT_REQUEST:
      return {
        ...state,
        cockpits: [],
        isLoadingFetch: true,
        errorFetch: null
      };
    case CockpitActionTypes.FETCH_COCKPIT_SUCCESS:
      return {
        ...state,
        cockpits: action.payload,
        isLoadingFetch: false,
        errorFetch: null
      };

    case CockpitActionTypes.FETCH_COCKPIT_FAILURE:
      return {
        ...state,
        cockpits: [],
        isLoadingFetch: false,
        errorFetch: action.payload
      };
    case CockpitActionTypes.SET_SELECTED_COCKPIT:
      return {
        ...state,
        selectedCockpit: action.payload
      };
    case CockpitActionTypes.CANCEL_COCKPIT_SUCCESS:
      const updated = state.cockpits?.filter(
        (data) => data.id !== action.payload
      );
      return {
        ...state,
        cockpits: updated ? updated : state.cockpits,
        isLoadingFetch: false
      };
    case CockpitActionTypes.CANCEL_SIM_SUCCESS:
      const updatedEntry = state.cockpits?.filter(
        (data) => data.id !== action.payload
      );
      return {
        ...state,
        cockpits: updatedEntry ? updatedEntry : state.cockpits,
        isLoadingFetch: false
      };
    case CockpitActionTypes.FETCH_DOCUMENT_TABLE_REQUEST:
      return {
        ...state,
        isLoadingDocument: true,
        documentList: []
      };
    case CockpitActionTypes.FETCH_DOCUMENT_TABLE_SUCCESS:
      return {
        ...state,
        isLoadingDocument: false,
        documentList: action.payload
      };
    case CockpitActionTypes.FETCH_DOCUMENT_TABLE_FAILURE:
      return {
        ...state,
        isLoadingDocument: false,
        documentList: []
      };
    default:
      return state;
  }
};
export default cockpitReducer;
