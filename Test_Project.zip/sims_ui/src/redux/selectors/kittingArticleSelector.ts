// @ts-nocheck
import { RootState } from "../store";

export const selectIsLoadingFetch = (state: RootState) =>
  state.kittingArticles.isLoadingFetch;
export const selectKittingArticles = (state: RootState) =>
  state.kittingArticles.kittingArticles;
export const selectErrorFetch = (state: RootState) =>
  state.kittingArticles.errorFetch;
export const selectSelectedKittingArticle = (state: RootState) =>
  state.kittingArticles.selectedKittingArticle;
