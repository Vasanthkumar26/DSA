import { selectLanguage } from "../languageSelector";

describe("languageSelectors", () => {
  const mockedState = {
    lang: {
      language: "en",
    },
  };

  test("selectLanguage should return the correct value", () => {
    expect(selectLanguage(mockedState)).toEqual("en");
  });
});
