import {
  selectIsLoadingFetch,
  selectKittingArticles,
  selectErrorFetch,
  selectSelectedKittingArticle,
} from "../kittingArticleSelector";

describe("kittingArticlesSelectors", () => {
  const mockedState = {
    kittingArticles: {
      isLoadingFetch: false,
      kittingArticles: [
        { id: 1, name: "Article 1" },
        { id: 2, name: "Article 2" },
      ],
      errorFetch: null,
      selectedKittingArticle: { id: 1, name: "Article 1" },
    },
  };

  test("selectIsLoadingFetch should return the correct value", () => {
    expect(selectIsLoadingFetch(mockedState)).toEqual(false);
  });

  test("selectKittingArticles should return the correct value", () => {
    expect(selectKittingArticles(mockedState)).toEqual([
      { id: 1, name: "Article 1" },
      { id: 2, name: "Article 2" },
    ]);
  });

  test("selectErrorFetch should return the correct value", () => {
    expect(selectErrorFetch(mockedState)).toEqual(null);
  });

  test("selectSelectedKittingArticle should return the correct value", () => {
    expect(selectSelectedKittingArticle(mockedState)).toEqual({
      id: 1,
      name: "Article 1",
    });
  });
});
