import { RootState } from "../store";

export const selectLanguage = (state: RootState) => state.lang.language;
