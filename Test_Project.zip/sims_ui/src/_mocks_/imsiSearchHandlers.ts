import { REACT_BASE_URL } from "../utils/common";

export const searchImsiAllocationResponse = [
  {
    startImsi: "262074090000000",
    endImsi: "262074099999999",
    amount: 100000,
    status: "Undefiniert",
    oaRefPoPk: null,
    hlrName: "HLRBLUE2",
    productTypeName: null,
    cardTypeName: null,
    systemStack: "SP613 (TUI)",
    imsiDigits1_8: "26207409",
    mainRangeDescription: "SP105 postpaid M-Net bluesdasd",
    subRangeDescription: null,
    endImsiNumber: 262074099999999,
    startImsiNumber: 262074090000000
  }
];

export const ISL_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/imsisearch/searchImsiAllocation`,
    res: () => [
      {
        startImsi: "262074090000000",
        endImsi: "262074099999999"
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/imsisearch/searchImsiAllocation`,
    method: "post",
    res: () => searchImsiAllocationResponse
  },
  {
    path: `${REACT_BASE_URL}/imsisearch/addToBlockList`,
    method: "post",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/imsisearch/releaseBlockListed`,
    method: "post",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/imsisearch/seachFiltersData`,
    res: () => ({
      listHlr: [
        {
          id: 21,
          name: "HLR21",
          archived: false
        }
      ],
      listStatus: null,
      listProductType: [
        {
          id: 338,
          name: "TestNew1",
          archived: false
        }
      ],
      listCardType: [
        {
          id: 2,
          name: "name",
          archived: true
        }
      ],
      listSystemStack: [
        {
          id: 73,
          name: "SP112 (Versatel)",
          archived: false
        }
      ]
    })
  },
  {
    path: `${REACT_BASE_URL}/imsisearch/downloadImsiSearchResult`, //export
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  }
];

export const ISL_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/imsisearch/searchImsiAllocation`,
    method: "post",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/imsisearch/addToBlockList`,
    method: "post",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/imsisearch/releaseBlockListed`,
    method: "post",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/imsisearch/seachFiltersData`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}//imsisearch/downloadImsiSearchResult`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  }
];
