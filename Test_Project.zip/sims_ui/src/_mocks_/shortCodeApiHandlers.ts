import { REACT_BASE_URL } from "../utils/common";

export const SC_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/shortcode/loadServiceProviderShortCode`, //fetch
    res: () => [
      {
        spid: "abc",
        shortCode: "xyz",
        archived: false
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/shortcode/createServiceProviderShortCode`, //create
    method: "post",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/shortcode/updateServiceProviderShortCode/*`, //update
    method: "put",
    res: () => []
  }
];

export const SC_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/shortcode/loadServiceProviderShortCode`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/shortcode/createServiceProviderShortCode`,
    method: "post",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/shortcode/updateServiceProviderShortCode/*`,
    method: "put",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  }
];
