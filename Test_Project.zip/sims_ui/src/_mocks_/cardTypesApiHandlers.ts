import { REACT_BASE_URL } from "../utils/common";

export const cardType = [
  {
    id: 73,
    iccId: 1,
    name: "NEW CARD9991",
    provisioningIdentifier: "1",
    oneSim: true,
    prepaid: false,
    lte: true,
    version: "v1.0",
    generation: "gen",
    manufacturers: [],
    archived: false,
    akaHlr: "perfect45",
    simArticleList: [],
    lastUpdatedBy: 1,
    lastUpdateDate: "2023-08-07T16:20:00.428079",
    technicalType: "technicalType",
    dtoId: 73
  }
];

export const CARDTYPES_SUCCESS_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/cardtype/delete/87`,
    status: 200,
    res: () => [],
    method: "delete"
  },
  {
    path: `${REACT_BASE_URL}/cardtype/export/excel?archived=true`,
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  },
  {
    path: `${REACT_BASE_URL}/cardtype/create`,
    method: "post",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/cardtype/update`,
    method: "put",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/cardtype/loadAllManufacturers`,
    res: () => [
      {
        manufacturerName: "testManufacturer",
        iccIdDigit7: "1",
        id: "1"
      }
    ]
  }
];

export const CARDTYPES_FAILURE_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/cardtype/delete/87`,
    method: "delete",
    status: 406,
    res: () => ({ message: "COSINUS-MSG-ERR-GEN-REFERENCE-NOT-EXIST" })
  },
  {
    path: `${REACT_BASE_URL}/cardtype/export/excel*`,
    status: 404,
    res: () => ({
      message: "Something went wrong"
    })
  },
  {
    path: `${REACT_BASE_URL}/cardtype/create`,
    status: 406,
    res: () => ({
      message: "Selected record exist"
    })
  },
  {
    path: `${REACT_BASE_URL}/cardtype/update`,
    status: 406,
    res: () => ({
      message: "COSINUS-MSG-ERR-GEN-REFERENCE-NOT-EXIST"
    })
  },
  {
    path: `${REACT_BASE_URL}/cardtype/loadAllManufacturers`,
    status: 404,
    res: () => ({
      message: "Something went wrong"
    })
  }
];
