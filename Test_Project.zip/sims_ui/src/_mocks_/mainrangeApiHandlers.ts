import { REACT_BASE_URL } from "../utils/common";

export const mainRangeStatusData = [
  {
    startImsi: "262119250000000",
    endImsi: "262119259999999",
    amount: 100000,
    status: "Undefiniert",
    oaRefPoPk: null,
    hlrName: "HLR1111",
    productTypeName: null,
    cardTypeName: null,
    systemStack: "SP115 (SP115)",
    imsiDigits1_8: "26211925",
    mainRangeDescription: "aug-20",
    subRangeDescription: null,
    endImsiNumber: 262119259999999,
    startImsiNumber: 262119250000000
  }
];

export const MAINRANGE_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/imsisearch/searchIMSIMainRangeStatus`,
    method: "post",
    status: 201,
    res: () => mainRangeStatusData
  },
  {
    path: `${REACT_BASE_URL}/imsi/loadIMSIMainRange`,
    res: () => [
      {
        imsiName: "testImsi6",
        hlrCombinedName: "HLRBLACK - 123-45",
        imsiDigits678: "234",
        serviceProvider: "BCS (SP995)"
      },
      {
        imsiName: "description2",
        hlrCombinedName: "HLRBLACK - 123-45",
        imsiDigits678: "245",
        serviceProvider: "BCS (SP995)"
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/imsi/imsi/download?archived=true`,
    status: 200,
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  },
  {
    path: `${REACT_BASE_URL}/imsi/deleteImsiMainRange/123`,
    res: () => [],
    method: "delete"
  }
];

export const MAINRANGE_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/imsisearch/searchIMSIMainRangeStatus`,
    method: "post",
    status: 404,
    res: () => ({ message: "404 not founnd" })
  },
  {
    path: `${REACT_BASE_URL}/imsi/imsi/download?archived=true`,
    status: 400,
    res: () => ({ error: "something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/imsi/imsi/download?archived=true`,
    status: 404,
    res: () => ({ error: "404 not found" })
  }
];
