import { REACT_BASE_URL } from "../utils/common";

export const EP_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/electricalProfile/export/excel?archived=true&lang=en`, //export
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  },
  {
    path: `${REACT_BASE_URL}/electricalProfile/delete/123`,
    res: () => "successful",
    method: "delete"
  }
];

export const EP_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/electricalProfile/export/excel?archived=true`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/electricalProfile/delete/123`,
    method: "delete",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  }
];
