import { REACT_BASE_URL } from "../utils/common";

export const subrangeStatusData = [
  {
    startImsi: "262074090000000",
    endImsi: "262074099999999",
    amount: 100000,
    status: "Undefiniert",
    oaRefPoPk: null,
    hlrName: "HLRBLUE2",
    productTypeName: null,
    cardTypeName: null,
    systemStack: "SP613 (TUI)",
    imsiDigits1_8: "26207409",
    mainRangeDescription: "SP105 postpaid M-Net bluesdasd",
    subRangeDescription: null,
    endImsiNumber: 262074099999999,
    startImsiNumber: 262074090000000
  }
];

export const SUBRANGE_API_SUCCESS = [
  {
    path: `${REACT_BASE_URL}/imsisubrange/loadIMSISubRange`,
    res: () => [
      {
        imsiSubRangeId: 2,
        imsiSubRangeName: "imsiSubRange7",
        imsiStartRange: "1022023",
        imsiEndRange: "1822023",
        imsiDigits8: "262-03-901",
        archived: false,
        userName: 1,
        imsiMainRangeProductTypeResponse: {
          allImsiMainRanges: [
            {
              imsiMainRangeId: 1,
              mainRangeCombinedName: "testImsi489131",
              systemStackId: 1,
              greenIccidImsi: true
            }
          ],
          allProductTypes: [
            {
              productTypeId: 1,
              name: "product_type1",
              greenIccidImsi: null
            }
          ]
        }
      },
      {
        imsiSubRangeId: 1,
        imsiSubRangeName: "imsiSubRange8",
        imsiStartRange: "1022023",
        imsiEndRange: "1822023",
        imsiDigits8: "262-03-901",
        archived: false,
        userName: 1,
        imsiMainRangeProductTypeResponse: {
          allImsiMainRanges: [
            {
              imsiMainRangeId: 1,
              mainRangeCombinedName: "testImsi489131",
              systemStackId: 1,
              greenIccidImsi: true
            }
          ],
          allProductTypes: [
            {
              productTypeId: 1,
              name: "product_type1",
              greenIccidImsi: null
            }
          ]
        }
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/imsisubrange/download?archived=true`,
    status: 200,
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  },
  {
    path: `${REACT_BASE_URL}/imsisubrange/deleteImsiSubRange/123`,
    res: () => [],
    method: "delete"
  },
  {
    path: `${REACT_BASE_URL}/imsisearch/searchIMSISubRangeStatus`,
    method: "post",
    res: () => subrangeStatusData
  }
];

export const SUBRANGE_API_FAILURE = [
  {
    path: `${REACT_BASE_URL}/imsisubrange/loadIMSISubRange`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/imsisubrange/download?archived=true`,
    status: 404,
    res: () => ({ message: "Request failed with status code 404" })
  },
  {
    path: `${REACT_BASE_URL}/imsisearch/searchIMSISubRangeStatus`,
    method: "post",
    status: 404,
    res: () => ({ message: "Request failed" })
  }
];
