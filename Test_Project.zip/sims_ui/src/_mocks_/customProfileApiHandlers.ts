import { REACT_BASE_URL } from "../utils/common";

export const customProfileData = [
  {
    id: 46,
    name: "Hello Test101",
    description: "Description111",
    simVendor: "ManufacturerName",
    xmlFileName: "file",
    archived: true,
    isReferenceExist: false
  },
  {
    id: 47,
    name: "Hello Test101",
    description: "Description111",
    simVendor: "ManufacturerName",
    xmlFileName: "file",
    archived: true,
    isReferenceExist: false
  }
];

export const CustomProfile_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/customProfile/loadAll`,
    res: () => customProfileData
  }
];

export const CustomProfile_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/customProfile/loadAll`,
    status: 404,
    res: () => ({ message: "something went wrong" })
  }
];
