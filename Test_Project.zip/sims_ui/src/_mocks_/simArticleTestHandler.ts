import { REACT_BASE_URL } from "../utils/common";

export const SimArticle_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/simarticle/simArticle/download?archived=true&lang='en'`, //export
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  },
  {
    path: `${REACT_BASE_URL}/simarticle/updateSimArticleArchived/123?archived=true`,
    res: () => [],
    method: "patch",
    status: 200
  }
];

export const SimArticle_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/simarticle/simArticle/download/*`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/simarticle/updateSimArticleArchived/123?archived=true`,
    res: () => [],
    method: "patch",
    status: 404
  }
];
