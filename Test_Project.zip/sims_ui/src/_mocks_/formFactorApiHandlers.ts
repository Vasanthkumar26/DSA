import { REACT_BASE_URL } from "../utils/common";

export const FF_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/formfactor/loadAll`, //fetch
    res: () => [
      {
        name: "abc",
        value: "xyz",
        archived: false
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/formfactor/create`, //create
    method: "post",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/formfactor/update/*`, //update
    method: "put",
    res: () => []
  }
];

export const FF_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/formfactor/loadAll`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/formfactor/create`,
    method: "post",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/formfactor/update/*`,
    method: "put",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  }
];
