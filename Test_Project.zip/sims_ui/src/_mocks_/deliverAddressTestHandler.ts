import { REACT_BASE_URL } from "../utils/common";

export const deliverAddress = [
  {
    id: 7,
    partyname: "partyname123",
    contactName: "contactName333",
    telephoneNo: "telephoneNo",
    emailId: null,
    address1: "Meitnerstr. 16",
    address2: "Herr Schmoll",
    address3: "_DEF_VAL_",
    zipCode: "70563",
    city: "Stuttgart-Vaihingen",
    country: "Deutschland",
    cardtype: "Third Party",
    deliveryType: "REST",
    outfileSendTiming: 1,
    restUrl: "restUrl",
    restUsername: "restUsername",
    restPassword: "restPassword",
    pgpKey: null,
    shipmentConfirmation: false,
    generation: "5G",
    iccid: 1,
    lte: false,
    onesim: false,
    prepaid: false,
    provId: "2",
    version: "V1",
    akaHlrId: 2,
    archived: false,
    lastUpdateDate: "2023-07-29T05:35:16.512527929",
    lastUpdatedBy: 1
  }
];

export const DeliveryAddress_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/deliveryAddress/loadAll`,
    res: () => deliverAddress
  },
  {
    path: `${REACT_BASE_URL}/deliveryAddress/export/excel?archived=true&lang='en'`, //export
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  },
  {
    path: `${REACT_BASE_URL}/deliveryAddress/delete/?id=123`,
    res: () => [],
    method: "delete",
    status: 200
  },
  {
    path: `${REACT_BASE_URL}/deliveryAddress/create`, //create
    method: "post",
    status: 200,
    res: () => ({ status: 200 })
  },
  {
    path: `${REACT_BASE_URL}/deliveryAddress/update`, //update
    method: "put",
    status: 200,
    res: () => ({ status: 200 })
  }
];

export const DeliveryAddress_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/externalsystem/loadAll`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/deliveryAddress/export/excel/*`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/deliveryAddress/delete/?id=123`,
    method: "delete",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/deliveryAddress/create`,
    method: "post",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/deliveryAddress/update/*`,
    method: "put",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  }
];
