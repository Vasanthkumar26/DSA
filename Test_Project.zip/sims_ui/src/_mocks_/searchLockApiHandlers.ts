import { REACT_BASE_URL } from "../utils/common";

export const SL_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/imsisearch/addToBlockList`,
    method: "post",
    res: () => [
      {
        startImsi: "262076780000000",
        endImsi: "262076789999999",
        amount: 100000,
        status: "Undefiniert",
        oaRefPoPk: null,
        hlrName: "HLRGREEN123",
        productTypeName: null,
        cardTypeName: null,
        systemStack: "SP113 (Breko)",
        imsiDigits1_8: "26207678",
        mainRangeDescription: "test_104",
        subRangeDescription: null,
        endImsiNumber: 262076789999999,
        startImsiNumber: 262076780000000
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/create`, //create
    method: "post",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/update/*`, //update
    method: "put",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/export/excel?archived=true`, //export
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  }
];

export const SL_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/externalsystem/loadAll`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/create`,
    method: "post",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/update/*`,
    method: "put",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/export/*`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  }
];
