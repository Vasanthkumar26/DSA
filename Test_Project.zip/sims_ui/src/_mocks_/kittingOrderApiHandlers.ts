import { REACT_BASE_URL } from "../utils/common";

export const KittingOrder_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/kittingOrder/createKittingOrderManual`,
    method: "post",
    status: 201,
    res: () => ({ message: "successful" })
  },
  {
    path: `${REACT_BASE_URL}/kittingOrder/loadKittingArticle`,
    method: "get",
    status: 200,
    res: () => [
      { name: "test", id: 12 },
      { name: "test 2", id: 13 }
    ]
  }
];

export const KittingOrder_Failure_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/kittingOrder/createKittingOrderManual`,
    method: "post",
    status: 400,
    res: () => "something went wrong"
  },
  {
    path: `${REACT_BASE_URL}/kittingOrder/loadKittingArticle`,
    method: "get",
    status: 400,
    res: () => "something went wrong"
  }
];
