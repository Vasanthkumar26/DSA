import { REACT_BASE_URL } from "../utils/common";
export const productTypeDataMock = [
  {
    productTypeId: 275,
    name: "o2 postpaid oldco Dualline blue livenet testcards",
    simType: 1,
    confirmationExternalSystem: true,
    greenIccidImsi: false,
    ntUDBAucReq: false,
    ntOtapReq: false,
    imsiThreshold: 0,
    lastUpdatedDate: null,
    lastUpdatedBy: null,
    biggestFreeRange: 700,
    freeImsis: 700,
    serviceProviderShortCodeId: "",
    serviceproviderShortcode: "",
    archived: false,
    isReferenceExist: false,
    dtoId: 275
  }
];
export const PRODUCT_TYPE_SUCCESS_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/productType/create`,
    method: "post",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/productType/update`,
    method: "put",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/productType/loadAll`,
    res: () => productTypeDataMock
  }
];

export const PRODUCT_TYPE_FAILURE_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/productType/create`,
    method: "post",
    status: 406,
    res: () => ({
      reason: "Product Type name already exists"
    })
  },
  {
    path: `${REACT_BASE_URL}/productType/update`,
    method: "put",
    status: 406,
    res: () => ({
      reason: "Product Type Id Validation error"
    })
  },
  {
    path: `${REACT_BASE_URL}/productType/loadAll`,
    status: 404,
    res: () => "Failed with 404"
  }
];
