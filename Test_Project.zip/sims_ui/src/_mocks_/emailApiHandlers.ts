import { REACT_BASE_URL } from "../utils/common";

export const EM_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/email/loadAll`, //fetch
    res: () => [
      {
        eventname: "Mail-Output File",
        emailAddress: "abc@test.com",
        replyAddress: "xyz@gmail.com",
        subject: "sbject11",
        text: "data",
        archived: false
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/email/update/*`, //update
    method: "put",
    res: () => []
  }
];

export const EM_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/email/loadAll`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/email/update/*`,
    method: "put",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  }
];
