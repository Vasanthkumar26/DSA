import { REACT_BASE_URL } from "../utils/common";

export const TaskEscalation_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/taskescalation/excel/export?lang='en'`, //export
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  }
];

export const TaskEscalation_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/taskescalation/excel/export`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  }
];
