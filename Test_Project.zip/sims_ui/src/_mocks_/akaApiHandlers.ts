import { REACT_BASE_URL } from "../utils/common";

export const AKA_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/akaHlr/loadAll`, //fetch
    res: () => [
      {
        name: "test22",
        emailAddress: "abc_1@outlook",
        replyAddress: "abc_1@outlook.com",
        subject: "test subject",
        text: " test text",
        archived: false,
        users: [
          {
            userId: "1",
            userName: "user1"
          }
        ]
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/create`, //create
    method: "post",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/update/*`, //update
    method: "put",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/akaHlr/export/excel*`,
    status: 200,
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  },
  {
    path: `${REACT_BASE_URL}/akaHlr/delete/123`,
    res: () => [],
    method: "delete"
  },
  {
    path: `${REACT_BASE_URL}/akaHlr/archive/123?archived=true`,
    res: () => [],
    status: 200,
    method: "patch"
  }
];

export const AKA_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/akaHlr/loadAll`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/create`,
    method: "post",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/update/*`,
    method: "put",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/akaHlr/export/excel*`,
    status: 404,
    res: () => ({ message: "Request failed with status code 404" })
  },
  {
    path: `${REACT_BASE_URL}/akaHlr/delete/123`,
    method: "delete",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/akaHlr/archive/1?archived=false`,
    method: "patch",
    status: 404,
    res: () => ({ message: "Request failed with status code 404" })
  }
];
