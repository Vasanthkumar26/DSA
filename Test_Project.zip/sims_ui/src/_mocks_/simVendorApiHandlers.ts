import { REACT_BASE_URL } from "../utils/common";

export const SV_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/simvendor/loadAll`, //fetch
    res: () => [
      {
        id: 40,
        manufacturerName: "testvendor698",
        externalName: "id123",
        iccIdDigit7: 1,
        deliveryType: 0,
        sapVendorNo: "vend001",
        emailIdDelivery: "true@am.c",
        sftpOutboundPath: "sftpOutboundPath",
        sftpOutboundUser: "sftpOutboundUser",
        pgpKey:
          "XHg3MDY3NzA0YjY1NzkyMDYxNzM2NDYxMjA2NjZmNzIyMDY0NjU2ZDZmMjA3NjY1NmU2NDZmNzIyMDZjNjU3NDIwNmQ2NTIwNmI2ZTZmNzcyMDY4NmY3NzczMjA2NzZmNjk2ZTY3",
        sftpInboundPath: "sftpInboundPath",
        sftpInboundUser: "sftpInboundUser",
        sapSimVendor: {
          businessPartnerId: 3000010055,
          externalName: "external_name",
          archived: true
        },
        archived: false,
        userName: "userName",
        lastUpdatedBy: 1,
        lastUpdateDate: "2023-07-28T07:36:53.526863",
        pgpKeyAsString: "",
        standardizedSftpOutboundPath: "sftpOutboundPath/",
        standardizedSftpInboundPath: "sftpInboundPath/",
        dtoId: 40
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/simvendor/create`, //create
    method: "post",
    status: 200,
    res: () => ({ status: 200 })
  },
  {
    path: `${REACT_BASE_URL}/simvendor/update`, //update
    method: "put",
    status: 200,
    res: () => ({ status: 200 })
  },
  {
    path: `${REACT_BASE_URL}/simvendor/export/excel?archived=true&lang=en`, //export
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  },
  {
    path: `${REACT_BASE_URL}/simvendor/delete/123`,
    res: () => [],
    method: "delete"
  }
];

export const SV_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/simvendor/loadAll`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/simvendor/create`,
    method: "post",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/simvendor/update/*`,
    method: "put",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/simvendor/export/excel?archived=true&lang=en`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/simvendor/delete/123`,
    method: "delete",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  }
];
