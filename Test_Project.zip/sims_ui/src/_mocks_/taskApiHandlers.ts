import { REACT_BASE_URL } from "../utils/common";

export const TASK_API_SUCCESS = [
  {
    path: `${REACT_BASE_URL}/sftpinboundfile/download?archiveId=true`,
    status: 200,
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  },
  {
    path: `${REACT_BASE_URL}/sftpinboundfile/delete/123`,
    res: () => [],
    method: "delete"
  }
];

export const TASK_API_FAILURE = [
  {
    path: `${REACT_BASE_URL}/sftpinboundfile/download?archiveId=true`,
    status: 404,
    res: () => ({ message: "Request failed with status code 404" })
  },
  {
    path: `${REACT_BASE_URL}/sftpinboundfile/delete/123`,
    method: "delete",
    status: 404,
    res: () => ({ message: "Request failed" })
  }
];
