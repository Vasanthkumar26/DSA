import { REACT_BASE_URL } from "../utils/common";

export const ES_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/externalsystem/loadAll`, //fetch
    res: () => [
      {
        name: "test22",
        emailAddress: "abc_1@outlook",
        replyAddress: "abc_1@outlook.com",
        subject: "test subject",
        text: " test text",
        archived: false,
        users: [
          {
            userId: "1",
            userName: "user1"
          }
        ]
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/create`, //create
    method: "post",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/update/*`, //update
    method: "put",
    res: () => []
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/export/excel?archived=true`, //export
    res: () => new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/loadUsers`, //user list
    res: () => [
      {
        id: 1,
        userId: "1",
        userNtLogin: null,
        userName: "user1",
        email: "something@outlook.com",
        lastUpdateDate: "2023-07-04T11:53:31.20581"
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/delete/123`,
    res: () => [],
    method: "delete"
  }
];

export const ES_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/externalsystem/loadAll`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/create`,
    method: "post",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/update/*`,
    method: "put",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/export/*`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/loadUsers`, //user list
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/externalsystem/delete/123`,
    method: "delete",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  }
];
