import { REACT_BASE_URL } from "../utils/common";

export const documentTableData = [
  {
    importDate: "2023-09-11T13:18:05.936+00:00",
    document: "NTRESPONSEFILE",
    archiveId: "COSINUS_mobc8341718-cb5f-41fb-99d1-459be87cf84a",
    name: "Test-Test-Test132.zip"
  },
  {
    importDate: "2023-09-11T05:58:50.150+00:00",
    document: "NTRESPONSEFILE",
    archiveId: "COSINUS_mob939f4d6f-e863-4120-99bb-2af0bb93cf26",
    name: "Test-123.xml"
  }
];
export const COCKPIT_SUCCESS_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/cockpit/loadCustomQuery`,
    res: () => [
      {
        queryId: 8,
        queryName: "Query-12"
      },
      {
        queryId: 9,
        queryName: "Query-13"
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/cockpit/loadCockpitOrdersInProcess`,
    res: () => [
      {
        orderNumber: 7,
        article: "16616",
        articleDescription: "des",
        quantity: 100,
        status: "in-progress",
        workflowStatus: [
          {
            kittingSimId: 1,
            errCode: null,
            errMsg: null,
            iccid: "894921723256300107",
            kittingOrderId: 7,
            kittingStatus: "reserved",
            msisdn: null,
            msisdnLockingId: null,
            provChunk: "1",
            provStatus: "0",
            puk2: null,
            user: null,
            lastUpdatedDate: null
          },
          {
            kittingSimId: 9,
            errCode: null,
            errMsg: null,
            iccid: "894921000000095702",
            kittingOrderId: 7,
            kittingStatus: "reserved",
            msisdn: null,
            msisdnLockingId: null,
            provChunk: "1",
            provStatus: "0",
            puk2: null,
            user: null,
            lastUpdatedDate: null
          }
        ],
        serviceProvider: null,
        orderCreationDate: "2023-08-22",
        delivery: "2023-08-27"
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/cockpit/kittingOrder/cancelKittingOrder`, //create
    method: "post",
    status: 200,
    res: () => ({ status: 200 })
  },
  {
    path: `${REACT_BASE_URL}/cockpit/getOrderDetails/*`,
    res: () => [
      {
        id: 7,
        creationDate: "2023-08-22",
        expectedDeliveryDate: "2023-08-27",
        noOfSimCards: 100,
        article: "16616",
        description: "des",
        serviceProvider: "SP002",
        startPackType: "SP002",
        msisdnType: null,
        packs: null,
        status: "in-progress",
        originator: "SIM_ORACLE",
        lastUpdatedBy: 1,
        lastUpdatedDate: "2023-08-23T07:05:00.274069",
        organization: null,
        simstatus: null
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/cockpit/loadOrderStatus`,
    res: () => [
      "Wait Kitting Reserved File",
      "Wait IMSI Ranges Required",
      "ManualRetrigger"
    ]
  },
  {
    path: `${REACT_BASE_URL}/cockpit/loadCustomProfileData`,
    res: () => ["Hello Test67708", "demo230817", "Hellodemo767"]
  },
  {
    path: `${REACT_BASE_URL}/cockpit/loadKittingArticle`,
    res: () => ["315", "316", "317", "319", "318"]
  },
  {
    path: `${REACT_BASE_URL}/cockpit/downloadDocument/*`,
    res: () => ({
      archiveBinaryData: "sdsasdasd",
      mimeType: "application/zip",
      fileName: "dummy (1).xlsx"
    })
  },
  {
    path: `${REACT_BASE_URL}/cockpit/loadArchiveFileType`,
    res: () => [
      {
        id: 1,
        fileType: "INPUTFILE",
        fileDescription: "Input file"
      },
      {
        id: 2,
        fileType: "RETURNFILE",
        fileDescription: "Return file"
      }
    ]
  },
  {
    path: `${REACT_BASE_URL}/cockpit/cockpitUploadDocument`,
    method: "post",
    status: 200,
    res: () => "uploaded"
  },
  {
    path: `${REACT_BASE_URL}/cockpit/loadAllDocumentsByOrderId/*`,
    res: () => documentTableData
  }
];

export const COCKPIT_FAILURE_API_HANDLERS = [
  {
    path: `${REACT_BASE_URL}/cockpit/loadCustomQuery`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/cockpit/loadCockpitOrdersInProcess`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/cockpit/getOrderDetails/*`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/cockpit/downloadDocument/*`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/cockpit/downloadDocument/*`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/cockpit/loadArchiveFileType`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/cockpit/cockpitUploadDocument`,
    method: "post",
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  },
  {
    path: `${REACT_BASE_URL}/cockpit/loadAllDocumentsByOrderId/*`,
    status: 404,
    res: () => ({ message: "Oops! Something went wrong" })
  }
];
