import { ImsiMainrangeActionTypes } from "../redux/actions/types";
import { ImsiSubAndMainRangeStatusTable } from "./global.model";

export interface ImsiMainrange {
  imsiMainRangeId: number;
  imsiName: string;
  hlrCombinedName: string;
  imsiDigits678: string;
  serviceProvider: string | null;
  archive: boolean;
  lastUpdatedDate?: string;
  userName?: string;
  imsiSubRangeLinked: boolean;
  deleteSuccessMsg?: string;
  archiveSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  archiveSuccessMsgFlag?: boolean;
  spid: number;
  hlrid: number;
}

export interface ICreateIMSIMainRangeRequestBody {
  imsiName: string;
  hlr?: number;
  serviceProvider?: number;
  imsiDigit1to5?: string;
  imsiDigits678?: string;
  archived?: boolean;
}

/*========REDUX ============*/

export interface ImsiMainrangeState {
  isLoadingFetch: boolean;
  isLoadingExport: boolean;
  imsiMainranges: Array<ImsiMainrange>;
  selectedImsiMainrange: ImsiMainrange | null;
  errorFetch: string | null;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  isLoadingCreate: boolean;
  errorCreate: string | null;
  isLoadingUpdate: boolean;
  errorUpdate: string | null;
  deleteSuccessMsg?: string;
  archiveSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  archiveSuccessMsgFlag?: boolean;
  isLoadingStatusTable: boolean;
  mainrangeStatusDetail: Array<ImsiSubAndMainRangeStatusTable>;
}

interface FetchImsiMainrangeRequest {
  type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_REQUEST;
}

interface FetchImsiMainrangeSuccess {
  type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_SUCCESS;
  payload: Array<ImsiMainrange>;
}

interface FetchImsiMainrangeFailure {
  type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_FAILURE;
  payload: string;
}

interface SelectedImsiMainrange {
  type: ImsiMainrangeActionTypes.SET_SELECTED_IMSI_MAINRANGE;
  payload: ImsiMainrange | null;
}

interface CreateIMSIMainRangeRequest {
  type: ImsiMainrangeActionTypes.CREATE_IMSI_MAINRANGE_REQUEST;
}

interface CreateIMSIMainRangeSuccess {
  type: ImsiMainrangeActionTypes.CREATE_IMSI_MAINRANGE_SUCCESS;
}

interface CreateIMSIMainRangeFailure {
  type: ImsiMainrangeActionTypes.CREATE_IMSI_MAINRANGE_FAILURE;
  payload: string;
}

interface UpdateIMSIMainRangeRequest {
  type: ImsiMainrangeActionTypes.UPDATE_IMSI_MAINRANGE_REQUEST;
}

interface UpdateIMSIMainRangeSuccess {
  type: ImsiMainrangeActionTypes.UPDATE_IMSI_MAINRANGE_SUCCESS;
}

interface UpdateIMSIMainRangeFailure {
  type: ImsiMainrangeActionTypes.UPDATE_IMSI_MAINRANGE_FAILURE;
  payload: string;
}

interface ResetIMSIMainRangeErr {
  type: ImsiMainrangeActionTypes.RESET_IMSI_MAINRANGE_ERR;
}
interface DeleteIMSIRequest {
  type: ImsiMainrangeActionTypes.DELETE_IMSI_REQUEST;
}

interface DeleteIMSISucess {
  type: ImsiMainrangeActionTypes.DELETE_IMSI_SUCCESS;
  payload: number;
}

interface DeleteIMSIFailure {
  type: ImsiMainrangeActionTypes.DELETE_IMSI_FAILURE;
  payload: string;
}

interface FetchIMSIExportRequest {
  type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_REQUEST;
}

interface FetchIMSIExportSuccess {
  type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_SUCCESS;
  payload: string;
}

interface FetchIMSIExportFailure {
  type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_FAILURE;
  payload: string;
}

interface ArchiveIMSIMainRangeRequest {
  type: ImsiMainrangeActionTypes.ARCHIVE_IMSI_MAINRANGE_REQUEST;
}

interface ArchiveIMSIMainRangeSuccess {
  type: ImsiMainrangeActionTypes.ARCHIVE_IMSI_MAINRANGE_SUCCESS;
  payload: { imsiMainRangeId: number; archive: boolean };
}

interface ArchiveIMSIMainRangeFailure {
  type: ImsiMainrangeActionTypes.ARCHIVE_IMSI_MAINRANGE_FAILURE;
  payload: string;
}

interface ResetIMSIMainRange {
  type: ImsiMainrangeActionTypes.RESET_IMSI_MAINRANGE;
}

interface FetchIMSIMainRangeStatusRequest {
  type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_STATUS_REQUEST;
}

interface FetchIMSIMainRangeStatusSuccess {
  type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_STATUS_SUCCESS;
  payload: Array<ImsiSubAndMainRangeStatusTable>;
}

interface FetchIMSIMainRangeStatusFailure {
  type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_STATUS_FAILURE;
}

export type ImsiMainrangeAction =
  | FetchImsiMainrangeRequest
  | FetchImsiMainrangeSuccess
  | FetchImsiMainrangeFailure
  | SelectedImsiMainrange
  | DeleteIMSIRequest
  | DeleteIMSISucess
  | DeleteIMSIFailure
  | CreateIMSIMainRangeRequest
  | CreateIMSIMainRangeSuccess
  | CreateIMSIMainRangeFailure
  | UpdateIMSIMainRangeRequest
  | UpdateIMSIMainRangeSuccess
  | UpdateIMSIMainRangeFailure
  | ResetIMSIMainRangeErr
  | FetchIMSIExportRequest
  | FetchIMSIExportSuccess
  | FetchIMSIExportFailure
  | ArchiveIMSIMainRangeRequest
  | ArchiveIMSIMainRangeSuccess
  | ArchiveIMSIMainRangeFailure
  | ResetIMSIMainRange
  | FetchIMSIMainRangeStatusRequest
  | FetchIMSIMainRangeStatusSuccess
  | FetchIMSIMainRangeStatusFailure;
