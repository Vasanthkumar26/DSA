import { TaskEscalationActionTypes } from "../redux/actions/types";
import { ISelectionOption } from "./global.model";

export interface TaskEscalations {
  id: number;
  task: string;
  time: string;
  emailAddress: string;
  subject: string;
  archived: boolean;
}

export interface TaskEscalationState {
  isLoadingFetch: boolean;
  taskEscalations: Array<TaskEscalations>;
  errorFetch: string | null;
  isCreated: boolean;
  createdSuccess: string | null;
  isLoadingExport: boolean;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  selectedTaskEscalation?: TaskEscalations | null;
}

export interface TaskEscalationDropdownValue {
  allTaskValues: ISelectionOption[];
}

interface FetchTaskEscalations {
  type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_REQUEST;
}

interface FetchTaskEscalationsSuccess {
  type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_SUCCESS;
  payload: Array<TaskEscalations>;
}

interface FetchTaskEscalationsFailure {
  type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_FAILURE;
  payload: string;
}
interface CreateTaskEscalationRequest {
  type: TaskEscalationActionTypes.CREATE_TASK_ESCALATION_REQUEST;
}

interface CreateTaskEscalationSuccess {
  type: TaskEscalationActionTypes.CREATE_TASK_ESCALATION_SUCCESS;
  payload: string | null;
}

interface ResetMessage {
  type: TaskEscalationActionTypes.RESET_MESSAGE;
}
interface FetchTaskEscalationRequest {
  type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_REQUEST;
}

interface FetchTaskEscalationExportSuccess {
  type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_SUCCESS;
  payload: string;
}

interface FetchTaskEscalationExportFailure {
  type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_FAILURE;
  payload: string;
}
interface UpdateTaskEscalationRequest {
  type: TaskEscalationActionTypes.UPDATE_TASK_ESCALATION_REQUEST;
}

interface UpdateTaskEscalationSuccess {
  type: TaskEscalationActionTypes.UPDATE_TASK_ESCALATION_SUCCESS;
  payload: string | null;
}

interface UpdateTaskEscalationFailure {
  type: TaskEscalationActionTypes.UPDATE_TASK_ESCALATION_FAILURE;
  payload: string;
}

interface SetSelectedTaskEscalation {
  type: TaskEscalationActionTypes.SET_SELECTED_TASK_ESCALATION;
  payload: TaskEscalations | null;
}

interface DeleteTaskEscalationRequest {
  type: TaskEscalationActionTypes.DELETE_TASK_ESCALATION_REQUEST;
}

interface DeleteTaskEscalationSuccess {
  type: TaskEscalationActionTypes.DELETE_TASK_ESCALATION_SUCCESS;
  payload: number;
}

interface DeleteTaskEscalationFailure {
  type: TaskEscalationActionTypes.DELETE_TASK_ESCALATION_FAILURE;
  payload: string;
}

export type TaskEscalationAction =
  | FetchTaskEscalations
  | FetchTaskEscalationsSuccess
  | FetchTaskEscalationsFailure
  | CreateTaskEscalationRequest
  | CreateTaskEscalationSuccess
  | ResetMessage
  | FetchTaskEscalationExportFailure
  | FetchTaskEscalationExportSuccess
  | FetchTaskEscalationRequest
  | UpdateTaskEscalationRequest
  | UpdateTaskEscalationSuccess
  | UpdateTaskEscalationFailure
  | SetSelectedTaskEscalation
  | DeleteTaskEscalationRequest
  | DeleteTaskEscalationSuccess
  | DeleteTaskEscalationFailure;
