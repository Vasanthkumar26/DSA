import { AuthActionTypes } from "../redux/actions/types";

export interface User {
  username: string;
  password: string;
}

/*========REDUX ============*/

export interface AuthState {
  isLoading: boolean;
  isLoggedIn: boolean;
  user: User | null;
  error: string | null;
}

interface AuthLoginRequest {
  type: AuthActionTypes.LOGIN_REQUEST;
}

interface AuthLoginSuccess {
  type: AuthActionTypes.LOGIN_SUCCESS;
  payload: User;
}

interface AuthLoginFailure {
  type: AuthActionTypes.LOGIN_FAILURE;
  payload: string;
}

interface AuthLogoutRequest {
  type: AuthActionTypes.LOGOUT_REQUEST;
}

interface AuthLogoutSucess {
  type: AuthActionTypes.LOGOUT_SUCCESS;
}

interface AuthLogoutFailure {
  type: AuthActionTypes.LOGOUT_FAILURE;
  payload: string;
}

export type AuthAction =
  | AuthLoginRequest
  | AuthLoginSuccess
  | AuthLoginFailure
  | AuthLogoutRequest
  | AuthLogoutSucess
  | AuthLogoutFailure;
