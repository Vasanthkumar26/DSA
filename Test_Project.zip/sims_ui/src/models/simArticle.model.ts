import { SimArticleActionTypes } from "../redux/actions/types";
import { ISelectionOption } from "./global.model";
export interface SimArticles {
  id: number;
  name: string;
  cardPerFile: number;
  defwert: number;
  chipType: string;
  description: string;
  userName: number;
  lastUpdateDate: Date;
  cardTypeId: number;
  simVendorId: number;
  serviceProviderId: number;
  electricalProfileId: number;
  customProfileId: number;
  formFactorId: number;
  productTypeId: number;
  comment: string;
  deliveryAddressId: number;
  articleStatusName: string;
  smDpHostId: number;
  archived: boolean;
  starterPackReq: boolean;
  starterPackId: number;
  starterPackName: string;
  articleId: number;
  simCardOrderExist: null;
  aritcleStatusId: number;
  additionalInputFile: number;
}

export interface SimArticleState {
  isLoadingExport: boolean;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  isLoadingFetch: boolean;
  simArticles: Array<SimArticles>;
  errorFetch: string | null;
  isLoadingArchive: boolean | null;
  archiveMsg: string | null;
  selectedSimArticle?: SimArticles | null;
  isCreateOrUpdate: boolean;
  createOrUpdateSuccess: string | null;
}
export interface IProductTypes extends ISelectArchive {
  serviceProviderShortCodeId: number;
  imsiSubRangeReferenceExists: boolean;
  archive: boolean;
}

export interface ISelectArchive extends ISelectionOption {
  archive: boolean;
}
export interface ISimVendors extends ISelectionOption {
  cartTypeId: number;
}

export interface ICPOrEP extends ISelectArchive {
  simVendorId: number;
}

export interface IStarterPack extends ISelectArchive {
  spId: number;
}

export interface SimArticleDropdownValue {
  [key: string]: any;
  allCardType: ISelectArchive[];
  allSimVendor: ISimVendors[];
  allServiceProviderDetails: ISelectArchive[];
  allElectricalProfile: ICPOrEP[];
  allCustomProfile: ICPOrEP[];
  allFormFactor: ISelectArchive[];
  allProductType: IProductTypes[];
  allDeliveryAddress: ISelectArchive[];
  allSmdpHost: ISelectionOption[];
  allStarterPack: IStarterPack[];
  allDeliveryAddressOutputFile: ISelectArchive[];
  allSimArticleStatus: ISelectionOption[];
}
interface FetchSimArticleRequest {
  type: SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_REQUEST;
}

interface FetchSimArticleExportSuccess {
  type: SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_SUCCESS;
  payload: string;
}

interface FetchSimArticleExportFailure {
  type: SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_FAILURE;
  payload: string;
}

interface FetchSimArticles {
  type: SimArticleActionTypes.FETCH_SIM_ARTICLES_REQUEST;
}

interface FetchSimArticlesSuccess {
  type: SimArticleActionTypes.FETCH_SIM_ARTICLES_SUCCESS;
  payload: Array<SimArticles>;
}

interface FetchSimArticlesFailure {
  type: SimArticleActionTypes.FETCH_SIM_ARTICLES_FAILURE;
  payload: string;
}

interface SetSimArticle {
  type: SimArticleActionTypes.SET_SIM_ARTICLE;
  payload: SimArticles | null;
}

interface ArchiveSimArticlesRequest {
  type: SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_REQUEST;
}

interface ArchiveSimArticlesSuccess {
  type: SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_SUCCESS;
  payload: { id: number; archived: boolean; name: string };
}

interface ArchiveSimArticlesFailure {
  type: SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_FAILURE;
  payload: { name: string };
}

interface DeleteSimVendorsRequest {
  type: SimArticleActionTypes.DELETE_SIM_ARTICLES_REQUEST;
}

interface DeleteSimVendorsSuccess {
  type: SimArticleActionTypes.DELETE_SIM_ARTICLES_SUCCESS;
  payload: number;
}

interface DeleteSimVendorsFailure {
  type: SimArticleActionTypes.DELETE_SIM_ARTICLES_FAILURE;
  payload: string;
}

interface ArchiveSimArticlesRequest {
  type: SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_REQUEST;
}

interface ArchiveSimArticlesSuccess {
  type: SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_SUCCESS;
  payload: { id: number; archived: boolean; name: string };
}

interface ArchiveSimArticlesFailure {
  type: SimArticleActionTypes.ARCHIVE_SIM_ARTICLES_FAILURE;
  payload: { name: string };
}

interface DeleteSimVendorsRequest {
  type: SimArticleActionTypes.DELETE_SIM_ARTICLES_REQUEST;
}

interface DeleteSimVendorsSuccess {
  type: SimArticleActionTypes.DELETE_SIM_ARTICLES_SUCCESS;
  payload: number;
}

interface DeleteSimVendorsFailure {
  type: SimArticleActionTypes.DELETE_SIM_ARTICLES_FAILURE;
  payload: string;
}

interface CreateOrUpdateSimArticleRequest {
  type: SimArticleActionTypes.CREATE_UPDATE_SIM_ARTICLE_REQUEST;
}

interface CreateOrUpdateSimArticleSuccess {
  type: SimArticleActionTypes.CREATE_UPDATE_SIM_ARTICLE_SUCCESS;
  payload: string | null;
}

interface ResetMessage {
  type: SimArticleActionTypes.RESET_MESSAGE;
}
export type SimArticleAction =
  | FetchSimArticleRequest
  | FetchSimArticleExportSuccess
  | FetchSimArticleExportFailure
  | FetchSimArticles
  | FetchSimArticlesSuccess
  | FetchSimArticlesFailure
  | ArchiveSimArticlesRequest
  | ArchiveSimArticlesSuccess
  | ArchiveSimArticlesFailure
  | SetSimArticle
  | CreateOrUpdateSimArticleRequest
  | CreateOrUpdateSimArticleSuccess
  | ResetMessage
  | DeleteSimVendorsRequest
  | DeleteSimVendorsSuccess
  | DeleteSimVendorsFailure;
