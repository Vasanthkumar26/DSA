import { ProductTypeActionTypes } from "../redux/actions/types";

export interface IProductType {
  //Added I to avoid duplication with subrange productType
  id: number;
  name: string;
  serviceProvider: string;
  simType: string;
  externalSystem: string;
  greenICCID: boolean;
  provisioningUDB: boolean;
  provisioningOTAP: boolean;
  archived: boolean;
}

export interface ProductTypeData {
  productTypeId: number;
  name: string;
  simType: number;
  confirmationExternalSystem: boolean;
  greenIccidImsi: boolean;
  ntUDBAucReq: boolean;
  ntOtapReq: boolean;
  imsiThreshold: number;
  lastUpdatedDate?: string;
  lastUpdatedBy: number;
  biggestFreeRange: number;
  freeImsis: number;
  serviceProviderShortCodeId: number;
  serviceproviderShortcode: string;
  archived: boolean;
  dtoId: number;
  isReferenceExist?: boolean;
}

export interface productTypePayload {
  name: string;
  simType: number;
  serviceProviderShortCodeId: number;
  confirmationExternalSystem: boolean;
  greenIccidImsi: boolean;
  ntUDBAucReq: boolean;
  ntOtapReq: boolean;
  imsiThreshold: number;
  biggestFreeRange: number;
  externalSystemId: string | boolean;
  freeImsis: string | number;
  userUpdatedBy: number;
}

export interface productTypeUpdatePayload {
  productTypeId: number;
  name: string;
  simType: number;
  serviceProviderShortCodeId: number;
  confirmationExternalSystem: boolean;
  greenIccidImsi: boolean;
  ntUDBAucReq: boolean;
  ntOtapReq: boolean;
  imsiThreshold: number;
  biggestFreeRange: number;
  externalSystemId: string | boolean;
  freeImsis: string | number;
  userUpdatedBy: number;
}
export interface productDropDownValues {
  value: boolean;
  name: string;
}

export interface assignedImsiSubRangeProto {
  startImsi: string;
  endImsi: string;
  description: string;
  freeImsi: string;
}

export interface productSimType {
  value: number;
  name: string;
}

export interface ProductTypeState {
  isLoadingFetch: boolean;
  productTypes: Array<ProductTypeData>;
  errorFetch: string | null;
  selectedProductType: ProductTypeData | null;
  deleteSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  deleteErrorMsg?: string | null;
  productDropDown: Array<productDropDownValues>;
  productSimType: Array<productSimType>;
  isCreating: boolean;
  isUpdating: boolean;
  errorCreate?: string | null;
  errorUpdate?: string | null;
  isLoadingAssignedImsiSubrange: boolean;
  assignedImsiSubranges: Array<assignedImsiSubRangeProto>;
  errorFetchAssignedImsiSubrange: string | null;
  isLoadingAllImsiSubrange: boolean;
  allImsiSubranges: Array<assignedImsiSubRangeProto>;
  errorFetchAllImsiSubrange: string | null;
}

interface FetchProductTypeRequest {
  type: ProductTypeActionTypes.FETCH_PRODUCT_TYPE_REQUEST;
}

interface FetchProductTypeSuccess {
  type: ProductTypeActionTypes.FETCH_PRODUCT_TYPE_SUCCESS;
  payload: Array<ProductTypeData>;
}

interface FetchProductTypeFailure {
  type: ProductTypeActionTypes.FETCH_PRODUCT_TYPE_FAILURE;
  payload: string;
}

interface SetSelectedProductType {
  type: ProductTypeActionTypes.SET_SELECTED_PRODUCT_TYPE;
  payload: ProductTypeData | null;
}

interface FetchCardTypesExportRequest {
  type: ProductTypeActionTypes.FETCH_PRODUCT_TYPES_EXPORT_REQUEST;
}

interface FetchCardTypesExportSuccess {
  type: ProductTypeActionTypes.FETCH_PRODUCT_TYPES_EXPORT_SUCCESS;
  payload: string;
}

interface FetchCardTypesExportFailure {
  type: ProductTypeActionTypes.FETCH_PRODUCT_TYPES_EXPORT_FAILURE;
  payload: string;
}

interface DeleteProductTypeRequest {
  type: ProductTypeActionTypes.PRODUCT_TYPE_DELETE_REQUEST;
}

interface DeleteProductTypeSucess {
  type: ProductTypeActionTypes.PRODUCT_TYPE_DELETE_SUCCESS;
  payload: number;
}

interface DeleteProductTypeFailure {
  type: ProductTypeActionTypes.PRODUCT_TYPE_DELETE_FAILURE;
  payload: string;
}

interface CreateProductTypeRequest {
  type: ProductTypeActionTypes.CREATE_PRODUCT_TYPE_REQUEST;
}

interface CreateProductTypeSuccess {
  type: ProductTypeActionTypes.CREATE_PRODUCT_TYPE_SUCCESS;
  payload?: productTypePayload;
}

interface CreateProductTypeFailure {
  type: ProductTypeActionTypes.CREATE_PRODUCT_TYPE_FAILURE;
  payload: string;
}

interface UpdateProductTypeRequest {
  type: ProductTypeActionTypes.UPDATE_PRODUCT_TYPE_REQUEST;
}

interface UpdateProductTypeSuccess {
  type: ProductTypeActionTypes.UPDATE_PRODUCT_TYPE_SUCCESS;
  payload?: productTypePayload;
}

interface UpdateProductTypeFailure {
  type: ProductTypeActionTypes.UPDATE_PRODUCT_TYPE_FAILURE;
  payload: string;
}

interface ResetProductType {
  type: ProductTypeActionTypes.RESET_PRODUCT_TYPE;
}

interface ArchiveProductTypeRequest {
  type: ProductTypeActionTypes.ARCHIVE_PRODUCT_TYPE_REQUEST;
}

interface ArchiveProductTypeSucess {
  payload: string | null;
  type: ProductTypeActionTypes.ARCHIVE_PRODUCT_TYPE_SUCCESS;
}

interface ArchiveProductTypeFailure {
  type: ProductTypeActionTypes.ARCHIVE_PRODUCT_TYPE_FAILURE;
  payload: string;
}

interface fetchAssignedSubrangeRequest {
  type: ProductTypeActionTypes.FETCH_ASSIGNED_IMSI_SUBRANGES_REQUEST;
}

interface fetchAssignedSubrangeSuccess {
  type: ProductTypeActionTypes.FETCH_ASSIGNED_IMSI_SUBRANGES_SUCCESS;
  payload: Array<assignedImsiSubRangeProto>;
}

interface fetchAssignedSubrangeFailure {
  type: ProductTypeActionTypes.FETCH_ASSIGNED_IMSI_SUBRANGES_FAILURE;
  payload: string;
}

interface fetchAllSubrangeRequest {
  type: ProductTypeActionTypes.FETCH_ALL_IMSI_SUBRANGES_REQUEST;
}

interface fetchAllSubrangeSuccess {
  type: ProductTypeActionTypes.FETCH_ALL_IMSI_SUBRANGES_SUCCESS;
  payload: Array<assignedImsiSubRangeProto>;
}

interface fetchAllSubrangeFailure {
  type: ProductTypeActionTypes.FETCH_ALL_IMSI_SUBRANGES_FAILURE;
  payload: string;
}

export type ProductTypeAction =
  | FetchProductTypeRequest
  | FetchProductTypeSuccess
  | FetchProductTypeFailure
  | SetSelectedProductType
  | FetchCardTypesExportRequest
  | FetchCardTypesExportSuccess
  | FetchCardTypesExportFailure
  | DeleteProductTypeRequest
  | DeleteProductTypeSucess
  | DeleteProductTypeFailure
  | CreateProductTypeRequest
  | CreateProductTypeSuccess
  | CreateProductTypeFailure
  | UpdateProductTypeRequest
  | UpdateProductTypeSuccess
  | UpdateProductTypeFailure
  | ResetProductType
  | ArchiveProductTypeRequest
  | ArchiveProductTypeSucess
  | ArchiveProductTypeFailure
  | fetchAssignedSubrangeRequest
  | fetchAssignedSubrangeSuccess
  | fetchAssignedSubrangeFailure
  | fetchAllSubrangeRequest
  | fetchAllSubrangeSuccess
  | fetchAllSubrangeFailure;
