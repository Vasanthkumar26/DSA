import { ElectricalProfileActionTypes } from "../redux/actions/types";
import { ISelectionOption } from "./global.model";
import { ISelectArchive } from "./simArticle.model";

export interface ElectricalProfile {
  itemId: number;
  name: string;
  manufacture: string;
  value: string;
  fileAnnotation: string;
  pin1State: string;
  pin1Value: string;
  akaHlr: string;
  akaAlgType: string;
  akaAlg: string;
  akaTpKey: string;
  isimActivation: boolean;
  archived: boolean;
  description?: string;
  lastUpdatedDate?: string;
  lastUpdatedBy?: string;
  manufactureId: number;
  pin1StateId: number;
  akaHlrId: number;
  akaAlgTypeId: number;
  akaAlgId: number;
  akaTpKeyId: number;
  sim_article_ref_exist?: boolean;
  akaHlrArchived: boolean;
  manufactureArchived: boolean;
}

/*========REDUX ============*/

export interface ElectricalProfileState {
  isLoadingFetch: boolean;
  electricalProfiles: Array<ElectricalProfile>;
  selectedElectricalProfile: ElectricalProfile | null;
  errorFetch: string | null;
  isLoadingExport: boolean;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  deleteSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  deleteErrorMsg?: string | null;
  isLoadingCreate: boolean;
  errorCreate: string | null;
  successCreate: string | null;
  isLoadingUpdate: boolean;
  successUpdate: string | null;
  errorUpdate: string | null;
  archiveSuccess: string | null;
}

export interface ElectricalProfileRequestPayload {
  itemId?: number;
  name: string;
  value: string;
  fileAnnotation: string;
  description: string;
  pin1Value: string;
  archived: boolean;
  userUpdated: number | string;
  isimActivation: boolean;
  manufactureId: number;
  pin1StateId: number;
  akaHlrId: number;
  akaAlgTypeId: number;
  akaAlgId: number;
  akaTpKeyId: number;
}

export interface IAkaAlg extends ISelectArchive {
  akaHlrId: number;
  akaAlgTypeId: number;
}

export interface IAkaTpKey extends ISelectionOption {
  akaHlrId: number;
  akaAlgTypeId: number;
  simVendorId: number;
}

export interface IDropdown {
  pinState: ISelectionOption[];
  akaAlg: IAkaAlg[];
  akaAlgType: ISelectionOption[];
  akaTpKey: IAkaTpKey[];
  akaHlr: ISelectArchive[];
  isImActivation: ISelectionOption[];
  manufacaturer: ISelectArchive[];
}
interface FetchImsiSubrangeRequest {
  type: ElectricalProfileActionTypes.FETCH_REQUEST;
}

interface FetchImsiSubrangeSuccess {
  type: ElectricalProfileActionTypes.FETCH_SUCCESS;
  payload: Array<ElectricalProfile>;
}

interface FetchImsiSubrangeFailure {
  type: ElectricalProfileActionTypes.FETCH_FAILURE;
  payload: string;
}

interface SelectedEP {
  type: ElectricalProfileActionTypes.SET_SELECTED_EP;
  payload: ElectricalProfile | null;
}

interface FetchEPExportRequest {
  type: ElectricalProfileActionTypes.FETCH_EP_EXPORT_REQUEST;
}

interface FetchEPExportSuccess {
  type: ElectricalProfileActionTypes.FETCH_EP_EXPORT_SUCCESS;
  payload: string;
}

interface FetchEPExportFailure {
  type: ElectricalProfileActionTypes.FETCH_EP_EXPORT_FAILURE;
  payload: string;
}
interface DeleteEPRequest {
  type: ElectricalProfileActionTypes.EP_DELETE_REQUEST;
}

interface DeleteEPSucess {
  type: ElectricalProfileActionTypes.EP_DELETE_SUCCESS;
  payload: number;
}

interface DeleteEPFailure {
  type: ElectricalProfileActionTypes.EP_DELETE_FAILURE;
  payload: string;
}
interface ArchiveEPRequest {
  type: ElectricalProfileActionTypes.ARCHIVE_EP_REQUEST;
}

interface ArchiveEPSucess {
  payload: string | null;
  type: ElectricalProfileActionTypes.ARCHIVE_EP_SUCCESS;
}

interface ArchiveEPFailure {
  type: ElectricalProfileActionTypes.ARCHIVE_EP_ERROR;
  payload: string;
}

interface CreateEPRequest {
  type: ElectricalProfileActionTypes.CREATE_EP_REQUEST;
}

interface CreateEPSuccess {
  type: ElectricalProfileActionTypes.CREATE_EP_SUCCESS;
  payload: string;
}
interface CreateEPFailure {
  type: ElectricalProfileActionTypes.CREATE_EP_ERROR;
  payload: string;
}

interface UpdateEPRequest {
  type: ElectricalProfileActionTypes.UPDATE_EP_REQUEST;
}

interface UpdateEPSuccess {
  type: ElectricalProfileActionTypes.UPDATE_EP_SUCCESS;
  payload: string;
}

interface UpdateEPFailure {
  type: ElectricalProfileActionTypes.UPDATE_EP_FAILURE;
  payload: string;
}

interface RestEPCreateUpdateState {
  type: ElectricalProfileActionTypes.RESET_EP_CREATE_UPDATE_STATE;
}

interface ResetEP {
  type: ElectricalProfileActionTypes.RESET_EP;
}

export type ElectricalProfileAction =
  | FetchImsiSubrangeRequest
  | FetchImsiSubrangeFailure
  | FetchImsiSubrangeSuccess
  | SelectedEP
  | FetchEPExportFailure
  | FetchEPExportRequest
  | FetchEPExportSuccess
  | DeleteEPRequest
  | DeleteEPSucess
  | DeleteEPFailure
  | ArchiveEPRequest
  | ArchiveEPSucess
  | ArchiveEPFailure
  | CreateEPRequest
  | CreateEPSuccess
  | CreateEPFailure
  | UpdateEPFailure
  | UpdateEPRequest
  | UpdateEPSuccess
  | RestEPCreateUpdateState
  | ResetEP;
