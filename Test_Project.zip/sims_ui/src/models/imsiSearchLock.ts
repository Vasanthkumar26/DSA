import { ImsiRangesActionTypes } from "../redux/actions/types";

export interface ImsiSearchLock {
  id: number;
  imsiFrom: string;
  imsiTo: string;
  hlr: string;
  productType: string;
  cardType: string;
  serviceProvider: string;
  status: boolean;
}

export interface ImsiRange {
  startImsi: string;
  endImsi: string;
  number: string;
  hlr: string;
  status: string;
  productType: string;
  orderNumber: string;
  cartType: string;
  serviceProvider: string;
}

export interface SFData {
  id: string;
  name: string;
  archived: boolean;
  label?: string;
}

/*========REDUX ============*/

export interface ImsiRangesState {
  isLoadingFetch: boolean;
  imsiRanges: Array<ImsiRange>;
  selectedImsiRange: ImsiRange | null;
  errorFetch: string | null;
}

interface FetchImsiRangesRequest {
  type: ImsiRangesActionTypes.FETCH_IMSI_RANGES_REQUEST;
}

interface FetchImsiRangesSuccess {
  type: ImsiRangesActionTypes.FETCH_IMSI_RANGES_SUCCESS;
  payload: Array<ImsiRange>;
}

interface FetchImsiRangesFailure {
  type: ImsiRangesActionTypes.FETCH_IMSI_RANGES_FAILURE;
  payload: string;
}

interface SelectedImsiRanges {
  type: ImsiRangesActionTypes.SET_SELECTED_IMSI_RANGES;
  payload: ImsiRange | null;
}

export type ImsiRangesAction =
  | FetchImsiRangesRequest
  | FetchImsiRangesSuccess
  | FetchImsiRangesFailure
  | SelectedImsiRanges;
