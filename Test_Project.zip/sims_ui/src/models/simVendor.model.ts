import { SimVendorActionTypes } from "../redux/actions/types";

export interface SimVendor {
  id: number;
  name: string;
  externerName: string;
  iccidDigit7: string;
  inputFile: string;
  emailAddress: string;
  archived: boolean;
  deleteSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  pgpKey: string;
  sapVendorNo: number;
  sftpOutboundPath: string;
  sftpOutboundUser: string;
  sftpInboundPath: string;
  sftpInboundUser: string;
  businessPartnerId: string;
  userName: string;
  lastUpdatedBy: number;
  isReferenceExist?: boolean;
}
export interface ExternalName {
  businessPartnerId: number;
  externalName: string;
  archived: boolean;
}
export interface InputFile {
  name: string;
  value: number;
}

/*========REDUX ============*/

export interface SimVendorState {
  isLoadingFetch: boolean;
  simVendros: Array<SimVendor>;
  errorFetch: string | null;
  selectedSimVendor?: SimVendor | null;
  isLoadingExport: boolean;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  deleteSuccessMsg?: string;
  deleteErrorMsg?: string | null;
  deleteSuccessMsgFlag?: boolean;
  isLoadingCreate?: boolean;
  isLoadingUpdate?: boolean;
  errorCreate: string | null;
  errorUpdate: string | null;
  externalName: Array<ExternalName>;
  inputFile: Array<InputFile>;
}
export interface FetchSimVendorResponse {
  data: SimVendor;
  message: string | null;
}
interface FetchSimVendorRequest {
  type: SimVendorActionTypes.FETCH_SIM_VENDOR_REQUEST;
}

interface FetchSimVendorSuccess {
  type: SimVendorActionTypes.FETCH_SIM_VENDOR_SUCCESS;
  payload: Array<SimVendor>;
}

interface FetchSimVendorFailure {
  type: SimVendorActionTypes.FETCH_SIM_VENDOR_FAILURE;
  payload: string;
}
interface FetchExternalNameRequest {
  type: SimVendorActionTypes.FETCH_EXTERNAL_REQUEST;
}

interface FetchExternalNameSuccess {
  type: SimVendorActionTypes.FETCH_EXTERNAL_SUCCESS;
  payload: Array<ExternalName>;
}

interface FetchExternalNameFailure {
  type: SimVendorActionTypes.FETCH_EXTERNAL_FAILURE;
  payload: string;
}
interface SetSelectedHLR {
  type: SimVendorActionTypes.SET_SELECTED_SIM_VENDOR;
  payload: SimVendor | null;
}

interface DeleteSimVendorRequest {
  type: SimVendorActionTypes.DELETE_SIM_VENDOR_REQUEST;
}

interface DeleteSimVendorSucess {
  type: SimVendorActionTypes.DELETE_SIM_VENDOR_SUCCESS;
  payload: number;
}

interface DeleteSimVendorFailure {
  type: SimVendorActionTypes.DELETE_SIM_VENDOR_FAILURE;
  payload: string;
}

interface ArchiveSimVendorRequest {
  type: SimVendorActionTypes.ARCHIVE_SIM_VENDOR_REQUEST;
}

interface ArchiveSimVendorSucess {
  type: SimVendorActionTypes.ARCHIVE_SIM_VENDOR_SUCCESS;
}

interface ArchiveSimVendorFailure {
  type: SimVendorActionTypes.ARCHIVE_SIM_VENDOR_FAILURE;
  payload: string;
}

interface ExportSimVendorRequest {
  type: SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_REQUEST;
}

interface ExportSimVendorSuccess {
  type: SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_SUCCESS;
  payload: string;
}

interface ExprtSimVendorFailure {
  type: SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_ERROR;
  payload: string;
}
interface CreateSimVendorRequest {
  type: SimVendorActionTypes.CREATE_SIM_VENDOR_REQUEST;
}

interface CreateSimVendorSuccess {
  type: SimVendorActionTypes.CREATE_SIM_VENDOR_SUCCESS;
  payload?: FetchSimVendorResponse;
}

interface CreateSimVendorFailure {
  type: SimVendorActionTypes.CREATE_SIM_VENDOR_FAILURE;
  payload: string;
}
interface UpdateSimVendorRequest {
  type: SimVendorActionTypes.UPDATE_ISIM_VENDORE_REQUEST;
}

interface UpdateSimVendorSuccess {
  type: SimVendorActionTypes.UPDATE_SIM_VENDOR_SUCCESS;
}

interface UpdateSimVendorFailure {
  type: SimVendorActionTypes.UPDATE_SIM_VENDORE_FAILURE;
  payload: string;
}
interface ResetSimVendorError {
  type: SimVendorActionTypes.RESET_ERROR;
}
interface ResetSimVendorForm {
  type: SimVendorActionTypes.RESET_FORM;
}

interface ResetSimVendor {
  type: SimVendorActionTypes.RESET_SIM_VENDOR;
}

export type SimVendorAction =
  | FetchSimVendorRequest
  | FetchSimVendorSuccess
  | FetchSimVendorFailure
  | SetSelectedHLR
  | DeleteSimVendorRequest
  | DeleteSimVendorSucess
  | DeleteSimVendorFailure
  | ArchiveSimVendorRequest
  | ArchiveSimVendorSucess
  | ArchiveSimVendorFailure
  | ExportSimVendorRequest
  | ExportSimVendorSuccess
  | ExprtSimVendorFailure
  | CreateSimVendorRequest
  | CreateSimVendorSuccess
  | CreateSimVendorFailure
  | UpdateSimVendorRequest
  | UpdateSimVendorSuccess
  | UpdateSimVendorFailure
  | ResetSimVendorError
  | ResetSimVendorForm
  | FetchExternalNameRequest
  | FetchExternalNameSuccess
  | FetchExternalNameFailure
  | ResetSimVendor;
