import { AlertColor } from "@mui/material";
import { SnackBarActionType } from "../redux/actions/types";

/*========REDUX ============*/
export interface SnackbarState {
  priority: "high" | "low";
  severity: AlertColor | null;
  message: string;
}

interface ShowSnackbar {
  type:
    | SnackBarActionType.SHOW_SNACK_BAR_SUCCESS
    | SnackBarActionType.SHOW_HIGH_SNACK_BAR_SUCCESS
    | SnackBarActionType.SHOW_SNACK_BAR_FAILURE
    | SnackBarActionType.SHOW_HIGH_SNACK_BAR_FAILURE;

  payload: string;
}

interface HideSnackbar {
  type: SnackBarActionType.HIDE_SNACK_BAR;
}

export type SnackbarAction = ShowSnackbar | HideSnackbar;
