import { DeliveryAddressActionTypes } from "../redux/actions/types";
import { ISelectionOption } from "./global.model";

export interface DeliveryAddress {
  id: number;
  partyname: string;
  contactName: string;
  telephoneNo: string;
  emailId: string;
  address1: string;
  address2: string;
  address3: string;
  zipCode: string;
  city: string;
  country: string;
  cardtype: string;
  deliveryType: string;
  outfileSendTiming: number;
  restUrl: string;
  restUsername: string;
  restPassword: string;
  pgpKey: null | string;
  shipmentConfirmation: boolean;
  generation: string;
  iccid: number;
  lte: boolean;
  onesim: boolean;
  prepaid: boolean;
  provId: string;
  version: string;
  akaHlrId: number;
  archived: boolean;
  lastUpdateDate: string;
  lastUpdatedBy: number;
  deleteSuccessMsgFlag?: boolean;
  sim_article_ref_exist?: boolean;
}
export interface ExternalName {
  name: string;
  value: string;
}
export interface Timing {
  name: string;
  value: number;
}
export interface InputFile {
  name: string;
  value: number;
}
export interface PartnerAddress {
  id: string;
  label: string;
}
export interface DeliveryAddressState {
  isLoadingFetch: boolean;
  deliveryAddresses: Array<DeliveryAddress>;
  errorFetch: string | null;
  selectedDeliveryAddress?: DeliveryAddress | null;
  isLoadingCreate: boolean;
  errorCreate: string | null;
  isLoadingUpdate: boolean;
  errorUpdate: string | null;
  isLoadingExport: boolean;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  deleteSuccessMsg?: string;
  archiveSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  deleteErrorMsg?: string | null;
  externalName: Array<ExternalName>;
  inputFile: Array<InputFile>;
  timing: Array<Timing>;
  partnerAddress: Array<ISelectionOption>;
}

interface FetchDeliveryAddressRequest {
  type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_REQUEST;
}

interface FetchDeliveryAddressSuccess {
  type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_SUCCESS;
  payload: Array<DeliveryAddress>;
}

interface FetchDeliveryAddressFailure {
  type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_FAILURE;
  payload: string;
}

interface SetSelectedDeliverAddress {
  type: DeliveryAddressActionTypes.SET_SELECTED_DELIVERY_ADDRESS;
  payload: DeliveryAddress | null;
}
interface DeleteDeliveryAddressRequest {
  type: DeliveryAddressActionTypes.DELETE_DELIVERY_ADDRESS_REQUEST;
}

interface DeleteDeliveryAddressSucess {
  type: DeliveryAddressActionTypes.DELETE_DELIVERY_ADDRESS_SUCCESS;
  payload: number;
}

interface DeleteDeliveryAddressFailure {
  type: DeliveryAddressActionTypes.DELETE_DELIVERY_ADDRESS_FAILURE;
  payload: string;
}

interface ArchiveDeliveryAddressRequest {
  type: DeliveryAddressActionTypes.ARCHIVE_DELIVERY_ADDRESS_REQUEST;
}

interface ArchiveDeliveryAddressSucess {
  type: DeliveryAddressActionTypes.ARCHIVE_DELIVERY_ADDRESS_SUCCESS;
  payload: { id: number; archive: boolean };
}

interface ArchiveDeliveryAddressFailure {
  type: DeliveryAddressActionTypes.ARCHIVE_DELIVERY_ADDRESS_FAILURE;
  payload: string;
}

interface ExportDeliveryAddressRequest {
  type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_REQUEST;
}

interface ExportDeliveryAddressSuccess {
  type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_SUCCESS;
  payload: string;
}

interface ExprtDeliveryAddressFailure {
  type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_ERROR;
  payload: string;
}
interface CreateDeliveryAddressRequest {
  type: DeliveryAddressActionTypes.CREATE_DELIVERY_ADDRESS_REQUEST;
}

interface CreateDeliveryAddressSuccess {
  type: DeliveryAddressActionTypes.CREATE_DELIVERY_ADDRESS_SUCCESS;
}

interface CreateDeliveryAddressFailure {
  type: DeliveryAddressActionTypes.CREATE_DELIVERY_ADDRESS_FAILURE;
  payload: string;
}
interface UpdateDeliveryAddressRequest {
  type: DeliveryAddressActionTypes.UPDATE_IDELIVERY_ADDRESSE_REQUEST;
}

interface UpdateDeliveryAddressSuccess {
  type: DeliveryAddressActionTypes.UPDATE_DELIVERY_ADDRESS_SUCCESS;
}

interface FetchDeliveryAddressExportRequest {
  type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_REQUEST;
}

interface FetchDeliveryAddressExportSuccess {
  type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_SUCCESS;
  payload: string;
}

interface FetchDeliveryAddressExportFailure {
  type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_FAILURE;
  payload: string;
}

interface UpdateDeliveryAddressFailure {
  type: DeliveryAddressActionTypes.UPDATE_DELIVERY_ADDRESSE_FAILURE;
  payload: string;
}
interface ResetDeliveryAddressError {
  type: DeliveryAddressActionTypes.RESET_ERROR;
}
interface ResetDeliveryAddressForm {
  type: DeliveryAddressActionTypes.RESET_FORM;
}
interface FetchPartnerAddressRequest {
  type: DeliveryAddressActionTypes.FETCH_PartnerAddress_REQUEST;
}

interface FetchPartnerAddressSuccess {
  type: DeliveryAddressActionTypes.FETCH_PartnerAddress_SUCCESS;
  payload: Array<ISelectionOption>;
}

interface FetchPartnerAddressFailure {
  type: DeliveryAddressActionTypes.FETCH_PartnerAddress_FAILURE;
  payload: string;
}

interface ResetDeliveryAddress {
  type: DeliveryAddressActionTypes.RESET_DELIVERY_ADDRESS;
}

export type DeliveryAddressAction =
  | FetchDeliveryAddressRequest
  | FetchDeliveryAddressSuccess
  | FetchDeliveryAddressFailure
  | SetSelectedDeliverAddress
  | DeleteDeliveryAddressRequest
  | DeleteDeliveryAddressSucess
  | DeleteDeliveryAddressFailure
  | ArchiveDeliveryAddressRequest
  | ArchiveDeliveryAddressSucess
  | ArchiveDeliveryAddressFailure
  | ExportDeliveryAddressRequest
  | ExportDeliveryAddressSuccess
  | ExprtDeliveryAddressFailure
  | CreateDeliveryAddressRequest
  | CreateDeliveryAddressSuccess
  | CreateDeliveryAddressFailure
  | UpdateDeliveryAddressRequest
  | UpdateDeliveryAddressSuccess
  | UpdateDeliveryAddressFailure
  | ResetDeliveryAddressError
  | ResetDeliveryAddressForm
  | FetchDeliveryAddressExportRequest
  | FetchDeliveryAddressExportSuccess
  | FetchDeliveryAddressExportFailure
  | FetchPartnerAddressRequest
  | FetchPartnerAddressSuccess
  | FetchPartnerAddressFailure
  | ResetDeliveryAddress;
