import { CardTypeActionTypes } from "../redux/actions/types";
export interface AkaHlrObject {
  id: number;
  displayValue: string;
  inputFileValue: string;
  fileEnding: string;
  archived: boolean;
  dtoId: number;
}
export interface CardTypeData {
  id: number;
  iccId: number;
  name: string;
  provisioningIdentifier: string;
  oneSim: boolean;
  prepaid: boolean;
  lte: boolean;
  version: string;
  generation: string;
  manufacturers: Array<ManufacturerValue>;
  archived: boolean;
  akaHlr: string;
  simArticleList: Array<string>;
  lastUpdatedBy: number;
  lastUpdatedDate: string;
  technicalType: string;
  isReferenceExist: boolean;
  dtoId: number;
}

export interface AkaHlrValues {
  displayValue: string;
  id: number;
}

export interface ManufacturerValue {
  manufacturerName: string;
  iccIdDigit7: number;
  id: number;
}

export interface CardTypesState {
  cardTypes: Array<CardTypeData>;
  selectedCardType?: CardTypeData | null;
  isLoadingFetch: boolean;
  errorFetch: string | null;
  hlrValues: Array<AkaHlrValues>;
  isLoadingExport: boolean;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  deleteSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  isLoadingCreate: boolean | null;
  errorCreate: string | null;
  isLoadingUpdate: boolean | null;
  errorUpdate: string | null;
  isLoadingManufacturer: boolean;
  errorManufacturerList: string | null;
  manufacturersDetails: Array<ManufacturerValue>;
  severity: string | undefined;
}

export interface CardTypesPayload {
  id: number;
  iccId: number;
  technicalType: string;
  name: string;
  provisioningIdentifier: string;
  oneSim: boolean;
  prepaid: boolean;
  lte: boolean;
  version: string;
  generation: string;
  manufacturers: Array<ManufacturerValue>;
  archived: boolean;
  akaHlr: string;
  lastUpdatedBy: number;
  simArticleList: Array<string>;
  lastUpdatedDate: string;
  dtoId: number;
}

export interface updateCardTypePayload {
  id: number;
  iccId: number;
  technicalType: string;
  name: string;
  provisioningIdentifier: string;
  oneSim: boolean;
  prepaid: boolean;
  lte: boolean;
  version: string;
  generation: string;
  archived: boolean;
  akaHlr: string;
  lastUpdatedBy: number;
  lastUpdatedDate: string;
}

interface FetchCardTypesRequest {
  type: CardTypeActionTypes.CARD_TYPES_REQUEST;
}

interface FetchCardTypesSuccess {
  type: CardTypeActionTypes.CARD_TYPES_SUCCESS;
  payload: Array<CardTypeData>;
}

interface FetchCardTypesFailure {
  type: CardTypeActionTypes.CARD_TYPES_FAILURE;
  payload: string;
}

interface FetchAkaHlrValuesRequest {
  type: CardTypeActionTypes.ALL_AKA_HLR_REQUEST;
}

interface FetchAkaHlrValuesSuccess {
  type: CardTypeActionTypes.ALL_AKA_HLR_SUCCESS;
  payload: Array<AkaHlrValues>;
}

interface FetchAkaHlrValuesFailure {
  type: CardTypeActionTypes.ALL_AKA_HLR_FAILURE;
  payload: string;
}
interface FetchCardTypesExportRequest {
  type: CardTypeActionTypes.FETCH_CARD_TYPES_EXPORT_REQUEST;
}

interface FetchCardTypesExportSuccess {
  type: CardTypeActionTypes.FETCH_CARD_TYPES_EXPORT_SUCCESS;
  payload: string;
}

interface FetchCardTypesExportFailure {
  type: CardTypeActionTypes.FETCH_CARD_TYPES_EXPORT_FAILURE;
  payload: string;
}

interface CreateCardTypeRequest {
  type: CardTypeActionTypes.CREATE_CARD_TYPE_REQUEST;
}

interface CreateCardTypeSuccess {
  type: CardTypeActionTypes.CREATE_CARD_TYPE_SUCCESS;
  payload?: CardTypesPayload;
}

interface CreateCardTypeFailure {
  type: CardTypeActionTypes.CREATE_CARD_TYPE_FAILURE;
  payload: string;
}

interface SetSelectedCardType {
  type: CardTypeActionTypes.SET_SELECTED_CARD_TYPE;
  payload: CardTypeData | null;
}

interface FetchManufacturersRequest {
  type: CardTypeActionTypes.FETCH_MANUFACTURERS_REQUEST;
}

interface FetchManufacturersSuccess {
  type: CardTypeActionTypes.FETCH_MANUFACTURERS_SUCCESS;
  payload: Array<ManufacturerValue>;
}

interface FetchManufacturersFailure {
  type: CardTypeActionTypes.FETCH_MANUFACTURERS_FAILURE;
  payload: string;
}

interface UpdateCardTypeRequest {
  type: CardTypeActionTypes.UPDATE_CARD_TYPE_REQUEST;
}

interface UpdateCardTypeSuccess {
  type: CardTypeActionTypes.UPDATE_CARD_TYPE_SUCCESS;
  payload?: updateCardTypePayload;
}

interface UpdateCardTypeFailure {
  type: CardTypeActionTypes.UPDATE_CARD_TYPE_FAILURE;
  payload: string;
}

interface DeleteCardTypeRequest {
  type: CardTypeActionTypes.DELETE_CARD_TYPES_REQUEST;
}
interface DeleteCardTypeSuccess {
  type: CardTypeActionTypes.DELETE_CARD_TYPES_SUCCESS;
  payload: number;
}
interface DeleteCardTypeFailure {
  type: CardTypeActionTypes.DELETE_CARD_TYPES_FAILURE;
  payload: string;
}

interface ArchiveCardTypeRequest {
  type: CardTypeActionTypes.ARCHIVE_CARD_TYPES_REQUEST;
}
interface ArchiveCardTypeSuccess {
  type: CardTypeActionTypes.ARCHIVE_CARD_TYPES_SUCCESS;
}
interface ArchiveCardTypeFailure {
  type: CardTypeActionTypes.ARCHIVE_CARD_TYPES_FAILURE;
  payload: string;
}

interface ResetCardTypesError {
  type: CardTypeActionTypes.RESET_CARD_TYPES_ERR;
}

interface ResetCardTypes {
  type: CardTypeActionTypes.RESET_CARD_TYPES;
}

export type CardTypesAction =
  | FetchCardTypesRequest
  | FetchCardTypesSuccess
  | FetchCardTypesFailure
  | FetchAkaHlrValuesRequest
  | FetchAkaHlrValuesSuccess
  | FetchAkaHlrValuesFailure
  | FetchCardTypesExportRequest
  | FetchCardTypesExportSuccess
  | FetchCardTypesExportFailure
  | DeleteCardTypeRequest
  | DeleteCardTypeSuccess
  | DeleteCardTypeFailure
  | CreateCardTypeRequest
  | CreateCardTypeSuccess
  | CreateCardTypeFailure
  | SetSelectedCardType
  | FetchManufacturersRequest
  | FetchManufacturersSuccess
  | FetchManufacturersFailure
  | UpdateCardTypeRequest
  | UpdateCardTypeSuccess
  | UpdateCardTypeFailure
  | ResetCardTypesError
  | ArchiveCardTypeRequest
  | ArchiveCardTypeSuccess
  | ArchiveCardTypeFailure
  | ResetCardTypes;
