import { LanguageActionType } from "../redux/actions/types";

/*========REDUX ============*/

export interface LanguageState {
  language: string;
}

interface ToggleLanguage {
  type: LanguageActionType.TOGGLE_LANGUAGE;
}

export type LanguageAction = ToggleLanguage;
