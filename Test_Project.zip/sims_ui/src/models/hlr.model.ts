import { HlrActionTypes } from "../redux/actions/types";

export interface Hlr {
  id: number;
  hlrName: string;
  description: string;
  greenIccidImsi: boolean;
  imsiDigits12345: string;
  iccid?: number;
  archived: boolean;
  lastUpdateDate: string;
  userName?: string;
  imsi_main_range_exists?: boolean;
  imsiDigits123?: string;
  imsiDigits45?: string;
  deleteSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  archiveSuccessMsg?: string;
}

export interface CreateHLRRequestBody {
  id?: string;
  iccidDigit12?: string;
  description: string;
  greenSim: boolean;
  imsiDigit123: string;
  imsiDigit45: string;
  hlrName: string;
  archived: boolean;
  lastUpdatedDate: string;
  userName: string;
}

/*========REDUX ============*/

export interface HlrState {
  isLoadingFetch: boolean;
  isLoadingExport: boolean;
  hlrs: Array<Hlr>;
  errorFetch: string | null;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  archiveSuccessMsg: string | null;
  errorArchive: string | null;
  selectedHLR?: Hlr | null;
  isLoadingCreate: boolean;
  errorCreate: string | null;
  isLoadingUpdate: boolean;
  errorUpdate: string | null;
  deleteSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
}

interface FetchHlrRequest {
  type: HlrActionTypes.FETCH_HLR_REQUEST;
}

interface FetchHlrSuccess {
  type: HlrActionTypes.FETCH_HLR_SUCCESS;
  payload: Array<Hlr>;
}

interface FetchHlrFailure {
  type: HlrActionTypes.FETCH_HLR_FAILURE;
  payload: string;
}

interface FetchHlrExportRequest {
  type: HlrActionTypes.FETCH_HLR_EXPORT_REQUEST;
}

interface FetchHlrExportSucess {
  type: HlrActionTypes.FETCH_HLR_EXPORT_SUCCESS;
  payload: string;
}

interface FetchHlrExportFailure {
  type: HlrActionTypes.FETCH_HLR_EXPORT_FAILURE;
  payload: string;
}
interface DeleteHlrRequest {
  type: HlrActionTypes.DELETE_HLR_REQUEST;
}

interface DeleteHlrSucess {
  type: HlrActionTypes.DELETE_HLR_SUCCESS;
  payload: number;
}

interface DeleteHlrFailure {
  type: HlrActionTypes.DELETE_HLR_FAILURE;
  payload: string;
}

interface CreateHLRRequest {
  type: HlrActionTypes.CREATE_HLR_REQUEST;
}

interface CreateHLRSuccess {
  type: HlrActionTypes.CREATE_HLR_SUCCESS;
  payload: Hlr;
}

interface ArchiveHLRRequest {
  type: HlrActionTypes.ARCHIVE_HLR_REQUEST;
}

interface ArchiveHLRSuccess {
  type: HlrActionTypes.ARCHIVE_HLR_SUCCESS;
  payload: { id: number; archived: boolean };
}

interface ArchiveHLRFailure {
  type: HlrActionTypes.ARCHIVE_HLR_FAILURE;
  payload: string;
}

interface CreateHLRFailure {
  type: HlrActionTypes.CREATE_HLR_FAILURE;
  payload: string;
}

interface UpdateHLRRequest {
  type: HlrActionTypes.UPDATE_HLR_REQUEST;
}

interface UpdateHLRSuccess {
  type: HlrActionTypes.UPDATE_HLR_SUCCESS;
  payload: CreateHLRRequestBody;
}

interface UpdateHLRFailure {
  type: HlrActionTypes.UPDATE_HLR_FAILURE;
  payload: string;
}

interface ResetHLRErr {
  type: HlrActionTypes.RESET_HLR_ERR;
}

interface ResetHLR {
  type: HlrActionTypes.RESET_HLR;
}

interface SetSelectedHLR {
  type: HlrActionTypes.SET_SELECTED_HLR;
  payload: Hlr | null;
}

export type HlrAction =
  | FetchHlrRequest
  | FetchHlrSuccess
  | FetchHlrFailure
  | FetchHlrExportRequest
  | FetchHlrExportSucess
  | FetchHlrExportFailure
  | CreateHLRRequest
  | CreateHLRSuccess
  | CreateHLRFailure
  | DeleteHlrRequest
  | DeleteHlrSucess
  | DeleteHlrFailure
  | ArchiveHLRRequest
  | ArchiveHLRSuccess
  | ArchiveHLRFailure
  | SetSelectedHLR
  | UpdateHLRRequest
  | UpdateHLRSuccess
  | ResetHLRErr
  | ResetHLR
  | UpdateHLRFailure;
