import { EmailActionTypes } from "../redux/actions/types";

export interface Email {
  id: number;
  eventname: string;
  emailAddress: string;
  replyAddress: string;
  subject: string;
  text: string;
  lastUpdateDate: Date;
}

export interface EmailPayload {
  eventname: string;
  subject: string;
  emailAddress: string;
  text: string;
  replyAddress: string;
}

/*========REDUX ============*/

export interface EmailState {
  isLoadingFetch: boolean;
  emails: Array<Email>;
  emNames: Array<string>;
  errorFetch: string | null;
  selectedEmail?: Email | null;
  isLoadingUpdate: boolean;
  errorUpdate: string | null;
  isLoadingExport: boolean;
  exportSuccessMsg: string | null;
  errorExport: string | null;
}

interface FetchEmailRequest {
  type: EmailActionTypes.FETCH_EMAIL_REQUEST;
}

interface FetchEmailSuccess {
  type: EmailActionTypes.FETCH_EMAIL_SUCCESS;
  payload: Array<Email>;
}

interface FetchEmailFailure {
  type: EmailActionTypes.FETCH_EMAIL_FAILURE;
  payload: string;
}

interface SetSelectedEmail {
  type: EmailActionTypes.SET_SELECTED_EMAIL;
  payload: Email | null;
}

interface UpdateEmailRequest {
  type: EmailActionTypes.UPDATE_EMAIL_REQUEST;
}

interface UpdateEmailSuccess {
  type: EmailActionTypes.UPDATE_EMAIL_SUCCESS;
}

interface UpdateEmailFailure {
  type: EmailActionTypes.UPDATE_EMAIL_FAILURE;
  payload: string;
}

interface FetchEmailExportRequest {
  type: EmailActionTypes.FETCH_EMAIL_EXPORT_REQUEST;
}

interface FetchEmailExportSuccess {
  type: EmailActionTypes.FETCH_EMAIL_EXPORT_SUCCESS;
  payload: string;
}

interface FetchEmailExportFailure {
  type: EmailActionTypes.FETCH_EMAIL_EXPORT_FAILURE;
  payload: string;
}
interface RESETEmailERR {
  type: EmailActionTypes.RESET_EMAIL_ERR;
}

interface ResetEmail {
  type: EmailActionTypes.RESET_EMAIL;
}
export type EmailAction =
  | FetchEmailRequest
  | FetchEmailSuccess
  | FetchEmailFailure
  | SetSelectedEmail
  | UpdateEmailRequest
  | UpdateEmailSuccess
  | UpdateEmailFailure
  | FetchEmailExportRequest
  | FetchEmailExportFailure
  | FetchEmailExportSuccess
  | RESETEmailERR
  | ResetEmail;
