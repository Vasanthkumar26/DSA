import { Dayjs } from "dayjs";
import { KittingOrderManualActionTypes } from "../redux/actions/types";

export interface KittingOrderPayload {
  orderNumber: number | null;
  kittingArticleNumber: number | null;
  noOfSimCard: number | null;
  orderDate: string | Dayjs;
  deliveryDate: string;
}

export interface KittingOrderState {
  isLoadingCreate: boolean;
  successCreate: string | null;
  errorCreate: string | null;
}

interface CreatekittingOrderManualRequest {
  type: KittingOrderManualActionTypes.CREATE_KITTING_ORDER_MANUAL_REQUEST;
}

interface CreateKittingOrderManualSuccess {
  type: KittingOrderManualActionTypes.CREATE_KITTING_ORDER_MANUAL_SUCCESS;
  payload: string;
}

interface CreateKittingOrderManualFailure {
  type: KittingOrderManualActionTypes.CREATE_KITTING_ORDER_MANUAL_FAILURE;
  payload: string;
}

interface ResetKittingOrderstate {
  type: KittingOrderManualActionTypes.KITTING_ORDER_RESET_STATE;
}

export type KittingOrderAction =
  | CreateKittingOrderManualFailure
  | CreateKittingOrderManualSuccess
  | CreatekittingOrderManualRequest
  | ResetKittingOrderstate;
