import {
  ResetPageActionType,
  ResetReduxActionType
} from "../redux/actions/types";

/*=========== Table ============*/
export type Order = "desc" | "asc";
export interface TableConfig {
  title: string;
  orderBy: string;
  tableRowTestId: string;
}

export interface HeadCell {
  id: string;
  label: string;
}

export interface CommonObject {
  [key: string]: any;
}

export interface ISelectionOption {
  label: string;
  id: string | number;
}

/*=========== Axios ============*/
export enum Method {
  GET,
  POST,
  PUT,
  PATCH,
  DELETE
}

/*=========== REDUX ============*/
export interface ResetPageState {
  resetCounter: number;
}

export interface ResetReduxStoreAction {
  type: ResetReduxActionType.RESET_REDUX_STORE;
}

export interface ResetPageAction {
  type: ResetPageActionType.RESET_PAGE;
}

export interface ImsiSubAndMainRangeStatusTable {
  startImsi: string;
  endImsi: string;
  amount: number;
  status: string;
  oaRefPoPk: string | null;
  hlrName: string;
  productTypeName: string | null;
  cardTypeName: string | null;
  systemStack: string;
  imsiDigits1_8: string;
  mainRangeDescription: string;
  subRangeDescription: string | null;
}

export interface ImsiSubAndMainRangeStatusRequestPayload {
  startIMSIForSearch: string;
  endIMSIForSearch: string;
}
