import { CustomProfileActionTypes } from "../redux/actions/types";

export interface CustomProfile {
  id: number;
  name: string;
  description: string;
  simVendor: string;
  xmlFileName: string;
  archived: boolean;
  isReferenceExist: boolean;
  lastUpdateDate?: string;
  lastUpdatedBy?: string | number;
  userName: string;
}

export interface CustomProfilePayload {
  name: string;
  description: string;
  userUpdatedBy: string;
  simVendorId: number;
  file: string;
  archived: boolean;
  id: number;
}

export interface CustomProfileState {
  isLoadingFetch: boolean;
  customProfiles: Array<CustomProfile>;
  cpNames: Array<string>;
  selectedCustomProfile: CustomProfile | null;
  isLoadingCreate: boolean;
  errorCreate: string | null;
  isLoadingUpdate: boolean;
  errorUpdate: string | null;
  deleteSuccessMsg?: string;
  archiveSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
}

interface FetchCustomProfileRequest {
  type: CustomProfileActionTypes.FETCH_CUSTOM_PROFILE_REQUEST;
}

interface FetchCustomProfileSuccess {
  type: CustomProfileActionTypes.FETCH_CUSTOM_PROFILE_SUCCESS;
  payload: CustomProfile[];
}

interface FetchCustomProfileError {
  type: CustomProfileActionTypes.FETCH_CUSTOM_PROFILE_FAILURE;
}

interface SetSelectedCustomProfile {
  type: CustomProfileActionTypes.SET_SELECTED_CUSTOM_PROFILE;
  payload: CustomProfile | null;
}

interface CreateCustomProfileRequest {
  type: CustomProfileActionTypes.CREATE_CUSTOM_PROFILE_REQUEST;
}

interface CreateCustomProfileSuccess {
  type: CustomProfileActionTypes.CREATE_CUSTOM_PROFILE_SUCCESS;
}

interface CreateCustomProfileFailure {
  type: CustomProfileActionTypes.CREATE_CUSTOM_PROFILE_FAILURE;
  payload: string;
}

interface UpdateCustomProfileRequest {
  type: CustomProfileActionTypes.UPDATE_CUSTOM_PROFILE_REQUEST;
}

interface UpdateCustomProfileSuccess {
  type: CustomProfileActionTypes.UPDATE_CUSTOM_PROFILE_SUCCESS;
}

interface UpdateCustomProfileFailure {
  type: CustomProfileActionTypes.UPDATE_CUSTOM_PROFILE_FAILURE;
  payload: string;
}

interface ResetCustomProfile {
  type: CustomProfileActionTypes.RESET_CUSTOM_PROFILE;
}

interface DeleteCustomProfileRequest {
  type: CustomProfileActionTypes.DELETE_CUSTOM_PROFILE_REQUEST;
}
interface DeleteCustomProfileSuccess {
  type: CustomProfileActionTypes.DELETE_CUSTOM_PROFILE_SUCCESS;
  payload: number;
}

interface DeleteCustomProfileFailure {
  type: CustomProfileActionTypes.DELETE_CUSTOM_PROFILE_FAILURE;
  payload: string;
}

interface ArchiveCustomProfileRequest {
  type: CustomProfileActionTypes.ARCHIVE_CUSTOM_PROFILE_REQUEST;
}
interface ArchiveCustomProfileSuccess {
  type: CustomProfileActionTypes.ARCHIVE_CUSTOM_PROFILE_SUCCESS;
  payload: { id: number; archive: boolean };
}

interface ArchiveCustomProfileFailure {
  type: CustomProfileActionTypes.ARCHIVE_CUSTOM_PROFILE_FAILURE;
  payload: string;
}

interface ExportCustomProfileRequest {
  type: CustomProfileActionTypes.EXPORT_CUSTOM_PROFILE_REQUEST;
}

interface ExportCustomProfileSuccess {
  type: CustomProfileActionTypes.EXPORT_CUSTOM_PROFILE_SUCCESS;
  payload: string;
}

interface ExportCustomProfileFailure {
  type: CustomProfileActionTypes.EXPORT_CUSTOM_PROFILE_FAILURE;
  payload: string;
}
interface ResetCustomProfile {
  type: CustomProfileActionTypes.RESET_CUSTOM_PROFILE;
}

export type CustomProfileAction =
  | FetchCustomProfileRequest
  | FetchCustomProfileSuccess
  | FetchCustomProfileError
  | SetSelectedCustomProfile
  | CreateCustomProfileRequest
  | CreateCustomProfileSuccess
  | CreateCustomProfileFailure
  | UpdateCustomProfileRequest
  | UpdateCustomProfileSuccess
  | UpdateCustomProfileFailure
  | DeleteCustomProfileRequest
  | DeleteCustomProfileSuccess
  | DeleteCustomProfileFailure
  | ArchiveCustomProfileRequest
  | ArchiveCustomProfileSuccess
  | ArchiveCustomProfileFailure
  | ExportCustomProfileRequest
  | ExportCustomProfileSuccess
  | ExportCustomProfileFailure
  | ResetCustomProfile;
