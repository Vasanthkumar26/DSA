import { ShortCodeActionTypes } from "../redux/actions/types";

export interface ShortCode {
  id: number;
  shortCodeId: string;
  spid: string;
  serviceProviderId: number;
  shortCode: string;
  lastUpdateDate: Date;
  archived: boolean;
  text?: string;
  deleteSuccessMsg?: string;
  archiveSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  productTypeRefExists: boolean;
}

export interface SCUser {
  id: number;
  spid: string;
  userNtLogin: string | null;
  lastUpdateDate: string;
}

export interface ShortCodePayload {
  spid: string;
  shortCode: string;
  archived?: boolean;
  serviceProvider?: string;
}

export interface ShortCodeAddress {
  id: string;
  label: string;
}

/*========REDUX ============*/

export interface ShortCodeState {
  isLoadingFetch: boolean;
  shortCodes: Array<ShortCode>;
  scSpid: Array<string>;
  errorFetch: string | null;
  selectedShortCode?: ShortCode | null;
  isLoadingCreate: boolean;
  errorCreate: string | null;
  isLoadingUpdate: boolean;
  errorUpdate: string | null;
  isLoadingExport: boolean;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  deleteSuccessMsg?: string;
  archiveSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  deleteErrorMsg?: string | null;
  shortCodeValue: Array<ShortCodeAddress>;
}

interface FetchShortCodeRequest {
  type: ShortCodeActionTypes.FETCH_SHORT_CODE_REQUEST;
}

interface FetchShortCodeSuccess {
  type: ShortCodeActionTypes.FETCH_SHORT_CODE_SUCCESS;
  payload: Array<ShortCode>;
}

interface FetchShortCodeFailure {
  type: ShortCodeActionTypes.FETCH_SHORT_CODE_FAILURE;
  payload: string;
}

interface SetSelectedShortCode {
  type: ShortCodeActionTypes.SET_SELECTED_SHORT_CODE;
  payload: ShortCode | null;
}

interface CreateShortCodeRequest {
  type: ShortCodeActionTypes.CREATE_SHORT_CODE_REQUEST;
}

interface CreateShortCodeSuccess {
  type: ShortCodeActionTypes.CREATE_SHORT_CODE_SUCCESS;
}

interface CreateShortCodeFailure {
  type: ShortCodeActionTypes.CREATE_SHORT_CODE_FAILURE;
  payload: string;
}

interface UpdateShortCodeRequest {
  type: ShortCodeActionTypes.UPDATE_SHORT_CODE_REQUEST;
}

interface UpdateShortCodeSuccess {
  type: ShortCodeActionTypes.UPDATE_SHORT_CODE_SUCCESS;
}

interface UpdateShortCodeFailure {
  type: ShortCodeActionTypes.UPDATE_SHORT_CODE_FAILURE;
  payload: string;
}

interface DeleteShortCodeRequest {
  type: ShortCodeActionTypes.DELETE_SELECTED_SHORTCODE_REQUEST;
}

interface DeleteShortCodeSucess {
  type: ShortCodeActionTypes.DELETE_SELECTED_SHORTCODE_SUCCESS;
  payload: string;
}

interface DeleteShortCodeFailure {
  type: ShortCodeActionTypes.DELETE_SELECTED_SHORTCODE_FAILURE;
  payload: string;
}

interface ArchiveShortCodeRequest {
  type: ShortCodeActionTypes.ARCHIVE_SELECTED_SHORTCODE_REQUEST;
}

interface ArchiveShortCodeSucess {
  type: ShortCodeActionTypes.ARCHIVE_SELECTED_SHORTCODE_SUCCESS;
  payload: { id: string; archive: boolean };
}

interface ArchiveShortCodeFailure {
  type: ShortCodeActionTypes.ARCHIVE_SELECTED_SHORTCODE_FAILURE;
  payload: string;
}

interface FetchShortCodeExportRequest {
  type: ShortCodeActionTypes.FETCH_SHORT_CODE_EXPORT_REQUEST;
}

interface FetchShortCodeExportSuccess {
  type: ShortCodeActionTypes.FETCH_SHORT_CODE_EXPORT_SUCCESS;
  payload: string;
}

interface FetchShortCodeExportFailure {
  type: ShortCodeActionTypes.FETCH_SHORT_CODE_EXPORT_FAILURE;
  payload: string;
}
interface RESETShortCodeERR {
  type: ShortCodeActionTypes.RESET_SHORTCODE_ERR;
}

interface ResetShortCode {
  type: ShortCodeActionTypes.RESET_SHORT_CODE;
}

interface FetchShortCodeAddressRequest {
  type: ShortCodeActionTypes.FETCH_ShortCode_REQUEST;
}

interface FetchShortCodeAddressSuccess {
  type: ShortCodeActionTypes.FETCH_ShortCode_SUCCESS;
  payload: Array<ShortCodeAddress>;
}

interface FetchShortCodeAddressFailure {
  type: ShortCodeActionTypes.FETCH_ShortCode_FAILURE;
  payload: string;
}

export type ShortCodeAction =
  | FetchShortCodeRequest
  | FetchShortCodeSuccess
  | FetchShortCodeFailure
  | SetSelectedShortCode
  | CreateShortCodeRequest
  | CreateShortCodeSuccess
  | CreateShortCodeFailure
  | UpdateShortCodeRequest
  | UpdateShortCodeSuccess
  | UpdateShortCodeFailure
  | DeleteShortCodeRequest
  | DeleteShortCodeSucess
  | DeleteShortCodeFailure
  | ArchiveShortCodeRequest
  | ArchiveShortCodeSucess
  | ArchiveShortCodeFailure
  | FetchShortCodeExportRequest
  | FetchShortCodeExportFailure
  | FetchShortCodeExportSuccess
  | RESETShortCodeERR
  | ResetShortCode
  | FetchShortCodeAddressRequest
  | FetchShortCodeAddressSuccess
  | FetchShortCodeAddressFailure;
