import { FormFactorActionTypes } from "../redux/actions/types";

export interface FormFactor {
  FormFactorId: number;
  name: string;
  value: string;
  lastUpdateDate: Date;
  user: string;
  archived: boolean;
  deleteSuccessMsg?: string;
  archiveSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  sim_article_reference_exist: boolean;
}

export interface FormFactorPayload {
  name: string;
  value: string;
  user: string;
  archived?: boolean;
}

/*========REDUX ============*/

export interface FormFactorState {
  isLoadingFetch: boolean;
  formFactors: Array<FormFactor>;
  errorFetch: string | null;
  selectedFormFactor?: FormFactor | null;
  isLoadingCreate: boolean;
  errorCreate: string | null;
  isLoadingUpdate: boolean;
  errorUpdate: string | null;
  isLoadingExport: boolean;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  deleteSuccessMsg?: string;
  archiveSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  deleteErrorMsg?: string;
}

interface FetchFormFactorRequest {
  type: FormFactorActionTypes.FETCH_FORM_FACTOR_REQUEST;
}

interface FetchFormFactorSuccess {
  type: FormFactorActionTypes.FETCH_FORM_FACTOR_SUCCESS;
  payload: Array<FormFactor>;
}

interface FetchFormFactorFailure {
  type: FormFactorActionTypes.FETCH_FORM_FACTOR_FAILURE;
  payload: string;
}

interface SetSelectedFormFactor {
  type: FormFactorActionTypes.SET_SELECTED_FORM_FACTOR;
  payload: FormFactor | null;
}

interface CreateFormFactorRequest {
  type: FormFactorActionTypes.CREATE_FORM_FACTOR_REQUEST;
}

interface CreateFormFactorSuccess {
  type: FormFactorActionTypes.CREATE_FORM_FACTOR_SUCCESS;
}

interface CreateFormFactorFailure {
  type: FormFactorActionTypes.CREATE_FORM_FACTOR_FAILURE;
  payload: string;
}

interface UpdateFormFactorRequest {
  type: FormFactorActionTypes.UPDATE_FORM_FACTOR_REQUEST;
}

interface UpdateFormFactorSuccess {
  type: FormFactorActionTypes.UPDATE_FORM_FACTOR_SUCCESS;
}

interface UpdateFormFactorFailure {
  type: FormFactorActionTypes.UPDATE_FORM_FACTOR_FAILURE;
  payload: string;
}

interface DeleteFormFactorRequest {
  type: FormFactorActionTypes.DELETE_SELECTED_FORM_FACTOR_REQUEST;
}

interface DeleteFormFactorSuccess {
  type: FormFactorActionTypes.DELETE_SELECTED_FORM_FACTOR_SUCCESS;
  payload: number;
}

interface DeleteFormFactorFailure {
  type: FormFactorActionTypes.DELETE_SELECTED_FORM_FACTOR_FAILURE;
  payload: string;
}
interface ArchiveFormFactorRequest {
  type: FormFactorActionTypes.ARCHIVE_SELECTED_FORM_FACTOR_REQUEST;
}

interface ArchiveFormFactorSuccess {
  type: FormFactorActionTypes.ARCHIVE_SELECTED_FORM_FACTOR_SUCCESS;
  payload: { id: number; archive: boolean };
}

interface ArchiveFormFactorFailure {
  type: FormFactorActionTypes.ARCHIVE_SELECTED_FORM_FACTOR_FAILURE;
  payload: string;
}

interface FetchFormFactorExportRequest {
  type: FormFactorActionTypes.FETCH_FORM_FACTOR_EXPORT_REQUEST;
}

interface FetchFormFactorExportSuccess {
  type: FormFactorActionTypes.FETCH_FORM_FACTOR_EXPORT_SUCCESS;
  payload: string;
}

interface FetchFormFactorExportFailure {
  type: FormFactorActionTypes.FETCH_FORM_FACTOR_EXPORT_FAILURE;
  payload: string;
}
interface RESETFormFactorERR {
  type: FormFactorActionTypes.RESET_FORMFACTOR_ERR;
}

interface ResetFormFactor {
  type: FormFactorActionTypes.RESET_FORM_FACTOR;
}
export type FormFactorAction =
  | FetchFormFactorRequest
  | FetchFormFactorSuccess
  | FetchFormFactorFailure
  | SetSelectedFormFactor
  | CreateFormFactorRequest
  | CreateFormFactorSuccess
  | CreateFormFactorFailure
  | UpdateFormFactorRequest
  | UpdateFormFactorSuccess
  | UpdateFormFactorFailure
  | DeleteFormFactorRequest
  | DeleteFormFactorSuccess
  | DeleteFormFactorFailure
  | ArchiveFormFactorRequest
  | ArchiveFormFactorSuccess
  | ArchiveFormFactorFailure
  | FetchFormFactorExportRequest
  | FetchFormFactorExportFailure
  | FetchFormFactorExportSuccess
  | RESETFormFactorERR
  | ResetFormFactor;
