import { ExternalSystemsActionTypes } from "../redux/actions/types";

export interface ExternalSystem {
  externalSystemId: number;
  name: string;
  emailAddress: string;
  replyAddress?: string;
  subject: string;
  lastUpdateDate: Date;
  user: string;
  users: Array<Partial<ESUser>>;
  archived: boolean;
  text?: string;
  deleteSuccessMsg?: string;
  archiveSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  productTypeRefferanceExists: boolean;
}

export interface ESUser {
  id: number;
  userId: string;
  userNtLogin: string | null;
  userName: string;
  email: string;
  lastUpdateDate: string;
}

export interface ExternalSystemPayload {
  name: string;
  emailAddress: string;
  replyAddress: string;
  subject: string;
  text: string;
  userIds: Array<string>;
  archived?: boolean;
}

/*========REDUX ============*/

export interface ExternalSystemState {
  isLoadingFetch: boolean;
  externalSystems: Array<ExternalSystem>;
  esNames: Array<string>;
  errorFetch: string | null;
  selectedExternalSystem?: ExternalSystem | null;
  isLoadingCreate: boolean;
  errorCreate: string | null;
  isLoadingUpdate: boolean;
  errorUpdate: string | null;
  isLoadingExport: boolean;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  deleteSuccessMsg?: string;
  archiveSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  deleteErrorMsg?: string | null;
}

interface FetchExternalSystemsRequest {
  type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEMS_REQUEST;
}

interface FetchExternalSystemsSuccess {
  type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEMS_SUCCESS;
  payload: Array<ExternalSystem>;
}

interface FetchExternalSystemsFailure {
  type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEMS_FAILURE;
  payload: string;
}

interface SetSelectedExternalSystem {
  type: ExternalSystemsActionTypes.SET_SELECTED_EXTERNAL_SYSTEMS;
  payload: ExternalSystem | null;
}

interface CreateExternalSystemsRequest {
  type: ExternalSystemsActionTypes.CREATE_EXTERNAL_SYSTEMS_REQUEST;
}

interface CreateExternalSystemsSuccess {
  type: ExternalSystemsActionTypes.CREATE_EXTERNAL_SYSTEMS_SUCCESS;
}

interface CreateExternalSystemsFailure {
  type: ExternalSystemsActionTypes.CREATE_EXTERNAL_SYSTEMS_FAILURE;
  payload: string;
}

interface UpdateExternalSystemsRequest {
  type: ExternalSystemsActionTypes.UPDATE_EXTERNAL_SYSTEMS_REQUEST;
}

interface UpdateExternalSystemsSuccess {
  type: ExternalSystemsActionTypes.UPDATE_EXTERNAL_SYSTEMS_SUCCESS;
}

interface UpdateExternalSystemsFailure {
  type: ExternalSystemsActionTypes.UPDATE_EXTERNAL_SYSTEMS_FAILURE;
  payload: string;
}

interface DeleteExternalSystemRequest {
  type: ExternalSystemsActionTypes.DELETE_SELECTED_EXTERNAL_REQUEST;
}

interface DeleteExternalSystemSucess {
  type: ExternalSystemsActionTypes.DELETE_SELECTED_EXTERNAL_SUCCESS;
  payload: number;
}

interface DeleteExternalSystemFailure {
  type: ExternalSystemsActionTypes.DELETE_SELECTED_EXTERNAL_FAILURE;
  payload: string;
}

interface ArchiveExternalSystemRequest {
  type: ExternalSystemsActionTypes.ARCHIVE_SELECTED_EXTERNAL_REQUEST;
}

interface ArchiveExternalSystemSucess {
  type: ExternalSystemsActionTypes.ARCHIVE_SELECTED_EXTERNAL_SUCCESS;
  payload: { id: number; archive: boolean };
}

interface ArchiveExternalSystemFailure {
  type: ExternalSystemsActionTypes.ARCHIVE_SELECTED_EXTERNAL_FAILURE;
  payload: string;
}

interface FetchExternalSystemExportRequest {
  type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_REQUEST;
}

interface FetchExternalSystemExportSuccess {
  type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_SUCCESS;
  payload: string;
}

interface FetchExternalSystemExportFailure {
  type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_FAILURE;
  payload: string;
}
interface RESETExtertnalSystemERR {
  type: ExternalSystemsActionTypes.RESET_ExtertnalSystem_ERR;
}

interface ResetExternalSystem {
  type: ExternalSystemsActionTypes.RESET_EXTERNAL_SYSTEM;
}

export type ExternalSystemsAction =
  | FetchExternalSystemsRequest
  | FetchExternalSystemsSuccess
  | FetchExternalSystemsFailure
  | SetSelectedExternalSystem
  | CreateExternalSystemsRequest
  | CreateExternalSystemsSuccess
  | CreateExternalSystemsFailure
  | UpdateExternalSystemsRequest
  | UpdateExternalSystemsSuccess
  | UpdateExternalSystemsFailure
  | DeleteExternalSystemRequest
  | DeleteExternalSystemSucess
  | DeleteExternalSystemFailure
  | ArchiveExternalSystemRequest
  | ArchiveExternalSystemSucess
  | ArchiveExternalSystemFailure
  | FetchExternalSystemExportRequest
  | FetchExternalSystemExportFailure
  | FetchExternalSystemExportSuccess
  | RESETExtertnalSystemERR
  | ResetExternalSystem;
