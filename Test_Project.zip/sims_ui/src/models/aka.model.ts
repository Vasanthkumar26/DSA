import { AkaActionTypes } from "../redux/actions/types";

export interface akaTpKey {
  akaAlgTypeId: any;
  akaTpKeyIdValue: any;
  manufactureId: any;
}

export interface akaAlgorithm {
  akaAlgTypeId: any;
  akaAlgIdValue: any;
}
export interface akaCreatePayload {
  displayValue: string;
  inputFileValue: string;
  fileEnding: string;
  archived: boolean;
  userUpdated: number;
  assocAkaAlgId: Array<akaAlgorithm>;
  assocAkaTpKeyId: Array<akaTpKey>;
}

export interface Aka {
  id: number;
  akaHlrName: string;
  inputFileValue: string;
  fileExtension: string;
  archived: boolean;
  dateUpdated: Date;
  assocAkaTpKeyId: Array<akaTpKey>;
  assocAkaAlgId: Array<akaAlgorithm>;
  isReferenceExist: boolean;
  userUpdated: number;
}

/*========REDUX ============*/

export interface AkaState {
  isLoadingFetch: boolean;
  akas: Array<Aka>;
  errorFetch: string | null;
  selectedAka?: Aka | null;
  isLoadingExport: boolean;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  deleteSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  deleteErrorMsg?: string | null;
  isLoadingCreate: boolean;
  isLoadingUpdate: boolean;
  isArchiveRequestSuccessful: boolean | null;
  archiveMsg: string | null;
}

interface FetchAkaRequest {
  type: AkaActionTypes.FETCH_AKA_REQUEST;
}

interface FetchAkaSuccess {
  type: AkaActionTypes.FETCH_AKA_SUCCESS;
  payload: Array<Aka>;
}

interface FetchAkaFailure {
  type: AkaActionTypes.FETCH_AKA_FAILURE;
  payload: string;
}

interface SetSelectedAka {
  type: AkaActionTypes.SET_SELECTED_AKA;
  payload: Aka | null;
}

interface ExportAkaRequest {
  type: AkaActionTypes.FETCH_AKA_EXPORT_REQUEST;
}

interface ExportAkaSuccess {
  type: AkaActionTypes.FETCH_AKA_EXPORT_SUCCESS;
  payload: string;
}

interface ExportAkaFailure {
  type: AkaActionTypes.FETCH_AKA_EXPORT_ERROR;
  payload: string;
}
interface DeleteAKArequest {
  type: AkaActionTypes.DELETE_AKA_REQUEST;
}

interface DeleteAKASucess {
  type: AkaActionTypes.DELETE_AKA_SUCCESS;
  payload: number;
}

interface DeleteAKAFailure {
  type: AkaActionTypes.DELETE_AKA_FAILURE;
  payload: string;
}

interface CreateAkaRequest {
  type: AkaActionTypes.CREATE_AKA_REQUEST;
}

interface CreateAkaSuccess {
  type: AkaActionTypes.CREATE_AKA_SUCCESS;
  payload: Array<Aka>;
}

interface CreateAkaFailure {
  type: AkaActionTypes.CREATE_AKA_FAILURE;
  payload: string;
}

interface UpdateAkaRequest {
  type: AkaActionTypes.UPDATE_AKA_REQUEST;
}

interface UpdateAkaSuccess {
  type: AkaActionTypes.UPDATE_AKA_SUCCESS;
  payload: Array<Aka>;
}

interface UpdateAkaFailure {
  type: AkaActionTypes.UPDATE_AKA_FAILURE;
  payload: string;
}

interface ArchiveAkaRequest {
  type: AkaActionTypes.ARCHIVE_AKA_REQUEST;
}
interface ArchiveAkaSuccess {
  type: AkaActionTypes.ARCHIVE_AKA_SUCCESS;
  payload: { id: number; archived: boolean; akaName: String };
}
interface ArchiveAkaFailure {
  type: AkaActionTypes.ARCHIVE_AKA_FAILURE;
  payload: { error: any; akaName: string };
}

interface ResetAka {
  type: AkaActionTypes.RESET_AKA;
}

export type AkaAction =
  | FetchAkaRequest
  | FetchAkaSuccess
  | FetchAkaFailure
  | SetSelectedAka
  | ExportAkaFailure
  | ExportAkaSuccess
  | ExportAkaRequest
  | DeleteAKArequest
  | DeleteAKASucess
  | DeleteAKAFailure
  | CreateAkaRequest
  | CreateAkaSuccess
  | CreateAkaFailure
  | UpdateAkaRequest
  | UpdateAkaSuccess
  | UpdateAkaFailure
  | ArchiveAkaRequest
  | ArchiveAkaSuccess
  | ArchiveAkaFailure
  | ResetAka;
