export type NavItem = {
  Icon: string;
  Text: string;
  Path?: string;
};
export type SubItem = Omit<NavItem, "Icon">;
export interface SideBarItem extends NavItem {
  children?: Array<SubItem>;
}
