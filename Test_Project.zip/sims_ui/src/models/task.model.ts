import { TaskActionTypes } from "../redux/actions/types";

export interface Task {
  id: number;
  originatorType: string;
  originatorName: string;
  fileName: string;
  timeStamp: Date;
  orderId: string;
  errorCode: string;
  errorMsg: string;
  isDownloaded: string;
  archiveId: string;
}

export interface TaskOrder {
  creationDate: string;
  orderId: string;
  task: string;
  orderType: Date;
  workflowException: Boolean;
  exceptionText: string;
}

/*========REDUX ============*/

export interface TaskState {
  isLoadingFetch: boolean;
  tasks: Array<Task>;
  orders: Array<TaskOrder>;
  errorFetch: string | null;
  selectedTask?: Task | null;
  isLoadingExport: boolean;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  deleteSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  deleteErrorMsg?: string | null;
  isLoadingCreate: boolean;
  isLoadingUpdate: boolean;
}

interface FetchOrderRequest {
  type: TaskActionTypes.FETCH_ORDER_REQUEST;
}

interface FetchOrderSuccess {
  type: TaskActionTypes.FETCH_ORDER_SUCCESS;
  payload: Array<TaskOrder>;
}

interface FetchOrderFailure {
  type: TaskActionTypes.FETCH_ORDER_FAILURE;
  payload: string;
}

interface FetchTaskRequest {
  type: TaskActionTypes.FETCH_TASK_REQUEST;
}

interface FetchTaskSuccess {
  type: TaskActionTypes.FETCH_TASK_SUCCESS;
  payload: Array<Task>;
}

interface FetchTaskFailure {
  type: TaskActionTypes.FETCH_TASK_FAILURE;
  payload: string;
}

interface DownloadTaskRequest {
  type: TaskActionTypes.DOWNLOAD_TASK_REQUEST;
}

interface DownloadTaskSuccess {
  type: TaskActionTypes.DOWNLOAD_TASK_SUCCESS;
  payload: string;
}

interface DownloadTaskFailure {
  type: TaskActionTypes.DOWNLOAD_TASK_ERROR;
  payload: string;
}
interface DeleteTaskRequest {
  type: TaskActionTypes.DELETE_TASK_REQUEST;
}

interface DeleteTaskSuccess {
  type: TaskActionTypes.DELETE_TASK_SUCCESS;
  payload: number;
}

interface DeleteTaskFailure {
  type: TaskActionTypes.DELETE_TASK_FAILURE;
  payload: string;
}

export type TaskAction =
  | FetchOrderRequest
  | FetchOrderSuccess
  | FetchOrderFailure
  | FetchTaskRequest
  | FetchTaskSuccess
  | FetchTaskFailure
  | DownloadTaskRequest
  | DownloadTaskSuccess
  | DownloadTaskFailure
  | DeleteTaskRequest
  | DeleteTaskSuccess
  | DeleteTaskFailure;
