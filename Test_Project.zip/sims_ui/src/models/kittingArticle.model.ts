// articleNumber: string;
// description: string;
// serviceProvider: string;
// startPack: string;
// offer: string;
// comment: string;
// archive: boolean;

export interface KittingArticle {
  article_number: string;
  description: string;
  startPackType: string;
  comment: string;
  archived: boolean | null;

  offer: string;
  serviceProvider: string;

  id: number | null;
  dtoId: number | null;
  systemStackId: number | null;
  preBarred: boolean | null;
  msisdnType: string | null;
  tariffOptionId: string | null;
  tariffDescription: string | null;
  packagingType: string | null;
  packagingDescription: string | null;
  initialCreditCents: string | null;
  userName: string | null;
  lastUpdateDate: string | null;
  kitting_order_exists: boolean | null;
  kittingPackProduct: Array<any> | null;
  kittingPackProductString: string | null;
}

export interface StarterPack {
  value: string;
  label: string;
}

export interface Offer {
  value: string;
  label: string;
}
