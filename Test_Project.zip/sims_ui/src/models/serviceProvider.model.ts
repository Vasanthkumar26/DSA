import { ServiceProviderActionTypes } from "../redux/actions/types";

export interface ServiceProvider {
  id: string;
  spid: string;
  description: string;
}

/*========REDUX ============*/

export interface ServiceProviderState {
  isLoadingFetch: boolean;
  serviceProviders: Array<ServiceProvider>;
  errorFetch: string | null;
}

interface FetchServiceProviderRequest {
  type: ServiceProviderActionTypes.FETCH_SERVICE_PROVIDER_REQUEST;
}

interface FetchServiceProviderSuccess {
  type: ServiceProviderActionTypes.FETCH_SERVICE_PROVIDER_SUCCESS;
  payload: Array<ServiceProvider>;
}

interface FetchServiceProviderFailure {
  type: ServiceProviderActionTypes.FETCH_SERVICE_PROVIDER_FAILURE;
  payload: string;
}

export type ServiceProviderAction =
  | FetchServiceProviderRequest
  | FetchServiceProviderSuccess
  | FetchServiceProviderFailure;
