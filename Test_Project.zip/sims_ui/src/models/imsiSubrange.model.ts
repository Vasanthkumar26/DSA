import { ImsiSubrangeActionTypes } from "../redux/actions/types";
import { ImsiSubAndMainRangeStatusTable } from "./global.model";
export interface ImsiSubrange {
  id: number;
  name: string;
  ismiMainrange: string;
  imsiMainRangeId: string;
  imsiDigits12345678: string;
  startImsi: string;
  endImsi: string;
  productType: string;
  productTypeId: string;
  archived: boolean;
  imsisubRangeId: number;
  deleteSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  archSuccessMsgFlag?: boolean;
  archSuccessMsg?: string;
  lastUpdateDate: Date;
  userName?: string;
}

export interface FetchSubRangeStatusTableRequest {
  type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_STATUS_REQUEST;
}

export interface FetchSubRangeStatusTableSuccess {
  type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_STATUS_SUCCESS;
  payload: Array<ImsiSubAndMainRangeStatusTable>;
}

export interface FetchSubRangeStatusTableFailure {
  type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_STATUS_FAILURE;
  payload: string;
}

export interface ProductType {
  productTypeId: string;
  name: string;
}

export interface MainRange {
  imsiMainRangeId: string;
  mainRangeCombinedName: string;
}

export interface FetchMainRangeProductTypeResponse {
  allImsiMainRanges: Array<MainRange>;
  allProductTypes: Array<ProductType>;
}

export interface FetchImsiSubrangeResponse {
  data: ImsiSubrange;
  message: string | null;
}
/*========REDUX ============*/

export interface ImsiSubrangeState {
  isLoadingFetch: boolean;
  isLoadingExport: boolean;
  isLoading: boolean;
  imsiSubranges: Array<ImsiSubrange>;
  selectedImsiSubrange: ImsiSubrange | null;
  errorFetch: string | null;
  error: string | null;
  successMsg: string | null;
  productTypeList: Array<ProductType>;
  exportSuccessMsg: string | null;
  errorExport: string | null;
  deleteSuccessMsg?: string;
  deleteSuccessMsgFlag?: boolean;
  archSuccessMsgFlag?: boolean;
  archSuccessMsg?: string;
  imsiMainRangeList: Array<MainRange> | [];
  isLoadingFetchStatusTable: boolean;
  errorFetchStatusTable: string | null;
  subrangestatusdetail: Array<ImsiSubAndMainRangeStatusTable>;
}

interface FetchImsiSubrangeRequest {
  type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_REQUEST;
}

interface FetchImsiSubrangeSuccess {
  type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_SUCCESS;
  payload: Array<ImsiSubrange>;
}

interface FetchImsiSubrangeFailure {
  type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_FAILURE;
  payload: string;
}

interface FetchMainRangeProductTypeRequest {
  type: ImsiSubrangeActionTypes.FETCH_DDL_DATA_REQUEST;
}

interface FetchMainRangeProductTypeSuccess {
  type: ImsiSubrangeActionTypes.FETCH_DDL_DATA_SUCCESS;
  payload: FetchMainRangeProductTypeResponse;
}

interface FetchMainRangeProductTypeFailure {
  type: ImsiSubrangeActionTypes.FETCH_DDL_DATA_ERROR;
  payload: string;
}

interface SelectedImsiSubrange {
  type: ImsiSubrangeActionTypes.SET_SELECTED_IMSI_SUBRANGE;
  payload: ImsiSubrange | null;
}

interface CreateImsiSubrangeRequest {
  type: ImsiSubrangeActionTypes.CREATE_REQUEST;
}

interface CreateImsiSubrangeSuccess {
  type: ImsiSubrangeActionTypes.CREATE_SUCCESS;
  payload?: FetchImsiSubrangeResponse;
}

interface CreateImsiSubrangeFailure {
  type: ImsiSubrangeActionTypes.CREATE_FAILURE;
  payload: string;
}

interface ResetImsiSubrangeError {
  type: ImsiSubrangeActionTypes.RESET_ERROR;
}

interface ResetImsiSubrangeForm {
  type: ImsiSubrangeActionTypes.RESET_FORM;
}

interface DeleteIMSISubRequest {
  type: ImsiSubrangeActionTypes.DELETE_IMSI_SUBRANGE_REQUEST;
}

interface DeleteIMSISubSucess {
  type: ImsiSubrangeActionTypes.DELETE_IMSI_SUBRANGE_SUCCESS;
  payload: number;
}

interface DeleteIMSISubFailure {
  type: ImsiSubrangeActionTypes.DELETE_IMSI_SUBRANGE_FAILURE;
  payload: string;
}

interface ArchiveIMSISubRequest {
  type: ImsiSubrangeActionTypes.ARCHIVE_IMSI_SUBRANGE_REQUEST;
}

interface ArchiveIMSISubSucess {
  type: ImsiSubrangeActionTypes.ARCHIVE_IMSI_SUBRANGE_SUCCESS;
  payload: { imsiId: number; archive: boolean };
}

interface ArchiveIMSISubFailure {
  type: ImsiSubrangeActionTypes.ARCHIVE_IMSI_SUBRANGE_FAILURE;
  payload: string;
}

interface ExportIMSISubRequest {
  type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_REQUEST;
}

interface ExportIMSISubSuccess {
  type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_SUCCESS;
  payload: string;
}

interface ExportIMSISubFailure {
  type: ImsiSubrangeActionTypes.FETCH_IMSI_SUBRANGE_EXPORT_FAILURE;
  payload: string;
}

interface ResetSubrange {
  type: ImsiSubrangeActionTypes.RESET_IMSI_SUBRANGE;
}

export type ImsiSubrangeAction =
  | FetchImsiSubrangeRequest
  | FetchImsiSubrangeSuccess
  | FetchImsiSubrangeFailure
  | SelectedImsiSubrange
  | FetchMainRangeProductTypeRequest
  | FetchMainRangeProductTypeSuccess
  | FetchMainRangeProductTypeFailure
  | CreateImsiSubrangeFailure
  | CreateImsiSubrangeRequest
  | CreateImsiSubrangeSuccess
  | ResetImsiSubrangeError
  | ResetImsiSubrangeForm
  | DeleteIMSISubRequest
  | DeleteIMSISubSucess
  | DeleteIMSISubFailure
  | ArchiveIMSISubRequest
  | ArchiveIMSISubSucess
  | ArchiveIMSISubFailure
  | ExportIMSISubRequest
  | ExportIMSISubSuccess
  | ExportIMSISubFailure
  | FetchSubRangeStatusTableFailure
  | FetchSubRangeStatusTableRequest
  | FetchSubRangeStatusTableSuccess
  | ResetSubrange;
