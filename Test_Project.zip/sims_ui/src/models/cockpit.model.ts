import { CockpitActionTypes } from "../redux/actions/types";

export interface Cockpit {
  id: number;
  orderNumber: string;
  articleNumber: string;
  itemDescription: string;
  crowd: string;
  status: string;
  serviceProvider: string;
  registerDate: string;
  deliveryDate: string;
  lastUpdateDate: string;
  oaRefPoPk: string;
  workflowStatus: Array<WorkflowStatus>;
}

export interface CockpitQuery {
  queryId: number;
  queryName: string;
}

export interface WorkflowStatus {
  kittingStatus: string;
}

export interface OrderDetail {
  id: string;
  creationDate: string;
  expectedDeliveryDate: string;
  noOfSimCards: string;
  article: string;
  description: string;
  serviceProvider: string;
  startPackType: string;
  msisdnType: string;
  packs: string;
  status: string;
  originator: string;
  lastUpdatedBy: string;
  lastUpdatedDate: string;
  organization: string;
  simstatus: string;
}

export interface DocumentTable {
  document: string;
  name: string;
  archiveId: string;
  importDate: Date | string;
  action?: JSX.Element;
}

/*========REDUX ============*/

export interface CockpitState {
  isLoadingFetch: boolean;
  cockpits: Array<Cockpit>;
  selectedCockpit: Cockpit | null;
  errorFetch: string | null;
  isLoadingDocument: boolean;
  documentList: Array<DocumentTable>;
}

export interface FileInput {
  name: string; // The name of the file
  size: number; // The size of the file in bytes
  type: string; // The MIME type of the file
  lastModified: number; // The timestamp when the file was last modified
}

export interface DocumentUpload {
  filetypeId: number | null;
  selectedFile: FileInput | null;
}

interface FetchCockpitRequest {
  type: CockpitActionTypes.FETCH_COCKPIT_REQUEST;
}

interface FetchCockpitSuccess {
  type: CockpitActionTypes.FETCH_COCKPIT_SUCCESS;
  payload: Array<Cockpit>;
}

interface FetchCockpitFailure {
  type: CockpitActionTypes.FETCH_COCKPIT_FAILURE;
  payload: string;
}

interface SelectedCockpit {
  type: CockpitActionTypes.SET_SELECTED_COCKPIT;
  payload: Cockpit | null;
}

interface CancelCockpitRequest {
  type: CockpitActionTypes.CANCEL_COCKPIT_REQUEST;
}

interface CancelCockpitSucess {
  type: CockpitActionTypes.CANCEL_COCKPIT_SUCCESS;
  payload: number;
}

interface CancelCockpitFailure {
  type: CockpitActionTypes.CANCEL_COCKPIT_FAILURE;
  payload: string;
}

interface FetchDocumentTableRequest {
  type: CockpitActionTypes.FETCH_DOCUMENT_TABLE_REQUEST;
}

interface FetchDocumentTableSuccess {
  type: CockpitActionTypes.FETCH_DOCUMENT_TABLE_SUCCESS;
  payload: DocumentTable[];
}

interface FetchDocumentTableFailure {
  type: CockpitActionTypes.FETCH_DOCUMENT_TABLE_FAILURE;
}

interface CancelSimRequest {
  type: CockpitActionTypes.CANCEL_SIM_REQUEST;
}

interface CancelSimSucess {
  type: CockpitActionTypes.CANCEL_SIM_SUCCESS;
  payload: number;
}

interface CancelSimFailure {
  type: CockpitActionTypes.CANCEL_SIM_FAILURE;
  payload: string;
}
export type CockpitAction =
  | FetchCockpitRequest
  | FetchCockpitSuccess
  | FetchCockpitFailure
  | SelectedCockpit
  | CancelCockpitRequest
  | CancelCockpitSucess
  | CancelCockpitFailure
  | FetchDocumentTableFailure
  | FetchDocumentTableRequest
  | FetchDocumentTableSuccess
  | CancelSimRequest
  | CancelSimSucess
  | CancelSimFailure;
