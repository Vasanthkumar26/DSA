import React, { FC } from "react";
import { ThemeProvider } from "@mui/material/styles";
import { simsTheme } from "./theme/simsTheme";
import Router from "./routes";
import { CssBaseline } from "@mui/material";

const App: FC = () => {
  return (
    <ThemeProvider theme={simsTheme}>
      <CssBaseline />
      <Router />
    </ThemeProvider>
  );
};

export default App;
