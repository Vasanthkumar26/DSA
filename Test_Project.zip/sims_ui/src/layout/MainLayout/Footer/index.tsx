import { Stack } from "@mui/material";
import { useTranslation } from "../../../hooks/useTranslation";
import Typography from "@mui/material/Typography";

const Footer = () => {
  const t = useTranslation();
  return (
    <Stack
      sx={{
        minHeight: "25px",
        color: "#001936",
        fontWeight: "bold",
        padding: "16px",
      }}
    >
      <Typography
        variant="h5"
        color="#031a34"
        sx={{ fontWeight: 600 }}
      ></Typography>
      <footer>
        <Typography align="left" data-testid="foot-id">
          <b>{t("footer_msg_prefix")}</b>
          {t("footer_msg")}
        </Typography>
      </footer>
    </Stack>
  );
};

export default Footer;
