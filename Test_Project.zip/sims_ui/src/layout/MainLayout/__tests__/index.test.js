import "@testing-library/jest-dom";
import MainLayout from "..";
import { renderWithAllWrappers } from "../../../utils/testUtils";

describe("Main Layout", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<MainLayout />, { route: "/" });

    expect(container).toBeInTheDocument();
  });
});
