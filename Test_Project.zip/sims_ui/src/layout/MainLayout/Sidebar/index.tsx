import React, { FC, useEffect, useState } from "react";
import { ChevronLeft, ChevronRight } from "@mui/icons-material";
import { Box, List, ListItemText, Tooltip } from "@mui/material";
import { useLocation, useNavigate } from "react-router-dom";

import { useTranslation } from "../../../hooks/useTranslation";
import {
  StyledDrawer,
  StyledListItemButton,
  StyledListItemIcon,
  StyledListItemText
} from "./styles";
import SubNavItem from "./SubNavItem";
import { sidebarItems } from "./sidebarItems";

interface Props {
  handleDrawerOpen: (isDrawerOpen: boolean) => void;
}

const Sidebar: FC<Props> = ({ handleDrawerOpen }) => {
  const [isDrawerOpen, setIsDrawerOpen] = useState<boolean>(true);
  const navigate = useNavigate();
  const t = useTranslation();
  const { pathname } = useLocation();

  useEffect(() => {
    handleDrawerOpen(isDrawerOpen);
  }, [handleDrawerOpen, isDrawerOpen]);

  return (
    <StyledDrawer variant="permanent" open={isDrawerOpen}>
      <Box
        component="nav"
        sx={{
          minHeight: "100vh",
          paddingTop: "65px",
          backgroundColor: "#031a34",
          color: "#fcfcfc",
          overflowY: "scroll",
          "&::-webkit-scrollbar": {
            display: "none"
          }
        }}
      >
        <List>
          <StyledListItemButton
            data-testid="drawer-button"
            onClick={() => setIsDrawerOpen(!isDrawerOpen)}
          >
            <ListItemText sx={{ display: isDrawerOpen ? "block" : "none" }} />
            {isDrawerOpen ? <ChevronLeft /> : <ChevronRight />}
          </StyledListItemButton>
          {(sidebarItems || []).map((item) => {
            if ("children" in item) {
              return (
                <SubNavItem
                  key={item?.Text}
                  navItem={item}
                  isDrawerOpen={isDrawerOpen}
                />
              );
            } else {
              const { Icon = "", Text = "", Path = "" } = item;
              return (
                <StyledListItemButton
                  key={Path}
                  data-testid="nav-link"
                  onClick={() => navigate(item?.Path ?? "")}
                  selected={pathname === item?.Path}
                >
                  <StyledListItemIcon>
                    {isDrawerOpen ? (
                      Icon ? (
                        <img src={Icon} alt={Text} />
                      ) : (
                        " "
                      )
                    ) : Icon ? (
                      <Tooltip title={t(Text)} placement="right">
                        <img src={Icon} alt={Text} />
                      </Tooltip>
                    ) : (
                      ""
                    )}
                  </StyledListItemIcon>
                  <StyledListItemText open={isDrawerOpen} primary={t(Text)} />
                </StyledListItemButton>
              );
            }
          })}
        </List>
      </Box>
    </StyledDrawer>
  );
};

export default Sidebar;
