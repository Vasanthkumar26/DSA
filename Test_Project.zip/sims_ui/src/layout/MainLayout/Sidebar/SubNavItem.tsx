import React, { FC, useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Collapse, List, Tooltip } from "@mui/material";
import { ExpandLess, ExpandMore } from "@mui/icons-material";

import { useTranslation } from "../../../hooks/useTranslation";
import {
  StyledListItemIcon,
  StyledListItemText,
  SubListItemButton,
  StyledListItemButton,
} from "./styles";
import { SideBarItem } from "../../../models";

interface Props {
  navItem: SideBarItem;
  isDrawerOpen: boolean;
}

const SubNavItem: FC<Props> = ({ navItem, isDrawerOpen }) => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const t = useTranslation();
  const navigate = useNavigate();
  const { pathname } = useLocation();

  useEffect(() => {
    !isDrawerOpen && setIsOpen(false);
  }, [isDrawerOpen]);

  const { Icon, Text = "", children = [] } = navItem;
  return (
    <>
      <StyledListItemButton
        data-testid="subnav-button"
        onClick={() => setIsOpen(!isOpen)}
      >
        <StyledListItemIcon>
          {isDrawerOpen ? (
            <img src={Icon} alt={Text} />
          ) : (
            <Tooltip title={t(Text)} placement="right">
              <img src={Icon} alt={Text} />
            </Tooltip>
          )}
        </StyledListItemIcon>
        <StyledListItemText open={isDrawerOpen} primary={t(Text)} />
        {isDrawerOpen && (isOpen ? <ExpandLess /> : <ExpandMore />)}
      </StyledListItemButton>
      <Collapse in={isOpen} timeout="auto" unmountOnExit>
        <List component="div" disablePadding>
          {children?.map(({ Text, Path }) => (
            <SubListItemButton
              data-testid="subnav-link"
              key={Path}
              onClick={() => navigate(Path ?? "")}
              selected={pathname === Path}
            >
              <StyledListItemText open={isDrawerOpen} primary={t(Text)} />
            </SubListItemButton>
          ))}
        </List>
      </Collapse>
    </>
  );
};

export default SubNavItem;
