import { SideBarItem } from "../../../models";

export const sidebarItems: Array<SideBarItem> = [
  {
    Icon: "/sidebarIcons/cockpit.png",
    Text: "Cockpit",
    Path: "/cockpit"
  },
  {
    Icon: "/sidebarIcons/tasks.png",
    Text: "Tasks",
    Path: "/tasks"
  },
  {
    Icon: "/sidebarIcons/simcreateorder.png",
    Text: "SIM Create Order",
    Path: "/sim-create-order"
  },
  {
    Icon: "/sidebarIcons/kittingcreateorder.png",
    Text: "Kitting Create Order",
    Path: "/kitting-create-order"
  },
  {
    Icon: "/sidebarIcons/kittingarticle.png",
    Text: "Kitting Article",
    Path: "/kitting-article"
  },
  {
    Icon: "/sidebarIcons/articleadmin.png",
    Text: "Article Administration",
    children: [
      {
        Text: "SIM Article",
        Path: "/article-administration/sim-article"
      },
      {
        Text: "Delivery Addresses",
        Path: "/article-administration/delivery-addresses"
      },
      {
        Text: "Service  Provider",
        Path: "/article-administration/short-code"
      },
      {
        Text: "Manufacturer",
        Path: "/article-administration/manufacturer"
      },
      {
        Text: "Form Factors",
        Path: "/article-administration/form-factors"
      }
    ]
  },
  {
    Icon: "/sidebarIcons/simprovmngt.png",
    Text: "SIM Provisioning Management",
    children: [
      {
        Text: "Product types",
        Path: "/sim-provisioning-management/product-types"
      },
      {
        Text: "Card types",
        Path: "/sim-provisioning-management/card-types"
      },
      {
        Text: "External Systems",
        Path: "/sim-provisioning-management/external-systems"
      }
    ]
  },
  {
    Icon: "/sidebarIcons/simprofilemngt.png",
    Text: "SIM Profile Management",
    children: [
      {
        Text: "Electrical Profiles",
        Path: "/sim-profile-management/electrical-profiles"
      },
      {
        Text: "Custom Profile",
        Path: "/sim-profile-management/custom-profile"
      },
      {
        Text: "AKA",
        Path: "/sim-profile-management/aka"
      }
    ]
  },
  {
    Icon: "/sidebarIcons/imsimngt.png",
    Text: "IMSI Management",
    children: [
      {
        Text: "IMSI Search/Lock",
        Path: "/imsi-management/imsi-search-lock"
      },
      {
        Text: "IMSI Subranges",
        Path: "/imsi-management/imsi-subranges"
      },
      {
        Text: "IMSI Main ranges",
        Path: "/imsi-management/imsi-mainranges"
      },
      {
        Text: "HLRs",
        Path: "/imsi-management/hlr"
      }
    ]
  },
  {
    Icon: "/sidebarIcons/genmngt.png",
    Text: "General Management",
    children: [
      {
        Text: "Emails",
        Path: "/general-management/email"
      },
      {
        Text: "Escalations",
        Path: "/general-management/task-escalations"
      }
    ]
  }
];
