// @ts-nocheck
import styled from "@emotion/styled";
import {
  Drawer,
  ListItemButton,
  ListItemIcon,
  ListItemText,
} from "@mui/material";

const drawerWidth = 300;

export const openedMixin = (theme) => ({
  width: drawerWidth,
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.enteringScreen,
  }),
  overflowX: "hidden",
});

export const closedMixin = (theme) => ({
  transition: theme.transitions.create("width", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  overflowX: "hidden",
  width: `calc(${theme.spacing(7)} + 1px)`,
  [theme.breakpoints.up("sm")]: {
    width: `calc(${theme.spacing(8)} + 1px)`,
  },
});

export const StyledDrawer = styled(Drawer, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  width: drawerWidth,
  flexShrink: 0,
  whiteSpace: "nowrap",
  boxSizing: "border-box",
  ...(open && {
    ...openedMixin(theme),
    "& .MuiDrawer-paper": openedMixin(theme),
  }),
  ...(!open && {
    ...closedMixin(theme),
    "& .MuiDrawer-paper": closedMixin(theme),
  }),
}));

export const StyledListItemButton = styled(ListItemButton)({
  minHeight: 48,
  "&.Mui-selected": {
    backgroundColor: "#243658",
  },
  "& .MuiListItemText-primary": {
    fontWeight: "300",
  },
  "&.Mui-selected .MuiListItemText-primary": {
    fontWeight: "700",
  },
});

export const StyledListItemText = styled(
  (props) => (
    <ListItemText
      {...props}
      primaryTypographyProps={{
        variant: "body1",
        style: {
          whiteSpace: "normal",
          padding: 0,
        },
      }}
    />
  ),
  {
    shouldForwardProp: (prop) => prop !== "open",
  }
)(({ open }) => ({
  display: open ? "flex" : "none",
  flexWrap: "wrap",
}));

export const StyledListItemIcon = styled(ListItemIcon)({
  minWidth: 32,
  marginRight: 12,
  color: "inherit",
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
});

export const SubListItemButton = styled(ListItemButton)({
  paddingLeft: 72,
  "&.Mui-selected": {
    backgroundColor: "#243658",
  },
  "& .MuiListItemText-primary": {
    fontWeight: "300",
  },
  "&.Mui-selected .MuiListItemText-primary": {
    fontWeight: "700",
  },
});
