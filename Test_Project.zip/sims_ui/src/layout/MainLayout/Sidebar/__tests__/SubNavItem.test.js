import "@testing-library/jest-dom";
import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import { renderWithAllWrappers } from "../../../../utils/testUtils";
import SubNavItem from "../SubNavItem";

const mockSubNavItem = {
  Icon: "/sidebarIcons/simprovmngt.png",
  Text: "Nav item",
  children: [
    {
      Text: "item 1",
      Path: "/path1",
    },
    {
      Text: "item 2",
      Path: "/path2",
    },
  ],
};

describe("SubNavItem", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(
      <SubNavItem navItem={mockSubNavItem} isDrawerOpen={true} />,
      { route: "/" }
    );
    expect(container).toBeInTheDocument();
  });

  test("toggle the sidebar accord button", () => {
    const { container } = renderWithAllWrappers(
      <SubNavItem navItem={mockSubNavItem} isDrawerOpen={true} />,
      { route: "/" }
    );
    const toggleButton = screen.getAllByTestId(/subnav-button/i);
    userEvent.click(toggleButton[0]);
    expect(container).toBeInTheDocument();
  });
});
