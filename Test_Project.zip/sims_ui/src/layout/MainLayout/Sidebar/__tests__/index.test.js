import "@testing-library/jest-dom";
import { screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

import { renderWithAllWrappers } from "../../../../utils/testUtils";
import Sidebar from "..";

describe("Sidebar", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(
      <Sidebar handleDrawerOpen={jest.fn()} />,
      { route: "/" }
    );
    expect(container).toBeInTheDocument();
  });

  test("should navigate to selected link", () => {
    const { container } = renderWithAllWrappers(
      <Sidebar handleDrawerOpen={jest.fn()} />,
      { route: "/" }
    );
    const toggleButton = screen.getAllByTestId(/nav-link/i);
    userEvent.click(toggleButton[0]);
    expect(container).toBeInTheDocument();
  });

  test("toggle the sidebar drawer", () => {
    const { container } = renderWithAllWrappers(
      <Sidebar handleDrawerOpen={jest.fn()} />,
      { route: "/" }
    );
    const toggleButton = screen.getByTestId(/drawer-button/i);
    userEvent.click(toggleButton);
    expect(container).toBeInTheDocument();
  });
});
