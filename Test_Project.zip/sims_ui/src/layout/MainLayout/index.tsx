import React, { FC, useCallback, useState } from "react";
import { Outlet } from "react-router-dom";
import { Alert, Box, Snackbar } from "@mui/material";
import Header from "./Header";
import Sidebar from "./Sidebar";
import Footer from "./Footer";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import { hideSnackbar } from "../../redux/actions/snackbarAction";
import { useTranslation } from "../../hooks/useTranslation";

interface Props extends PropsFromRedux {}

const MainLayout: FC<Props> = ({ snackbar, resetCounter, hideSnackbar }) => {
  const [outletLeftMargin, setOutletLeftMargin] = useState("300px");
  const t = useTranslation();
  const { severity = null, message = "" } = snackbar;

  const handleDrawerOpen = useCallback((isDrawerOpen: boolean) => {
    setOutletLeftMargin(isDrawerOpen ? "300px" : "65px");
  }, []);

  return (
    <Box>
      <Box
        sx={{
          width: "100vw",
          height: "100vh",
          overflowX: "hidden"
        }}
      >
        <Header />
        <Sidebar handleDrawerOpen={handleDrawerOpen} />
        <Box
          component="main"
          sx={{
            marginTop: "65px",
            position: "relative",
            marginLeft: outletLeftMargin
          }}
        >
          <Box sx={{ minHeight: "85vh" }}>
            <Snackbar
              anchorOrigin={{ vertical: "top", horizontal: "center" }}
              open={!!severity}
              onClose={hideSnackbar}
              autoHideDuration={5000}
            >
              <Alert
                onClose={hideSnackbar}
                severity={severity ?? "info"}
                elevation={6}
                variant="filled"
                sx={{ width: "100%" }}
              >
                {t(message)}
              </Alert>
            </Snackbar>
            <Outlet key={`app-${resetCounter}`} />
          </Box>
          <Footer />
        </Box>
      </Box>
    </Box>
  );
};

const mapStateToProps = (state: RootState) => ({
  snackbar: state.snackbar,
  resetCounter: state.app.resetCounter
});

const connector = connect(mapStateToProps, { hideSnackbar });
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(MainLayout);
