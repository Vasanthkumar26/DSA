import React, { FC } from "react";
import {
  AppBar,
  Box,
  Button,
  Stack,
  Switch,
  Theme,
  Toolbar,
  Typography
} from "@mui/material";

import { useTranslation } from "../../../hooks/useTranslation";
import { useDispatch, useSelector } from "react-redux";
import { selectLanguage } from "../../../redux/selectors/languageSelector";
import { toggleLanguage } from "../../../redux/actions/languageActions";
import { AppDispatch } from "../../../redux/store";

const navItems = ["User Name"]; // To do list

const Header: FC = () => {
  const t = useTranslation();

  const dispatch = useDispatch<AppDispatch>();
  const language = useSelector(selectLanguage);

  return (
    <AppBar
      component="nav"
      position="fixed"
      sx={{ zIndex: (theme: Theme) => theme.zIndex.drawer + 1 }}
    >
      {/* <Auth /> */}
      <Toolbar>
        <Typography
          variant="h6"
          component="div"
          sx={{ flexGrow: 1, display: { xs: "none", sm: "block" } }}
        >
          {t("header_title")}
        </Typography>
        <Stack direction="row" spacing={1} alignItems="center" marginRight={10}>
          <Typography
            sx={{
              color: language === "en" ? "gray" : "black"
            }}
          >
            Deutsch
          </Typography>
          <Switch
            sx={{
              "&.MuiSwitch-root .MuiSwitch-switchBase": {
                color: "#1976d2"
              }
            }}
            checked={language === "en"}
            onClick={() => dispatch(toggleLanguage(language))}
          />
          <Typography
            sx={{
              color: language === "de" ? "gray" : "black"
            }}
          >
            English
          </Typography>
        </Stack>
        <Box>
          {navItems.map((item) => (
            <Button key={item} sx={{ color: "#000" }}>
              {item}
            </Button>
          ))}
        </Box>
      </Toolbar>
    </AppBar>
  );
};

export default Header;
