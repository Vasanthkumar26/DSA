import React, { FC } from "react";
import { Outlet } from "react-router-dom";

const MinimalLayout: FC = () => (
  <>
    <Outlet />
  </>
);

export default MinimalLayout;
