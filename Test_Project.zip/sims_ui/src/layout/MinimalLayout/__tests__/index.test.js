import "@testing-library/jest-dom";

import MinimalLayout from "..";
import { renderWithAllWrappers } from "../../../utils/testUtils";

describe("Minimal Layout", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<MinimalLayout />, {
      route: "/login",
    });
    expect(container).toBeInTheDocument();
  });
});
