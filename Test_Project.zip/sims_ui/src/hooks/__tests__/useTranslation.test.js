import { useTranslation } from "../useTranslation";
import { useSelector } from "react-redux";

jest.mock("react-redux", () => ({
  useSelector: jest.fn(),
}));

describe("useTranslation", () => {
  afterEach(() => {
    useSelector.mockClear();
  });

  test("returns the translated string for an existing key in the en locale", () => {
    useSelector.mockReturnValueOnce("en");
    const t = useTranslation();
    expect(t("Loading")).toEqual("Loading");
  });

  test("returns the key if the translation for the given key is not found", () => {
    useSelector.mockReturnValueOnce("en");
    const t = useTranslation();
    expect(t("Nonexistent Key")).toEqual("Nonexistent Key");
  });

  test("returns the translated string for an existing key in the de locale", () => {
    useSelector.mockReturnValueOnce("de");
    const t = useTranslation();
    expect(t("Loading")).toEqual("Wird geladen");
  });

  test("returns the key if the translation for the given key is not found in the de locale", () => {
    useSelector.mockReturnValueOnce("de");
    const t = useTranslation();
    expect(t("Nonexistent Key")).toEqual("Nonexistent Key");
  });
});
