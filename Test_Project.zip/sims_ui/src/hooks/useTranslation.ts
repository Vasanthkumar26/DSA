import { useSelector } from "react-redux";
import { selectLanguage } from "../redux/selectors/languageSelector";
import en from "../locales/en.json";
import de from "../locales/de.json";

interface Translations {
  [index: string]: Record<string, string>;
}

const translations: Translations = { en, de };

export function useTranslation() {
  const language = useSelector(selectLanguage);

  const t = (key: string | undefined): string => {
    if (key) {
      return translations[language][key] || key;
    }
    return "";
  };

  return t;
}
