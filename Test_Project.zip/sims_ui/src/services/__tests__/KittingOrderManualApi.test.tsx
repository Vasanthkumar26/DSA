// @ts-nocheck
import {
  KittingOrder_SUCCESS_API_HANDLERS,
  KittingOrder_Failure_API_HANDLERS
} from "../../_mocks_/kittingOrderApiHandlers";
import { KittingOrderPayload } from "../../models";
import { createServer } from "../../utils/testUtils";
import {
  handleCreateKittingOrderManual,
  handleFetchKittingArticleNumber
} from "../kittingOrderManualApi";

describe("Kittingorder manual api test", () => {
  describe("API Success", () => {
    createServer(KittingOrder_SUCCESS_API_HANDLERS);
    test("should create the new kitting order", async () => {
      const payload: KittingOrderPayload = {
        orderNumber: 1,
        kittingArticleNumber: 22,
        noOfSimCard: 49,
        orderDate: "Wed Aug 09 2023 13:49:09 GMT+0530 (India Standard Time)",
        deliveryDate: "Wed Aug 09 2023 13:49:09 GMT+0530 (India Standard Time)"
      };
      const res = await handleCreateKittingOrderManual(payload);
      expect(res).toBe("Successfull");
    });

    test("should handle the fetch kittingArtileId api success", async () => {
      const res = await handleFetchKittingArticleNumber();
      expect(res).toHaveLength(2);
    });
  });

  describe("API failure", () => {
    createServer(KittingOrder_Failure_API_HANDLERS);
    test("should fail the new kitting order", async () => {
      const payload: KittingOrderPayload = {
        orderNumber: 1,
        kittingArticleNumber: 22,
        noOfSimCard: 49,
        orderDate: "9thjyly",
        deliveryDate: "8thjuly"
      };

      await expect(
        handleCreateKittingOrderManual(payload)
      ).rejects.toThrowError("Request failed with status code 400");
    });

    test("should fail the load kitting articles id", async () => {
      await expect(handleFetchKittingArticleNumber()).rejects.toThrowError(
        "Request failed with status code 400"
      );
    });
  });
});
