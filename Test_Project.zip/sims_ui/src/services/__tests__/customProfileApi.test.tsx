import {
  CustomProfile_FAILURE_API_HANDLERS,
  CustomProfile_SUCCESS_API_HANDLERS,
  customProfileData
} from "../../_mocks_";
import { createServer } from "../../utils/testUtils";
import { handleFetchCustomProfile } from "../customProfileApi";

describe("CustomProfileAPI", () => {
  describe("API SUCCESS", () => {
    createServer(CustomProfile_SUCCESS_API_HANDLERS);

    test("Should fetch all the customProfles", async () => {
      const res = await handleFetchCustomProfile(true);
      expect(res).toEqual(customProfileData);
    });
  });

  describe("API Failure", () => {
    createServer(CustomProfile_FAILURE_API_HANDLERS);
    test("Should handle the failure for load customProfiles", async () => {
      await expect(handleFetchCustomProfile(true)).rejects.toThrowError(
        "Request failed with status code 404"
      );
    });
  });
});
