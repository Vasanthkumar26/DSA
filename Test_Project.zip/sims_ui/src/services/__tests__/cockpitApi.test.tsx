// @ts-nocheck
import {
  COCKPIT_FAILURE_API_HANDLERS,
  COCKPIT_SUCCESS_API_HANDLERS
} from "../../_mocks_";
import { createServer } from "../../utils/testUtils";
import {
  handleFetchAllDocumentList,
  handleFetchCockpit,
  handleFetchCustomQueries,
  handleFetchDownloadDocument,
  handleFetchFileType,
  handleFetchOrderDetails,
  handleUploadDocument
} from "../cockpitApi";

describe("cockpitApi", () => {
  describe("API success", () => {
    createServer(COCKPIT_SUCCESS_API_HANDLERS);

    test("fetch should return all loadCustomQuery", async () => {
      const res = await handleFetchCustomQueries();
      expect(res).toHaveLength(2);
    });

    test("fetch should return all loadCockpitOrdersInProcess", async () => {
      const res = await handleFetchCockpit();
      expect(res).toHaveLength(1);
    });

    test("fetch should return all OrderDetails", async () => {
      const res = await handleFetchOrderDetails("7");
      expect(res).toHaveLength(1);
    });

    test("fetch all fileType", async () => {
      const res = await handleFetchFileType();
      expect(res).toHaveLength(2);
    });

    test("fetch all document list by orderId", async () => {
      const res = await handleFetchAllDocumentList(3);
      expect(res).toHaveLength(2);
    });

    test("fetch download Document", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      await handleFetchDownloadDocument("test");
    });

    test("should upload the document", async () => {
      const res = await handleUploadDocument("test");
      expect(res).toEqual("uploaded");
    });
  });

  describe("API failure", () => {
    createServer(COCKPIT_FAILURE_API_HANDLERS);

    test("fetch api call should fail when server down for loadCustomQuery", async () => {
      await expect(handleFetchCustomQueries()).rejects.toThrowError();
    });
    test("fetch api call should fail when server down for loadCockpitOrdersInProcess", async () => {
      await expect(handleFetchCockpit()).rejects.toThrowError();
    });
    test("fetch api call should fail when server down for OrderDetails", async () => {
      await expect(handleFetchOrderDetails("7")).rejects.toThrowError();
    });
    test("fetch api call should fail when server down for all filetype", async () => {
      await expect(handleFetchFileType()).rejects.toThrowError(
        "Request failed with status code 404"
      );
    });
    test("fetch api call should fail when server down for document list", async () => {
      await expect(handleFetchAllDocumentList(3)).rejects.toThrowError(
        "Request failed with status code 404"
      );
    });
    test("fetch api call should fail when server down for download document", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      await expect(handleFetchDownloadDocument(3)).rejects.toThrowError(
        "Request failed with status code 404"
      );
    });
    test("fetch api call should fail when server down for upload document", async () => {
      await expect(handleUploadDocument("test")).rejects.toThrowError(
        "Request failed with status code 404"
      );
    });
  });
});
