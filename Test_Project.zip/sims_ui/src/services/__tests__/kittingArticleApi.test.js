import { BASE_URL } from "../../utils/constants";
import {
  handleFetchKittingArticles,
  handleKittingArticleExport,
  handleDeleteKittingArticle,
} from "../kittingArticleApi";
import { createServer } from "../../utils/testUtils";
import { REACT_BASE_URL } from "../../utils/common";

describe.skip("handleFetchKittingArticles function", () => {
  test("should fetch kitting articles successfully", async () => {
    const fakeData = [{ id: 1, name: "Kitting article 1" }];

    // Mock fetch
    global.fetch = jest.fn(() =>
      Promise.resolve({
        json: () => Promise.resolve(fakeData),
      })
    );

    const result = await handleFetchKittingArticles();

    // Assertions
    expect(global.fetch).toHaveBeenCalledWith(`${BASE_URL}/kitting-article`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    });
    expect(result).toEqual(fakeData);
  });

  test("should throw an error if fetching kitting articles fails", async () => {
    // Mock fetch to throw an error
    global.fetch = jest.fn(() => Promise.reject(new Error("Fake error")));

    await expect(handleFetchKittingArticles()).rejects.toThrow("Fake error");
  });
});

describe("handle export imsi main range", () => {
  createServer([
    {
      path: `${REACT_BASE_URL}/kittingarticle/kittingArticle/download?archived=true`,
      status: 200,
      res: () =>
        new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" }),
    },
  ]);

  test("should return success message", async () => {
    window.URL.createObjectURL = jest.fn();
    window.URL.revokeObjectURL = jest.fn();
    const res = await handleKittingArticleExport(true);
    expect(res).toEqual("successful");
  });
});

describe("handle export failure imsi main range", () => {
  createServer([
    {
      path: `${REACT_BASE_URL}/kittingarticle/kittingArticle/download?archived=true`,
      status: 404,
      res: () => ({ message: "Oops! Something went wrong" }),
    },
  ]);

  test("fetch call should fail when server down", async () => {
    await expect(handleKittingArticleExport(true)).rejects.toThrowError();
  });
});
describe("Delete Kitting article API success", () => {
  createServer([
    {
      path: `${REACT_BASE_URL}/kittingarticle/deleteKittingArticle/123`,
      res: () => [],
      method: "delete",
    },
  ]);

  test("Api should return correct response", async () => {
    const res = await handleDeleteKittingArticle(123);
    expect(res).toEqual(200);
  });
});
