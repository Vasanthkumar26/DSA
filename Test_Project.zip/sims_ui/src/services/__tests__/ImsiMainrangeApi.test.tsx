//@ts-nocheck

import {
  MAINRANGE_FAILURE_API_HANDLERS,
  MAINRANGE_SUCCESS_API_HANDLERS,
  mainRangeStatusData
} from "../../_mocks_/mainrangeApiHandlers";
import { createServer } from "../../utils/testUtils";
import {
  handleFetchImsiMainRangeStatusTable,
  handleIMSIMainRangeExport
} from "../ImsiMainrangeApi";
import { handleImsiRangeExport } from "../imsiSearchLockApi";

describe("MAIN range API", () => {
  describe("MAIN range success", () => {
    createServer(MAINRANGE_SUCCESS_API_HANDLERS);

    test("should handle fetch status table successfully", async () => {
      const res = await handleFetchImsiMainRangeStatusTable({
        startIMSIForSearch: "1223",
        endIMSIForSearch: "23234"
      });
      expect(res).toEqual(mainRangeStatusData);
    });

    test("should handle the fetch export", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      const res = await handleIMSIMainRangeExport(true);
      expect(res).toBe("successful");
    });
  });

  describe("MAIN range failure", () => {
    createServer(MAINRANGE_FAILURE_API_HANDLERS);
    test("should fail the fetch status table", async () => {
      await expect(
        handleFetchImsiMainRangeStatusTable({
          startIMSIForSearch: "1223",
          endIMSIForSearch: "23234"
        })
      ).rejects.toThrowError("Request failed with status code 404");
    });

    test("should fail the fetch export", async () => {
      await expect(handleImsiRangeExport(true)).rejects.toThrowError(
        /Request failed with status code 500|Network Error/
      );
    });
  });
});
