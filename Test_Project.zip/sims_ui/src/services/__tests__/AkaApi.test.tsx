// @ts-nocheck
import {
  AKA_FAILURE_API_HANDLERS,
  AKA_SUCCESS_API_HANDLERS
} from "../../_mocks_";
import { createServer } from "../../utils/testUtils";
import {
  handleAkaExport,
  handleFetchAkas,
  handleDeleteAka,
  handleArchiveAka
} from "../AkaApi";

//TODO: Need to change the url
describe("AkaApi.test", () => {
  describe("API success", () => {
    createServer(AKA_SUCCESS_API_HANDLERS);

    test("fetch should return all external systems", async () => {
      const res = await handleFetchAkas(true);
      expect(res).toHaveLength(1);
    });

    test("should return success message", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      const res = await handleAkaExport(true);
      expect(res).toEqual("successful");
    });

    test("DELETE Api should return correct response", async () => {
      const res = await handleDeleteAka(123);
      expect(res).toEqual(true);
    });
    test("Archiving", async () => {
      const res = await handleArchiveAka(123, true);
      expect(res).toEqual(true);
    });
  });

  describe("handle export failure imsi sub range", () => {
    createServer(AKA_FAILURE_API_HANDLERS);

    test("fetch api call should fail when server down", async () => {
      await expect(handleFetchAkas(true)).rejects.toThrowError();
    });

    test("fetch call should fail when server down", async () => {
      await expect(handleAkaExport(true)).rejects.toThrowError(
        "Request failed with status code 404"
      );
    });
  });

  describe("Archiving", () => {
    createServer(AKA_FAILURE_API_HANDLERS);
    test("archive aka call should fail when server down", async () => {
      await expect(handleArchiveAka(1, true)).rejects.toThrowError(
        "Request failed with status code 404"
      );
    });
  });
});
