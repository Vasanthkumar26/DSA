// @ts-nocheck

import { createServer } from "../../utils/testUtils";
import {
  handleCardTypesDelete,
  handleCardTypesExport,
  handleCreateCardType,
  handleUpdateCardType,
  fetchManufacturers
} from "../cardTypesApi";
import { REACT_BASE_URL } from "../../utils/common";

describe.skip("CardTypesApi", () => {
  describe("API success", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/cardtype/delete/87`,
        res: () => [],
        method: "delete"
      },
      {
        path: `${REACT_BASE_URL}/cardtype/export/excel?archived=true`,
        res: () =>
          new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" })
      },
      {
        path: `${REACT_BASE_URL}/cardtype/create`,
        method: "post",
        res: () => []
      },
      {
        path: `${REACT_BASE_URL}/cardtype/update`,
        method: "put",
        res: () => []
      },
      {
        path: `${REACT_BASE_URL}/cardtype/loadAllManufacturers`,
        res: () => [
          {
            manufacturerName: "testManufacturer",
            iccIdDigit7: "1",
            id: "1"
          }
        ]
      }
    ]);

    test("should delete card type", async () => {
      const response = await handleCardTypesDelete(87);
      expect(response).toEqual(true);
    });
    test("export api should return excel data", async () => {
      URL.createObjectURL = jest.fn();
      URL.revokeObjectURL = jest.fn();
      const res = await handleCardTypesExport(true);
      expect(res).toEqual("successful");
    });

    test("Create Card Type", async () => {
      const res = await handleCreateCardType({ payload: "dummy" });
      expect(res).toBe("Card Type created successfully");
    });

    test("Update Card Type", async () => {
      const res = await handleUpdateCardType({ payload: "dummy" });
      expect(res).toBe("Card Type Updated successfully");
    });

    test("fetch Manufacturers should get success", async () => {
      const res = await fetchManufacturers(true);
      expect(res).toHaveLength(1);
    });
  });

  describe("API failure", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/cardtype/delete/87`,
        method: "delete",
        status: 406,
        res: () => ({ message: "COSINUS-MSG-ERR-GEN-REFERENCE-NOT-EXIST" })
      },
      {
        path: `${REACT_BASE_URL}/cardtype/export/excel*`,
        status: 404,
        res: () => ({
          message: "Something went wrong"
        })
      },
      {
        path: `${REACT_BASE_URL}/cardtype/create`,
        status: 406,
        res: () => ({
          message: "Selected record exist"
        })
      },
      {
        path: `${REACT_BASE_URL}/cardtype/update`,
        status: 406,
        res: () => ({
          message: "COSINUS-MSG-ERR-GEN-REFERENCE-NOT-EXIST"
        })
      },
      {
        path: `${REACT_BASE_URL}/cardtype/loadAllManufacturers`,
        status: 404,
        res: () => ({
          message: "Something went wrong"
        })
      }
    ]);
    test("should delete card type", async () => {
      await expect(handleCardTypesDelete(87)).rejects.toThrowError();
    });
    test("export api should fail", async () => {
      await expect(handleCardTypesExport(true)).rejects.toThrowError();
    });

    test("create card type api fail case", async () => {
      await expect(
        handleCreateCardType({ payload: "dummy" })
      ).rejects.toThrowError();
    });

    test("update card type api fail case", async () => {
      await expect(
        handleUpdateCardType({ payload: "dummy" })
      ).rejects.toThrowError();
    });

    test("fetch Manufacturers should fail when server down", async () => {
      await expect(fetchManufacturers(true)).rejects.toThrowError();
    });
  });
});
