// @ts-nocheck
import {
  ES_FAILURE_API_HANDLERS,
  ES_SUCCESS_API_HANDLERS
} from "../../_mocks_";
import { createServer } from "../../utils/testUtils";
import {
  handleFetchExternalSystems,
  handleExternalSystemExport,
  handleExternalSystemsCreate,
  handleExternalSystemsUpdate,
  fetchExternalSystemUsers,
  handleDeleteExternalSystem
} from "../ExternalSystemsApi";

describe("ExternalSystemsApi", () => {
  describe("API success", () => {
    createServer(ES_SUCCESS_API_HANDLERS);

    test("fetch should return all external systems", async () => {
      const res = await handleFetchExternalSystems(true);
      expect(res).toHaveLength(1);
    });

    test("create api should insert new record into external system", async () => {
      const res = await handleExternalSystemsCreate({ payload: "dummy" });
      expect(res).toBe("External system created successfully");
    });

    test("update api should update existing record in external system", async () => {
      const res = await handleExternalSystemsUpdate(
        { payload: "dummy" },
        "testId"
      );
      expect(res).toBe("External system updated successfully");
    });

    test("loadUsers should fetch all user list", async () => {
      const res = await fetchExternalSystemUsers();
      expect(res).toHaveLength(1);
    });

    test("export api should return success message", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      const res = await handleExternalSystemExport(true);
      expect(res).toEqual("successful");
    });

    test("DELETE Api should return correct response", async () => {
      const res = await handleDeleteExternalSystem(123);
      expect(res).toEqual(true);
    });
  });

  describe("API failure", () => {
    createServer(ES_FAILURE_API_HANDLERS);

    test("fetch api call should fail when server down", async () => {
      await expect(handleFetchExternalSystems(true)).rejects.toThrowError();
    });
    test("create api call should fail when server down", async () => {
      await expect(
        handleExternalSystemsCreate({ payload: "dummy" })
      ).rejects.toThrowError();
    });
    test("update api call should fail when server down", async () => {
      await expect(
        handleExternalSystemsUpdate({ payload: "dummy" }, "testId")
      ).rejects.toThrowError();
    });
    test("export api should fail when server down", async () => {
      await expect(handleExternalSystemExport(true)).rejects.toThrowError();
    });
    test("loaduser api should fail when server down", async () => {
      await expect(fetchExternalSystemUsers()).rejects.toThrowError();
    });
  });
});
