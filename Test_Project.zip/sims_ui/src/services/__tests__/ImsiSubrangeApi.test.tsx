//@ts-nocheck
import {
  SUBRANGE_API_FAILURE,
  SUBRANGE_API_SUCCESS,
  subrangeStatusData
} from "../../_mocks_/subrangeApiHandlers";
import { createServer } from "../../utils/testUtils";
import {
  handleFetchImsiSubranges,
  handleIMSISubrangeExport,
  handleDeleteImsiSubrange,
  handleFetchIMSISubrangeStatusTable
} from "../ImsiSubrangeApi";

describe("ImsiSubrangeApi", () => {
  describe("API success", () => {
    createServer(SUBRANGE_API_SUCCESS);

    test("Api should return correct response", async () => {
      const res = await handleFetchImsiSubranges(true, "", "");
      expect(res).toHaveLength(2);
    });

    test("should return success message", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      const res = await handleIMSISubrangeExport(true);
      expect(res).toEqual("successful");
    });

    test("Api should return correct response for delete", async () => {
      const res = await handleDeleteImsiSubrange(123);
      expect(res).toEqual(true);
    });

    test("Should fetch the data for status table", async () => {
      const res = await handleFetchIMSISubrangeStatusTable({
        startIMSIForSearch: "123",
        endIMSIForSearch: "312"
      });
      expect(res).toEqual(subrangeStatusData);
    });
  });

  describe("API failure", () => {
    createServer(SUBRANGE_API_FAILURE);

    test("fetch call should fail when server down", async () => {
      await expect(
        handleFetchImsiSubranges(true, "", "")
      ).rejects.toThrowError();
    });

    test("fetch call should fail when server down for export", async () => {
      await expect(handleIMSISubrangeExport(true)).rejects.toThrowError(
        "Request failed with status code 404"
      );
    });

    test("shoudl fail the status table fetch", async () => {
      await expect(
        handleFetchIMSISubrangeStatusTable({
          startIMSIForSearch: "123",
          endIMSIForSearch: "312"
        })
      ).rejects.toThrowError("Request failed with status code 404");
    });
  });
});
