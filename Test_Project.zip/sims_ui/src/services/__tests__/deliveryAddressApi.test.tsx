// @ts-nocheck
import {
  DeliveryAddress_FAILURE_API_HANDLERS,
  DeliveryAddress_SUCCESS_API_HANDLERS
} from "../../_mocks_";
import { createServer } from "../../utils/testUtils";
import {
  handleFetchDeliveryAddress,
  handleDeliveryAddressExport,
  handleUpdateDeliveryAddress,
  handleCreateDeliveryAddress
} from "../deliveryAddressApi";

describe.skip("deliverAddressApi test", () => {
  describe("API SUCCESS", () => {
    createServer(DeliveryAddress_SUCCESS_API_HANDLERS);
    test("fetch should return the delivery address successfully", async () => {
      const res = await handleFetchDeliveryAddress(true);
      expect(res).toHaveLength(1);
    });

    test("should return export success message", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      const res = await handleDeliveryAddressExport(true);
      expect(res).toEqual("successful");
    });
    test("create api should insert new record delivery", async () => {
      const res = await handleCreateDeliveryAddress({ payload: "dummy" });
      expect(res.message).toBe("Sim Vendor created successfully");
    });

    test("update api should update existing record in  delivery", async () => {
      const res = await handleUpdateDeliveryAddress({ payload: "dummy" });
      expect(res.message).toBe("Sim Vendor updated successfully");
    });
  });

  describe("API Failure", () => {
    createServer(DeliveryAddress_FAILURE_API_HANDLERS);
    test("fetch should return the failure message", async () => {
      await expect(handleFetchDeliveryAddress(true)).rejects.toThrowError(
        "Error: Network Error"
      );
    });

    test("should return error message for export", async () => {
      await expect(handleDeliveryAddressExport(true)).rejects.toThrowError(
        "Network Error"
      );
    });
    test("create api call should fail when server down", async () => {
      await expect(
        handleCreateDeliveryAddress({ payload: "dummy" })
      ).rejects.toThrowError();
    });
    test("update api call should fail when server down", async () => {
      await expect(
        handleUpdateDeliveryAddress({ payload: "dummy" })
      ).rejects.toThrowError();
    });
  });
});
