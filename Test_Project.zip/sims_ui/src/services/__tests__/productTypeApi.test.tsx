// @ts-nocheck
import { createServer } from "../../utils/testUtils";
import {
  handleFetchProductType,
  handleProductTypeCreate,
  handleProductTypeUpdate
} from "../productTypeApi";
import {
  PRODUCT_TYPE_SUCCESS_HANDLERS,
  PRODUCT_TYPE_FAILURE_HANDLERS
} from "../../_mocks_";

describe("Product Type Api", () => {
  describe("API success", () => {
    createServer(PRODUCT_TYPE_SUCCESS_HANDLERS);

    test("create new product type record", async () => {
      const res = await handleProductTypeCreate({ payload: "dummy" });
      expect(res).toBe("Product Type created successfully");
    });

    test("update product type record", async () => {
      const res = await handleProductTypeUpdate({ payload: "dummy" }, "testId");
      expect(res).toBe("Product Type updated successfully");
    });

    test("shoudl fetch the table data", async () => {
      const res = await handleFetchProductType(true);
      expect(res).toHaveLength(1);
    });
  });

  describe("API failure", () => {
    createServer(PRODUCT_TYPE_FAILURE_HANDLERS);

    test("create api call should fail when server down", async () => {
      await expect(
        handleProductTypeCreate({ payload: "dummy1" })
      ).rejects.toThrowError();
    });
    test("update api call should fail when server down", async () => {
      await expect(
        handleProductTypeUpdate({ payload: "dummy1" }, "testId")
      ).rejects.toThrowError();
    });

    test("should fail the api call for table load", async () => {
      await expect(handleFetchProductType(true)).rejects.toThrowError(
        "Request failed with status code 404"
      );
    });
  });
});
