import {
  EP_FAILURE_API_HANDLERS,
  EP_SUCCESS_API_HANDLERS
} from "../../_mocks_";
import { createServer } from "../../utils/testUtils";
import {
  handleDeleteElectricalProfile,
  handleElectricalProfileExport
} from "../electricalProfileApi";

describe("ElectricalProfileApi test", () => {
  describe("handle Export Success", () => {
    createServer(EP_SUCCESS_API_HANDLERS);

    test("should return success message", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      const res = await handleElectricalProfileExport(true);
      expect(res).toEqual("successful");
    });

    test("DELETE Api should return correct response", async () => {
      const res = await handleDeleteElectricalProfile(123);
      expect(res).toEqual(true);
    });
  });

  describe("hanle Export Failure", () => {
    createServer(EP_FAILURE_API_HANDLERS);

    test("fetch call should fail when server down", async () => {
      await expect(handleElectricalProfileExport(true)).rejects.toThrowError(
        "Request failed with status code 404"
      );
    });
  });
});
