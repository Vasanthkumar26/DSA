// @ts-nocheck
import { ISL_SUCCESS_API_HANDLERS } from "../../_mocks_";
import { createServer } from "../../utils/testUtils";
import {
  addToBlocklist,
  fetchSearchFilterData,
  fetchSearchImsiAllocation,
  handleFetchImsiRanges,
  handleImsiRangeExport,
  releaseBlocklisted
} from "../imsiSearchLockApi";

describe("imsiSearchLockApi", () => {
  describe("API success", () => {
    createServer(ISL_SUCCESS_API_HANDLERS);

    test("fetch should return all searchImsiAllocation", async () => {
      const res = await handleFetchImsiRanges();
      expect(res).toHaveLength(1);
    });

    test("should add to block list", async () => {
      const res = await addToBlocklist({ payload: "payload" });
      expect(res).toHaveLength(0);
    });

    test("should release blocked list", async () => {
      const res = await releaseBlocklisted({ payload: "payload" });
      expect(res).toHaveLength(0);
    });

    test("fetch should return all SearchFilterData", async () => {
      const res = await fetchSearchFilterData();
      expect(res).toBeTruthy();
    });

    test("fetch should return searchImsiAllocation", async () => {
      const res = await fetchSearchImsiAllocation({ payload: "payload" });
      expect(res).toHaveLength(1);
    });

    test("should export", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      const res = await handleImsiRangeExport();
      expect(res).toEqual("successful");
    });
  });
});
