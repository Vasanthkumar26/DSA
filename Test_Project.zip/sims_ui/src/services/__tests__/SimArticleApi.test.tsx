// @ts-nocheck
import {
  SimArticle_SUCCESS_API_HANDLERS,
  SimArticle_FAILURE_API_HANDLERS
} from "../../_mocks_";
import { createServer } from "../../utils/testUtils";
import { handleArchiveSimArticle } from "../simArticleApi";

describe("SimArticle.test", () => {
  describe("Sim article success", () => {
    createServer(SimArticle_SUCCESS_API_HANDLERS);

    test("Archiving", async () => {
      const res = await handleArchiveSimArticle(123, true);
      expect(res).toEqual(true);
    });
  });
});

describe("Sim article failure", () => {
  createServer(SimArticle_FAILURE_API_HANDLERS);
  test("archive sim article call should fail when server down", async () => {
    await expect(handleArchiveSimArticle(1, true)).rejects.toThrowError(
      "Network Error"
    );
  });
});
