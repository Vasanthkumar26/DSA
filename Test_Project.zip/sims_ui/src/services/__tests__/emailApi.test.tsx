// @ts-nocheck
import {
  EM_FAILURE_API_HANDLERS,
  EM_SUCCESS_API_HANDLERS
} from "../../_mocks_";
import { createServer } from "../../utils/testUtils";
import {
  handleFetchEmail,
  handleEmailExport,
  handleEmailUpdate
} from "../emailApi";

describe("emailApi", () => {
  describe("API success", () => {
    createServer(EM_SUCCESS_API_HANDLERS);

    test("fetch should return all email", async () => {
      const res = await handleFetchEmail(true);
      expect(res).toHaveLength(1);
    });
  });

  describe("API failure", () => {
    createServer(EM_FAILURE_API_HANDLERS);

    test("fetch api call should fail when server down", async () => {
      await expect(handleFetchEmail(true)).rejects.toThrowError();
    });
    test("update api call should fail when server down", async () => {
      await expect(
        handleEmailUpdate({ payload: "dummy" }, "testId")
      ).rejects.toThrowError();
    });
    test("export api should fail when server down", async () => {
      await expect(handleEmailExport(true)).rejects.toThrowError();
    });
  });
});
