// @ts-nocheck
import {
  SV_FAILURE_API_HANDLERS,
  SV_SUCCESS_API_HANDLERS
} from "../../_mocks_";
import { createServer } from "../../utils/testUtils";
import {
  handleFetchSimVendors,
  handleCreateSimVendor,
  handleUpdateSimVendor,
  handleDeleteSimVendor
} from "../SimVendorApi";

describe("SimVendorApi", () => {
  describe("API success", () => {
    createServer(SV_SUCCESS_API_HANDLERS);

    test("fetch should return all sim vendors", async () => {
      const res = await handleFetchSimVendors(true);
      expect(res).toHaveLength(1);
    });
    test("create api should insert new record into SIM vendors", async () => {
      const res = await handleCreateSimVendor({ payload: "dummy" });
      expect(res.message).toBe("Sim Vendor created successfully");
    });

    test("update api should update existing record in  SIM vendors", async () => {
      const res = await handleUpdateSimVendor({ payload: "dummy" });
      expect(res.message).toBe("Sim Vendor updated successfully");
    });
    test("DELETE Api should return correct response", async () => {
      const res = await handleDeleteSimVendor(123);
      expect(res).toEqual(true);
    });
  });

  describe("API failure", () => {
    createServer(SV_FAILURE_API_HANDLERS);

    test("fetch api call should fail when server down", async () => {
      await expect(handleFetchSimVendors(true)).rejects.toThrowError();
    });
    test("create api call should fail when server down", async () => {
      await expect(
        handleCreateSimVendor({ payload: "dummy" })
      ).rejects.toThrowError();
    });
    test("update api call should fail when server down", async () => {
      await expect(
        handleUpdateSimVendor({ payload: "dummy" })
      ).rejects.toThrowError();
    });
    test("delete api call should fail when server down", async () => {
      await expect(handleDeleteSimVendor(123)).rejects.toThrowError();
    });
  });
});
