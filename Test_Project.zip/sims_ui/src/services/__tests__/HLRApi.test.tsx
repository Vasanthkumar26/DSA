import { REACT_BASE_URL } from "../../utils/common";
import { createServer } from "../../utils/testUtils";
import {
  handleFetchHlrs,
  handleHLRExport,
  handleDeleteHLRArticle,
} from "../HLRApi";

describe("HLRApi", () => {
  describe("API success", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/hlr/loadHLR`,
        res: () => [
          {
            id: 1,
            hlrName: "HLRDaimlar",
            description: "foreign:notOperated",
            greenICCID: "Nein",
            imsiDigit: "262-11",
            iccidDigit: "5",
            archived: false,
          },
          {
            id: 2,
            hlrName: "HLRDaimlar",
            description: "foreign:notOperated",
            greenICCID: "Nein",
            imsiDigit: "262-11",
            iccidDigit: "5",
            archived: false,
          },
        ],
      },
    ]);

    test("Api should return correct response", async () => {
      const res = await handleFetchHlrs(true);
      expect(res).toHaveLength(2);
    });
  });
  describe("Delete HLR API success", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/hlr/deleteHLR/123`,
        res: () => [],
        method: "delete",
      },
    ]);

    test("Api should return correct response", async () => {
      const res = await handleDeleteHLRArticle(123);
      expect(res).toEqual(true);
    });
  });

  describe("API failure", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/hlr/loadHLR`,
        status: 404,
        res: () => ({ message: "Oops! Something went wrong" }),
      },
    ]);

    test("fetch call should fail when server down", async () => {
      await expect(handleFetchHlrs(true)).rejects.toThrowError();
    });
  });

  describe("handle export hlr range", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/hlr/hlr/download?archived=true`,
        status: 200,
        res: () =>
          new Blob(["mockExcelData"], { type: "application/vnd.ms-excel" }),
      },
    ]);

    test("should return success message", async () => {
      window.URL.createObjectURL = jest.fn();
      window.URL.revokeObjectURL = jest.fn();
      const res = await handleHLRExport(true);
      expect(res).toEqual("successful");
    });
  });

  describe("handle export failure hlr range", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/hlr/hlr/download?archived=true`,
        status: 404,
        res: () => ({ message: "Oops! Something went wrong" }),
      },
    ]);

    test("fetch call should fail when server down", async () => {
      await expect(handleHLRExport(true)).rejects.toThrowError();
    });
  });
});
