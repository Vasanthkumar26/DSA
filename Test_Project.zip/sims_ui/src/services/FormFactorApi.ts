import { HttpStatusCode } from "axios";
import { Method } from "../models";
import { CoreApi } from "../utils/core";
import { FormFactor, FormFactorPayload } from "../models/formFactor.model";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";
export const handleFetchFormFactor = async (isArchived: boolean) => {
  try {
    const path = `formfactor/loadAll?archived=${isArchived ? "true" : "false"}`;
    const res = await CoreApi(Method.GET, path, null);
    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error(`Failed to fetch: ${res?.status}`);
    }
    const FormFactor: Array<FormFactor> = (res.data ?? []).map((es: any) => ({
      ...es,
      name: es?.name ?? "",
      FormFactorId: es?.id ?? "",
      value: es?.value ?? "",
      archived: es?.archived ?? false
    }));
    return FormFactor;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleFormFactorCreate = async (data: FormFactorPayload) => {
  try {
    const path = "/formfactor/create";
    const res = await CoreApi(Method.POST, path, data);
    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error(`Failed to create: ${res?.status}`);
    }
    return "Form Factor created successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleFormFactorUpdate = async (
  data: FormFactorPayload,
  id: string
) => {
  try {
    const path = `/formfactor/update/${id}`;
    const res = await CoreApi(Method.PUT, path, data);
    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error(`Failed to create: ${res?.status}`);
    }
    return "Form Factor updated successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleDeleteFormFactor = async (Id: number): Promise<boolean> => {
  try {
    const res = await CoreApi(Method.DELETE, `/formfactor/delete/${Id}`, null);

    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    return res.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleArchiveFormFactor = async (
  formFactorId: number,
  archive: boolean
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `/formfactor/updateFormFactorArchived/${formFactorId}?archived=${!archive}`,
      null
    );

    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    return res.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleFormFactorExport = async (isArchived: boolean) => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `formfactor/export/excel?archived=${isArchived}&lang=${langauge}`,
      null,
      "blob"
    );
    if (response?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `FormFactorExport_${dateAndTime}.xlsx`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
