import { ServiceProvider, Method } from "../models";
import { CoreApi } from "../utils/core";

export const handleFetchServiceProviders = async (
  isArchived: boolean
): Promise<Array<ServiceProvider>> => {
  try {
    const path = `externaldata/loadAllServiceProvider?isArchived=${isArchived}`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};
