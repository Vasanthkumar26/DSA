import { HttpStatusCode } from "axios";
import {
  FetchImsiSubrangeResponse,
  FetchMainRangeProductTypeResponse,
  ImsiSubrange,
  Method
} from "../models";

import {
  ImsiSubAndMainRangeStatusRequestPayload,
  ImsiSubAndMainRangeStatusTable
} from "../models/global.model";
import { CoreApi } from "../utils/core";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";

export const handleFetchImsiSubranges = async (
  isArchived: boolean,
  predefinedImsiMainRange: string,
  showArchived: string
): Promise<Array<ImsiSubrange>> => {
  try {
    const path =
      predefinedImsiMainRange === "0" || predefinedImsiMainRange === ""
        ? `/imsisubrange/loadIMSISubRange?isActive=${
            isArchived ? "true" : "false"
          }`
        : `imsisubrange/loadImsiSubRangeFromImsiMainRange?predefinedImsiMainRange=${predefinedImsiMainRange}&showArchived=${showArchived}`;

    const res = await CoreApi(Method.GET, path, null);
    const imsiSubranges: Array<ImsiSubrange> = (res?.data ?? []).map(
      (obj: any) => {
        const imsiSubrange: ImsiSubrange = {
          id: obj?.imsiSubRangeId ?? 0,
          name: obj?.imsiSubRangeName ?? "",
          imsiDigits12345678: obj?.imsiDigits8 ?? "",
          startImsi: obj?.imsiStartRange ?? "",
          endImsi: obj?.imsiEndRange ?? "",
          ismiMainrange:
            obj?.imsiMainRangeProductTypeResponse?.allImsiMainRanges?.[0]
              ?.mainRangeCombinedName ?? "",
          imsiMainRangeId:
            obj?.imsiMainRangeProductTypeResponse?.allImsiMainRanges?.[0]
              ?.imsiMainRangeId ?? "",
          imsisubRangeId: obj?.imsiSubRangeId ?? 0,
          productType:
            obj?.imsiMainRangeProductTypeResponse?.allProductTypes?.[0]?.name ??
            "",
          productTypeId:
            obj?.imsiMainRangeProductTypeResponse?.allProductTypes?.[0]
              ?.productTypeId ?? "",
          archived: obj?.archived,
          lastUpdateDate: obj?.lastUpdateDate
        };
        return imsiSubrange;
      }
    );
    return imsiSubranges;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleFetchMainRangesProductType =
  async (): Promise<FetchMainRangeProductTypeResponse> => {
    try {
      const path = `imsisubrange/loadMainRangesProductTypes`;
      const res = await CoreApi(Method.GET, path, null);
      return res?.data;
    } catch (err: any) {
      throw new Error(err?.message);
    }
  };

export const handleCreateImsiSubrange = async (
  data: ImsiSubrange
): Promise<FetchImsiSubrangeResponse> => {
  try {
    const res = await CoreApi(
      Method.POST,
      `/imsisubrange/createImsiSubRange`,
      data
    );
    return { data: res?.data, message: "IMSI subrange created successfully" };
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleUpdateImsiSubrange = async (
  data: ImsiSubrange,
  id: string
): Promise<FetchImsiSubrangeResponse> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `/imsisubrange/updateImsiSubRange/${id}`,
      data
    );
    return { data: res?.data, message: "IMSI subrange updated successfully" };
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleDeleteImsiSubrange = async (
  imsiId: number
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.DELETE,
      `/imsisubrange/deleteImsiSubRange/${imsiId}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleArchiveImsiSubrange = async (
  imsiId: number,
  archive: boolean
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `/imsisubrange/updateImsiSubArchived/${imsiId}?archived=${!archive}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleIMSISubrangeExport = async (
  isArchived: boolean
): Promise<string> => {
  try {
    const language = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `/imsisubrange/download?archived=${isArchived}&localisation=${language}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `ImsiSubrangeExport_${dateAndTime}.xlsx`);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchIMSISubrangeStatusTable = async (
  data: ImsiSubAndMainRangeStatusRequestPayload
): Promise<Array<ImsiSubAndMainRangeStatusTable>> => {
  try {
    const response = await CoreApi(
      Method.POST,
      `imsisearch/searchIMSISubRangeStatus`,
      data
    );
    return response?.data;
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
