import { HttpStatusCode } from "axios";
import {
  Method,
  productTypePayload,
  ProductTypeData,
  assignedImsiSubRangeProto
} from "../models";
import { CoreApi } from "../utils/core";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";

export const handleFetchProductType = async (
  isArchived: boolean
): Promise<Array<ProductTypeData>> => {
  try {
    const res = await CoreApi(
      Method.GET,
      `/productType/loadAll?archived=${isArchived}`,
      null
    );
    const data = res?.data.map((item: any) => {
      return {
        ...item,
        serviceProviderShortCodeId:
          item?.serviceProviderShortCode?.serviceProvider?.id ?? "",
        serviceproviderShortcode:
          item?.serviceProviderShortCode?.serviceProvider?.spidname ?? ""
      };
    });
    return data;
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleProductTypesExport = async (isArchived: boolean) => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `/productType/export/excel?archived=${isArchived}&localisation=${langauge}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });

    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `ProductTypeExport_${dateAndTime}.xlsx`);

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
export const handleDeleteProductType = async (id: number): Promise<boolean> => {
  try {
    const res = await CoreApi(Method.DELETE, `/productType/delete/${id}`, null);
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleProductTypeCreate = async (data: productTypePayload) => {
  try {
    await CoreApi(Method.POST, `/productType/create`, data);
    return "Product Type created successfully";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleProductTypeUpdate = async (data: productTypePayload) => {
  try {
    await CoreApi(Method.PUT, `/productType/update`, data);
    return "Product Type updated successfully";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleArchiveProductType = async (
  itemId: number,
  archive: boolean
): Promise<boolean> => {
  console.log("called API");
  try {
    const res = await CoreApi(
      Method.PUT,
      `/productType/archived/${itemId}?archived=${archive}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const loadAssignedImsiSubRanges = async (
  id: number
): Promise<Array<assignedImsiSubRangeProto>> => {
  try {
    const res = await CoreApi(
      Method.GET,
      `/productType/loadAllProductIMSI?productId=${id}`,
      null
    );
    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    const data = res?.data.map((subRange: any) => {
      return {
        startImsi: subRange?.startImsi,
        endImsi: subRange?.endImsi,
        description: subRange?.description,
        freeImsi: subRange?.freeImsi
      };
    });
    return data;
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const loadAllImsiSubRanges = async (
  greenIcccid: boolean,
  providerId: number
): Promise<Array<assignedImsiSubRangeProto>> => {
  try {
    const res = await CoreApi(
      Method.GET,
      `/productType/loadAllFreeIMSI?greenICCID=${greenIcccid}&serviceProviderId=${providerId}`,
      null
    );
    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    const data = res?.data.map((subRange: any) => {
      return {
        startImsi: subRange?.startImsi,
        endImsi: subRange?.endImsi,
        description: subRange?.description,
        freeImsi: subRange?.freeImsi
      };
    });
    return data;
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
