import { HttpStatusCode } from "axios";
import { Aka, akaCreatePayload, Method } from "../models";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";
import { CoreApi } from "../utils/core";

export const handleFetchAkas = async (isArchived: boolean) => {
  try {
    const path = `/akaHlr/loadAll?archived=${isArchived ? "true" : "false"}`;
    const res = await CoreApi(Method.GET, path, null);
    const akas: Array<Aka> = (res?.data ?? []).map((ak: any) => {
      const aka: Aka = {
        ...ak,
        akaHlrName: ak?.displayValue ?? "",
        inputFileValue: ak?.inputFileValue ?? "",
        fileExtension: ak?.fileEnding ?? "",
        archived: ak?.archived ?? false,
        isReferenceExist: ak?.isReferenceExist ?? false,
        assocAkaAlgId: ak?.assocAkaAlgId ?? [],
        assocAkaTpKeyId: ak?.assocAkaTpKeyId ?? [],
        userUpdated: ak?.userUpdated ?? 0
      };
      return aka;
    });
    return akas;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleAkaExport = async (isArchived: boolean): Promise<string> => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `akaHlr/export/excel?archived=${isArchived}&lang=${langauge}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `AKAExport_${dateAndTime}.xlsx`);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
export const handleDeleteAka = async (Id: number): Promise<boolean> => {
  try {
    const res = await CoreApi(Method.DELETE, `/akaHlr/delete/${Id}`, null);
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleCreateAka = async (data: akaCreatePayload) => {
  try {
    const path = "/akaHlr/create";
    await CoreApi(Method.POST, path, data);
    return "External system created successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleUpdateAka = async (data: akaCreatePayload) => {
  try {
    const path = "/akaHlr/update";
    await CoreApi(Method.PUT, path, data);
    return "External system updated successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleArchiveAka = async (
  akaId: number,
  archive: boolean
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `akaHlr/archive/${akaId}?archived=${!archive}`,
      null
    );

    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err.message);
  }
};
