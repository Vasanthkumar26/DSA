import { ISelectionOption, Method } from "../models";
import { CoreApi } from "../utils/core";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";
import {
  ICPOrEP,
  IProductTypes,
  ISelectArchive,
  ISimVendors,
  IStarterPack,
  SimArticleDropdownValue,
  SimArticles
} from "../models/simArticle.model";
import { HttpStatusCode } from "axios";

export const handleSimArticleExport = async (
  isArchived: boolean
): Promise<string> => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `simarticle/simArticle/download?archived=${isArchived}&localisation=${langauge}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `SimArticle_${dateAndTime}.xlsx`);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchSimArticles = async (
  isArchived: boolean
): Promise<Array<SimArticles>> => {
  try {
    const path = `simarticle/loadAll?isArchived=${
      isArchived ? "true" : "false"
    }`;
    const res = await CoreApi(Method.GET, path, null);

    const simArticles: Array<SimArticles> = (res?.data ?? []).map(
      (sim: any) => {
        const simArticle: SimArticles = {
          ...sim,
          serviceProviderId: sim?.serviceProviderId ?? "",
          articleStatusName: sim?.articleStatusId?.name,
          aritcleStatusId: sim?.articleStatusId?.id,
          deliveryAddressId: sim?.deliveryAddressId ?? "",
          productTypeId: sim?.productTypeId ?? "",
          cardTypeId: sim?.cardTypeId ?? "",
          simVendorId: sim?.simVendorId ?? "",
          electricalProfileId: sim?.electricalProfileId ?? "",
          customProfileId: sim?.customProfileId ?? "",
          formFactorId: sim?.formFactorId ?? "",
          description: sim?.description ?? "",
          starterPackId: sim?.starterPackId?.id
        };
        return simArticle;
      }
    );
    return simArticles;
  } catch (error: any) {
    throw new Error(error);
  }
};

export const handleFetchLoadSimArticleDropdown = async () => {
  try {
    const dropdownValue: SimArticleDropdownValue = {
      allCardType: [] as ISelectArchive[],
      allSimVendor: [] as ISimVendors[],
      allServiceProviderDetails: [] as ISelectArchive[],
      allElectricalProfile: [] as ICPOrEP[],
      allCustomProfile: [] as ICPOrEP[],
      allFormFactor: [] as ISelectArchive[],
      allProductType: [] as IProductTypes[],
      allDeliveryAddress: [] as ISelectArchive[],
      allSmdpHost: [] as ISelectionOption[],
      allStarterPack: [] as IStarterPack[],
      allDeliveryAddressOutputFile: [] as ISelectArchive[],
      allSimArticleStatus: [] as ISelectionOption[]
    };

    const path = "simarticle/loadAllCombined";
    const res = await CoreApi(Method.GET, path, null);
    const cartTypes = res?.data?.allCardType?.map((item: any) => {
      return {
        label: item?.cardTypeName ?? "",
        id: item?.cardTypeId ?? -1,
        archive: item?.archive
      };
    });
    const simVendor = res?.data?.assocCardVendor?.map((item: any) => {
      return {
        label: item?.simVendorId?.manufacturerName,
        id: item?.simVendorId?.id,
        cartTypeId: item?.cardtypeId?.id,
        archive: item?.simVendorId?.archived
      };
    });
    const serviceProviders = res?.data?.allServiceProviderDetails?.map(
      (item: any) => {
        return {
          label: item?.spidName,
          id: item?.serviceProviderId,
          archive: item?.archive
        };
      }
    );
    const electricalProfiles = res?.data?.allElectricalProfile?.map(
      (item: any) => {
        return {
          label: item?.electricalProfileName,
          id: item?.electricalProfileId,
          simVendorId: item?.simVendorId?.id,
          archive: item?.archive
        };
      }
    );
    const formFactors = res?.data?.allFormFactor?.map((item: any) => {
      return {
        label: item?.formFactorName,
        id: item?.formFactorId,
        archive: item?.archive
      };
    });

    const deliveryAddresses = res?.data?.allDeliveryAddress?.map(
      (item: any) => {
        return {
          label: item?.deliveryAddressName,
          id: item?.deliveryAddressId,
          archive: item?.deliveryAddressArchived
        };
      }
    );

    const productTypes = res?.data?.allProductType?.map((item: any) => {
      return {
        label: item?.productTypeName,
        id: item?.productTypeId,
        serviceProviderShortCodeId: item?.serviceProviderShortCodeId?.id,
        imsiSubRangeReferenceExists: item?.imsiSubRangeReferenceExists,
        archive: item?.archive
      };
    });

    const smdpHosts =
      res?.data?.allSmdpHost?.map((item: any) => {
        return {
          label: `eSIM - ${item?.smdpHostName}`,
          id: item?.smdpHostId
        };
      }) || [];
    smdpHosts?.unshift({ label: "Physical SIM - no SMDP host", id: 0 });

    const starterPacks = res?.data?.allStarterPack?.map((item: any) => {
      return {
        label: item?.starterPackName,
        id: item?.starterPackid,
        spId: item?.serviceProviderId?.id,
        archive: item?.archive
      };
    });

    const customProfiles = res?.data?.allCustomProfile?.map((item: any) => {
      return {
        label: item?.customProfileName,
        id: item?.customProfileId,
        simVendorId: item?.simVendorId?.id,
        archive: item?.archive
      };
    });

    const deliveryAddressOutputFile = (
      res?.data?.alladditionalInputFile || []
    ).map((item: any) => ({
      label: item?.deliveryAddressName,
      id: item?.deliveryAddressId,
      archive: item?.archived
    }));

    const simArticleStatus = res?.data?.simCardArticleStatus?.map(
      (item: any) => ({
        label: item?.simCardArticleStatusName,
        id: item?.simCardArticleStatusId
      })
    );

    dropdownValue.allCardType.push(...cartTypes);
    dropdownValue.allSimVendor.push(...simVendor);
    dropdownValue.allServiceProviderDetails.push(...serviceProviders);
    dropdownValue.allElectricalProfile.push(...electricalProfiles);
    dropdownValue.allFormFactor.push(...formFactors);
    dropdownValue.allDeliveryAddress.push(...deliveryAddresses);
    dropdownValue.allProductType.push(...productTypes);
    dropdownValue.allSmdpHost.push(...smdpHosts);
    dropdownValue.allStarterPack.push(...starterPacks);
    dropdownValue.allCustomProfile.push(...customProfiles);
    dropdownValue.allDeliveryAddressOutputFile.push(
      ...deliveryAddressOutputFile
    );
    dropdownValue.allSimArticleStatus.push(...simArticleStatus);
    return dropdownValue;
  } catch (error: any) {
    throw new Error(error?.message);
  }
};

export const handleDeleteSimArticle = async (Id: number): Promise<boolean> => {
  try {
    const res = await CoreApi(Method.DELETE, `/simarticle/delete/${Id}`, null);
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleInputFile = async (id: number) => {
  try {
    const path = `simarticle/generateInputFile?simArticleId=${id}`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data;
  } catch (error: any) {
    throw new Error(error?.message);
  }
};

export const handleArchiveSimArticle = async (
  id: number,
  archive: boolean
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `/simarticle/updateSimArticleArchived/${id}?archived=${archive}`,
      null
    );
    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    return res.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleCreateSimArticle = async (data: any) => {
  try {
    const path = "/simarticle/create";
    await CoreApi(Method.POST, path, data);
    return "Sim article created successfully";
  } catch (error: any) {
    throw new Error(error?.message);
  }
};

export const handleUpdateSimArticle = async (id: number, data: any) => {
  try {
    const path = `simarticle/updateSimArticle/${id}`;
    await CoreApi(Method.POST, path, data);
    return "Sim article updated successfully";
  } catch (error: any) {
    throw new Error(error?.message);
  }
};
