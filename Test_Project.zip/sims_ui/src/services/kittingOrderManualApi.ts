import { HttpStatusCode } from "axios";
import { KittingOrderPayload, Method } from "../models";
import { CoreApi } from "../utils/core";

export const handleCreateKittingOrderManual = async (
  data: KittingOrderPayload
): Promise<string> => {
  try {
    const path = `kittingOrder/createKittingOrderManual`;

    const formatedPayload = {
      orderItem: {
        orderItemId: data?.orderNumber,
        amount: data?.noOfSimCard
      },
      expectedDeliveryDate: new Date(data?.deliveryDate),
      creationDate: data?.orderDate,
      externalReference: [
        {
          kittingArticleid: data?.kittingArticleNumber,
          owner: "SAP"
        }
      ],
      lastUpdatedBy: 1
    };
    await CoreApi(Method.POST, path, formatedPayload);

    return "Successfull";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchKittingArticleNumber = async () => {
  try {
    const path = `kittingOrder/loadKittingArticle`;
    const response = await CoreApi(Method.GET, path, null);
    if (response?.status !== HttpStatusCode.Ok) {
      throw new Error(response?.data?.message);
    }
    return response.data?.map((item: any) => {
      return {
        label: item?.name ?? "",
        id: item?.id ?? -1
      };
    });
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
