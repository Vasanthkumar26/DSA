import { HttpStatusCode } from "axios";
import { Method } from "../models";
import { CoreApi } from "../utils/core";
import { DeliveryAddress } from "../models/deliveryAddress.model";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage,
  returnSelectOption
} from "../utils/common";

export const handleFetchDeliveryAddress = async (
  isArchived: boolean
): Promise<Array<DeliveryAddress>> => {
  try {
    const path = `deliveryAddress/loadAll?archived=${
      isArchived ? "true" : "false"
    }`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data;
  } catch (error: any) {
    throw new Error(error);
  }
};
export const handleDeleteDeliveryAddress = async (
  Id: number
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.DELETE,
      `/deliveryAddress/delete/?id=${Id}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleArchiveDeliveryAddress = async (
  Id: number,
  archive: boolean
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `/deliveryAddress/archive/${Id}?archived=${archive}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleCreateDeliveryAddress = async (data: DeliveryAddress) => {
  try {
    const res = await CoreApi(Method.POST, `/deliveryAddress/create`, data);
    return { data: res?.data, message: "DeliveryAddress created successfully" };
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
export const handleUpdateDeliveryAddress = async (data: DeliveryAddress) => {
  try {
    const res = await CoreApi(Method.PUT, `/deliveryAddress/update`, data);
    return { data: res?.data, message: "DeliveryAddress updated successfully" };
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleDeliveryAddressExport = async (
  isArchived: boolean
): Promise<string> => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `deliveryAddress/export/excel?archived=${isArchived}&lang=${langauge}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `DeliveryAddressExport_${dateAndTime}.xlsx`);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
export const loadPartnerAddress = async () => {
  try {
    const path = `deliveryAddress/loadAllCompany`;
    const res = await CoreApi(Method.GET, path, null);
    return returnSelectOption(res?.data);
  } catch (err: any) {
    throw new Error(err);
  }
};
