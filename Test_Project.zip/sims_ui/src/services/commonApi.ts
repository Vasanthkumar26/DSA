import { Method, ISelectionOption } from "../models";
import { CoreApi } from "../utils/core";

export const handleFetchServiceProviders = async () => {
  try {
    const path = `externaldata/loadAllServiceProvider`;
    const res = await CoreApi(Method.GET, path, null);
    const data: ISelectionOption[] = res?.data?.map(
      (item: any) =>
        ({
          label: `${item?.spid}(${item?.description})`,
          id: item?.id
        } as ISelectionOption)
    );

    return data;
  } catch (err: any) {
    throw new Error(err);
  }
};
