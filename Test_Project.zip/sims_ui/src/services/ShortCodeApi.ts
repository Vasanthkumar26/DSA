import { HttpStatusCode } from "axios";
import { SCUser, ShortCode, ShortCodePayload, Method } from "../models";
import { CoreApi } from "../utils/core";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";

export const handleFetchShortCode = async (isArchived: boolean) => {
  try {
    const path = `/shortcode/loadServiceProviderShortCode?isArchived= ${
      isArchived ? "true" : "false"
    }`;
    const res = await CoreApi(Method.GET, path, null);
    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error(`Failed to fetch: ${res?.status}`);
    }
    const shortCodes: Array<ShortCode> = (res.data ?? []).map((es: any) => {
      const shortCode: ShortCode = {
        ...es,
        spid: es?.spid ?? "",
        shortCode: es?.shortCode ?? "",
        archived: es?.archived ?? false,
        lastUpdateDate: es?.lastUpdateDate ?? ""
      };
      return shortCode;
    });
    return shortCodes;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const fetchShortCodeSPID = async () => {
  try {
    const path = `/shortcode/loadSpids`;
    const res = await CoreApi(Method.GET, path, null);
    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error(`Failed to fetch: ${res?.status}`);
    }
    const scUsers: Array<SCUser> = (res.data ?? []).map((es: any) => ({
      ...es,
      id: es?.id ?? "",
      spid: es?.spid ?? ""
    }));
    return scUsers;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleShortCodeCreate = async (data: ShortCodePayload) => {
  try {
    const path = "/shortcode/createServiceProviderShortCode";
    const serviceProviderId = data.spid;
    const shortCode = data.shortCode;
    const dta = { serviceProviderId, shortCode, userName: 12 };
    const res = await CoreApi(Method.POST, path, dta);
    if (res?.status !== HttpStatusCode.Created) {
      throw new Error(`Failed to create: ${res?.status}`);
    }
    return "Short code created successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleShortCodeUpdate = async (
  data: ShortCodePayload,
  id: string
) => {
  try {
    const serviceProviderId = data.spid;
    const path = `/shortcode/updateServiceProviderShortCode/${serviceProviderId}`;
    const shortCode = data.shortCode;
    const archived = data.archived;
    const dta = { serviceProviderId, shortCode, archived, userName: 111 };
    const res = await CoreApi(Method.PATCH, path, dta);
    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error(`Failed to create: ${res?.status}`);
    }
    return "Short code updated successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleDeleteShortCode = async (Id: string): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.DELETE,
      `/shortcode/deleteServiceProvideShortCode/${Id}`,
      null
    );

    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    return res.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleArchiveShortCode = async (
  spid: string,
  archive: boolean
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `/shortcode/archive/${spid}?archived=${archive}`,
      null
    );

    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    return res.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleShortCodeExport = async (isArchived: boolean) => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `shortcode/serviceProviderShortCode/download?archived=${isArchived}&localisation=${langauge}`,
      null,
      "blob"
    );
    if (response?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute(
      "download",
      `ServiceProviderShortCodeExport_${dateAndTime}.xlsx`
    );

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const loadShortCodeSPID = async () => {
  try {
    const path = `shortcode/loadSpids`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data.map((item: any) => {
      return {
        label: item.spid,
        id: item.id
      };
    });
  } catch (err: any) {
    throw new Error(err);
  }
};
