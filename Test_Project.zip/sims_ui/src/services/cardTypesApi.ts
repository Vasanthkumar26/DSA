import { HttpStatusCode } from "axios";
import {
  CardTypeData,
  Method,
  CardTypesPayload,
  updateCardTypePayload
} from "../models";
import { CoreApi } from "../utils/core";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";

export const handleFetchCardTypes = async (isArchived: boolean = true) => {
  try {
    const path = `cardtype/loadAllCardTypesByArchived?archived=${isArchived}`;
    const res = await CoreApi(Method.GET, path, null);
    const cardType: Array<CardTypeData> = (res?.data ?? []).map((ct: any) => ({
      ...ct,
      id: ct?.id ?? -1,
      iccId: ct?.iccId ?? -1,
      name: ct?.name ?? "",
      provisioningIdentifier: ct?.provisioningIdentifier ?? "",
      oneSim: ct?.oneSim ?? false,
      prepaid: ct?.prepaid ?? false,
      lte: ct?.lte ?? false,
      version: ct?.version ?? "",
      generation: ct?.generation ?? "",
      manufacturers: ct?.manufacturers ?? [],
      archived: ct?.archived ?? false,
      akaHlr: ct?.akaHlr?.displayValue ?? "",
      simArticleList: ct?.simArticleList ?? [],
      lastUpdatedBy: ct?.lastUpdatedBy ?? -1,
      lastUpdatedDate: ct?.lastUpdatedDate ?? "",
      technicalType: ct?.technicalType ?? "",
      isReferenceExist: ct?.isReferenceExist ?? false,
      dtoId: ct?.dtoId ?? -1
    }));
    return cardType;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const loadAllAkaHLR = async () => {
  try {
    const path = `cardtype/loadAllAkaHLR`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};
export const handleCardTypesExport = async (isArchived: boolean) => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `/cardtype/export/excel?archived=${isArchived}&localisation=${langauge}`,
      null,
      "blob"
    );
    if (response?.status !== HttpStatusCode.Ok) {
      throw new Error();
    }

    const blob = new Blob([response.data], {
      type: "application/vnd.ms-excel"
    });

    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `CardTypeExport_${dateAndTime}.xlsx`);

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleCardTypesDelete = async (id?: number): Promise<boolean> => {
  try {
    const res = await CoreApi(Method.DELETE, `/cardtype/delete/${id}`, null);
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleCreateCardType = async (data: CardTypesPayload) => {
  try {
    await CoreApi(Method.POST, `/cardtype/create`, data);
    return "Card Type created successfully";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleUpdateCardType = async (data: updateCardTypePayload) => {
  try {
    await CoreApi(Method.PUT, `/cardtype/update`, data);
    return "Card Type Updated successfully";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const fetchManufacturers = async () => {
  try {
    const path = `cardtype/loadAllManufacturers`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleArchiveCardType = async (
  id: number | undefined,
  ArchiveFlag: boolean | undefined
) => {
  try {
    await CoreApi(
      Method.PATCH,
      `cardtype/archived/${id}?archived=${ArchiveFlag}`,
      null
    );
    return "Card Type Archived successfully";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
