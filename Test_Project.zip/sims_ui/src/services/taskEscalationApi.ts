import { CoreApi } from "../utils/core";
import {
  TaskEscalationDropdownValue,
  TaskEscalations
} from "../models/taskEscalation.model";
import { ISelectionOption, Method } from "../models";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";
import { HttpStatusCode } from "axios";

export const handleFetchTaskEscalations = async (
  isArchived: boolean
): Promise<Array<TaskEscalations>> => {
  try {
    const path = `taskescalation/loadTaskEscalation?isArchived=${
      isArchived ? true : false
    }`;
    const res = await CoreApi(Method.GET, path, null);
    const taskEscalations: Array<TaskEscalations> = (res?.data ?? []).map(
      (t: any) => {
        const taskEscalation: TaskEscalations = {
          ...t,
          task: t?.workFlowEventId ?? "",
          time: t?.waitingTime ?? "",
          emailAddress: t?.emailId ?? "",
          subject: t?.subject ?? ""
        };
        return taskEscalation;
      }
    );
    return taskEscalations;
  } catch (error: any) {
    throw new Error(error);
  }
};

export const handleCreateTaskEscalation = async (data: any) => {
  try {
    const path = "/taskescalation/create";
    await CoreApi(Method.POST, path, data);
    return "Task escalation created successfully";
  } catch (error: any) {
    throw new Error(error?.message);
  }
};

export const handleTaskEscalationDropdown = async () => {
  try {
    const dropdownValue: TaskEscalationDropdownValue = {
      allTaskValues: [] as ISelectionOption[]
    };
    const path = "taskescalation/loadTaskEscalation";
    const res = await CoreApi(Method.GET, path, null);
    const task = res?.data?.map((item: any) => {
      return {
        label: item?.workFlowEventId ?? "",
        id: item?.id ?? -1,
        archive: item?.archive ?? false
      };
    });
    dropdownValue.allTaskValues.push(...task);
    return dropdownValue;
  } catch (error: any) {
    throw new Error(error?.message);
  }
};

export const handleTaskEscalationExport = async (
  isArchived: boolean
): Promise<string> => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `/taskescalation/excel/export?lang=${langauge}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `TaskEscalation_${dateAndTime}.xlsx`);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleUpdateTaskEscalation = async (id: number, data: any) => {
  try {
    await CoreApi(Method.POST, `/taskescalation/update/${id}`, data);
    return "Task Escalation updated successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleDeleteTaskEscalation = async (
  Id: number
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.DELETE,
      `/taskescalation/delete/?id=${Id}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};
