import { HttpStatusCode } from "axios";
import { Method } from "../models";
import { CoreApi } from "../utils/core";
import { SimVendor, FetchSimVendorResponse } from "../models/simVendor.model";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";

export const handleFetchSimVendors = async (isArchived: boolean) => {
  try {
    const path = `simvendor/loadAll?archived=${isArchived ? "true" : "false"}`;
    const res = await CoreApi(Method.GET, path, null);
    const simVendors: Array<SimVendor> = (res?.data ?? []).map((sv: any) => ({
      ...sv,
      name: sv?.manufacturerName ?? "",
      externerName: sv?.externalName ?? "",
      iccidDigit7: sv?.iccIdDigit7 ?? "",
      inputFile: "SFTP",
      emailAddress: sv?.emailIdDelivery ?? "",
      archived: sv?.archived ?? false
    }));
    return simVendors;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleDeleteSimVendor = async (id: number): Promise<boolean> => {
  try {
    const res = await CoreApi(Method.DELETE, `/simvendor/delete/${id}`, null);
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleArchiveSimVendor = async (
  id: number,
  archive: boolean
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `/simvendor/archived/${id}?archived=${archive}`,
      null
    );
    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    return res.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleSimVendorExport = async (
  isArchived: boolean
): Promise<string> => {
  try {
    const language = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `simvendor/export/excel?archived=${isArchived}&lang=${language}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `SIMVendorExport_${dateAndTime}.xlsx`);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
export const handleCreateSimVendor = async (
  data: SimVendor
): Promise<FetchSimVendorResponse> => {
  try {
    const res = await CoreApi(Method.POST, `/simvendor/create`, data);
    return { data: res?.data, message: "Sim Vendor created successfully" };
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
export const handleUpdateSimVendor = async (
  data: SimVendor
): Promise<FetchSimVendorResponse> => {
  try {
    const res = await CoreApi(Method.PUT, `/simvendor/update`, data);
    return { data: res?.data, message: "Sim Vendor updated successfully" };
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
export const loadExternalName = async () => {
  try {
    const path = `simvendor/loadExternalName`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};
