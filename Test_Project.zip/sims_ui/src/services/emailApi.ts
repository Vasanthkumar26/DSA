import { HttpStatusCode } from "axios";
import { Method } from "../models";
import { CoreApi } from "../utils/core";
import { Email, EmailPayload } from "../models/email.model";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";

export const handleFetchEmail = async (isArchived: boolean) => {
  try {
    const path = `email/loadAll?archived=${isArchived ? "true" : "false"}`;
    const res = await CoreApi(Method.GET, path, null);
    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error(`Failed to fetch: ${res?.status}`);
    }
    const Email: Array<Email> = (res.data ?? []).map((em: any) => ({
      ...em,
      action: em?.action ?? "",
      EmailId: em?.id ?? "",
      email_address: em?.email_address ?? "",
      reply_address: em?.reply_address ?? "",
      subject: em?.subject ?? "",
      text: em?.text ?? "",
      archived: em?.archived ?? false
    }));
    return Email;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleEmailUpdate = async (data: EmailPayload, id: string) => {
  try {
    const path = `/email/update/${id}`;
    const res = await CoreApi(Method.PATCH, path, data);
    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error(`Failed to create: ${res?.status}`);
    }
    return "Email updated successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleEmailExport = async (isArchived: boolean) => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `email/emailAdministration/download?archived=${isArchived}&lang=${langauge}`,
      null,
      "blob"
    );
    if (response?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `EmailExport_${dateAndTime}.xlsx`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
