import { ImsiRange, Method } from "../models";
import { CoreApi } from "../utils/core";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";

export const handleFetchImsiRanges = async (): Promise<Array<ImsiRange>> => {
  try {
    const path = `/imsisearch/searchImsiAllocation`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const addToBlocklist = async (payload: any) => {
  try {
    const url = `/imsisearch/addToBlockList`;
    const res = await CoreApi(Method.POST, url, payload);
    return res?.data ?? "";
  } catch (error: any) {
    throw new Error(error?.reason ?? "Failed to add to blacklist");
  }
};

export const releaseBlocklisted = async (payload: any) => {
  try {
    const url = `/imsisearch/releaseBlockListed`;
    const res = await CoreApi(Method.POST, url, payload);
    return res?.data ?? "";
  } catch (error: any) {
    throw new Error(error?.reason ?? "Failed to release blacklist");
  }
};

export const fetchSearchFilterData = async () => {
  try {
    const url = `/imsisearch/seachFiltersData`;
    const res = await CoreApi(Method.GET, url, null);
    return res?.data;
  } catch (error: any) {
    throw new Error(error?.reason ?? "Failed to fetch filter data");
  }
};

export const fetchSearchImsiAllocation = async (payload: any) => {
  try {
    const url = `/imsisearch/searchImsiAllocation`;
    const res = await CoreApi(Method.POST, url, payload);
    const imsiRanges: ImsiRange[] = (res?.data ?? []).map(
      (ir: any) =>
        ({
          ...ir,
          startImsi: ir?.startImsi ?? "",
          endImsi: ir?.endImsi ?? "",
          number: `${ir?.amount ?? 0}`,
          hlr: ir?.hlrName ?? "",
          status: ir?.status ?? "",
          productType: ir?.productTypeName ?? "",
          orderNumber: ir?.oaRefPoPk ?? "",
          cartType: ir?.cardTypeName ?? "",
          serviceProvider: ir?.systemStack ?? ""
        } as ImsiRange)
    );
    return imsiRanges;
  } catch (error: any) {
    throw new Error(error?.reason ?? "Failed to fetch filter data");
  }
};

export const handleImsiRangeExport = async () => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `imsisearch/downloadImsiSearchResult?localisation=${langauge}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `ImsiStatusExport_${dateAndTime}.xlsx`);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
