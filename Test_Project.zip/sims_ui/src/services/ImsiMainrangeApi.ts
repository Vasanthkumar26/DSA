import { HttpStatusCode } from "axios";
import {
  ICreateIMSIMainRangeRequestBody,
  ImsiMainrange,
  ImsiSubAndMainRangeStatusRequestPayload,
  ImsiSubAndMainRangeStatusTable,
  Method
} from "../models";
import { CoreApi } from "../utils/core";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";

export const handleFetchImsiMainranges = async (
  isArchived: boolean
): Promise<Array<ImsiMainrange>> => {
  try {
    const path = `imsi/loadIMSIMainRange?isActive=${
      isArchived ? "true" : "false"
    }`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleDeleteImsiMainrange = async (
  imsiId: number
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.DELETE,
      `/imsi/deleteImsiMainRange/${imsiId}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleArchiveImsiMainrange = async (
  imsiId: number,
  archive: boolean
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `/imsi/updateImsiMainRangeArchived/${imsiId}?archived=${!archive}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleIMSIMainRangeCreate = async (
  data: ICreateIMSIMainRangeRequestBody
): Promise<string> => {
  try {
    const path = "/imsi/createImsiMainRange";
    await CoreApi(Method.POST, path, data);
    return "IMSI Main Range created successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleIMSIMainRangeUpdate = async (
  data: ICreateIMSIMainRangeRequestBody,
  id: string
): Promise<string> => {
  try {
    const path = `imsi/updateImsiMainRange/${id}`;
    await CoreApi(Method.PATCH, path, data);
    return "IMSI Main Range updated successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleIMSIMainRangeExport = async (
  isArchived: boolean
): Promise<string> => {
  try {
    const language = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `/imsi/imsi/download?archived=${isArchived}&localisation=${language}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `ImsiMainRangeExport_${dateAndTime}.xlsx`);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchImsiMainRangeStatusTable = async (
  payload: ImsiSubAndMainRangeStatusRequestPayload
): Promise<Array<ImsiSubAndMainRangeStatusTable>> => {
  try {
    const res = await CoreApi(
      Method.POST,
      `/imsisearch/searchIMSIMainRangeStatus`,
      payload
    );
    return res?.data ?? [];
  } catch (error: any) {
    throw new Error(error?.message);
  }
};
