// @ts-nocheck
import { HttpStatusCode } from "axios";
import { Method } from "../models";
import { KittingArticle } from "../models/kittingArticle.model";
import { CoreApi } from "../utils/core";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";

/* Export kitting article */
export const handleKittingArticleExport = async (isArchive: boolean) => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `/kittingarticle/kittingArticle/download?archived=${isArchive}&localisation=${langauge}`,
      null,
      "blob"
    );

    if (response?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }

    const blob = new Blob([response.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `KittingArticleExport_${dateAndTime}.xlsx`);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err) {
    throw new Error(err?.message);
  }
};

/* Fetch kitting article */
export const handleFetchKittingArticles = async (
  isArchived: boolean = true
): Promise<Array<KittingArticle>> => {
  try {
    const res = await CoreApi(
      Method.GET,
      `/kittingarticle/loadKittingArticle?isArchived=${isArchived}`,
      null
    );
    return res?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleDeleteKittingArticle = async (
  kittingArticleId: number
): Promise<Array<KittingArticle>> => {
  try {
    const res = await CoreApi(
      Method.DELETE,
      `/kittingarticle/deleteKittingArticle/${kittingArticleId}`,
      null
    );
    return res?.status;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleArchiveKittingArticle = async (
  archive: boolean,
  kittingArticleId: number
): Promise<Array<KittingArticle>> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `kittingarticle/updateKittingArticleArchived/${kittingArticleId}?archived=${!archive}`,
      null
    );
    return res?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleCreateArticle = async (data) => {
  try {
    const response = await CoreApi(
      Method.POST,
      "kittingarticle/createKittingArticle",
      data
    );
    return response?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleUpdateArticle = async (data, id) => {
  try {
    const response = await CoreApi(
      Method.PATCH,
      `kittingarticle/updateKittingArticle/${id}`,
      data
    );
    return response?.status;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleFetchOffers = async (serviceProviderId) => {
  try {
    // offers API yet to be shared
    const response = await CoreApi(
      Method.GET,
      `/api/Offers/${serviceProviderId}`
    );
    return response?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};
