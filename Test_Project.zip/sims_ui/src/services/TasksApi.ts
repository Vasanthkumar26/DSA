import { HttpStatusCode } from "axios";
import { Task, Method } from "../models";
import { CoreApi } from "../utils/core";
import { TaskOrder } from "../models/task.model";

export const handleFetchOrders = async () => {
  try {
    const path = `/task/loadAllTasks`;
    const res = await CoreApi(Method.GET, path, null);
    const orders: Array<TaskOrder> = (res?.data ?? []).map(
      (o: any) => ({ ...o } as TaskOrder)
    );
    return orders;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleFetchTasks = async (isArchived: boolean) => {
  try {
    const path = `/sftpinboundfile/loadAll`;
    const res = await CoreApi(Method.GET, path, null);
    const tasks: Array<Task> = (res?.data ?? []).map((ak: any) => {
      const task: Task = {
        ...ak
      };
      return task;
    });
    return tasks;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleDownload = async (
  archiveId: string,
  fileExtension: string
): Promise<string> => {
  try {
    const response = await CoreApi(
      Method.GET,
      `sftpinboundfile/download?archiveId=${archiveId}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: `application/${fileExtension.split(".")[1]}`
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    link.setAttribute("download", archiveId);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleDeleteTask = async (Id: number): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.DELETE,
      `/sftpinboundfile/delete/${Id}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleNotifyKittingReserved = async (payload: FormData) => {
  try {
    const path = `/simsArvatoFileManagement/notifyKittingReserved`;
    const res = await CoreApi(Method.POST, path, payload);
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleNotifyKittingCompleted = async (payload: FormData) => {
  try {
    const path = `/simsArvatoFileManagement/notifyKittingCompleted`;
    const res = await CoreApi(Method.POST, path, payload);
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};
