import { HttpStatusCode } from "axios";
import { Method } from "../models";
import { CustomProfile } from "../models/customProfile.model";
import { CoreApi } from "../utils/core";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";

export const handleFetchCustomProfile = async (
  isArchived: boolean
): Promise<Array<CustomProfile>> => {
  try {
    const path = `/customProfile/loadAll?archived=${isArchived}`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data;
  } catch (error: any) {
    throw new Error(error?.message);
  }
};

export const handleCustomProfileCreate = async (data: FormData) => {
  try {
    const path = "/customProfile/create";
    await CoreApi(Method.POST, path, data);
    return "Custom profile created successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleCustomProfileUpdate = async (data: FormData) => {
  try {
    const path = `/customProfile/update`;
    await CoreApi(Method.PUT, path, data);
    return "External system updated successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleCustomProfileExport = async (isArchived: boolean) => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `customProfile/export/excel?archived=${isArchived}&lang=${langauge}`,
      null,
      "blob"
    );
    if (response?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `CustomProfileExport_${dateAndTime}.xlsx`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleDeleteCustomProfile = async (
  id: number
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.DELETE,
      `/customProfile/delete/${id}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleArchiveCustomProfile = async (
  id: number,
  archive: boolean
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `/customProfile/archived/${id}?archived=${!archive}`,
      null
    );

    if (res?.status !== HttpStatusCode.Ok) {
      throw new Error("error");
    }
    return res.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleDownloadXML = async (id: number, xmlFileName: string) => {
  try {
    const path = `customProfile/export/xml?id=${id}`;
    const response = await CoreApi(Method.GET, path, null, "blob");
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    link.setAttribute("download", `${xmlFileName}.xml`);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err.message);
  }
};
