import { HttpStatusCode } from "axios";
import {
  ESUser,
  ExternalSystem,
  ExternalSystemPayload,
  Method
} from "../models";
import { CoreApi } from "../utils/core";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";

export const handleFetchExternalSystems = async (isArchived: boolean) => {
  try {
    const path = `/externalsystem/loadAll?archived=${
      isArchived ? "true" : "false"
    }`;
    const res = await CoreApi(Method.GET, path, null);
    const externalSystems: Array<ExternalSystem> = (res?.data ?? []).map(
      (es: any) => {
        const externSystem: ExternalSystem = {
          ...es,
          name: es?.name ?? "",
          emailAddress: es?.emailAddress ?? "",
          subject: es?.subject ?? "",
          user: es?.users?.map((x: ESUser) => x?.userName ?? "")?.toString(),
          users: es?.users ?? [],
          archived: es?.archived ?? false,
          lastUpdateDate: es?.lastUpdateDate ?? ""
        };
        return externSystem;
      }
    );
    return externalSystems;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleExternalSystemsCreate = async (
  data: ExternalSystemPayload
) => {
  try {
    const path = "/externalsystem/create";
    await CoreApi(Method.POST, path, data);
    return "External system created successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleExternalSystemsUpdate = async (
  data: ExternalSystemPayload,
  id: string
) => {
  try {
    const path = `/externalsystem/update/${id}`;
    await CoreApi(Method.PUT, path, data);
    return "External system updated successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleDeleteExternalSystem = async (
  Id: number
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.DELETE,
      `/externalsystem/delete/${Id}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleArchiveExternalSystem = async (
  imsiId: number,
  archive: boolean
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `/externalsystem/archived/${imsiId}?archived=${!archive}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleExternalSystemExport = async (isArchived: boolean) => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `externalsystem/export/excel?archived=${isArchived}&lang=${langauge}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `ExternalSystemExport_${dateAndTime}.xlsx`);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const fetchExternalSystemUsers = async () => {
  try {
    const path = `/externalsystem/loadUsers`;
    const res = await CoreApi(Method.GET, path, null);
    const esUsers: Array<ESUser> = (res?.data ?? []).map((u: any) => ({
      ...u,
      userName: u?.userName ?? ""
    }));
    return esUsers;
  } catch (err: any) {
    throw new Error(err);
  }
};
