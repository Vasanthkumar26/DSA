import { HttpStatusCode } from "axios";
import {
  ElectricalProfile,
  ElectricalProfileRequestPayload,
  IAkaAlg,
  IAkaTpKey,
  Method
} from "../models";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage,
  returnSelectOption
} from "../utils/common";
import { CoreApi } from "../utils/core";
import { ISelectionOption } from "../models/global.model";
import { ISelectArchive } from "../models/simArticle.model";

export const handleFetchElectricalProfile = async (
  isArchived: boolean
): Promise<Array<ElectricalProfile>> => {
  try {
    const path = `electricalProfile/loadAll?archived=${isArchived}`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data;
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleElectricalProfileExport = async (
  isArchived: boolean
): Promise<string> => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `electricalProfile/export/excel?archived=${isArchived}&?lang=${langauge}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute(
      "download",
      `ElectricalProfileExport_${dateAndTime}.xlsx`
    );

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchPinState = async (): Promise<ISelectionOption[]> => {
  try {
    const res = await CoreApi(Method.GET, `/electricalProfile/pin1State`, null);
    return returnSelectOption(res?.data);
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchakaTpKey = async (): Promise<IAkaTpKey[]> => {
  try {
    const res = await CoreApi(Method.GET, `/electricalProfile/akaTpKey`, null);
    return res?.data?.map((item: any) => {
      return {
        label: item?.name,
        id: item?.id,
        akaHlrId: item?.akaHlrId,
        akaAlgTypeId: item?.akaAlgTypeId,
        simVendorId: item?.simVendorId
      };
    });
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchakaHlr = async (): Promise<ISelectArchive[]> => {
  try {
    const res = await CoreApi(Method.GET, `/electricalProfile/akaHlr`, null);
    return res?.data?.map((item: any) => {
      return {
        label: item?.name,
        id: item?.id,
        archive: item?.archived
      };
    });
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchakaAlg = async (): Promise<IAkaAlg[]> => {
  try {
    const res = await CoreApi(Method.GET, `/electricalProfile/akaAlg`, null);
    return res?.data?.map((item: any) => {
      return {
        label: item?.name,
        id: item?.id,
        akaHlrId: item?.akaHlrId,
        akaAlgTypeId: item?.akaAlgTypeId
      };
    });
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchakaAlgType = async (): Promise<ISelectionOption[]> => {
  try {
    const res = await CoreApi(
      Method.GET,
      `/electricalProfile/akaAlgType`,
      null
    );
    return returnSelectOption(res?.data);
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchisImActivation = async (): Promise<
  ISelectionOption[]
> => {
  try {
    const res = await CoreApi(
      Method.GET,
      `/electricalProfile/isImActivation`,
      null
    );
    return returnSelectOption(res?.data);
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchManufacturer = async (): Promise<ISelectArchive[]> => {
  try {
    const res = await CoreApi(
      Method.GET,
      `/electricalProfile/manufacturer`,
      null
    );
    return res?.data?.map((item: any) => {
      return {
        label: item?.name,
        id: item?.id,
        archive: item?.archived
      };
    });
  } catch (err: any) {
    throw new Error(err?.message);
  }
};
export const handleDeleteElectricalProfile = async (
  Id: number
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.DELETE,
      `/electricalProfile/delete/${Id}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleCreateElectricalProfile = async (
  data: ElectricalProfileRequestPayload
) => {
  try {
    const path = "/electricalProfile/create";
    await CoreApi(Method.POST, path, data);
    return "Electrical Profile created successfully";
  } catch (error: any) {
    throw new Error(error?.message);
  }
};

export const handleUpdateElectricalProfile = async (
  data: ElectricalProfileRequestPayload
) => {
  try {
    const path = "/electricalProfile/update";
    await CoreApi(Method.PUT, path, data);
    return "Electrical Profile updated successfully";
  } catch (error: any) {
    throw new Error(error?.message);
  }
};

export const handleArchiveElectricalProfile = async (
  itemId: number,
  archive: boolean
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `/electricalProfile/archived/${itemId}?archived=${!archive}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};
