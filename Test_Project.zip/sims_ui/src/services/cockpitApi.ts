import { HttpStatusCode } from "axios";
import { ISelectionOption, Method } from "../models";
import {
  Cockpit,
  CockpitQuery,
  DocumentTable,
  OrderDetail
} from "../models/cockpit.model";
import { CoreApi } from "../utils/core";

export const handleFetchCockpit = async () => {
  try {
    const path = `/cockpit/loadCockpitOrdersInProcess`;
    const res = await CoreApi(Method.GET, path, null);
    const cockpits: Array<Cockpit> = (res?.data ?? []).map((cp: any) => {
      const cockpit: Cockpit = {
        ...cp,
        orderNumber: `${cp?.orderNumber ?? ""}`,
        articleNumber: cp?.article ?? "",
        itemDescription: cp?.articleDescription ?? "",
        crowd: `${cp?.quantity ?? ""}`,
        status: cp?.status ?? "",
        serviceProvider: cp?.serviceProvider ?? "",
        registerDate: cp?.orderCreationDate ?? "",
        deliveryDate: cp?.delivery ?? "",
        oaRefPoPk: cp?.oaRefPoPk ?? ""
      };
      return cockpit;
    });
    return cockpits;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleFetchCustomQueries = async () => {
  try {
    const path = `/cockpit/loadCustomQuery`;
    const res = await CoreApi(Method.GET, path, null);
    const cQueries: Array<CockpitQuery> = (res?.data ?? []).map((cq: any) => {
      const query: CockpitQuery = {
        ...cq,
        queryId: cq?.queryId ?? 0,
        queryName: cq?.queryName ?? ""
      };
      return query;
    });
    return cQueries;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleFetchOrderDetails = async (orderId: string) => {
  try {
    const path = `/cockpit/getOrderDetails/${orderId}`;
    const res = await CoreApi(Method.GET, path, null);
    const cQueries: Array<OrderDetail> = (res?.data ?? []).map((od: any) => {
      const query: OrderDetail = {
        ...od,
        id: `${od?.id ?? ""}`,
        creationDate: od?.creationDate ?? "",
        expectedDeliveryDate: od?.expectedDeliveryDate ?? "",
        noOfSimCards: od?.noOfSimCards ?? "",
        article: od?.article ?? "",
        description: od?.description ?? "",
        serviceProvider: od?.serviceProvider ?? "",
        startPackType: od?.startPackType ?? "",
        msisdnType: od?.msisdnType ?? "",
        packs: od?.packs ?? "",
        status: od?.status ?? "",
        originator: od?.originator ?? "",
        lastUpdatedBy: od?.lastUpdatedBy ?? "",
        lastUpdatedDate: od?.lastUpdatedDate ?? "",
        organization: od?.organization ?? "",
        simstatus: od?.simstatus ?? ""
      };
      return query;
    });
    return cQueries;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleCancelKittingOrder = async (
  Id: number,
  StopMessage: string
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.POST,
      `cockpit/kittingOrder/cancelKittingOrder`,
      { orderId: Id, stopMessage: StopMessage }
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleFetchAllDocumentList = async (
  id: number
): Promise<DocumentTable[]> => {
  try {
    const res = await CoreApi(
      Method.GET,
      `cockpit/loadAllDocumentsByOrderId/${id}`,
      null
    );
    return res?.data;
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchDownloadDocument = async (archivedId: string) => {
  try {
    const res = await CoreApi(
      Method.GET,
      `cockpit/downloadDocument/${archivedId}`,
      null
    );
    const fileType = res?.data?.fileName?.trim().split(".")?.[1];

    let file = `data:application/${fileType};base64,${res?.data?.archiveBinaryData}`;
    let a = document.createElement("a");
    a.href = file;
    a.setAttribute("download", res?.data?.fileName);

    // Making link downloadable
    document.body.appendChild(a);
    a.click();

    // Removing url object
    document.body.removeChild(a);
    URL.revokeObjectURL(file);
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleFetchFileType = async () => {
  try {
    const res = await CoreApi(Method.GET, `cockpit/loadArchiveFileType`, null);
    const data = res?.data?.map((item: any) => {
      return {
        label: item?.fileType,
        id: item?.id
      };
    }) as ISelectionOption[];
    return data;
  } catch (error: any) {
    throw new Error(error?.message);
  }
};

export const handleUploadDocument = async (payload: any) => {
  try {
    const res = await CoreApi(
      Method.POST,
      `cockpit/cockpitUploadDocument`,
      payload
    );
    return res?.data;
  } catch (error: any) {
    throw new Error(error?.message);
  }
};

export const handleFetchOrderStatus = async () => {
  try {
    const path = `/cockpit/loadOrderStatus`;
    const res = await CoreApi(Method.GET, path, null);
    const os: Array<ISelectionOption> = (res?.data ?? []).map(
      (item: string, i: number) =>
        ({ label: item ?? "", id: `${i}` } as ISelectionOption)
    );
    return os;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleFetchCustomProfileData = async () => {
  try {
    const path = `/cockpit/loadCustomProfileData`;
    const res = await CoreApi(Method.GET, path, null);
    const cp: Array<ISelectionOption> = (res?.data ?? []).map(
      (item: string, i: number) =>
        ({ label: item ?? "", id: `${i}` } as ISelectionOption)
    );
    return cp;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleFetchKittingArticle = async () => {
  try {
    const path = `/cockpit/loadKittingArticle`;
    const res = await CoreApi(Method.GET, path, null);
    const ka: Array<ISelectionOption> = (res?.data ?? []).map(
      (item: string, i: number) =>
        ({ label: item ?? "", id: `${i}` } as ISelectionOption)
    );
    return ka;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleCancelSimOrder = async (
  Id: number,
  StopMessage: string,
  cancelType: number
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.POST,
      `cockpit/cancelSimOrder?cancelType=${cancelType}`,
      { orderId: Id, stopMessage: StopMessage }
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};
