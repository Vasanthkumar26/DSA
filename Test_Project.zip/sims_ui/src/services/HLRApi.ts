import { HttpStatusCode } from "axios";
import { CreateHLRRequestBody, Hlr, Method } from "../models";
import { CoreApi } from "../utils/core";
import {
  getCurrentDateAndTime,
  getCurrentSelectedLanguage
} from "../utils/common";

export const handleFetchHlrs = async (
  isArchived: boolean
): Promise<Array<Hlr>> => {
  try {
    const path = `hlr/loadHLR?isArchived=${isArchived ? "true" : "false"}`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleDeleteHLRArticle = async (
  hlrArticleId: number
): Promise<boolean> => {
  try {
    const res = await CoreApi(
      Method.DELETE,
      `/hlr/deleteHLR/${hlrArticleId}`,
      null
    );
    return res?.status === HttpStatusCode.Ok;
  } catch (err: any) {
    throw new Error(err);
  }
};
export const handleFetchHlrByName = async (
  name: string
): Promise<Array<Hlr>> => {
  try {
    const path = `hlr/loadHLR/${name}`;
    const res = await CoreApi(Method.GET, path, null);
    return res?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleArchiveHLR = async (
  hlrId: number,
  archive: boolean
): Promise<Array<Hlr>> => {
  try {
    const res = await CoreApi(
      Method.PATCH,
      `hlr/updateHLRArchived/${hlrId}?archived=${!archive}`,
      null
    );
    return res?.data;
  } catch (err: any) {
    throw new Error(err);
  }
};

export const handleHLRExport = async (isArchived: boolean): Promise<string> => {
  try {
    const langauge = getCurrentSelectedLanguage();
    const response = await CoreApi(
      Method.GET,
      `hlr/hlr/download?archived=${isArchived}&localisation${langauge}`,
      null,
      "blob"
    );
    const blob = new Blob([response?.data], {
      type: "application/vnd.ms-excel"
    });
    const href = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = href;
    const dateAndTime = getCurrentDateAndTime();
    link.setAttribute("download", `HLRExport_${dateAndTime}.xlsx`);

    // Making link downloadable
    document.body.appendChild(link);
    link.click();

    // Removing url object
    document.body.removeChild(link);
    URL.revokeObjectURL(href);

    return "successful";
  } catch (err: any) {
    throw new Error(err?.message);
  }
};

export const handleHLRCreate = async (
  data: CreateHLRRequestBody
): Promise<Hlr> => {
  try {
    const path = "hlr/createHLR";
    const res = await CoreApi(Method.POST, path, data);
    return res?.data;
  } catch (err: any) {
    throw new Error(err.message);
  }
};

export const handleHLRUpdate = async (
  data: CreateHLRRequestBody,
  id: string
): Promise<string> => {
  try {
    const path = `hlr/updateHLR/${id}`;
    await CoreApi(Method.PATCH, path, data);
    return "HLR updated successfully";
  } catch (err: any) {
    throw new Error(err.message);
  }
};
