import React, { FC, useState } from "react";
import { Box, Grid } from "@mui/material";
import FormFactorHeader from "./FormFactorHeader";
import FormFactorTable from "./FormFactorTable";
import FormFactorAddEditForm from "./FormFactorAddEditForm";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import { showFailureSnackbar } from "../../redux/actions/snackbarAction";

interface Props extends PropsFromRedux {}

const FormFactor: FC<Props> = ({ selectedFormFactor, showFailureSnackbar }) => {
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);

  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <FormFactorHeader
            isArchivedVisible={isArchivedVisible}
            setIsArchivedVisible={setIsArchivedVisible}
            setShowForm={setShowForm}
          />
          <FormFactorTable isArchivedVisible={isArchivedVisible} />
        </Grid>
        {(showForm || selectedFormFactor) && (
          <Grid item xs={12}>
            <FormFactorAddEditForm
              setShowForm={setShowForm}
              // esUsers={esUsers}
            />
          </Grid>
        )}
      </Grid>
    </Box>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedFormFactor: state.formFactor.selectedFormFactor
});

const connector = connect(mapStateToProps, {
  showFailureSnackbar
});
type PropsFromRedux = ConnectedProps<typeof connector>;
export default connector(FormFactor);
