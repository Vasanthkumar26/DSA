import React, { FC, useEffect, useMemo, useState } from "react";
import { Grid } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import {
  fetchFormFactor,
  setSelectedFormFactor,
  resetFormFactorErr
} from "../../redux/actions/formFactorAction";

import { connect, ConnectedProps } from "react-redux";
import { FormFactor, HeadCell, TableConfig } from "../../models";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";
import CustomSnackBar from "../common/CustomSnackBar";

const headCells: Array<HeadCell> = [
  { id: "name", label: "Name" },
  { id: "value", label: "Value" }
];

const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
}

const tableConfig: TableConfig = {
  title: "Form Factor Administration",
  orderBy: "lastUpdateDate",
  tableRowTestId: "formFactor-row"
};

const FormFactorTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchFormFactor,
  setSelectedFormFactor,
  deleteSuccessMsgFlag,
  deleteSuccessMsg,
  formFactors = [],
  resetFormFactorErr
}) => {
  const [nameFilter, setNameFilter] = useState("");
  const [valueFilter, setValueFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchFormFactor(isArchivedVisible))();
  }, [fetchFormFactor, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getArchivedFilter = (formFactor: FormFactor) => {
    if (archivedFilter === "Yes") {
      return !!formFactor.archived;
    }
    return archivedFilter === "No" ? !formFactor.archived : true;
  };

  let visibleMainranges = formFactors?.filter(
    (formFactor: any) =>
      formFactor.name.includes(nameFilter) &&
      formFactor.value.includes(valueFilter) &&
      getArchivedFilter(formFactor)
  );

  if (!isArchivedVisible) {
    visibleMainranges = visibleMainranges?.filter(
      (mainrange) => !mainrange.archived
    );
  }

  const filterHeadCellMap = {
    [headCells[0].id]: {
      filter: nameFilter,
      setFilter: setNameFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[1].id]: {
      filter: valueFilter,
      setFilter: setValueFilter,
      filterComponent: FilterSearchBar(t)
    },
    [archivedCell.id]: {
      filter: archivedFilter,
      setFilter: setArchivedFilter,
      filterComponent: FilterDropdown(archivedCell.values, t)
    }
  };

  const resetAllFilters = useMemo(() => {
    return () => {
      setNameFilter("");
      setValueFilter("");
      setArchivedFilter("");
    };
  }, []);

  const handleRowSelected = async (row: any) => {
    setSelectedFormFactor(row);
  };
  const handleRefresh = async () => {
    await fetchFormFactor(isArchivedVisible);
    resetAllFilters();
  };

  const visibleHeadCells = [
    ...headCells,
    ...(isArchivedVisible ? [archivedCell] : [])
  ];
  function handleCloseSnackbar(): void {
    resetFormFactorErr();
  }
  return (
    <Grid container direction="row" wrap="nowrap">
      <CustomSnackBar
        variant="filled"
        open={deleteSuccessMsgFlag}
        autoHideDuration={3000}
        message={deleteSuccessMsg}
        onClose={handleCloseSnackbar}
        severity="success"
      />
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleMainranges]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
      <Grid item display={{ xs: "none", lg: "block" }}>
        <img
          src="/sidebarIcons/Mask_Group_hlr.jpg"
          alt="background"
          style={{
            objectFit: "cover",
            width: "300px",
            height: "100%",
            margin: "1px"
          }}
        />
      </Grid>
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.formFactor.isLoadingFetch,
  formFactors: state.formFactor.formFactors,
  deleteSuccessMsg: state.formFactor.deleteSuccessMsg,
  archiveSuccessMsg: state.formFactor.archiveSuccessMsg,
  deleteSuccessMsgFlag: state.formFactor.deleteSuccessMsgFlag
});

const connector = connect(mapStateToProps, {
  fetchFormFactor,
  setSelectedFormFactor,
  resetFormFactorErr
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(FormFactorTable);
