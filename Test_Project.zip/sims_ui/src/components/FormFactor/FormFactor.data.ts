import * as yup from "yup";
import { FormFactor, FormFactorPayload } from "../../models/formFactor.model";

export const initData: FormFactorPayload = {
  name: "",
  value: "",
  user: ""
};

export const setFormData = (data: FormFactor): FormFactorPayload => ({
  name: data?.name ?? "",
  value: data?.value ?? "",
  user: `${data?.user ?? ""}`
});

export const FormFactorSchema = (
  t: string,
  ffNames: string[],
  isCreate: boolean,
  isSimArticle: boolean
) =>
  yup.object().shape({
    name: yup
      .string()
      .required("Name is missing")
      .notOneOf([...(isCreate ? ffNames ?? [] : [])], t),
    value: yup.string().test("is sim article", "", function (v) {
      if (v) {
        if (isSimArticle) {
          return this.createError({
            message: `Form factor value can no longer be changed`
          });
        }
      } else {
        return this.createError({
          message: `Value is missing`
        });
      }
      return true;
    })
  });
