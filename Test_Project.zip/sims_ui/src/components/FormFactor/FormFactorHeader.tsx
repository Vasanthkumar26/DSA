import { Dispatch, FC, SetStateAction, useCallback } from "react";
import { ConnectedProps, connect } from "react-redux";
import TableHeader from "../common/TableHeader";
import { RootState } from "../../redux/store";
import {
  setSelectedFormFactor,
  fetchFormFactorExport
} from "../../redux/actions/formFactorAction";
interface Props extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
}

const FormFactorHeader: FC<Props> = ({
  setShowForm,
  setSelectedFormFactor,
  isLoadingExport,
  fetchFormFactorExport,
  isArchivedVisible,
  setIsArchivedVisible
}) => {
  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleAdd = useCallback(() => {
    setSelectedFormFactor(null);
    setShowForm(true);
  }, [setSelectedFormFactor, setShowForm]);

  const handleExport = useCallback(() => {
    fetchFormFactorExport(isArchivedVisible);
  }, [fetchFormFactorExport, isArchivedVisible]);

  return (
    <TableHeader
      title="Form Factor Administration"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.externalSystem.isLoadingExport
});

const connector = connect(mapStateToProps, {
  fetchFormFactorExport,
  setSelectedFormFactor
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(FormFactorHeader);
