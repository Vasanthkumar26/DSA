// @ts-nocheck
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import "@testing-library/jest-dom";
import { screen, waitFor } from "@testing-library/react";
import FormFactorTable from "../FormFactorTable";
import { REACT_BASE_URL } from "../../../utils/common";

describe("HlrTable", () => {
  test("should render without crash", () => {
    const setShowForm = jest.fn();
    const { container } = renderWithAllWrappers(
      <FormFactorTable isArchivedVisible={false} setShowForm={setShowForm} />
    );
    expect(container).toBeInTheDocument();
  });

  describe("API success", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/formfactor/loadAll`,
        res: () => [
          {
            name: "test22",
            value: "testvalue",
            archived: false,
            user: 1
          }
        ]
      }
    ]);

    test("Table should show correct data when archived unchecked", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <FormFactorTable isArchivedVisible={false} setShowForm={setShowForm} />
      );
      await waitFor(async () => {
        const formFactorRows = screen.queryAllByTestId(/formFactor-row/i);
        expect(formFactorRows).toHaveLength(0);
      });
    });

    test("Table should show correct data when archived checked", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <FormFactorTable isArchivedVisible={true} setShowForm={setShowForm} />
      );
      await waitFor(async () => {
        const formFactorRows = screen.queryAllByTestId(/formFactor-row/i);
        expect(formFactorRows).toHaveLength(0);
      });
    });
  });
  describe("API Failure", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/formfactor/loadAll`,
        status: 404,
        res: () => ({ message: "Oops! Something went wrong" })
      }
    ]);

    test("Table should show correct data when server down", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <FormFactorTable isArchivedVisible={false} setShowForm={setShowForm} />
      );
      await waitFor(async () => {
        const formFactorRows = screen.queryAllByTestId(/formFactor-row/i);
        expect(formFactorRows).toHaveLength(0);
      });
    });
  });
});
