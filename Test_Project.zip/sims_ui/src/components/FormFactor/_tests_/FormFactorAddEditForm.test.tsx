// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import FormFactorAddEditForm from "../FormFactorAddEditForm";

describe("FormFactorAddEditForm", () => {
  test("should render without crash", async () => {
    const { container } = renderWithAllWrappers(<FormFactorAddEditForm />);

    expect(container).toBeInTheDocument();
  });
});
