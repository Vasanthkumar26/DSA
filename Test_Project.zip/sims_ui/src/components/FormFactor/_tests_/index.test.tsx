import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import FormFactor from "..";

describe("FormFactor", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<FormFactor />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
