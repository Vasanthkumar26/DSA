import {
  Dispatch,
  FC,
  SetStateAction,
  useCallback,
  useEffect,
  useState
} from "react";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import { Grid } from "@mui/material";
import { useForm } from "react-hook-form";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import { FormFactorSchema, initData, setFormData } from "./FormFactor.data";
import { useTranslation } from "../../hooks/useTranslation";
import { StyledFormBox } from "../common/styles/shared";
import { FormFactorPayload } from "../../models/formFactor.model";
import {
  FormActionButtons,
  FormControllerTextField,
  LastUpdated
} from "../common/AddEditForm";
import {
  createFormFactor,
  fetchFormFactor,
  updateFormFactor,
  setSelectedFormFactor,
  archiveFormFactor,
  deleteFormFactor,
  resetFormFactor
} from "../../redux/actions/formFactorAction";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import { DeleteDailog } from "../common/AddEditForm/DeleteDialog";
import { resetPage } from "../../redux/actions/rootAction";

interface Props extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const FormFactorAddEditForm: FC<Props> = ({
  selectedFormFactor,
  formFactorsName,
  isLoadingCreate,
  errorCreate,
  isLoadingUpdate,
  errorUpdate,
  setShowForm,
  setSelectedFormFactor,
  fetchFormFactor,
  createFormFactor,
  updateFormFactor,
  showSuccessSnackbar,
  showFailureSnackbar,
  archiveFormFactor,
  deleteFormFactor
}) => {
  const t = useTranslation();
  const resolver = useYupValidationResolver(
    FormFactorSchema(
      t("name_already_exists"),
      [...(formFactorsName ?? [])],
      !selectedFormFactor,
      !!selectedFormFactor?.sim_article_reference_exist
    )
  );
  const [open, setOpen] = useState<boolean>(false);
  const { control, handleSubmit, reset } = useForm({
    mode: "all",
    resolver,
    defaultValues: { ...initData }
  });

  const {
    //lastUpdateDate = "",
    archived = false,
    sim_article_reference_exist = false,
    FormFactorId = 0
  } = selectedFormFactor ?? {};
  useEffect(() => {
    selectedFormFactor
      ? reset(setFormData(selectedFormFactor))
      : reset({ ...initData });
  }, [reset, selectedFormFactor]);

  useEffect(() => {
    if (errorCreate || errorUpdate) {
      showFailureSnackbar(errorCreate || errorUpdate || "");
    }
  }, [errorCreate, errorUpdate, showFailureSnackbar]);

  const handleReset = useCallback(() => {
    reset({ ...initData });
    setSelectedFormFactor(null);
    setShowForm(false);
  }, [reset, setSelectedFormFactor, setShowForm]);

  const handleConfirmation = (flag: boolean): any => {
    setOpen(flag);
  };

  const onActiveNArchive = () => {
    archiveFormFactor(FormFactorId, archived)
      .then(() => {
        showSuccessSnackbar(
          !archived ? t("successfully_archived") : t("successfully_activated")
        );
      })
      .catch(() => showFailureSnackbar(t("error-while-submitting-data")))
      .finally(() => handleReset());
  };

  const handleCloseConfirmation = () => {
    setOpen(false);
    deleteFormFactor(FormFactorId);
    handleReset();
    setSelectedFormFactor(null);
    setShowForm(false);
  };
  const onSubmit = (data: FormFactorPayload) => {
    let formFactorApi;
    const payload: FormFactorPayload = {
      name: data?.name ?? "",
      value: data?.value ?? "",
      user: "1"
    };
    if (selectedFormFactor) {
      formFactorApi = updateFormFactor(
        { ...payload, archived: false },
        `${selectedFormFactor?.FormFactorId ?? 0}`
      );
    } else {
      formFactorApi = createFormFactor({ ...payload });
    }

    formFactorApi
      .then(() => {
        handleReset();
        showSuccessSnackbar("Request processed successfully");
        fetchFormFactor(false);
      })
      .catch((error) => {
        showFailureSnackbar("Error while processing data");
      });
  };

  return (
    <>
      <DeleteDailog
        open={open}
        onDelete={handleConfirmation}
        handleCloseConfirmation={handleCloseConfirmation}
        message={"delete_confirmation"}
      ></DeleteDailog>
      <StyledFormBox component="form" onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={8}>
            <FormControllerTextField
              control={control}
              controlName="name"
              inputLabel="Name"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerTextField
              control={control}
              controlName="value"
              inputLabel="Value"
            />
          </Grid>
          {selectedFormFactor && (
            <Grid item xs={12}>
              <LastUpdated
                lastUpdatedDate={selectedFormFactor?.lastUpdateDate}
              />
            </Grid>
          )}
          <Grid item xs={12}>
            <FormActionButtons
              onCancel={handleReset}
              onDelete={handleConfirmation}
              onActiveNArchive={onActiveNArchive}
              selectedData={selectedFormFactor}
              submitDisabled={isLoadingCreate || isLoadingUpdate}
              cancelDisabled={isLoadingCreate || isLoadingUpdate}
              isArchiveVisible={!archived && sim_article_reference_exist}
              isDeleteVisible={!sim_article_reference_exist}
              isActiveVisible={archived && sim_article_reference_exist}
            />
          </Grid>
        </Grid>
      </StyledFormBox>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedFormFactor: state.formFactor.selectedFormFactor,
  isLoadingCreate: state.formFactor.isLoadingCreate,
  errorCreate: state.formFactor.errorCreate,
  isLoadingUpdate: state.formFactor.isLoadingUpdate,
  errorUpdate: state.formFactor.errorUpdate,
  formFactorsName: state.formFactor.formFactors.map((item) => item.name)
});

const connector = connect(mapStateToProps, {
  createFormFactor,
  updateFormFactor,
  setSelectedFormFactor,
  fetchFormFactor,
  showSuccessSnackbar,
  showFailureSnackbar,
  deleteFormFactor,
  archiveFormFactor,
  resetFormFactor,
  resetPage
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(FormFactorAddEditForm);
