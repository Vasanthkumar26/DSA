import * as yup from "yup";
import { ExternalSystem, ExternalSystemPayload } from "../../models";

export const initData = {
  name: "",
  emailAddress: "",
  replyAddress: "",
  subject: "",
  text: "",
  user: [""]
};

export const setFormData = (data: ExternalSystem) => ({
  name: data?.name ?? "",
  emailAddress: data?.emailAddress ?? "",
  replyAddress: data?.replyAddress ?? "",
  subject: data?.subject ?? "",
  text: data?.text ?? "",
  user: data?.users?.map((x) => x.userId ?? "")
});

export const externalSystemsSchema = (
  t: (key: string | undefined) => string,
  esNames: string[],
  isCreate: boolean
) =>
  yup.object().shape({
    name: yup
      .string()
      .required(t("name_is_missing"))
      .max(49, t("max_50_character"))
      .notOneOf([...(isCreate ? esNames ?? [] : [])], t("name_already_exists")),
    emailAddress: yup
      .string()
      .trim()
      .test("Valid Email", "", function (value) {
        if (value) {
          yup.object().shape({
            emails: yup
              .string()
              .required("es_please_provide_a_valid_email_address")
          });
          const emailSchema = yup.array().of(yup.string().email());
          const emails = value.split(",").map((email) => email.trim());
          if (!emailSchema.isValidSync(emails)) {
            return this.createError({
              message: `es_please_provide_a_valid_email_address`
            });
          }
        } else {
          return this.createError({
            message: `es_please_provide_a_valid_email_address`
          });
        }
        return true;
      }),
    replyAddress: yup
      .string()
      .trim()
      .test("Valid Email", "", function (value) {
        if (value) {
          yup.object().shape({
            emails: yup
              .string()
              .required("es_please_provide_a_valid_reply_address")
          });
          const emailSchema = yup.array().of(yup.string().email());
          const emails = value.split(",").map((email) => email.trim());
          if (!emailSchema.isValidSync(emails)) {
            return this.createError({
              message: `es_please_provide_a_valid_reply_address`
            });
          }
        } else {
          return this.createError({
            message: `es_please_provide_a_valid_reply_address`
          });
        }
        return true;
      }),
    subject: yup
      .string()
      .required(t("es_subject_is_missing"))
      .max(199, t("max_200_character")),
    text: yup.string().max(3999, t("max_4000_character"))
  });

export const createESPayload = (data: any) =>
  ({
    name: data?.name ?? "",
    emailAddress: data?.emailAddress ?? "",
    replyAddress: data?.replyAddress ?? "",
    subject: data?.subject ?? "",
    text: data?.text ?? "",
    userIds: data?.user
  } as ExternalSystemPayload);
