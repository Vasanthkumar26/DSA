import {
  Dispatch,
  FC,
  SetStateAction,
  useCallback,
  useEffect,
  useState
} from "react";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import { Grid, MenuItem } from "@mui/material";
import { useForm } from "react-hook-form";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import {
  createESPayload,
  externalSystemsSchema,
  initData,
  setFormData
} from "./ExternalSystems.data";
import { StyledFormBox } from "../common/styles/shared";
import { ESUser } from "../../models";
import {
  FormActionButtons,
  FormControllerTextField,
  LastUpdated
} from "../common/AddEditForm";
import { FormControllerSelect } from "../common/AddEditForm/FormControllerSelect";
import {
  createExternalSystem,
  setSelectedExternalSystem,
  updateExternalSystem,
  deleteExternalSystem,
  archiveExternalSystem,
  resetExternalSystem
} from "../../redux/actions/extenalSystemsAction";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import { DeleteDailog } from "../common/AddEditForm/DeleteDialog";
import { useTranslation } from "../../hooks/useTranslation";
import { resetPage } from "../../redux/actions/rootAction";

interface Props extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
  esUsers: Array<ESUser> | null;
}

const ExternalSystemsAddEditForm: FC<Props> = ({
  esNames,
  selectedExternalSystem,
  esUsers,
  isLoadingCreate,
  errorCreate,
  isLoadingUpdate,
  errorUpdate,
  setShowForm,
  setSelectedExternalSystem,
  createExternalSystem,
  updateExternalSystem,
  showSuccessSnackbar,
  showFailureSnackbar,
  deleteExternalSystem,
  archiveExternalSystem,
  resetExternalSystem,
  resetPage
}) => {
  const t = useTranslation();
  const resolver = useYupValidationResolver(
    externalSystemsSchema(t, [...(esNames ?? [])], !selectedExternalSystem)
  );
  const [open, setOpen] = useState<boolean>(false);
  const { control, handleSubmit, reset } = useForm({
    mode: "all",
    resolver,
    defaultValues: { ...initData }
  });
  const {
    lastUpdateDate = "",
    archived = false,
    productTypeRefferanceExists = false,
    externalSystemId = 0
  } = selectedExternalSystem ?? {};

  useEffect(() => {
    selectedExternalSystem
      ? reset(setFormData(selectedExternalSystem))
      : reset({ ...initData });
  }, [reset, selectedExternalSystem]);

  useEffect(() => {
    if (errorCreate || errorUpdate) {
      showFailureSnackbar(errorCreate || errorUpdate || "");
    }
  }, [errorCreate, errorUpdate, showFailureSnackbar]);

  const handleReset = useCallback(() => {
    reset({ ...initData });
    setSelectedExternalSystem(null);
    setShowForm(false);
  }, [reset, setSelectedExternalSystem, setShowForm]);

  const handleConfirmation = (flag: boolean): any => {
    setOpen(flag);
  };

  const onActiveNArchive = () => {
    archiveExternalSystem(externalSystemId, archived)
      .then(() =>
        showSuccessSnackbar(
          !archived ? t("successfully_archived") : t("successfully_activated")
        )
      )
      .catch(() => showFailureSnackbar("Error while processing data"))
      .finally(() => handleReset());
  };

  const handleCloseConfirmation = () => {
    setOpen(false);
    deleteExternalSystem(externalSystemId);
    handleReset();
    setSelectedExternalSystem(null);
    setShowForm(false);
  };
  const onSubmit = (data: any) => {
    const payload = createESPayload(data);
    const esApi = selectedExternalSystem
      ? updateExternalSystem(
          { ...payload, archived: false },
          `${externalSystemId}`
        )
      : createExternalSystem({ ...payload });
    esApi
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => {
        resetExternalSystem();
        resetPage();
      });
  };

  return (
    <>
      <DeleteDailog
        open={open}
        onDelete={handleConfirmation}
        handleCloseConfirmation={handleCloseConfirmation}
        message={"delete_confirmation"}
      ></DeleteDailog>
      <StyledFormBox component="form" onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerTextField
              control={control}
              controlName="name"
              inputLabel="Name"
              required
              inputProps={{ maxLength: 50 }}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerTextField
              control={control}
              controlName="emailAddress"
              inputLabel="Email-Address"
              required
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerTextField
              control={control}
              controlName="replyAddress"
              inputLabel="Reply-Address"
              required
            />
          </Grid>
          <Grid item xs={12} sm={6} md={8}>
            <FormControllerTextField
              control={control}
              controlName="subject"
              inputLabel="Subject"
              required
              inputProps={{ maxLength: 200 }}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerSelect
              control={control}
              controlName="user"
              inputLabel="User"
              required
              multiple
            >
              {(esUsers ?? []).map((user) => (
                <MenuItem key={user?.userId} value={user?.userId}>
                  {user?.userName}
                </MenuItem>
              ))}
            </FormControllerSelect>
          </Grid>
          <Grid item xs={12}>
            <FormControllerTextField
              control={control}
              controlName="text"
              inputLabel="Text"
              multiline
              rows={2}
              inputProps={{ maxLength: 4000 }}
            />
          </Grid>
          {lastUpdateDate && (
            <Grid item xs={12}>
              <LastUpdated lastUpdatedDate={lastUpdateDate} />
            </Grid>
          )}
          <Grid item xs={12}>
            <FormActionButtons
              onCancel={handleReset}
              onDelete={handleConfirmation}
              onActiveNArchive={onActiveNArchive}
              selectedData={selectedExternalSystem}
              submitDisabled={isLoadingCreate || isLoadingUpdate}
              cancelDisabled={isLoadingCreate || isLoadingUpdate}
              isArchiveVisible={!archived && productTypeRefferanceExists}
              isDeleteVisible={!productTypeRefferanceExists}
              isActiveVisible={archived && productTypeRefferanceExists}
            />
          </Grid>
        </Grid>
      </StyledFormBox>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  esNames: state.externalSystem.esNames,
  selectedExternalSystem: state.externalSystem.selectedExternalSystem,
  isLoadingCreate: state.externalSystem.isLoadingCreate,
  errorCreate: state.externalSystem.errorCreate,
  isLoadingUpdate: state.externalSystem.isLoadingUpdate,
  errorUpdate: state.externalSystem.errorUpdate
});

const connector = connect(mapStateToProps, {
  createExternalSystem,
  updateExternalSystem,
  setSelectedExternalSystem,
  showSuccessSnackbar,
  showFailureSnackbar,
  deleteExternalSystem,
  archiveExternalSystem,
  resetExternalSystem,
  resetPage
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ExternalSystemsAddEditForm);
