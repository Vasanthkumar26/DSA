import React, { FC, useEffect, useMemo, useState } from "react";
import { Grid } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import {
  fetchExternalSystems,
  setSelectedExternalSystem,
  resetExtertnalSystemErr
} from "../../redux/actions/extenalSystemsAction";
import { connect, ConnectedProps } from "react-redux";
import { ExternalSystem, HeadCell, TableConfig } from "../../models";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";
import CustomSnackBar from "../common/CustomSnackBar";

const headCells: Array<HeadCell> = [
  { id: "name", label: "Name" },
  { id: "emailAddress", label: "Email-Address" },
  { id: "subject", label: "Subject" },
  { id: "user", label: "User" }
];

const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
}

const tableConfig: TableConfig = {
  title: "External Systems Administration",
  orderBy: "lastUpdateDate",
  tableRowTestId: "externalSystems-row"
};

const ExternalSystemsTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchExternalSystems,
  setSelectedExternalSystem,
  deleteSuccessMsgFlag,
  deleteSuccessMsg,
  externalSystems = [],
  resetExtertnalSystemErr
}) => {
  const [nameFilter, setNameFilter] = useState("");
  const [emailAddressFilter, setEmailAddressFilter] = useState("");
  const [referenceFilter, setReferenceFilter] = useState("");
  const [userFilter, setUserFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchExternalSystems(isArchivedVisible))();
  }, [fetchExternalSystems, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getArchivedFilter = (externalSystem: ExternalSystem) => {
    if (archivedFilter === "Yes") {
      return !!externalSystem.archived;
    }
    return archivedFilter === "No" ? !externalSystem.archived : true;
  };

  let visibleMainranges = externalSystems?.filter(
    (externalSystem) =>
      externalSystem.name.includes(nameFilter) &&
      externalSystem.emailAddress.includes(emailAddressFilter) &&
      externalSystem.subject.includes(referenceFilter) &&
      externalSystem.user.includes(userFilter) &&
      getArchivedFilter(externalSystem)
  );

  if (!isArchivedVisible) {
    visibleMainranges = visibleMainranges?.filter(
      (mainrange) => !mainrange.archived
    );
  }

  const filterHeadCellMap = {
    [headCells[0].id]: {
      filter: nameFilter,
      setFilter: setNameFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[1].id]: {
      filter: emailAddressFilter,
      setFilter: setEmailAddressFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[2].id]: {
      filter: referenceFilter,
      setFilter: setReferenceFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[3].id]: {
      filter: userFilter,
      setFilter: setUserFilter,
      filterComponent: FilterSearchBar(t)
    },
    [archivedCell.id]: {
      filter: archivedFilter,
      setFilter: setArchivedFilter,
      filterComponent: FilterDropdown(archivedCell.values, t)
    }
  };

  const resetAllFilters = useMemo(() => {
    return () => {
      setNameFilter("");
      setEmailAddressFilter("");
      setReferenceFilter("");
      setUserFilter("");
      setArchivedFilter("");
    };
  }, []);

  const handleRowSelected = async (row: any) => {
    setSelectedExternalSystem(row);
  };

  const handleRefresh = async () => {
    await fetchExternalSystems(isArchivedVisible);
    resetAllFilters();
  };

  const visibleHeadCells = [
    ...headCells,
    ...(isArchivedVisible ? [archivedCell] : [])
  ];
  function handleCloseSnackbar(): void {
    resetExtertnalSystemErr();
  }
  return (
    <Grid container direction="row" wrap="nowrap">
      <CustomSnackBar
        variant="filled"
        open={deleteSuccessMsgFlag}
        autoHideDuration={3000}
        message={deleteSuccessMsg}
        onClose={handleCloseSnackbar}
        severity="success"
      />
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleMainranges]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.externalSystem.isLoadingFetch,
  externalSystems: state.externalSystem.externalSystems,
  deleteSuccessMsg: state.externalSystem.deleteSuccessMsg,
  archiveSuccessMsg: state.externalSystem.archiveSuccessMsg,
  deleteSuccessMsgFlag: state.externalSystem.deleteSuccessMsgFlag
});

const connector = connect(mapStateToProps, {
  fetchExternalSystems,
  setSelectedExternalSystem,
  resetExtertnalSystemErr
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ExternalSystemsTable);
