import { Dispatch, FC, SetStateAction, useCallback } from "react";
import { ConnectedProps, connect } from "react-redux";
import TableHeader from "../common/TableHeader";
import { RootState } from "../../redux/store";
import {
  fetchExtertnalSystemExport,
  setSelectedExternalSystem,
} from "../../redux/actions/extenalSystemsAction";
interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const ExternalSystemsHeader: FC<Props> = ({
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  isLoadingExport,
  fetchExtertnalSystemExport,
  setSelectedExternalSystem,
}) => {
  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleExport = useCallback(() => {
    fetchExtertnalSystemExport(isArchivedVisible);
  }, [fetchExtertnalSystemExport, isArchivedVisible]);

  const handleAdd = useCallback(() => {
    setSelectedExternalSystem(null);
    setShowForm(true);
  }, [setSelectedExternalSystem, setShowForm]);

  return (
    <TableHeader
      title="External Systems Administration"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.externalSystem.isLoadingExport,
});

const connector = connect(mapStateToProps, {
  fetchExtertnalSystemExport,
  setSelectedExternalSystem,
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ExternalSystemsHeader);
