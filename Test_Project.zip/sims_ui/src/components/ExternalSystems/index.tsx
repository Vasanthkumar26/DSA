import React, { FC, useEffect, useState } from "react";
import { Box, Grid } from "@mui/material";
import ExternalSystemsHeader from "./ExternalSystemsHeader";
import ExternalSystemsTable from "./ExternalSystemsTable";
import ExternalSystemsAddEditForm from "./ExternalSystemsAddEditForm";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import { fetchExternalSystemUsers } from "../../services/ExternalSystemsApi";
import { ESUser } from "../../models";
import { showFailureSnackbar } from "../../redux/actions/snackbarAction";

interface Props extends PropsFromRedux {}

const ExternalSystems: FC<Props> = ({
  selectedExternalSystem,
  showFailureSnackbar
}) => {
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [esUsers, setEsUsers] = useState<ESUser[] | null>(null);

  useEffect(() => {
    if (!esUsers) {
      fetchExternalSystemUsers()
        .then((result) => setEsUsers(result))
        .catch(() => showFailureSnackbar("Error while loading users"));
    }
  }, [esUsers, showFailureSnackbar]);

  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <ExternalSystemsHeader
            isArchivedVisible={isArchivedVisible}
            setIsArchivedVisible={setIsArchivedVisible}
            setShowForm={setShowForm}
          />
          <ExternalSystemsTable isArchivedVisible={isArchivedVisible} />
        </Grid>
        {(showForm || selectedExternalSystem) && (
          <Grid item xs={12}>
            <ExternalSystemsAddEditForm
              setShowForm={setShowForm}
              esUsers={esUsers}
            />
          </Grid>
        )}
      </Grid>
    </Box>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedExternalSystem: state.externalSystem.selectedExternalSystem
});

const connector = connect(mapStateToProps, {
  showFailureSnackbar
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ExternalSystems);
