import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import ExternalSystems from "..";

describe("ExternalSystems", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<ExternalSystems />, {
      route: "/",
    });

    expect(container).toBeInTheDocument();
  });
});
