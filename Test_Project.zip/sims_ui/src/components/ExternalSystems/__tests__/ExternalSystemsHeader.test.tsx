import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import ExternalSystemsHeader from "../ExternalSystemsHeader";
import { screen, fireEvent, render } from "@testing-library/react";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { Store, AnyAction } from "redux";
import { fetchExtertnalSystemExport } from "../../../redux/actions/extenalSystemsAction";
import { ExternalSystemsActionTypes } from "../../../redux/actions/types";

const mockStore = configureStore([thunk]);

jest.mock("../../../redux/actions/extenalSystemsAction", () => ({
  fetchExtertnalSystemExport: jest.fn(),
}));

describe("header test", () => {
  let store: Store<unknown, AnyAction>;
  beforeEach(() => {
    store = mockStore({
      externalSystem: {
        externalSystems: ["a", "b"],
      },
      lang: {
        language: "en",
      },
    });
  });
  test("should load component without failed", () => {
    const { container } = renderWithAllWrappers(
      <ExternalSystemsHeader
        isArchivedVisible={false}
        setIsArchivedVisible={jest.fn()}
        setShowForm={jest.fn()}
      />
    );
    expect(container).toBeInTheDocument();
  });

  test("should render the export button",() => {
    renderWithAllWrappers(
      <ExternalSystemsHeader  isArchivedVisible={false}
      setIsArchivedVisible={jest.fn()}
      setShowForm={jest.fn()}/>
    );

    expect(screen.getByText(/Export/i)).toBeInTheDocument();
  });

  test("should call the handleExport on button click",async() => {
    // @ts-ignore: Unreachable code error
    fetchExtertnalSystemExport.mockImplementation(() => {
      return {
        type: ExternalSystemsActionTypes.FETCH_EXTERNAL_SYSTEM_EXPORT_SUCCESS,
        payload: { message: "successfull" },
      };
    });

    render(
      <Provider store={store}>
        <ExternalSystemsHeader isArchivedVisible={false}
      setIsArchivedVisible={jest.fn()}
      setShowForm={jest.fn()} />
      </Provider>
    );

    const button = screen.getByRole("export-button");
    await fireEvent.click(button);
    expect(fetchExtertnalSystemExport).toHaveBeenCalled();
  });


});
