// @ts-nocheck
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import "@testing-library/jest-dom";
import { screen, waitFor } from "@testing-library/react";
import ExternalSystemsTable from "../ExternalSystemsTable";
import { REACT_BASE_URL } from "../../../utils/common";

describe("HlrTable", () => {
  test("should render without crash", () => {
    const setShowForm = jest.fn();
    const { container } = renderWithAllWrappers(
      <ExternalSystemsTable
        isArchivedVisible={false}
        setShowForm={setShowForm}
      />
    );
    expect(container).toBeInTheDocument();
  });

  describe("API success", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/externalsystem/loadAll`,
        res: () => [
          {
            name: "test22",
            emailAddress: "abc_1@outlook",
            replyAddress: "abc_1@outlook.com",
            subject: "test subject",
            text: " test text",
            archived: false,
            users: [
              {
                userId: "1",
                userName: "user1"
              }
            ]
          }
        ]
      }
    ]);

    test("Table should show correct data when archived unchecked", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <ExternalSystemsTable
          isArchivedVisible={false}
          setShowForm={setShowForm}
        />
      );
      await waitFor(async () => {
        const hlrRows = await screen.findAllByTestId(/externalSystems-row/i);
        expect(hlrRows).toHaveLength(1);
      });
    });

    test("Table should show correct data when archived checked", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <ExternalSystemsTable
          isArchivedVisible={true}
          setShowForm={setShowForm}
        />
      );
      await waitFor(async () => {
        const hlrRows = await screen.findAllByTestId(/externalSystems-row/i);
        expect(hlrRows).toHaveLength(1);
      });
    });
  });
  describe("API Failure", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/externalsystem/loadAll`,
        status: 404,
        res: () => ({ message: "Oops! Something went wrong" })
      }
    ]);

    test("Table should show correct data when server down", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <ExternalSystemsTable
          isArchivedVisible={false}
          setShowForm={setShowForm}
        />
      );
      await waitFor(async () => {
        const hlrRows = screen.queryAllByTestId(/externalSystems-row/i);
        expect(hlrRows).toHaveLength(0);
      });
    });
  });
});
