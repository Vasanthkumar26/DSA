// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import ExternalSystemsAddEditForm from "../ExternalSystemsAddEditForm";

describe("ExternalSystemsAddEditForm", () => {
  test("should render without crash", async () => {
    const { container } = renderWithAllWrappers(<ExternalSystemsAddEditForm />);

    expect(container).toBeInTheDocument();
  });
});
