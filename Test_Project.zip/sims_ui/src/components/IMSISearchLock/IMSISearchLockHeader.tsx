import { Button, Stack, Typography } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import UploadFileRoundedIcon from "@mui/icons-material/UploadFileRounded";
import { handleImsiRangeExport } from "../../services/imsiSearchLockApi";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import { ConnectedProps, connect } from "react-redux";
import { FC } from "react";

interface Props extends PropsFromRedux {}

const IMSISearchLockHeader: FC<Props> = ({
  showSuccessSnackbar,
  showFailureSnackbar
}) => {
  const t = useTranslation();

  const handleExport = () => {
    handleImsiRangeExport()
      .then(() => showSuccessSnackbar(t("successfully_exported")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")));
  };

  return (
    <Stack direction="row" paddingBottom={2} justifyContent="space-between">
      <Typography variant="h5" sx={{ fontWeight: 600 }}>
        {t("imsi_search_lock")}
      </Typography>
      <Button
        sx={{
          textTransform: "none",
          color: "black",
          textDecoration: "underline"
        }}
        onClick={handleExport}
        startIcon={<UploadFileRoundedIcon color="primary" />}
      >
        <Typography>{t("Export")}</Typography>
      </Button>
    </Stack>
  );
};

const connector = connect(null, {
  showSuccessSnackbar,
  showFailureSnackbar
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(IMSISearchLockHeader);
