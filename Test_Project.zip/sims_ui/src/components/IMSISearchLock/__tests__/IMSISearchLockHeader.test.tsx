// @ts-nocheck
import "@testing-library/jest-dom";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import IMSISearchLockHeader from "../IMSISearchLockHeader";
import { ISL_SUCCESS_API_HANDLERS } from "../../../_mocks_";

describe("IMSISearchLockHeader", () => {
  createServer(ISL_SUCCESS_API_HANDLERS);
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<IMSISearchLockHeader />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
