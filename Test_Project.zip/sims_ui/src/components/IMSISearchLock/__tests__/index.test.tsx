// @ts-nocheck
import "@testing-library/jest-dom";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import IMSISearchLock from "..";
import { ISL_SUCCESS_API_HANDLERS } from "../../../_mocks_";

describe("IMSISearchLock", () => {
  createServer(ISL_SUCCESS_API_HANDLERS);
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<IMSISearchLock />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
