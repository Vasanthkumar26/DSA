/* eslint-disable testing-library/no-node-access */
// @ts-nocheck
import "@testing-library/jest-dom";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import IMSISearchLockForm from "../IMSISearchLockForm";
import { fireEvent, screen, waitFor } from "@testing-library/react";
import { ISL_SUCCESS_API_HANDLERS } from "../../../_mocks_";

describe("ExternalSystemsAddEditForm", () => {
  createServer(ISL_SUCCESS_API_HANDLERS);
  test("should render without crash", async () => {
    const { container } = renderWithAllWrappers(<IMSISearchLockForm />);

    expect(container).toBeInTheDocument();
  });

  test("should be able to release or blacklist", async () => {
    renderWithAllWrappers(<IMSISearchLockForm />);

    expect(await screen.findByTestId("imsi_from")).toBeInTheDocument();
    expect(await screen.findByTestId("imsi_to")).toBeInTheDocument();

    const imsiFrom = screen.getByTestId("imsi_from")?.querySelector("input");
    const imsiTo = screen.getByTestId("imsi_to")?.querySelector("input");

    fireEvent.change(imsiFrom, { target: { value: "1234567" } });
    fireEvent.change(imsiTo, { target: { value: "1234567" } });

    const searchBtn = await screen.findByTestId(/search/i);
    expect(searchBtn).toBeInTheDocument();
    await fireEvent.click(searchBtn);
    await waitFor(async () => {
      const imsirangeRows = await screen.findAllByTestId(/imsirange-row/i);
      expect(imsirangeRows).toHaveLength(1);
    });
  });
});
