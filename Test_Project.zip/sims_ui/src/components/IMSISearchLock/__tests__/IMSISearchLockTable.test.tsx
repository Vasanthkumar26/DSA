// @ts-nocheck
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import "@testing-library/jest-dom";
import { screen, waitFor } from "@testing-library/react";
import IMSISearchLockTable from "../IMSISearchLockTable";
import {
  ISL_SUCCESS_API_HANDLERS,
  searchImsiAllocationResponse
} from "../../../_mocks_/imsiSearchHandlers";

describe("IMSISearchLockTable", () => {
  createServer(ISL_SUCCESS_API_HANDLERS);
  test("should render without crash", () => {
    const { container } = renderWithAllWrappers(<IMSISearchLockTable />);
    expect(container).toBeInTheDocument();
  });

  describe("API success", () => {
    test("Table should show correct data", async () => {
      renderWithAllWrappers(
        <IMSISearchLockTable imsiRanges={searchImsiAllocationResponse} />
      );
      await waitFor(async () => {
        const imsirangeRows = await screen.findAllByTestId(/imsirange-row/i);
        expect(imsirangeRows).toHaveLength(1);
      });
    });
  });
});
