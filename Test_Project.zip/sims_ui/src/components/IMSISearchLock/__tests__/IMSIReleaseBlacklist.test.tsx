/* eslint-disable testing-library/no-node-access */
// @ts-nocheck
import "@testing-library/jest-dom";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import IMSIReleaseBlacklist from "../IMSIReleaseBlacklist";
import { fireEvent, screen, waitFor } from "@testing-library/react";
import { ISL_SUCCESS_API_HANDLERS } from "../../../_mocks_";

describe("IMSIReleaseBlacklist", () => {
  createServer(ISL_SUCCESS_API_HANDLERS);

  test("should render without crash", async () => {
    const { container } = renderWithAllWrappers(<IMSIReleaseBlacklist />);

    expect(container).toBeInTheDocument();
  });

  test("should be able to release or blacklist", async () => {
    renderWithAllWrappers(<IMSIReleaseBlacklist />);

    expect(await screen.findByTestId("imsi_from")).toBeInTheDocument();
    expect(await screen.findByTestId("imsi_to")).toBeInTheDocument();

    const imsiFrom = screen.getByTestId("imsi_from")?.querySelector("input");
    const imsiTo = screen.getByTestId("imsi_to")?.querySelector("input");

    fireEvent.change(imsiFrom, { target: { value: "1234567" } });
    fireEvent.change(imsiTo, { target: { value: "1234567" } });

    const releaseBtn = await screen.findByTestId(/release/i);
    const blacklistBtn = await screen.findByTestId(/blacklist/i);
    expect(releaseBtn).toBeInTheDocument();
    expect(blacklistBtn).toBeInTheDocument();

    await waitFor(async () => {
      await fireEvent.click(releaseBtn);
      await fireEvent.click(blacklistBtn);
    });
  });
});
