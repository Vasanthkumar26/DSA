import { FC, useCallback, useState } from "react";
import { Button, Grid, Stack } from "@mui/material";
import { StyledFormBox } from "../common/styles/shared";
import { FormControllerTextField } from "../common/AddEditForm";
import { useTranslation } from "../../hooks/useTranslation";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import { useForm } from "react-hook-form";
import {
  ActionType,
  imsiReleaseBlacklistInitData,
  imsiSearchLockSchema
} from "./IMSISearchLock.data";
import {
  addToBlocklist,
  releaseBlocklisted
} from "../../services/imsiSearchLockApi";
import { showSuccessSnackbar } from "../../redux/actions/snackbarAction";
import { ConnectedProps, connect } from "react-redux";

interface Props extends PropsFromRedux {}

const IMSIReleaseBlacklist: FC<Props> = ({ showSuccessSnackbar }) => {
  const [actionType, setActionType] = useState(ActionType.None);
  const resolver = useYupValidationResolver(imsiSearchLockSchema);
  const { control, handleSubmit } = useForm({
    mode: "all",
    resolver,
    defaultValues: { ...imsiReleaseBlacklistInitData }
  });
  const t = useTranslation();

  const onSubmit = useCallback(
    (data: any) => {
      const payload = {
        startIMSI: data?.imsiFrom ?? "",
        endIMSI: data?.imsiTo ?? ""
      };
      if (actionType === ActionType.Blacklist) {
        addToBlocklist(payload).then(() =>
          showSuccessSnackbar("Request processed successfully")
        );
      } else {
        releaseBlocklisted(payload).then(() =>
          showSuccessSnackbar("Request processed successfully")
        );
      }
    },
    [actionType, showSuccessSnackbar]
  );

  return (
    <StyledFormBox component="form" onSubmit={handleSubmit(onSubmit)}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={4}>
          <FormControllerTextField
            required
            control={control}
            controlName="imsiFrom"
            inputLabel="imsi_from"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <FormControllerTextField
            required
            control={control}
            controlName="imsiTo"
            inputLabel="imsi_to"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={4}>
          <Stack
            direction="row"
            height="100%"
            alignItems="flex-end"
            spacing={2}
          >
            <Button
              type="submit"
              variant="contained"
              onClick={() => setActionType(ActionType.Release)}
              data-testid="release"
            >
              {t("release")}
            </Button>
            <Button
              type="submit"
              variant="contained"
              onClick={() => setActionType(ActionType.Blacklist)}
              data-testid="blacklist"
            >
              {t("blacklist")}
            </Button>
          </Stack>
        </Grid>
      </Grid>
    </StyledFormBox>
  );
};

const connector = connect(null, {
  showSuccessSnackbar
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(IMSIReleaseBlacklist);
