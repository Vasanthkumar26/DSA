import { FC, useCallback, useEffect, useState } from "react";
import { Box, Button, Grid, Stack } from "@mui/material";
import { FormControllerTextField } from "../common/AddEditForm";
import { useForm } from "react-hook-form";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import {
  ActionType,
  createSLPayload,
  getSearchFilterData,
  imsiSearchLockSchema,
  initData
} from "./IMSISearchLock.data";
import { useTranslation } from "../../hooks/useTranslation";
import IMSISearchLockTable from "./IMSISearchLockTable";
import {
  addToBlocklist,
  fetchSearchFilterData,
  fetchSearchImsiAllocation,
  releaseBlocklisted
} from "../../services/imsiSearchLockApi";

import { ImsiRange, SFData } from "../../models";
import { SPSelectWithSearch } from "../common/AddEditForm/SPSelectWithSearch";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import { showSuccessSnackbar } from "../../redux/actions/snackbarAction";
import { resetPage } from "../../redux/actions/rootAction";

interface Props extends PropsFromRedux {}

const IMSISearchLockForm: FC<Props> = ({ showSuccessSnackbar, resetPage }) => {
  const [hlrs, setHlrs] = useState<SFData[] | null>(null);
  const [productTypes, setProductTypes] = useState<SFData[] | null>(null);
  const [cardTypes, setCardTypes] = useState<SFData[] | null>(null);
  const [status, setStatus] = useState<SFData[] | null>(null);
  const [imsiRanges, setImsiRanges] = useState<ImsiRange[] | null>(null);
  const [selImsiRange, setSelImsiRange] = useState<ImsiRange | null>(null);
  const resolver = useYupValidationResolver(imsiSearchLockSchema);
  const { control, handleSubmit } = useForm({
    mode: "all",
    resolver,
    defaultValues: { ...initData }
  });
  const t = useTranslation();

  useEffect(() => {
    fetchSearchFilterData().then((result) => {
      result.listStatus = [
        {
          id: "1",
          label: "Frei (Available)",
          name: "Frei (Available)",
          archived: true
        },
        {
          id: "2",
          label: "Vergeben (Used)",
          name: "Vergeben (Used)",
          archived: true
        },
        {
          id: "3",
          label: "Gesperrt (Blocked)",
          name: "Gesperrt (Blocked)",
          archived: true
        },
        {
          id: "4",
          label: "Alle (pro Order)",
          name: "Alle (pro Order)",
          archived: true
        },
        {
          id: "5",
          label: "Alle (Status-Übersicht)",
          name: "Alle (Status-Übersicht)",
          archived: true
        }
      ];

      setHlrs(getSearchFilterData(result?.listHlr));
      setProductTypes(getSearchFilterData(result?.listProductType));
      setCardTypes(getSearchFilterData(result?.listCardType));
      setStatus(getSearchFilterData(result?.listStatus));
    });
  }, []);

  const onSubmit = useCallback((data: any) => {
    const payload = createSLPayload(data);
    fetchSearchImsiAllocation(payload).then((data) => setImsiRanges(data));
  }, []);

  const loadSelectList = (list: SFData[]) =>
    (list ?? []).map((value) => ({
      label: value?.name ?? "",
      id: `${value?.id ?? 0}`
    }));

  const handleAction = (actionType: ActionType) => {
    if (!selImsiRange) {
      return;
    }
    const payload = {
      startIMSI: selImsiRange?.startImsi ?? "",
      endIMSI: selImsiRange?.endImsi ?? ""
    };
    if (actionType === ActionType.Blacklist) {
      addToBlocklist(payload)
        .then(() => showSuccessSnackbar(t("request_processed_successfully")))
        .finally(() => resetPage());
    } else {
      releaseBlocklisted(payload)
        .then(() => showSuccessSnackbar(t("request_processed_successfully")))
        .finally(() => resetPage());
    }
  };

  return (
    <>
      <Box
        component="form"
        onSubmit={handleSubmit(onSubmit)}
        sx={{ backgroundColor: "#F3F4FF" }}
      >
        <Grid container spacing={2} padding="20px">
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerTextField
              required
              control={control}
              controlName="imsiFrom"
              inputLabel="imsi_from"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerTextField
              required
              control={control}
              controlName="imsiTo"
              inputLabel="imsi_to"
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerSelectWithSearch
              control={control}
              controlName="hlr"
              inputLabel="HLR"
              options={loadSelectList(hlrs ?? [])}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerSelectWithSearch
              control={control}
              controlName="productType"
              inputLabel="product_type"
              options={loadSelectList(productTypes ?? [])}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerSelectWithSearch
              control={control}
              controlName="cardType"
              inputLabel="card_type"
              options={loadSelectList(cardTypes ?? [])}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <SPSelectWithSearch
              control={control}
              controlName="serviceProvider"
              inputLabel={"serv_provider"}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerSelectWithSearch
              control={control}
              controlName="status"
              inputLabel="Status"
              options={loadSelectList(status ?? [])}
            />
          </Grid>
        </Grid>
        <Stack
          direction="row-reverse"
          justifyContent="space-between"
          paddingY={2}
          sx={{ background: "white" }}
        >
          <Button variant="contained" type="submit" data-testid="search">
            {t("search")}
          </Button>
          {selImsiRange && (
            <Stack direction="row" height="100%" spacing={2}>
              <Button
                type="submit"
                variant="contained"
                onClick={() => handleAction(ActionType.Release)}
                data-testid="release"
              >
                {t("release")}
              </Button>
              <Button
                type="submit"
                variant="contained"
                onClick={() => handleAction(ActionType.Blacklist)}
                data-testid="blacklist"
              >
                {t("blacklist")}
              </Button>
            </Stack>
          )}
        </Stack>
      </Box>
      {imsiRanges && (
        <IMSISearchLockTable
          imsiRanges={imsiRanges}
          setSelectedImsiRange={setSelImsiRange}
        />
      )}
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  showSuccessSnackbar,
  resetPage
});

const connector = connect(mapStateToProps, {});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(IMSISearchLockForm);
