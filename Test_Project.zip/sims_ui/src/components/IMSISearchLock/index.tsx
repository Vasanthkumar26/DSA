import React, { FC } from "react";
import { Box, Grid } from "@mui/material";
import IMSISearchLockForm from "./IMSISearchLockForm";
import IMSIReleaseBlacklist from "./IMSIReleaseBlacklist";
import IMSISearchLockHeader from "./IMSISearchLockHeader";

const IMSISearchLock: FC = () => {
  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <IMSISearchLockHeader />
        </Grid>
        <Grid item xs={12}>
          <IMSISearchLockForm />
        </Grid>
        <Grid item xs={12}>
          <IMSIReleaseBlacklist />
        </Grid>
      </Grid>
    </Box>
  );
};

export default IMSISearchLock;
