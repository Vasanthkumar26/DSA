import { FC } from "react";
import TableView from "../common/TableView";
import { Grid } from "@mui/material";
import {
  imsiRangeHeadCells,
  imsiRangeTableConfig
} from "./IMSISearchLock.data";
import { fetchImsiRanges } from "../../redux/actions/imsiSearchLockAction";
import { ImsiRange } from "../../models";

interface Props {
  imsiRanges: ImsiRange[];
  setSelectedImsiRange: React.Dispatch<React.SetStateAction<ImsiRange | null>>;
}

const IMSISearchLockTable: FC<Props> = ({
  imsiRanges = [],
  setSelectedImsiRange
}) => {
  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={false}
        visibleHeadCells={imsiRangeHeadCells}
        visibleItems={[...imsiRanges]}
        handleRowSelected={(row) => setSelectedImsiRange(row)}
        handleRefresh={fetchImsiRanges}
        tableConfig={imsiRangeTableConfig}
        filterHeadCellMap={undefined}
        isFilterSortingVisible={false}
      />
    </Grid>
  );
};

export default IMSISearchLockTable;
