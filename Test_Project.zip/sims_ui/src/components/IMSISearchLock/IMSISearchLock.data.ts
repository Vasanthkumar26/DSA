import * as yup from "yup";
import { HeadCell, SFData, TableConfig } from "../../models";

export const initData = {
  imsiFrom: "",
  status: {
    id: "4",
    label: "Alle (pro Order)",
    archived: true
  }
};

export const imsiReleaseBlacklistInitData = {
  imsiFrom: "",
  imsiTo: ""
};

export const imsiSearchLockSchema = yup.object().shape({
  imsiFrom: yup.string().required("IMSI is missing")
});

export const imsiReleaseBlacklistSchema = yup.object().shape({
  imsiFrom: yup.string().required("IMSI from is missing"),
  imsiTo: yup.string().required("IMSI to is missing")
});

export const imsiRangeHeadCells: Array<HeadCell> = [
  { id: "startImsi", label: "start_imsi" },
  { id: "endImsi", label: "end_imsi" },
  { id: "number", label: "number" },
  { id: "hlr", label: "hlr" },
  { id: "status", label: "status" },
  { id: "productType", label: "product_type" },
  { id: "orderNumber", label: "order_number" },
  { id: "cartType", label: "card_type" },
  { id: "serviceProvider", label: "serv_provider" }
];

export const imsiRangeTableConfig: TableConfig = {
  title: "",
  orderBy: "lastUpdateDate",
  tableRowTestId: "imsirange-row"
};

export enum ActionType {
  None,
  Blacklist,
  Release
}

export const getSearchFilterData = (data: Array<any>) => {
  if (!data || data?.length === 0) {
    return null;
  }
  const sfData = data?.map(
    (value) =>
      ({
        id: value?.id ?? "",
        name: value?.name ?? "",
        archived: value?.archived ?? false
      } as SFData)
  );
  return sfData;
};

export const createSLPayload = (data: Record<string, any>) => ({
  systemStack: data?.serviceProvider?.id ?? "",
  startIMSIForSearch: data?.imsiFrom ?? "",
  endIMSIForSearch: data?.imsiTo ?? "",
  status: data?.status?.id ?? "",
  prodType: data?.productType?.id ?? "",
  cardTypeICCID: data?.cardType?.id ?? "",
  hlrname: data?.hlr?.id ?? ""
});
