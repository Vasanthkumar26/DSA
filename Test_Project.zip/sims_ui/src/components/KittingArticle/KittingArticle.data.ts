export const initData = {
  article_number: "",
  description: "",
  systemStackId: null,
  startPackType: null,
  comment: ""
};

export const setFormData = (data: any, serviceProviders: any) => ({
  article_number: data?.article_number ?? "",
  description: data?.description ?? "",
  systemStackId:
    serviceProviders.find((item: any) => item.id === data?.systemStackId) ?? "",
  startPackType: data?.startPackType ?? "",
  comment: data?.comment ?? ""
});

export const createKAPayload = (data: any) => ({
  articleNumber: data?.article_number ?? "",
  description: data?.description ?? "",
  starterPackType: `${data?.startPackType ?? ""}`,
  comment: data?.comment ?? "",
  archived: false,
  systemStackId: `${data?.systemStackId?.id ?? null}`,
  userName: "123"
});
