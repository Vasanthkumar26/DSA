// @ts-nocheck
import { Box, Grid } from "@mui/material";
import React, { useState } from "react";
import KittingArticleHeader from "./KittingArticleHeader";
import KittingArticleForm from "./KittingArticleForm";
import { connect } from "react-redux";
import KittingArticleTable from "./KittingArticleTable";

const KittingArticle = ({ articleData }) => {
  const [showForm, setShowForm] = useState(false);
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);

  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={1}>
        <Grid item xs={12}>
          <KittingArticleHeader
            setShowForm={setShowForm}
            resetForm={() => {}}
            isArchivedVisible={isArchivedVisible}
            setIsArchivedVisible={setIsArchivedVisible}
          />
          <KittingArticleTable isArchivedVisible={isArchivedVisible} />
        </Grid>
        <Grid item xs={12}>
          {(showForm || !!articleData) && (
            <KittingArticleForm setShowForm={setShowForm} />
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

const mapStateToProps = ({ kittingArticles }) => ({
  articleData: kittingArticles.selectedKittingArticle
});

export default connect(mapStateToProps, {})(KittingArticle);
