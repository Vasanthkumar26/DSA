import React, { useState } from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { fetchKittingArticlesExport } from "../../../redux/actions/kittingArticleAction";
import { FETCH_KITTING_ARTICLES_EXPORT_SUCCESS } from "../../../redux/actions/types";
import KittingArticleHeader from "../KittingArticleHeader";

jest.mock("../../../redux/actions/kittingArticleAction", () => ({
  fetchKittingArticlesExport: jest.fn(),
}));

const mockStore = configureStore([thunk]);

describe("Header Component", () => {
  let store;

  beforeEach(() => {
    store = mockStore({
      kittingArticles: {
        isLoadingExport: false,
      },
      lang: {
        language: "en",
      },
    });
  });

  test("renders the component without crashing", () => {
    render(
      <Provider store={store}>
        <KittingArticleHeader />
      </Provider>
    );
  });

  test("renders the correct title", () => {
    render(
      <Provider store={store}>
        <KittingArticleHeader />
      </Provider>
    );
    expect(
      screen.getByText(/Kitting Article Administration/i)
    ).toBeInTheDocument();
  });

  test("renders the export button", () => {
    render(
      <Provider store={store}>
        <KittingArticleHeader />
      </Provider>
    );
    expect(screen.getByText(/Export/i)).toBeInTheDocument();
  });

  test("disables the export button when isLoadingExport is true", () => {
    store = mockStore({
      kittingArticles: {
        isLoadingExport: true,
      },
      lang: {
        language: "en",
      },
    });
    render(
      <Provider store={store}>
        <KittingArticleHeader />
      </Provider>
    );
    expect(screen.getByRole("export-button")).toBeDisabled();
  });

  test("calls fetchKittingArticlesExport when the export button is clicked", () => {
    fetchKittingArticlesExport.mockImplementation(() => {
      return {
        type: FETCH_KITTING_ARTICLES_EXPORT_SUCCESS,
        payload: { message: "successfull" },
      };
    });
    render(
      <Provider store={store}>
        <KittingArticleHeader />
      </Provider>
    );

    const button = screen.getByRole("export-button");
    fireEvent.click(button);
    expect(fetchKittingArticlesExport).toHaveBeenCalled();
  });

  test("calls setIsArchivedVisible when the archived checkbox is clicked", () => {
    const mockSetIsArchivedVisible = jest.fn();
    render(
      <Provider store={store}>
        <KittingArticleHeader setIsArchivedVisible={mockSetIsArchivedVisible} />
      </Provider>
    );
    fireEvent.click(screen.getByLabelText(/Archived/i));
    expect(mockSetIsArchivedVisible).toHaveBeenCalled();
  });

  test("toggles the archived checkbox when clicked", () => {
    const Wrapper = () => {
      const [isArchivedVisible, setIsArchivedVisible] = useState(false);

      return (
        <Provider store={store}>
          <KittingArticleHeader
            isArchivedVisible={isArchivedVisible}
            setIsArchivedVisible={setIsArchivedVisible}
          />
        </Provider>
      );
    };

    render(<Wrapper />);
    const checkbox = screen.getByLabelText(/Archived/i);
    expect(checkbox).not.toBeChecked();
    fireEvent.click(checkbox);
    expect(checkbox).toBeChecked();
  });
});
