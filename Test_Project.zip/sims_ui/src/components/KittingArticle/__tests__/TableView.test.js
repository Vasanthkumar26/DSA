import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import userEvent from "@testing-library/user-event";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureMockStore from "redux-mock-store";
import TableView from "../KittingArticleTable";
import {
  fetchKittingArticles,
  setSelectedKittingArticle,
} from "../../../redux/actions/kittingArticleAction";
import {
  FETCH_KITTING_ARTICLES_REQUEST,
  FETCH_KITTING_ARTICLES_SUCCESS,
  SET_SELECTED_KITTING_ARTICLE,
} from "../../../redux/actions/types";

jest.mock("../../../redux/actions/kittingArticleAction", () => ({
  fetchKittingArticles: jest.fn(),
  setSelectedKittingArticle: jest.fn(),
}));

const mockStore = configureMockStore([thunk]);

describe.skip("TableView", () => {
  let store;
  let kittingArticles;
  let isLoadingFetch;
  let isArchivedVisible;

  beforeEach(() => {
    kittingArticles = [
      {
        article_number: "123",
        description: "Article 123",
        systemStackId: "Service 1",
        startPackType: "Only with tariff",
        archived: false,
      },
      {
        article_number: "456",
        description: "Article 456",
        systemStackId: "Service 2",
        startPackType: "With MSISDN & tariff",
        archived: true,
      },
      {
        article_number: "789",
        description: "Article 789",
        systemStackId: "Service 3",
        startPackType: "Only with tariff",
        archived: false,
      },
    ];
    isLoadingFetch = false;
    isArchivedVisible = true;
    store = mockStore({
      kittingArticles: {
        kittingArticles,
        isLoadingFetch,
      },
      lang: {
        language: "en",
      },
    });
  });

  afterEach(() => {
    jest.resetAllMocks();
  });

  test("renders the table with the correct columns", () => {
    fetchKittingArticles.mockImplementation(() => {
      return {
        type: FETCH_KITTING_ARTICLES_SUCCESS,
        payload: { kittingArticles },
      };
    });

    render(
      <Provider store={store}>
        <TableView isArchivedVisible={isArchivedVisible} />
      </Provider>
    );

    const articleNumberColumn = screen.getByText("Article Number");
    expect(articleNumberColumn).toBeInTheDocument();

    const descriptionColumn = screen.getByText("Description");
    expect(descriptionColumn).toBeInTheDocument();

    const serviceProviderColumn = screen.getByText("Service Provider");
    expect(serviceProviderColumn).toBeInTheDocument();

    const startPackColumn = screen.getByText("Start Pack");
    expect(startPackColumn).toBeInTheDocument();

    const archivedColumn = screen.getByText("Archived");
    expect(archivedColumn).toBeInTheDocument();
  });

  test("displays a skeleton when loading", () => {
    const store = mockStore({
      kittingArticles: {
        kittingArticles: [],
        isLoadingFetch: true,
      },
      lang: {
        language: "en",
      },
    });

    fetchKittingArticles.mockImplementation(() => {
      return {
        type: FETCH_KITTING_ARTICLES_REQUEST,
      };
    });

    render(
      <Provider store={store}>
        <TableView isArchivedVisible={isArchivedVisible} />
      </Provider>
    );

    const skeleton = screen.getAllByRole("progressbar");
    expect(skeleton[0]).toBeInTheDocument();
  });

  test("displays the list of kitting articles when loaded", () => {
    fetchKittingArticles.mockImplementation(() => {
      return {
        type: FETCH_KITTING_ARTICLES_REQUEST,
      };
    });

    render(
      <Provider store={store}>
        <TableView isArchivedVisible={isArchivedVisible} />
      </Provider>
    );

    const articleNumberCells = screen.getAllByTestId(
      "table-cell-article_number"
    );
    expect(articleNumberCells).toHaveLength(3);

    const descriptionCells = screen.getAllByTestId("table-cell-description");
    expect(descriptionCells).toHaveLength(3);

    const serviceProviderCells = screen.getAllByTestId(
      "table-cell-systemStackId"
    );
    expect(serviceProviderCells).toHaveLength(3);
  });

  test("does not display archived kitting articles when loaded", () => {
    fetchKittingArticles.mockImplementation(() => {
      return {
        type: FETCH_KITTING_ARTICLES_REQUEST,
      };
    });

    render(
      <Provider store={store}>
        <TableView isArchivedVisible={false} />
      </Provider>
    );

    const articleNumberCells = screen.getAllByTestId(
      "table-cell-article_number"
    );
    expect(articleNumberCells).toHaveLength(2);

    const descriptionCells = screen.getAllByTestId("table-cell-description");
    expect(descriptionCells).toHaveLength(2);

    const serviceProviderCells = screen.getAllByTestId(
      "table-cell-systemStackId"
    );
    expect(serviceProviderCells).toHaveLength(2);
  });

  test("does display error if there are no visible kitting articles when loaded", () => {
    fetchKittingArticles.mockImplementation(() => {
      return {
        type: FETCH_KITTING_ARTICLES_REQUEST,
      };
    });
    const store = mockStore({
      kittingArticles: {
        kittingArticles: [],
        isLoadingFetch,
      },
      lang: {
        language: "en",
      },
    });

    render(
      <Provider store={store}>
        <TableView isArchivedVisible={false} />
      </Provider>
    );

    const errMessage = screen.getByText("Sorry! There is nothing to show here");
    expect(errMessage).toBeInTheDocument();
  });

  test("should filter kitting articles based on value", () => {
    fetchKittingArticles.mockImplementation(() => {
      return {
        type: FETCH_KITTING_ARTICLES_SUCCESS,
        payload: { kittingArticles },
      };
    });

    render(
      <Provider store={store}>
        <TableView isArchivedVisible={true} />
      </Provider>
    );

    const filterButtons = screen.getAllByTestId("filter-button");
    fireEvent.click(filterButtons[filterButtons.length - 1]);

    let dropDownInput = screen.getByLabelText("Select");
    userEvent.click(dropDownInput);

    let options = screen.getAllByRole("option");
    userEvent.click(options[1]);

    let articleNumberCells = screen.getAllByTestId("table-cell-article_number");
    expect(articleNumberCells).toHaveLength(1);
    fireEvent.click(filterButtons[filterButtons.length - 1]);

    dropDownInput = screen.getByLabelText("Select");
    userEvent.click(dropDownInput);

    options = screen.getAllByRole("option");
    userEvent.click(options[2]);

    articleNumberCells = screen.getAllByTestId("table-cell-article_number");
    expect(articleNumberCells).toHaveLength(2);
  });

  test("should close modal when clicked on filter twice", () => {
    fetchKittingArticles.mockImplementation(() => {
      return {
        type: FETCH_KITTING_ARTICLES_SUCCESS,
        payload: { kittingArticles },
      };
    });

    render(
      <Provider store={store}>
        <TableView isArchivedVisible={true} />
      </Provider>
    );

    const filterButtons = screen.getAllByTestId("filter-button");
    fireEvent.click(filterButtons[0]);

    let input = screen.getByLabelText("Search");
    expect(input).toBeInTheDocument();

    userEvent.click(screen.getByLabelText("Outside-test-element"));
    expect(input).not.toBeInTheDocument();
  });

  test("should sort kitting articles based on column", () => {
    fetchKittingArticles.mockImplementation(() => {
      return {
        type: FETCH_KITTING_ARTICLES_SUCCESS,
        payload: { kittingArticles },
      };
    });

    render(
      <Provider store={store}>
        <TableView isArchivedVisible={true} />
      </Provider>
    );

    let expectedArticleNumberOrder = kittingArticles
      .map((kittingArticle) => kittingArticle.article_number)
      .sort();

    const sortButton = screen.getAllByRole("sort-icon");
    userEvent.click(sortButton[0]);
    let sortedArticleNumber = screen
      .getAllByTestId("table-cell-article_number")
      .map((elem) => elem.innerHTML);

    expect(expectedArticleNumberOrder).toEqual(sortedArticleNumber);
    userEvent.click(sortButton[0]);
    sortedArticleNumber = screen
      .getAllByTestId("table-cell-article_number")
      .map((elem) => elem.innerHTML);
    expect(expectedArticleNumberOrder.reverse()).toEqual(sortedArticleNumber);
  });

  test("should reset all filters on reset button click", () => {
    fetchKittingArticles.mockImplementation(() => {
      return {
        type: FETCH_KITTING_ARTICLES_SUCCESS,
        payload: { kittingArticles },
      };
    });

    render(
      <Provider store={store}>
        <TableView isArchivedVisible={true} />
      </Provider>
    );

    const filterButtons = screen.getAllByTestId("filter-button");
    fireEvent.click(filterButtons[filterButtons.length - 1]);

    const dropDownInput = screen.getByLabelText("Select");
    userEvent.click(dropDownInput);

    const options = screen.getAllByRole("option");
    userEvent.click(options[1]);

    let articleNumberCells = screen.getAllByTestId("table-cell-article_number");
    expect(articleNumberCells).toHaveLength(1);

    const refreshButton = screen.getByTestId("refresh-button");
    fireEvent.click(refreshButton);

    articleNumberCells = screen.getAllByTestId("table-cell-article_number");
    expect(articleNumberCells).toHaveLength(3);
  });

  test("dispatches SET_SELECTED_KITTING_ARTICLE event on row click", () => {
    fetchKittingArticles.mockImplementation(() => {
      return {
        type: FETCH_KITTING_ARTICLES_SUCCESS,
        payload: { kittingArticles },
      };
    });
    setSelectedKittingArticle.mockImplementation((kittingArticle) => {
      return {
        type: SET_SELECTED_KITTING_ARTICLE,
        payload: { kittingArticle },
      };
    });

    render(
      <Provider store={store}>
        <TableView isArchivedVisible={true} />
      </Provider>
    );

    const row = screen.getByTestId("kitting-article-row-0");
    fireEvent.click(row);

    expect(setSelectedKittingArticle).toBeCalledWith(kittingArticles[2]);
  });
});
