import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import KittingArticle from "..";

describe("KittingArticle", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<KittingArticle />, {
      route: "/",
    });

    expect(container).toBeInTheDocument();
  });
});
