/* eslint-disable testing-library/prefer-find-by */
import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import userEvent from "@testing-library/user-event";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureMockStore from "redux-mock-store";
import KittingArticleForm from "../KittingArticleForm";

jest.mock("../../../redux/actions/kittingArticleAction", () => ({
  createArticle: jest.fn(),
  fetchOffers: jest.fn(),
  articleReset: jest.fn(),
}));

const mockStore = configureMockStore([thunk]);

describe.skip("KittingArticleForm", () => {
  let store;
  let offers;
  let serviceProvider;
  let starterPack;

  beforeEach(() => {
    serviceProvider = [
      { id: 1, name: "sp-1" },
      { id: 2, name: "sp-2" },
    ];
    starterPack = [
      { id: 1, name: "spack-1" },
      { id: 2, name: "spack-2" },
    ];
    offers = [
      { id: 1, name: "value-1" },
      { id: 2, name: "value-2" },
    ];
    store = mockStore({
      kittingArticles: {
        offers,
        isLoading: false,
        serviceProvider,
        starterPack,
      },
      lang: {
        language: "en",
      },
    });
  });

  afterEach(() => {
    jest.resetAllMocks();
  });

  test("should render the basic fields", () => {
    render(
      <Provider store={store}>
        <KittingArticleForm />
      </Provider>
    );

    expect(screen.getByTestId("article-number")).toBeInTheDocument();
    expect(screen.getByTestId("description")).toBeInTheDocument();
    expect(screen.getByTestId("comment")).toBeInTheDocument();
    expect(screen.getByTestId("service-provider")).toBeInTheDocument();
    expect(screen.getByTestId("starter-pack")).toBeInTheDocument();
    expect(screen.getByTestId("submit")).toBeInTheDocument();
    expect(screen.getByTestId("offers")).toBeInTheDocument();
    expect(screen.getByTestId("cancel")).toBeInTheDocument();
  });

  test("should populate service provider", async () => {
    render(
      <Provider store={store}>
        <KittingArticleForm />
      </Provider>
    );

    const selectNode = screen.getByTestId("service-provider");
    const selectButton = screen.getAllByRole("button");

    expect(selectNode).not.toBeNull();

    userEvent.click(selectButton[0]);

    await screen.findByText(/sp-1/i);
    const itemClickable = screen.getByText(/sp-1/i);
    expect(itemClickable).not.toBeNull();
  });

  test("should populate offers", async () => {
    render(
      <Provider store={store}>
        <KittingArticleForm />
      </Provider>
    );

    const selectButton = screen.getAllByRole("button");
    userEvent.click(selectButton[2]);

    await screen.findByText(/value-1/i);
    const itemClickable = await screen.findByText(/value-1/i);

    // Will be completed on edit integration
    //expect(itemClickable).not.toBeNull();

    userEvent.click(itemClickable);
  });

  test("Should display error message for mandatory field", async () => {
    render(
      <Provider store={store}>
        <KittingArticleForm />
      </Provider>
    );

    const button = await screen.findByTestId("submit");
    fireEvent.click(button);
    const errorMessage1 = await screen.findByText(
      /Missing entry in mandatory field for Article number value/i
    );
    expect(errorMessage1).toBeInTheDocument();

    const errorMessage2 = await screen.findByText(
      /Missing entry in mandatory field for Service provider value./i
    );
    expect(errorMessage2).toBeInTheDocument();

    const cancel = await screen.findByTestId("cancel");
    fireEvent.click(cancel);
  });
});
