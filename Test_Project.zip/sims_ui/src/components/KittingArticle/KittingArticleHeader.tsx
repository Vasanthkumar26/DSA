// @ts-nocheck
import React, { useCallback } from "react";
import { connect } from "react-redux";
import {
  fetchKittingArticlesExport,
  setSelectedKittingArticle
} from "../../redux/actions/kittingArticleAction";
import TableHeader from "../common/TableHeader";

const KittingArticleHeader = ({
  isLoadingExport,
  fetchKittingArticlesExport,
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  setSelectedKittingArticle
}) => {
  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleExport = useCallback(() => {
    fetchKittingArticlesExport(isArchivedVisible);
  }, [fetchKittingArticlesExport, isArchivedVisible]);

  const handleAdd = useCallback(() => {
    setSelectedKittingArticle(null);
    setShowForm(true);
  }, [setSelectedKittingArticle, setShowForm]);

  return (
    <TableHeader
      title="Kitting Article Administration"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = ({ kittingArticles }) => ({
  isLoadingExport: kittingArticles.isLoadingExport
});

export default connect(mapStateToProps, {
  fetchKittingArticlesExport,
  setSelectedKittingArticle
})(KittingArticleHeader);
