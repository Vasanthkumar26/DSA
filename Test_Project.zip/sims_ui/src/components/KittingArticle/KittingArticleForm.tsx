// @ts-nocheck
import React, { Fragment, useState, useEffect, useMemo } from "react";
import { Controller, useForm } from "react-hook-form";
import {
  InputLabel,
  FormHelperText,
  Typography,
  Box,
  Button,
  Stack,
  Grid,
  TextField,
  Select,
  MenuItem,
  TextareaAutosize
} from "@mui/material";
import { connect, useDispatch } from "react-redux";
import {
  articleReset,
  deleteKittingArticles,
  archiveKittingArticle,
  updateArticle,
  createArticle
} from "../../redux/actions/kittingArticleAction";
import { fetchServiceProviders } from "../../redux/actions/serviceProviderAction";
import { useTranslation } from "../../hooks/useTranslation";
import Loader from "../UI/Loader";
import dayjs from "dayjs";
import { createKAPayload, initData, setFormData } from "./KittingArticle.data";
import DeleteModal from "../common/modals/DeleteModal";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import { resetPage } from "../../redux/actions/rootAction";
import { SPSelectWithSearch } from "../common/AddEditForm/SPSelectWithSearch";

const KittingArticleForm = ({
  serviceProviderList,
  startPackList,
  articleData,
  articleReset,
  isLoading,
  updateArticle,
  createArticle,
  deleteKittingArticles,
  archiveKittingArticle,
  fetchServiceProviders,
  setShowForm,
  kittingArticles,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetPage
}) => {
  const t = useTranslation();
  const dispatch = useDispatch();
  const [open, setOpen] = useState(false);
  const [articleExists, setArticleExists] = useState<boolean | null>(false);
  const [serviceProviders, setServiceProviders] = useState([
    { label: "", id: -1 }
  ]);
  const { control, reset, handleSubmit, setValue } = useForm({
    reValidateMode: "onChange",
    defaultValues: { ...initData }
  });

  const {
    id = "",
    archived = false,
    article_number = "",
    comment = "",
    description = "",
    systemStackId = "",
    startPackType = "",
    lastUpdateDate = "",
    kitting_order_exists = true,
    userName = ""
  } = articleData ?? {};

  useEffect(() => {
    articleData
      ? reset(setFormData(articleData, serviceProviders))
      : reset({ ...initData });
  }, [reset, articleData, serviceProviders]);

  const resetThisPage = () => {
    articleReset();
    resetPage();
  };

  useEffect(() => {
    fetchServiceProviders();
  }, [fetchServiceProviders]);

  useMemo(() => {
    if (serviceProviderList !== undefined || serviceProviderList !== null) {
      const serviceProviderArray = serviceProviderList?.map((item) => {
        return {
          label: `${item.spid}(${item.description})`,
          id: item.id
        };
      });
      setServiceProviders(serviceProviderArray);
    }
  }, [serviceProviderList]);
  const onSubmit = (data) => {
    const payload = createKAPayload(data);
    const promiseAPI = articleData
      ? updateArticle(payload, articleData.id)
      : createArticle(payload);
    promiseAPI
      .then(() => showSuccessSnackbar(
          !archived ? t("successfully_archived") : t("successfully_activated")
        ))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const handleCloseConfirmation = () => {
    setOpen(false);
    deleteKittingArticles(id)
      .then(() => showSuccessSnackbar(t("successfully_deleted")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const handleArchKittArticle = () => {
    archiveKittingArticle(archived, id)
      .then(() => showSuccessSnackbar(t("successfully_archived")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const starterListItem = startPackList?.map(({ value, label }) => {
    return (
      <MenuItem key={value} value={value}>
        {label}
      </MenuItem>
    );
  });

  // to check if articleNumber is already exists
  const handleArticleNumber = (value) => {
    setValue("article_number", value);
    setArticleExists(
      kittingArticles.map((item) => item?.article_number).includes(value)
    );
  };

  return (
    <Fragment>
      <Loader isLoading={isLoading}></Loader>
      <DeleteModal
        isOpen={open}
        handleConfirm={handleCloseConfirmation}
        handleCancel={() => setOpen(false)}
      />
      <Box
        component="form"
        onSubmit={handleSubmit(onSubmit)}
        sx={{
          backgroundColor: "#F3F4FF",
          padding: "10px"
        }}
      >
        <Grid container spacing={1}>
          <Grid item xs={6}>
            <InputLabel htmlFor="article_number" required>
              {t("article_number")}
            </InputLabel>
            <Controller
              control={control}
              name="article_number"
              defaultValue={article_number}
              rules={{
                required: true,
                pattern: {
                  value: /^[A-Za-z0-9-]+$/,
                  message: "Please enter only alphanumeric characters"
                }
              }}
              render={({ field, fieldState: { error } }) => (
                <TextField
                  size="small"
                  {...field}
                  inputProps={{
                    maxLength: 255
                  }}
                  data-testid="article-number"
                  fullWidth
                  type="text"
                  disabled={articleData?.kitting_order_exists}
                  onChange={(e) => {
                    handleArticleNumber(e.target.value);
                  }}
                  error={error !== undefined || articleExists}
                  helperText={
                    error?.message ||
                    (error ? t("article_number_required") : "") ||
                    (articleExists && t("Article already exists"))
                  }
                />
              )}
            />
          </Grid>
          <Grid item xs={6}>
            <InputLabel htmlFor="description" required>
              {t("article_description")}
            </InputLabel>
            <Controller
              control={control}
              name="description"
              defaultValue={description}
              rules={{ required: true }}
              render={({ field, fieldState: { error } }) => (
                <TextField
                  {...field}
                  size="small"
                  fullWidth
                  data-testid="description"
                  error={error !== undefined}
                  helperText={error ? t("article_description_required") : ""}
                />
              )}
            />
          </Grid>

          <Grid item xs={6}>
            <SPSelectWithSearch
              control={control}
              controlName="systemStackId"
              spid={systemStackId}
              inputLabel={t("service_provider")}
              required
              setValue={setValue}
            />
          </Grid>
          <Grid item xs={6}>
            <InputLabel htmlFor="startPackType">{t("starter_pack")}</InputLabel>
            <Controller
              control={control}
              name="startPackType"
              defaultValue={startPackType}
              render={({ field }) => (
                <Select
                  {...field}
                  size="small"
                  fullWidth
                  data-testid="starter-pack"
                >
                  {starterListItem}
                </Select>
              )}
            />
          </Grid>
          <Grid item xs={12}>
            <InputLabel htmlFor="comment"> {t("comment")}</InputLabel>
            <Controller
              control={control}
              name="comment"
              defaultValue={comment}
              render={({ field, fieldState: { error } }) => (
                <>
                  <TextareaAutosize
                    minRows={1}
                    maxRows={10}
                    data-testid="comment"
                    style={{
                      resize: "vertical",
                      padding: "8.5px 32px 8.5px 14px",
                      fontSize: "16px",
                      font: "inherit",
                      minHeight: "50px",
                      maxHeight: "200px",
                      overflow: "auto",
                      width: "100%",
                      borderColor: error ? "red" : "inherit",
                      color: "#000000DE"
                    }}
                    {...field}
                    error={error}
                  />
                  <FormHelperText sx={{ paddingLeft: "13px" }}>
                    {error?.message}
                  </FormHelperText>
                </>
              )}
            />
          </Grid>
          {articleData && (
            <Grid item xs={12}>
              <Stack direction="row" justifyContent="flex-end">
                <Typography
                  align="center"
                  variant="h8"
                  color="#031a34"
                  sx={{ fontWeight: 500 }}
                >
                  {t("Last updated") + " : "}
                  {lastUpdateDate
                    ? `${dayjs(lastUpdateDate).format(
                        "YYYY-MM-DD HH:mm:ss"
                      )} (${userName})`
                    : "N/A"}
                </Typography>
              </Stack>
            </Grid>
          )}
          <Grid item xs={12}>
            <Stack
              direction="row"
              justifyContent={
                (articleData && !kitting_order_exists) ||
                (articleData && kitting_order_exists && archived === false) ||
                (articleData && kitting_order_exists && archived === true)
                  ? "space-between"
                  : "flex-end"
              }
              spacing={2}
              sx={{ marginBottom: "1em" }}
            >
              {!kitting_order_exists && (
                <Button
                  variant="contained"
                  sx={{
                    textTransform: "none"
                  }}
                  onClick={() => setOpen(true)}
                  data-testid="delete"
                >
                  {t("button_delete")}
                </Button>
              )}
              {articleData && kitting_order_exists && archived === false && (
                <Button
                  variant="contained"
                  onClick={handleArchKittArticle}
                  data-testid="archivedButton"
                  sx={{
                    textTransform: "none"
                  }}
                >
                  {t("button_archived")}
                </Button>
              )}
              {articleData && kitting_order_exists && archived === true && (
                <Button
                  variant="contained"
                  onClick={handleArchKittArticle}
                  data-testid="comment"
                  sx={{
                    textTransform: "none"
                  }}
                >
                  {t("button_active")}
                </Button>
              )}
              <Stack
                direction="row"
                justifyContent="flex-end"
                spacing={2}
                sx={{ marginBottom: "1em" }}
              >
                <Button
                  variant="outlined"
                  sx={{
                    textTransform: "none"
                  }}
                  onClick={() => {
                    dispatch(articleReset());
                    reset();
                    setShowForm(false);
                  }}
                  data-testid="cancel"
                >
                  {t("button_cancel")}
                </Button>
                <Button
                  variant="contained"
                  type="submit"
                  data-testid="submit"
                  sx={{
                    textTransform: "none"
                  }}
                >
                  {t("button_save")}
                </Button>
              </Stack>
            </Stack>
          </Grid>
        </Grid>
      </Box>
    </Fragment>
  );
};
const mapStateToProps = ({ kittingArticles, serviceProvider }) => ({
  isLoading: kittingArticles.isLoading | serviceProvider.isLoadingFetch,
  serviceProviderList: serviceProvider.serviceProviders,
  articleData: kittingArticles.selectedKittingArticle,
  startPackList: kittingArticles.startPack,
  formError: kittingArticles.error,
  successMsg: kittingArticles.successMsg,
  deleteSuccessMsg: kittingArticles.deleteSuccessMsg,
  archSuccessMsg: kittingArticles.archSuccessMsg,
  kittingArticles: kittingArticles.kittingArticles
});

export default connect(mapStateToProps, {
  updateArticle,
  createArticle,
  articleReset,
  deleteKittingArticles,
  archiveKittingArticle,
  fetchServiceProviders,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetPage
})(KittingArticleForm);
