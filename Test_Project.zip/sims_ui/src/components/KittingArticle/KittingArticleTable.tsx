// @ts-nocheck
import { Grid } from "@mui/material";
import { useEffect, useMemo, useState } from "react";
import { connect, useDispatch } from "react-redux";
import { useTranslation } from "../../hooks/useTranslation";
import {
  fetchKittingArticles,
  setSelectedKittingArticle,
} from "../../redux/actions/kittingArticleAction";

import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import TableView from "../common/TableView";

const headCells = [
  { id: "article_number", label: "Article Number" },
  { id: "description", label: "Description" },
  { id: "spidCombineName", label: "Service Provider" },
  {
    id: "starterPack",
    label: "Start Pack",
    values: ["WhatsAll 4000", "Only with tariff", "With MSISDN & tariff"],
  },
];

const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"],
};

const tableConfig: TableConfig = {
  title: "Kitting Article Administration",
  orderBy: "lastUpdateDate",
};

const KittingArticleTable = ({
  kittingArticles,
  isLoadingFetch,
  fetchKittingArticles,
  isArchivedVisible,
}) => {
  const [articleNumberFilter, setArticleNumberFilter] = useState("");
  const [descriptionrFilter, setDescriptionFilter] = useState("");
  const [serviceProviderFilter, setServiceProviderFilter] = useState("");
  const [startPackFilter, setStartPackFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const dispatch = useDispatch();
  const t = useTranslation();

  useEffect(() => {
    fetchKittingArticles(isArchivedVisible);
  }, [fetchKittingArticles, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getArchivedFilter = (kittingArticle) => {
    if (archivedFilter === "Yes") {
      return !!kittingArticle.archived;
    }
    return archivedFilter === "No" ? !kittingArticle.archived : true;
  };

  let visibleKittingArticles = [...kittingArticles].filter(
    (kittingArticle) =>
      kittingArticle.description?.includes(descriptionrFilter) &&
      kittingArticle.article_number?.includes(articleNumberFilter) &&
      // TODO : uncomment below line after proper string starts coming in systemStackId
      kittingArticle.spidCombineName?.includes(serviceProviderFilter) &&
      (`${kittingArticle?.starterPack}`?.includes(startPackFilter) ?? true) &&
      getArchivedFilter(kittingArticle)
  );

  if (!isArchivedVisible) {
    visibleKittingArticles = visibleKittingArticles.filter(
      (kittingArticle) => !kittingArticle.archived
    );
  }

  const filterHeadCellMap = {
    [headCells[0].id]: {
      filter: articleNumberFilter,
      setFilter: setArticleNumberFilter,
      filterComponent: FilterSearchBar(t),
    },
    [headCells[1].id]: {
      filter: descriptionrFilter,
      setFilter: setDescriptionFilter,
      filterComponent: FilterSearchBar(t),
    },
    [headCells[2].id]: {
      filter: serviceProviderFilter,
      setFilter: setServiceProviderFilter,
      filterComponent: FilterDropdown(
        [
          ...new Set(
            kittingArticles
              .map((kittingArticle) => kittingArticle[headCells[2].id])
              .filter((kittingArticle) => !!kittingArticle)
          ),
        ],
        t
      ),
    },
    [headCells[3].id]: {
      filter: startPackFilter,
      setFilter: setStartPackFilter,
      filterComponent: FilterDropdown(headCells[3].values, t),
    },
    [archivedCell.id]: {
      filter: archivedFilter,
      setFilter: setArchivedFilter,
      filterComponent: FilterDropdown(archivedCell.values, t),
    },
  };

  const resetAllFilters = useMemo(() => {
    return () => {
      setArticleNumberFilter("");
      setDescriptionFilter("");
      setServiceProviderFilter("");
      setStartPackFilter("");
      setArchivedFilter("");
    };
  }, []);

  const handleRowSelected = (row) => {
    dispatch(setSelectedKittingArticle(row));
  };

  const handleRefresh = async () => {
    await fetchKittingArticles();
    resetAllFilters();
  };

  const visibleHeadCells = [
    ...headCells,
    ...(isArchivedVisible ? [archivedCell] : []),
  ];

  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleKittingArticles]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
      <Grid item display={{ xs: "none", lg: "block" }}>
        <img
          src="/sidebarIcons/Mask_Group.jpg"
          alt="background"
          style={{
            objectFit: "cover",
            width: "150px",
            height: "100%",
            margin: "1px",
          }}
        />
      </Grid>
    </Grid>
  );
};

const mapStateToProps = ({ kittingArticles }) => ({
  isLoadingFetch: kittingArticles.isLoadingFetch,
  kittingArticles: kittingArticles.kittingArticles,
});

export default connect(mapStateToProps, {
  fetchKittingArticles,
})(KittingArticleTable);
