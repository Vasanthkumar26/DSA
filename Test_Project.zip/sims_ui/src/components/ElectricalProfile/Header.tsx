import React, { Dispatch, FC, SetStateAction, useCallback } from "react";
import {
  Button,
  Checkbox,
  FormControlLabel,
  Stack,
  Typography
} from "@mui/material";
import UploadFileRoundedIcon from "@mui/icons-material/UploadFileRounded";
import { useTranslation } from "../../hooks/useTranslation";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import {
  fetchElectricalProfileExport,
  setSelectedElectricProfile
} from "../../redux/actions/electricalProfileAction";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
  isLoadingExport: boolean;
  setDuplicateForm: Dispatch<SetStateAction<boolean>>;
}

const Header: FC<Props> = ({
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  setSelectedElectricProfile,
  fetchElectricalProfileExport,
  isLoadingExport,
  selectedEP,
  setDuplicateForm
}) => {
  const t = useTranslation();

  const handleAdd = useCallback(() => {
    setSelectedElectricProfile(null);
    setShowForm(false);
    setDuplicateForm(false);
    setTimeout(() => {
      setShowForm(true);
    }, 0);
  }, [setSelectedElectricProfile, setShowForm, setDuplicateForm]);

  const handleDuplicate = useCallback(() => {
    setShowForm(false);
    setDuplicateForm(true);
    setTimeout(() => {
      setShowForm(true);
    }, 0);
  }, [setDuplicateForm, setShowForm]);

  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);
  return (
    <Stack direction="row" paddingBottom={1} justifyContent="space-between">
      <Typography
        align="center"
        variant="h5"
        color="#031a34"
        sx={{ fontWeight: 600 }}
      >
        {t("Electrical Profile Administration")}
      </Typography>
      <Stack direction="row" spacing={1} justifyContent="flex-end">
        <Button
          sx={{
            textTransform: "none",
            color: "black",
            textDecoration: "underline"
          }}
          disabled={isLoadingExport}
          role="export-button"
          onClick={() => {
            fetchElectricalProfileExport(isArchivedVisible);
          }}
          startIcon={<UploadFileRoundedIcon color="primary" />}
        >
          <Typography>{t("Export")}</Typography>
        </Button>
        <FormControlLabel
          control={
            <Checkbox
              role="archive-checkbox"
              size="small"
              checked={isArchivedVisible}
              onChange={handleArchiveChange}
            />
          }
          label={t("Archived")}
        />
        {selectedEP && (
          <Button
            variant="outlined"
            sx={{
              textTransform: "none"
            }}
            onClick={handleDuplicate}
          >
            {t("Duplicate")}
          </Button>
        )}
        <Button
          variant="contained"
          sx={{
            textTransform: "none"
          }}
          onClick={handleAdd}
        >
          {t("Add")}
        </Button>
      </Stack>
    </Stack>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.electricalProfile?.isLoadingExport,
  selectedEP: state.electricalProfile?.selectedElectricalProfile
});

const connector = connect(mapStateToProps, {
  setSelectedElectricProfile,
  fetchElectricalProfileExport
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(Header);
