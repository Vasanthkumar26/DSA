import React, {
  FC,
  useEffect,
  useMemo,
  useState,
  Dispatch,
  SetStateAction
} from "react";
import { Grid } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import { connect, ConnectedProps } from "react-redux";
import { ElectricalProfile } from "../../models";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";
import {
  fetchElectricalProfiles,
  setSelectedElectricProfile
} from "../../redux/actions/electricalProfileAction";
import {
  headCells,
  archivedCell,
  activationCell,
  tableConfig
} from "./ElectricalProfile.data";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setShowForm: Dispatch<SetStateAction<boolean>>;
  setDuplicateForm: Dispatch<SetStateAction<boolean>>;
}

const ElectricalProfileTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchElectricalProfiles,
  setSelectedElectricProfile,
  electricalProfiles = [],
  setShowForm,
  setDuplicateForm
}) => {
  const [nameFilter, setNameFilter] = useState("");
  const [vendorFilter, setVendorFilter] = useState("");
  const [valueFilter, setValueFilter] = useState("");
  const [annotationFilter, setAnnotationFilter] = useState("");
  const [pinStateFilter, setPinStateFilter] = useState("");
  const [pinValueFilter, setPinValueFilter] = useState("");
  const [akaHlrFilter, setAkaHlrFilter] = useState("");
  const [akaAlgoTypeFilter, setAkaAlgoTypeFilter] = useState("");
  const [akaAlgoIdFilter, setAlgoIdFilter] = useState("");
  const [akaKeyIdFilter, setAkaKeyIdFilter] = useState("");
  const [activationFilter, setActivationFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchElectricalProfiles(isArchivedVisible))();
  }, [fetchElectricalProfiles, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getArchivedFilter = (ep: ElectricalProfile) => {
    if (archivedFilter === "Yes") {
      return !!ep.archived;
    }
    return archivedFilter === "No" ? !ep.archived : true;
  };
  const getActivationFilter = (ep: ElectricalProfile) => {
    if (activationFilter === "Yes") {
      return !!ep.isimActivation;
    }
    return activationFilter === "No" ? !ep.isimActivation : true;
  };

  let visibleEPs = electricalProfiles?.filter(
    (electricalProfile: ElectricalProfile) =>
      electricalProfile?.name?.includes(nameFilter) &&
      electricalProfile?.manufacture?.includes(vendorFilter) &&
      electricalProfile?.value?.includes(valueFilter) &&
      electricalProfile?.fileAnnotation?.includes(annotationFilter) &&
      electricalProfile?.pin1State?.includes(pinStateFilter) &&
      electricalProfile?.pin1Value?.includes(pinValueFilter) &&
      electricalProfile?.akaHlr?.includes(akaHlrFilter) &&
      electricalProfile?.akaAlgType?.includes(akaAlgoTypeFilter) &&
      electricalProfile?.akaAlg?.includes(akaAlgoIdFilter) &&
      getActivationFilter(electricalProfile) &&
      electricalProfile?.akaTpKey.includes(akaKeyIdFilter) &&
      getArchivedFilter(electricalProfile)
  );

  if (!isArchivedVisible) {
    visibleEPs = visibleEPs?.filter(
      (electricalProfile: ElectricalProfile) => !electricalProfile.archived
    );
  }

  const filterHeadCellMap = useMemo(
    () => ({
      [headCells[0].id]: {
        filter: nameFilter,
        setFilter: setNameFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[1].id]: {
        filter: vendorFilter,
        setFilter: setVendorFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[2].id]: {
        filter: valueFilter,
        setFilter: setValueFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[3].id]: {
        filter: annotationFilter,
        setFilter: setAnnotationFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[4].id]: {
        filter: pinStateFilter,
        setFilter: setPinStateFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[5].id]: {
        filter: pinValueFilter,
        setFilter: setPinValueFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[6].id]: {
        filter: akaHlrFilter,
        setFilter: setAkaHlrFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[7].id]: {
        filter: akaAlgoTypeFilter,
        setFilter: setAkaAlgoTypeFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[8].id]: {
        filter: akaAlgoIdFilter,
        setFilter: setAlgoIdFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[9].id]: {
        filter: akaKeyIdFilter,
        setFilter: setAkaKeyIdFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[10].id]: {
        filter: activationFilter,
        setFilter: setActivationFilter,
        filterComponent: FilterDropdown(activationCell.values, t)
      },
      [archivedCell.id]: {
        filter: archivedFilter,
        setFilter: setArchivedFilter,
        filterComponent: FilterDropdown(archivedCell.values, t)
      }
    }),
    [
      nameFilter,
      t,
      vendorFilter,
      valueFilter,
      annotationFilter,
      pinStateFilter,
      pinValueFilter,
      akaHlrFilter,
      akaAlgoTypeFilter,
      akaAlgoIdFilter,
      akaKeyIdFilter,
      activationFilter,
      archivedFilter
    ]
  );

  const resetAllFilters = useMemo(() => {
    return () => {
      setNameFilter("");
      setVendorFilter("");
      setValueFilter("");
      setAnnotationFilter("");
      setPinStateFilter("");
      setArchivedFilter("");
    };
  }, []);

  const visibleHeadCells = useMemo(
    () => [...headCells, ...(isArchivedVisible ? [archivedCell] : [])],
    [isArchivedVisible]
  );

  const handleRowSelected = (row: any) => {
    setSelectedElectricProfile(null);
    setShowForm(false);
    setDuplicateForm(false);
    setTimeout(() => {
      setSelectedElectricProfile(row);
    }, 0);
  };

  const handleRefresh = async () => {
    await fetchElectricalProfiles(isArchivedVisible);
    resetAllFilters();
  };

  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleEPs]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.electricalProfile.isLoadingFetch,
  electricalProfiles: state.electricalProfile.electricalProfiles
});

const connector = connect(mapStateToProps, {
  fetchElectricalProfiles,
  setSelectedElectricProfile
});
type PropsFromRedux = ConnectedProps<typeof connector>;
export default connector(ElectricalProfileTable);
