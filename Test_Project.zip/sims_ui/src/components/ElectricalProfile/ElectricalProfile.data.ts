import { ElectricalProfileRequestPayload } from "../../models";
import { HeadCell, TableConfig } from "../../models/global.model";

import * as yup from "yup";

const headCells: Array<HeadCell> = [
  { id: "name", label: "Name" },
  { id: "manufacture", label: "SIM-Manufacturer" },
  { id: "value", label: "Value" },
  { id: "fileAnnotation", label: "Input File Annotation" },
  { id: "pin1State", label: "Pin1 State" },
  { id: "pin1Value", label: "Pin1 Value" },
  { id: "akaHlr", label: "AKA HLR" },
  { id: "akaAlgType", label: "AKA Algo Type" },
  { id: "akaAlg", label: "AKA Algo ID" },
  { id: "akaTpKey", label: "AKA TP Key ID" },
  { id: "isimActivation", label: "ISIM Activation" }
];

const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};

const activationCell = {
  id: "isimActivation",
  label: "ISIM Activation",
  values: ["Yes", "No"]
};

const tableConfig: TableConfig = {
  title: "Electrical Profiles Administration",
  orderBy: "lastUpdatedDate",
  tableRowTestId: "ep-row"
};

const initDropDown = { label: "", id: "" };
const initData = {
  itemId: 0,
  name: "",
  value: "",
  fileAnnotation: "",
  description: "",
  pin1Value: "",
  archived: true,
  isimActivation: { label: "No", id: "false" },
  manufacture: initDropDown,
  pin1State: { label: "Enabled", id: "1" },
  akaHlr: initDropDown,
  akaAlgType: { label: "TUAK16", id: "2" },
  akaAlg: initDropDown,
  akaTpKey: initDropDown,
  lastUpdatedBy: "",
  lastUpdatedDate: ""
};

const setFormData = (
  data: any,
  dropDownValue: any,
  duplicateForm: boolean
) => ({
  itemId: data?.itemId ?? 0,
  name: duplicateForm ? "" : data?.name ?? "",
  value: data?.value ?? "",
  fileAnnotation: data?.fileAnnotation ?? "",
  description: data?.description ?? "",
  pin1Value: data?.pin1Value ?? "",
  archived: data?.archived ?? true,
  isimActivation:
    dropDownValue?.isImActivation?.find(
      (item: any) => item?.id === data?.isimActivation?.toString()
    ) ?? false,
  manufacture:
    dropDownValue?.manufacaturer?.find(
      (item: any) => item?.id === data?.manufactureId
    ) ?? initDropDown,
  pin1State:
    dropDownValue?.pinState?.find(
      (item: any) => item?.id === data?.pin1StateId?.toString()
    ) ?? initDropDown,
  akaHlr:
    dropDownValue?.akaHlr?.find((item: any) => item?.id === data?.akaHlrId) ??
    initDropDown,
  akaAlgType:
    dropDownValue?.akaAlgType?.find(
      (item: any) => item?.id === data?.akaAlgTypeId?.toString()
    ) ?? initDropDown,
  akaAlg:
    dropDownValue?.akaAlg?.find(
      (item: any) => item?.id === data?.akaAlgId?.toString()
    ) ?? initDropDown,
  akaTpKey:
    dropDownValue?.akaAlg?.find(
      (item: any) => item?.id === data?.akaTpKeyId?.toString()
    ) ?? initDropDown,
  lastUpdatedBy: data?.lastUpdatedBy ?? "",
  lastUpdatedDate: data?.lastUpdatedDate ?? ""
});

const createEPPayload = (data: any) =>
  ({
    itemId: data?.itemId ?? 0,
    name: data?.name ?? "",
    value: data?.value ?? "",
    fileAnnotation: data?.fileAnnotation ?? "",
    description: data?.description ?? "",
    pin1Value: data?.pin1Value ?? "",
    archived: data?.archived ?? false,
    userUpdated: 1,
    isimActivation: data?.isimActivation?.id ?? false,
    manufactureId: data?.manufacture?.id ?? -1,
    pin1StateId: parseInt(data?.pin1State?.id) ?? -1,
    akaHlrId: parseInt(data?.akaHlr?.id) ?? -1,
    akaAlgTypeId: parseInt(data?.akaAlgType?.id) ?? -1,
    akaAlgId: parseInt(data?.akaAlg?.id) ?? -1,
    akaTpKeyId: parseInt(data?.akaTpKey?.id) ?? -1
  } as ElectricalProfileRequestPayload);

const electricalProfileSchema = (
  t: string,
  epNames: string[],
  isCreate: boolean
) =>
  yup.object().shape({
    name: yup
      .string()
      .required("name_is_missing")
      .notOneOf([...(isCreate ? epNames ?? [] : [])], t),
    value: yup.string().required("value_is_missing"),
    fileAnnotation: yup.string().required("fileAnnotation_is_missing"),
    pin1Value: yup.string().required("pinValue_is_missing")
  });

export {
  headCells,
  archivedCell,
  activationCell,
  tableConfig,
  initData,
  setFormData,
  createEPPayload,
  electricalProfileSchema
};
