import { Grid } from "@mui/material";
import {
  Dispatch,
  FC,
  SetStateAction,
  useEffect,
  useMemo,
  useState
} from "react";
import { useForm } from "react-hook-form";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import {
  createElectricalProfile,
  deleteElectricalProfile,
  fetchElectricalProfiles,
  resetEPCreateUpdateState,
  setSelectedElectricProfile,
  updateElectricalProfile,
  archiveElectricalProfile,
  resetElectricalProfile
} from "../../redux/actions/electricalProfileAction";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import { StyledFormBox } from "../common/styles/shared";
import {
  FormActionButtons,
  FormControllerTextField,
  LastUpdated
} from "../common/AddEditForm";
import {
  createEPPayload,
  electricalProfileSchema,
  initData,
  setFormData
} from "./ElectricalProfile.data";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import { useTranslation } from "../../hooks/useTranslation";
import { IAkaAlg, IAkaTpKey, IDropdown, ISelectionOption } from "../../models";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import DeleteModal from "../common/modals/DeleteModal";
import { resetPage } from "../../redux/actions/rootAction";

interface Props extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
  setDuplicateForm: Dispatch<SetStateAction<boolean>>;
  dropDownValue: IDropdown;
  isArchivedVisible: boolean;
  duplicateForm: boolean;
}

const TBD = { label: "TBD", id: 1 };
const AddEditForm: FC<Props> = ({
  selectedEP,
  electricalProfilesName,
  deleteElectricalProfile,
  dropDownValue,
  createElectricalProfile,
  updateElectricalProfile,
  successCreate,
  archiveSuccess,
  errorCreate,
  isLoadingCreate,
  isArchivedVisible,
  showFailureSnackbar,
  showSuccessSnackbar,
  isLoadingUpdate,
  errorUpdate,
  successUpdate,
  resetEPCreateUpdateState,
  fetchElectricalProfiles,
  archiveElectricalProfile,
  resetElectricalProfile,
  resetPage,
  setSelectedElectricProfile,
  setShowForm,
  setDuplicateForm,
  duplicateForm
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const t = useTranslation();
  const resolver = useYupValidationResolver(
    electricalProfileSchema(
      t("name_already_exists"),
      [...(electricalProfilesName ?? [])],
      !selectedEP
    )
  );

  const { control, handleSubmit, reset, watch, setValue } = useForm({
    mode: "all",
    resolver,
    reValidateMode: "onSubmit",
    defaultValues: { ...initData }
  });

  useEffect(() => {
    selectedEP
      ? reset(setFormData(selectedEP, dropDownValue, duplicateForm))
      : reset({ ...initData });
  }, [reset, selectedEP, dropDownValue, duplicateForm]);

  useEffect(() => {
    if (!isLoadingCreate || !isLoadingUpdate) {
      if (successCreate || successUpdate || archiveSuccess) {
        showSuccessSnackbar(
          successCreate ?? successUpdate ?? archiveSuccess ?? ""
        );
        resetEPCreateUpdateState();
      } else if (errorCreate || errorUpdate) {
        showFailureSnackbar(errorCreate ?? errorUpdate ?? "");
        resetEPCreateUpdateState();
      }
    }
  }, [
    successCreate,
    archiveSuccess,
    errorCreate,
    isLoadingCreate,
    showSuccessSnackbar,
    showFailureSnackbar,
    isLoadingUpdate,
    successUpdate,
    errorUpdate,
    resetEPCreateUpdateState
  ]);

  const resetThisPage = () => {
    resetElectricalProfile();
    resetPage();
  };

  const handleDelete = () => {
    setIsModalOpen(false);
    deleteElectricalProfile(selectedEP?.itemId ?? 0)
      .then(() => {
        showSuccessSnackbar(t("successfully_deleted"));
        setSelectedElectricProfile(null);
      })
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const handleCancle = () => {
    setShowForm(false);
    setDuplicateForm(false);
    reset(initData);
    setSelectedElectricProfile(null);
  };

  const handleActiveNArchive = () => {
    archiveElectricalProfile(
      selectedEP?.itemId ?? 0,
      selectedEP?.archived ?? false
    )
      .then(() => {
        showSuccessSnackbar(
          !selectedEP?.archived
            ? t("successfully_archived")
            : t("successfully_activated")
        );
        setSelectedElectricProfile(null);
      })
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const onSubmit = (data: any) => {
    const payload = createEPPayload({ ...data, archived: isArchivedVisible });
    let promiseAPI;
    if (selectedEP && duplicateForm) {
      promiseAPI = createElectricalProfile(payload);
    } else if (selectedEP) {
      promiseAPI = updateElectricalProfile(payload);
    } else {
      promiseAPI = createElectricalProfile(payload);
    }
    promiseAPI
      .then(() => {
        showSuccessSnackbar(t("request_processed_successfully"));
        setSelectedElectricProfile(null);
      })
      .catch(() => showFailureSnackbar("error_while_submitting_data"))
      .finally(() => resetThisPage());
  };

  const selectedAkaHlr = watch("akaHlr");
  const selectedAkaAlgType = watch("akaAlgType");
  const selectedSimVendor = watch("manufacture");

  const akaAlgValues = useMemo(() => {
    setValue("akaAlg", null);
    const algTBD = { ...TBD, akaAlgTypeId: -1, akaHlrId: -1, archive: false };
    if (selectedAkaAlgType !== null && selectedAkaHlr !== null) {
      // @ts-ignore: Unreachable code error
      const values = dropDownValue.akaAlg?.filter(
        (item: IAkaAlg) =>
          item.akaAlgTypeId === parseInt(selectedAkaAlgType?.id) &&
          item.akaHlrId === selectedAkaHlr?.id
      );
      if (values.length !== 0) {
        if (values.length === 1) {
          setValue("akaAlg", values[0]);
        }
        values.unshift(algTBD);
        return values;
      }
    }
    setValue("akaAlg", algTBD);
    return [algTBD] as ISelectionOption[];
    // eslint-disable-next-line
  }, [selectedAkaAlgType, selectedAkaHlr]);

  const akaTpKeyValues = useMemo(() => {
    setValue("akaTpKey", null);
    const tpTBD = { ...TBD, akaAlgTypeId: -1, akaHlrId: -1, simVendorId: -1 };
    if (
      selectedAkaAlgType !== null &&
      selectedAkaHlr !== null &&
      selectedSimVendor !== null
    ) {
      // @ts-ignore: Unreachable code error
      const values = dropDownValue.akaTpKey?.filter(
        (item: IAkaTpKey) =>
          item.akaAlgTypeId === parseInt(selectedAkaAlgType?.id) &&
          item.akaHlrId === selectedAkaHlr?.id &&
          item.simVendorId === selectedSimVendor?.id
      );
      if (values.length !== 0) {
        if (values.length === 1) {
          setValue("akaTpKey", values[0]);
        }
        values.unshift(tpTBD);
        return values;
      }
    }
    setValue("akaTpKey", tpTBD);
    return [tpTBD] as ISelectionOption[];
    // eslint-disable-next-line
  }, [selectedAkaAlgType, selectedAkaHlr, selectedSimVendor]);

  useEffect(() => {
    if (dropDownValue.akaHlr.length !== 0 && selectedEP === null) {
      const TEF = dropDownValue.akaHlr.find((item) => item.label === "TEF-DE");
      if (TEF) {
        setValue("akaHlr", TEF);
      }
    }
    // eslint-disable-next-line
  }, [dropDownValue.akaHlr, selectedEP]);
  return (
    <>
      <DeleteModal
        isOpen={isModalOpen}
        handleConfirm={handleDelete}
        handleCancel={() => setIsModalOpen(false)}
      />
      <StyledFormBox component="form" onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={12} md={12}>
            <FormControllerTextField
              control={control}
              controlName="name"
              inputLabel="name"
              required
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerSelectWithSearch
              control={control}
              controlName="manufacture"
              inputLabel="SIM-Manufacturer"
              options={dropDownValue.manufacaturer}
              required
              isDisabled={selectedEP?.sim_article_ref_exist}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerTextField
              control={control}
              controlName="value"
              inputLabel="Value"
              required
              disabled={selectedEP?.sim_article_ref_exist}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerTextField
              control={control}
              controlName="fileAnnotation"
              inputLabel="Input file Annotation"
              required
            />
          </Grid>
          <Grid item xs={12} sm={8} md={8}>
            <Grid container spacing={1}>
              <Grid item xs={12} sm={6} md={6}>
                <FormControllerSelectWithSearch
                  control={control}
                  controlName="pin1State"
                  inputLabel="Pin1 State"
                  options={dropDownValue.pinState}
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6} md={6}>
                <FormControllerTextField
                  control={control}
                  controlName="pin1Value"
                  inputLabel="Pin1 Value"
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6} md={6}>
                <FormControllerSelectWithSearch
                  control={control}
                  controlName="akaHlr"
                  inputLabel="AKA HLR"
                  isSorting={false}
                  options={dropDownValue.akaHlr}
                  required
                  isDisabled={selectedEP?.sim_article_ref_exist}
                />
              </Grid>
              <Grid item xs={12} sm={6} md={6}>
                <FormControllerSelectWithSearch
                  control={control}
                  controlName="akaAlgType"
                  inputLabel="AKA Algorithm Type"
                  options={dropDownValue.akaAlgType}
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6} md={6}>
                <FormControllerSelectWithSearch
                  control={control}
                  controlName="akaAlg"
                  inputLabel="AKA Algorithm ID"
                  options={akaAlgValues}
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6} md={6}>
                <FormControllerSelectWithSearch
                  control={control}
                  controlName="akaTpKey"
                  inputLabel="AKA TP Key ID"
                  options={akaTpKeyValues}
                  required
                />
              </Grid>
              <Grid item xs={12} sm={6} md={6}>
                <FormControllerSelectWithSearch
                  control={control}
                  controlName="isimActivation"
                  inputLabel="ISIM Activation"
                  options={dropDownValue.isImActivation.map((item) => {
                    return {
                      ...item,
                      label: `${t(item.label)}`
                    };
                  })}
                  required
                />
              </Grid>
            </Grid>
          </Grid>

          <Grid item xs={12} sm={4} md={4}>
            <FormControllerTextField
              control={control}
              controlName="description"
              inputLabel="Description"
              multiline
              rows={9}
            />
          </Grid>
          {selectedEP && (
            <Grid item xs={12}>
              <LastUpdated
                lastUpdatedDate={selectedEP?.lastUpdatedDate as string}
              />
            </Grid>
          )}
          <Grid item xs={12}>
            <FormActionButtons
              onCancel={handleCancle}
              selectedData={selectedEP}
              onActiveNArchive={() => handleActiveNArchive()}
              onDelete={() => setIsModalOpen(true)}
              isArchiveVisible={
                !selectedEP?.archived && selectedEP?.sim_article_ref_exist
              }
              isDeleteVisible={!selectedEP?.sim_article_ref_exist}
              isActiveVisible={
                selectedEP?.archived && selectedEP?.sim_article_ref_exist
              }
            />
          </Grid>
        </Grid>
      </StyledFormBox>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedEP: state.electricalProfile.selectedElectricalProfile,
  electricalProfilesName: state.electricalProfile.electricalProfiles.map(
    (item) => item.name
  ),
  successCreate: state.electricalProfile.successCreate,
  successUpdate: state.electricalProfile.successUpdate,
  archiveSuccess: state.electricalProfile.archiveSuccess,
  errorCreate: state.electricalProfile.errorCreate,
  errorUpdate: state.electricalProfile.errorUpdate,
  isLoadingCreate: state.electricalProfile.isLoadingCreate,
  isLoadingUpdate: state.electricalProfile.isLoadingUpdate
});

const connector = connect(mapStateToProps, {
  setSelectedElectricProfile,
  deleteElectricalProfile,
  createElectricalProfile,
  updateElectricalProfile,
  showFailureSnackbar,
  showSuccessSnackbar,
  resetEPCreateUpdateState,
  fetchElectricalProfiles,
  archiveElectricalProfile,
  resetElectricalProfile,
  resetPage
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(AddEditForm);
