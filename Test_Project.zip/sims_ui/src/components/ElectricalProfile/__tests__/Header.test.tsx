import "@testing-library/jest-dom";
import { SetStateAction } from "react";
import { screen, fireEvent, render } from "@testing-library/react";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { Store, AnyAction } from "redux";
import Header from "../Header";
import { getCurrentDateAndTime } from "../../../utils/common";
import { ElectricalProfileActionTypes } from "../../../redux/actions/types";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import { fetchElectricalProfileExport } from "../../../redux/actions/electricalProfileAction";

const mockStore =  configureStore([thunk]);

jest.mock("../../../redux/actions/electricalProfileAction",() => ({
    fetchElectricalProfileExport:jest.fn()
}));

describe("Header test",() => {
    let store: Store<unknown, AnyAction>;
    beforeEach(() => {
        store = mockStore({
        electricalProfiles:[
            {
                id: 1,
                name: "test",
                vendor: "Yes",
                value: "test",
                fileAnotation: "test",
                pinState: "No",
                pinValue: "Yes",
                akaHlr: "Yes",
                algorthimType: "No",
                algorithmId: "Yes",
                tpKeyId: "Yes",
                isimActivation: true,
                archived: false,
                lastUpdateDate:getCurrentDateAndTime()
                
              },
        ],
          lang: {
            language: "en",
          },
        });
      });

      test("should render the component without failed",() => {
        const {container} = renderWithAllWrappers(
            <Header isArchivedVisible={false} setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
                throw new Error("Function not implemented.");
            } } setShowForm={function (value: SetStateAction<boolean>): void {
                throw new Error("Function not implemented.");
            } }/>
        );
        expect(container).toBeInTheDocument();
      });

    test("render the export button",() => {
        renderWithAllWrappers(
            <Header isArchivedVisible={false} setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
                throw new Error("Function not implemented.");
            } } setShowForm={function (value: SetStateAction<boolean>): void {
                throw new Error("Function not implemented.");
            } }/>
        )

        expect(screen.getByText(/Export/i)).toBeInTheDocument();
    });

    test("should call the handle export on button Click",async() => {
        // @ts-ignore: Unreachable code error
        fetchElectricalProfileExport.mockImplementation(() => {
            return{
                type:ElectricalProfileActionTypes.FETCH_EP_EXPORT_SUCCESS,
                payload:{message:"successfull"}
            };
        });

        render(
            <Provider store={store}>
                <Header isArchivedVisible={false} setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
                    throw new Error("Function not implemented.");
                } } setShowForm={function (value: SetStateAction<boolean>): void {
                    throw new Error("Function not implemented.");
                } }/>
                    
            </Provider>
        );

        const button = screen.getByRole("export-button");
        await fireEvent.click(button);
        expect(fetchElectricalProfileExport).toHaveBeenCalled()
    });
})