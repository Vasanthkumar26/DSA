import {
  Alert,
  Backdrop,
  Box,
  CircularProgress,
  Grid,
  Snackbar
} from "@mui/material";
import React, { FC, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { useTranslation } from "../../hooks/useTranslation";
import { RootState, store } from "../../redux/store";
import ElectricalProfileTable from "./EPTable";
import AddEditForm from "./AddEditForm";
import Header from "./Header";
import { ISelectionOption } from "../../models/global.model";
import {
  handleFetchPinState,
  handleFetchakaAlg,
  handleFetchakaAlgType,
  handleFetchakaTpKey,
  handleFetchakaHlr,
  handleFetchisImActivation,
  handleFetchManufacturer
} from "../../services/electricalProfileApi";
import { showFailureSnackbar } from "../../redux/actions/snackbarAction";
import { ISelectArchive } from "../../models/simArticle.model";
import { sortDropDown } from "../../utils/common";
import { IAkaAlg, IAkaTpKey, IDropdown } from "../../models";
const initDropDownValue: ISelectionOption[] = [{ label: "", id: "" }];

const ElectricalProfile: FC = () => {
  const [isArchivedVisible, setIsArchivedVisible] = useState<boolean>(false);
  const [showForm, setShowForm] = useState<boolean>(false);
  const [duplicateForm, setDuplicateForm] = useState<boolean>(false);
  const [successSnackbarOpen, setSuccessSnackbarOpen] =
    useState<boolean>(false);
  const [dropDownValue, setDropDownValue] = useState<IDropdown>({
    pinState: initDropDownValue,
    akaAlg: [] as IAkaAlg[],
    akaAlgType: initDropDownValue,
    akaTpKey: [] as IAkaTpKey[],
    akaHlr: [] as ISelectArchive[],
    isImActivation: initDropDownValue,
    manufacaturer: [] as ISelectArchive[]
  });

  const selectedEP = useSelector(
    (state: RootState) => state.electricalProfile.selectedElectricalProfile
  );

  useMemo(() => {
    if (showForm || selectedEP !== null) {
      const responses = {
        pinState: [] as ISelectionOption[],
        akaAlg: [] as IAkaAlg[],
        akaAlgType: [] as ISelectionOption[],
        akaTpKey: [] as IAkaTpKey[],
        akaHlr: [] as ISelectArchive[],
        isImActivation: [] as ISelectionOption[],
        manufacaturer: [] as ISelectArchive[]
      };

      Promise.allSettled([
        handleFetchPinState(),
        handleFetchakaAlg(),
        handleFetchakaAlgType(),
        handleFetchakaTpKey(),
        handleFetchakaHlr(),
        handleFetchisImActivation(),
        handleFetchManufacturer()
      ])
        .then(
          ([
            pinState,
            akaAlg,
            akaAlgType,
            akaTpKey,
            akaHlr,
            isSimActivation,
            manufacaturer
          ]) => {
            if (pinState.status === "fulfilled") {
              responses.pinState.push(...pinState.value);
            }
            if (akaAlg.status === "fulfilled") {
              responses.akaAlg.push(...akaAlg.value);
            }
            if (akaAlgType.status === "fulfilled") {
              responses.akaAlgType.push(...akaAlgType.value);
            }
            if (akaTpKey.status === "fulfilled") {
              responses.akaTpKey.push(...akaTpKey.value);
            }
            if (akaHlr.status === "fulfilled") {
              const res = sortDropDown(akaHlr.value);
              if (selectedEP?.akaHlrArchived === true) {
                const archivedValues = res?.map((item: any) => {
                  if (item.archive === true) {
                    return {
                      ...item,
                      label: `${item.label} [archiviert]`
                    };
                  }
                  return item;
                });
                responses.akaHlr.push(...archivedValues, {
                  label: "TBD",
                  id: 1,
                  archive: true
                });
              } else {
                responses.akaHlr.push(...res, {
                  label: "TBD",
                  id: 1,
                  archive: true
                });
              }
            }
            if (isSimActivation.status === "fulfilled") {
              responses.isImActivation.push(...isSimActivation.value);
            }
            if (manufacaturer.status === "fulfilled") {
              if (selectedEP?.manufactureArchived === true) {
                const archivedManufacturer = manufacaturer.value.map((item) => {
                  if (item.archive === true) {
                    return {
                      ...item,
                      label: `${item.label} [archiviert]`
                    };
                  }
                  return item;
                });
                responses.manufacaturer.push(...archivedManufacturer);
              } else {
                responses.manufacaturer.push(...manufacaturer.value);
              }
            }
            setDropDownValue((prevState) => {
              return {
                ...prevState,
                ...responses
              };
            });
          }
        )
        .catch((err) => store.dispatch(showFailureSnackbar(err?.message)));
    }
  }, [showForm, selectedEP]);

  const t = useTranslation();

  const isLoadingCreate = useSelector(
    (state: RootState) => state.hlr.isLoadingCreate
  );
  const isLoadingUpdate = useSelector(
    (state: RootState) => state.hlr.isLoadingUpdate
  );

  return (
    <>
      <Backdrop
        sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={isLoadingCreate || isLoadingUpdate}
      >
        <CircularProgress color="inherit" />
      </Backdrop>
      <Snackbar
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        open={successSnackbarOpen}
        onClose={() => {
          setSuccessSnackbarOpen(false);
        }}
        autoHideDuration={2000}
      >
        <Alert
          onClose={() => {
            setSuccessSnackbarOpen(false);
          }}
          severity="success"
          elevation={6}
          variant="filled"
          sx={{ width: "100%" }}
        >
          {t("Request processed successfully")}
        </Alert>
      </Snackbar>
      <Box sx={{ padding: 2 }}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Header
              isArchivedVisible={isArchivedVisible}
              setIsArchivedVisible={setIsArchivedVisible}
              setShowForm={setShowForm}
              setDuplicateForm={setDuplicateForm}
            />
            <ElectricalProfileTable
              isArchivedVisible={isArchivedVisible}
              setShowForm={setShowForm}
              setDuplicateForm={setDuplicateForm}
            />
          </Grid>
          {showForm || duplicateForm || selectedEP ? (
            <Grid item xs={12}>
              <AddEditForm
                setShowForm={setShowForm}
                dropDownValue={dropDownValue}
                isArchivedVisible={isArchivedVisible}
                setDuplicateForm={setDuplicateForm}
                duplicateForm={duplicateForm}
              />
            </Grid>
          ) : (
            <></>
          )}
        </Grid>
      </Box>
    </>
  );
};

export default ElectricalProfile;
