import { FC, useCallback, useEffect, useState } from "react";
import { StyledFormBox } from "../common/styles/shared";
import { Grid, Box, Stack, Button } from "@mui/material";
import { FormControllerTextField } from "../common/AddEditForm";
import { useForm } from "react-hook-form";
import {
  KittingOrderSchema,
  createPayload,
  initData
} from "./KittingOrder.data";
import { FormControllerDatePicker } from "../common/AddEditForm/FormControllerDatePicker";
import { useTranslation } from "../../hooks/useTranslation";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import { ISelectionOption } from "../../models";
import { Modal } from "./Modal";
import { RootState, store } from "../../redux/store";
import {
  createkittingOrderManual,
  resetKittingOrderState
} from "../../redux/actions/kittingOrderAction";
import { connect, ConnectedProps } from "react-redux";
import { handleFetchKittingArticleNumber } from "../../services/kittingOrderManualApi";
import { showFailureSnackbar } from "../../redux/actions/snackbarAction";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";

interface Props extends PropsFromRedux {}

const KittingOrderAddForm: FC<Props> = ({
  isLoadingCreate,
  successCreate,
  errorCreate,
  createkittingOrderManual,
  resetKittingOrderState
}) => {
  const t = useTranslation();
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [kittingArticleNumbers, setKittingArticleNumbers] = useState<
    ISelectionOption[]
  >([{ label: "", id: -1 }]);
  const resolver = useYupValidationResolver(KittingOrderSchema);
  const { control, handleSubmit, watch, reset, setValue } = useForm({
    mode: "all",
    reValidateMode: "onChange",
    resolver,
    defaultValues: { ...initData }
  });

  const orderDate = watch("orderDate");

  useEffect(() => {
    handleFetchKittingArticleNumber()
      .then((res) => {
        if (res) {
          setKittingArticleNumbers(res);
        }
      })
      .catch((err) => {
        store.dispatch(showFailureSnackbar(err?.message));
      });
  }, []);

  const onSubmit = useCallback(
    async (data: any) => {
      const payload = createPayload(data);
      await createkittingOrderManual(payload);
    },
    [createkittingOrderManual]
  );

  useEffect(() => {
    if (!isLoadingCreate) {
      if (errorCreate) {
        setMessage(errorCreate);
        setOpen(true);
      }
      if (successCreate) {
        setOpen(true);
        setMessage(successCreate);
      }
      reset({ ...initData });
    }
    // eslint-disable-next-line
  }, [errorCreate, successCreate, onSubmit, isLoadingCreate, reset]);

  const handleDisableDateAsPerOrderDate = (date: Date) => {
    const _date = new Date(date);
    const _orderDate = new Date(orderDate);
    _orderDate.setHours(0, 0, 0, 0);
    return _date < _orderDate;
  };

  const handleDisableDateBefore30Days = (date: Date) => {
    const currentDate = new Date();
    const thirtyDayBefore = new Date();
    thirtyDayBefore.setDate(currentDate.getDate() - 30);
    return date < thirtyDayBefore;
  };

  const handleClose = () => {
    setOpen(!open);
    resetKittingOrderState();
  };

  return (
    <>
      <Modal open={open} handleClose={handleClose} message={message} />
      <Box component="form" onSubmit={handleSubmit(onSubmit)}>
        <StyledFormBox>
          <Grid container spacing={2}>
            <Grid item xs={4} sm={4} md={4}>
              <FormControllerTextField
                control={control}
                controlName="orderNumber"
                inputLabel="Order Number"
                required
              />
            </Grid>
            <Grid item xs={4} sm={4} md={4}>
              <FormControllerSelectWithSearch
                control={control}
                controlName="kittingArticleNumber"
                inputLabel="kittingArticleNumber"
                options={kittingArticleNumbers}
                setValue={setValue}
                required={true}
              />
            </Grid>
            <Grid item xs={4} sm={4} md={4}>
              <FormControllerTextField
                control={control}
                controlName="noOfSimCard"
                inputLabel="No of SimCard"
              />
            </Grid>
            <Grid item xs={4} sm={4} md={4}>
              <FormControllerDatePicker
                control={control}
                controlName="orderDate"
                inputLabel="Order Date"
                isFutureDisable
                handleDisableDate={handleDisableDateBefore30Days}
              />
            </Grid>
            <Grid item xs={4} sm={4} md={4}>
              <FormControllerDatePicker
                control={control}
                controlName="deliveryDate"
                inputLabel="Delivery Date"
                handleDisableDate={handleDisableDateAsPerOrderDate}
              />
            </Grid>
          </Grid>
        </StyledFormBox>

        <Stack direction="row" justifyContent="flex-end" mt={2}>
          <Button
            type="submit"
            sx={{
              textTransform: "none"
            }}
            variant="contained"
          >
            {t("Save")}
          </Button>
        </Stack>
      </Box>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingCreate: state.kittingOrder.isLoadingCreate,
  errorCreate: state.kittingOrder.errorCreate,
  successCreate: state.kittingOrder.successCreate
});

const connector = connect(mapStateToProps, {
  createkittingOrderManual,
  resetKittingOrderState
});

type PropsFromRedux = ConnectedProps<typeof connector>;
export default connector(KittingOrderAddForm);
