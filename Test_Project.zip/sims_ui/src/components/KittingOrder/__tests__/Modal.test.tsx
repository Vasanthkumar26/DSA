import "@testing-library/jest-dom";
import { Modal } from "../Modal";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import { screen } from "@testing-library/react";

describe("Test Modal", () => {
  const handleClose = jest.fn();
  const message = "Article already exist";
  const open = true;
  test("should render properly with given props", () => {
    const { container } = renderWithAllWrappers(
      <Modal handleClose={handleClose} message={message} open={open} />
    );
    expect(container).toBeInTheDocument();
  });
  test("should render the text properly", () => {
    renderWithAllWrappers(
      <Modal handleClose={handleClose} message={message} open={open} />
    );
    expect(screen.getByText(/Article already exist/)).toBeInTheDocument();
  });

  test("should not call the handleClose", () => {
    renderWithAllWrappers(
      <Modal handleClose={handleClose} message={message} open={false} />
    );
    expect(handleClose).not.toHaveBeenCalled();
  });
});
