/* eslint-disable testing-library/no-node-access */
//@ts-nocheck
import "@testing-library/jest-dom";
import {
  createServer,
  renderWithReduxThemeWrappers
} from "../../../utils/testUtils";
import KittingOrderAddForm from "../KittingOrderAddForm";
import {
  render,
  screen,
  fireEvent,
  within,
  waitFor
} from "@testing-library/react";
import configureMockStore from "redux-mock-store";
import thunk from "redux-thunk";
import { Provider } from "react-redux";
import { KittingOrder_SUCCESS_API_HANDLERS } from "../../../_mocks_/kittingOrderApiHandlers";
import userEvent from "@testing-library/user-event";
import { handleFetchKittingArticleNumber } from "../../../services/kittingOrderManualApi";
import { wait } from "@testing-library/user-event/dist/utils";

const mockStore = configureMockStore([thunk]);

describe("Kitting Order Add Form", () => {
  createServer(KittingOrder_SUCCESS_API_HANDLERS);
  let store;
  beforeEach(() => {
    store = mockStore({
      kittingOrder: {},
      lang: {
        language: "en"
      }
    });
  });

  afterEach(() => {
    jest.resetAllMocks();
  });
  test("shoudl render without crash", () => {
    const { container } = renderWithReduxThemeWrappers(<KittingOrderAddForm />);
    expect(container).toBeInTheDocument();
  });

  test("render form elements and fire the button click event", async () => {
    const createkittingOrderManual = jest.fn();
    render(
      <Provider store={store}>
        <KittingOrderAddForm
          createkittingOrderManual={createkittingOrderManual}
        />
      </Provider>
    );

    await handleFetchKittingArticleNumber();
    expect(screen.getByText("Order Number:")).toBeInTheDocument();
    expect(screen.getByLabelText("No of SimCard")).toBeInTheDocument();
    expect(screen.getByText(/Order Date/i)).toBeInTheDocument();
    expect(screen.getByText(/Delivery Date/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Save" })).toBeInTheDocument();
    expect(screen.getByTestId("kittingArticleNumber")).toBeInTheDocument();

    const orderNumber = screen
      .getByTestId("Order Number")
      ?.querySelector("input");
    const noOfSimCard = screen
      .getByTestId("No of SimCard")
      ?.querySelector("input");

    const orderDate = screen.getByTestId("Order Date");
    const deliveryDate = screen.getByTestId("Delivery Date");
    const chosenDate = screen.getByRole("button", { name: "Choose date" });

    fireEvent.change(orderNumber, { target: { value: 22 } });
    fireEvent.change(noOfSimCard, { target: { value: 21 } });

    userEvent.type(deliveryDate, orderDate.value);

    expect(deliveryDate.value).toBe(orderDate.value);
    expect(chosenDate).toBeInTheDocument();
    expect(orderNumber.value).toBe("22");

    const autocomplete = screen.getByTestId("kittingArticleNumber");
    const input = within(autocomplete).getByRole("combobox");
    autocomplete.focus();
    fireEvent.change(input, { target: { value: { label: "test", id: 12 } } });
    await wait();
    // navigate to the first item in the autocomplete box
    fireEvent.keyDown(autocomplete, { key: "ArrowDown" });
    await wait();
    // select the first item
    fireEvent.keyDown(autocomplete, { key: "Enter" });
    await wait();
    // check the new value of the input field
    expect(input.value).toEqual("test");

    const submitBtn = await screen.findByRole("button", { name: /save/i });
    expect(submitBtn).toBeInTheDocument();

    await waitFor(async () => {
      await fireEvent.click(submitBtn);
    });
  });
});
