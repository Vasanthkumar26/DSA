import dayjs from "dayjs";
import { KittingOrderPayload } from "../../models";
import * as yup from "yup";

export const initData: KittingOrderPayload = {
  orderNumber: null,
  kittingArticleNumber: null,
  noOfSimCard: null,
  orderDate: dayjs(new Date()),
  deliveryDate: ""
};

export const KittingOrderSchema = yup.object().shape({
  orderNumber: yup
    .number()
    .typeError("order_must_be_a_positive_number")
    .required("Order_Number_is_missing"),

  kittingArticleNumber: yup
    .object()
    .shape({
      label: yup.string().required(),
      id: yup.number().required("Kitting Article Number is missing")
    })
    .typeError("Kitting Article Number is missing")
    .required("Kitting Article Number is missing"),
  noOfSimCard: yup
    .number()
    .typeError("Number_of_SIM_cards_must_be_a_positive_number")
    .required("Number_of_SIM_card_is_missing")
    .min(1),
  deliveryDate: yup.string().required("Delivery_date_is_missing")
});

export const createPayload = (data: any) => ({
  orderNumber: data?.orderNumber,
  kittingArticleNumber: data?.kittingArticleNumber?.id,
  noOfSimCard: data?.noOfSimCard,
  orderDate: data?.orderDate,
  deliveryDate: data?.deliveryDate
});
