import { FC } from "react";
import { Box, Grid, Stack, Typography } from "@mui/material";
import KittingOrderAddForm from "./KittingOrderAddForm";
import { useTranslation } from "../../hooks/useTranslation";

const KittingOrder: FC = () => {
  const t = useTranslation();

  return (
    <>
      <Box sx={{ padding: 2 }}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Stack direction="row" justifyContent="space-between">
              <Typography
                align="center"
                variant="h5"
                color="#031a34"
                sx={{ fontWeight: 600 }}
              >
                {t("Create kitting order")}
              </Typography>
            </Stack>
          </Grid>
          <Grid item xs={12}>
            <KittingOrderAddForm />
          </Grid>
        </Grid>
      </Box>
    </>
  );
};

export default KittingOrder;
