import { FC } from "react";
import { useTranslation } from "../../hooks/useTranslation";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText
} from "@mui/material";

interface Props {
  handleClose: () => void;
  message: string;
  open: boolean;
}

export const Modal: FC<Props> = ({ handleClose, message, open }) => {
  const t = useTranslation();
  return (
    <Dialog
      PaperProps={{
        sx: {
          width: "20%",
          height: "18%",
          paddingBottom: 0
        }
      }}
      open={open}
      onClose={() => {
        handleClose();
      }}
    >
      <DialogContent>
        <DialogContentText fontWeight={800}>{t(message)}</DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button size="small" onClick={handleClose} variant="contained">
          OK
        </Button>
      </DialogActions>
    </Dialog>
  );
};
