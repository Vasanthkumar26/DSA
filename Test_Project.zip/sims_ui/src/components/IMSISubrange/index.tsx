import { Alert, Box, Grid, Snackbar } from "@mui/material";
import React, { FC, useState } from "react";
import ImsiSubrangeForm from "./Form";
import Header from "./ImsiSubrangeHeader";
import ImsiSubrangeTable from "./ImsiSubrangeTable";
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";
import { useTranslation } from "../../hooks/useTranslation";
import StatusTable from "./StatusTable";
import { ImsiSubAndMainRangeStatusRequestPayload } from "../../models/global.model";
export interface FormValues {
  imsiSubRangeName: string;
  imsiStartRange: string;
  imsiEndRange: string;
  imsiMainRangeId: string;
  productTypeId: string;
}

const IMSISubrange: FC = () => {
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState<boolean>(false);
  const [successSnackbarOpen, setSuccessSnackbarOpen] =
    useState<boolean>(false);
  const [showStatusTable, setShowStatusTable] = useState(false);

  const selectedSubrangeData = useSelector(
    (state: RootState) => state.imsiSubrange.selectedImsiSubrange
  );

  const payload: ImsiSubAndMainRangeStatusRequestPayload = {
    startIMSIForSearch: selectedSubrangeData?.startImsi || "", // Use an empty string as a default value
    endIMSIForSearch: selectedSubrangeData?.endImsi || "" // Use an empty string as a default value
  };

  const t = useTranslation();
  return (
    <>
      <Snackbar
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        open={successSnackbarOpen}
        onClose={() => {
          setSuccessSnackbarOpen(false);
        }}
        autoHideDuration={2000}
      >
        <Alert
          onClose={() => {
            setSuccessSnackbarOpen(false);
          }}
          severity="success"
          elevation={6}
          variant="filled"
          sx={{ width: "100%" }}
        >
          {t("Request processed successfully")}
        </Alert>
      </Snackbar>
      <Box sx={{ padding: 2 }}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Header
              isArchivedVisible={isArchivedVisible}
              setIsArchivedVisible={setIsArchivedVisible}
              setShowForm={setShowForm}
            />
            <ImsiSubrangeTable isArchivedVisible={isArchivedVisible} />
          </Grid>
          <Grid item xs={12}>
            {showForm || selectedSubrangeData ? (
              <Grid item xs={12}>
                <ImsiSubrangeForm
                  setShowForm={setShowForm}
                  setSuccessSnackbarOpen={setSuccessSnackbarOpen}
                  setShowStatusTable={setShowStatusTable}
                />
              </Grid>
            ) : (
              <></>
            )}
          </Grid>

          <Grid item xs={12}>
            {selectedSubrangeData && showStatusTable && (
              <StatusTable payload={payload} />
            )}
          </Grid>
        </Grid>
      </Box>
    </>
  );
};
// const mapStateToProps = (state: RootState) => ({
//   subrangeData: state.imsiSubrange.selectedImsiSubrange,
// });

// const connector = connect(mapStateToProps, {});

export default IMSISubrange;
