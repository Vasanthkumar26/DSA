import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import "@testing-library/jest-dom";
import { screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import ImsiSubrangeTable from "../ImsiSubrangeTable";
import { REACT_BASE_URL } from "../../../utils/common";

describe("TableView", () => {
  test("should render without crash", () => {
    const { container } = renderWithAllWrappers(
      <ImsiSubrangeTable isArchivedVisible={false} />
    );
    expect(container).toBeInTheDocument();
  });

  describe("API success", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/imsisubrange/loadIMSISubRange`,
        res: () => [
          {
            imsiSubRangeId: 2,
            imsiSubRangeName: "imsiSubRange7",
            imsiStartRange: "1022023",
            imsiEndRange: "1822023",
            imsiDigits8: "262-03-901",
            archived: false,
            userName: 1,
            imsiMainRangeProductTypeResponse: {
              allImsiMainRanges: [
                {
                  imsiMainRangeId: 1,
                  mainRangeCombinedName: "testImsi489131",
                  systemStackId: 1,
                  greenIccidImsi: true,
                },
              ],
              allProductTypes: [
                {
                  productTypeId: 1,
                  name: "product_type1",
                  greenIccidImsi: null,
                },
              ],
            },
          },
          {
            imsiSubRangeId: 1,
            imsiSubRangeName: "imsiSubRange8",
            imsiStartRange: "1022023",
            imsiEndRange: "1822023",
            imsiDigits8: "262-03-901",
            archived: false,
            userName: 1,
            imsiMainRangeProductTypeResponse: {
              allImsiMainRanges: [
                {
                  imsiMainRangeId: 1,
                  mainRangeCombinedName: "testImsi489131",
                  systemStackId: 1,
                  greenIccidImsi: true,
                },
              ],
              allProductTypes: [
                {
                  productTypeId: 1,
                  name: "product_type1",
                  greenIccidImsi: null,
                },
              ],
            },
          },
        ],
      },
    ]);

    test("Table should show correct data when archived unchecked", async () => {
      renderWithAllWrappers(<ImsiSubrangeTable isArchivedVisible={false} />);
      await waitFor(async () => {
        const mainrangeRows = await screen.findAllByTestId(/imsiSubrange-row/i);
        expect(mainrangeRows).toHaveLength(2);
      });
    });

    test("Table should show correct data when archived checked", async () => {
      renderWithAllWrappers(<ImsiSubrangeTable isArchivedVisible={true} />);
      await waitFor(async () => {
        const mainrangeRows = await screen.findAllByTestId(/imsiSubrange-row/i);
        expect(mainrangeRows).toHaveLength(2);
      });
    });

    test("Table should refresh on clicking refresh button", async () => {
      renderWithAllWrappers(<ImsiSubrangeTable isArchivedVisible={true} />);
      const refreshBtn = await screen.findByTestId(/refresh-button/);
      userEvent.click(refreshBtn);

      await waitFor(async () => {
        const mainrangeRows = await screen.findAllByTestId(/imsiSubrange-row/i);
        expect(mainrangeRows).toHaveLength(2);
      });
    });
  });

  describe("API Failure", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/imsi/loadIMSIMainRange`,
        status: 404,
        res: () => ({ message: "Oops! Something went wrong" }),
      },
    ]);

    test("Table should show correct message when server down", async () => {
      renderWithAllWrappers(<ImsiSubrangeTable isArchivedVisible={false} />);
      await waitFor(async () => {
        const hlrRows = screen.queryAllByTestId(/imsiSubrange-row/i);
        expect(hlrRows).toHaveLength(0);
      });
    });
  });
});
