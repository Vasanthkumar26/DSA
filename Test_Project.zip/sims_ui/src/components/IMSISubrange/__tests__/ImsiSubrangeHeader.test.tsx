import "@testing-library/jest-dom";
import { SetStateAction } from "react";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import { screen, fireEvent, render } from "@testing-library/react";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { Store, AnyAction } from "redux";
import { fetchImsiSubrangeExport } from "../../../redux/actions/imsiSubrangeAction";
import { ImsiMainrangeActionTypes } from "../../../redux/actions/types";
import ImsiSubrangeHeader from "../ImsiSubrangeHeader";

const mockStore = configureStore([thunk]);

jest.mock("../../../redux/actions/imsiSubrangeAction", () => ({
  fetchImsiSubrangeExport: jest.fn(),
}));

describe("header test", () => {
  let store: Store<unknown, AnyAction>;
  beforeEach(() => {
    store = mockStore({
      imsiSubrange: {
        imsiSubranges: ["a", "b"],
      },
      lang: {
        language: "en",
      },
    });
  });

  test("should load component without failed", () => {
    const { container } = renderWithAllWrappers(
      <ImsiSubrangeHeader
        isArchivedVisible={false}
        setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
        setShowForm={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
      />
    );
    expect(container).toBeInTheDocument();
  });

  test("rende the export button", () => {
    renderWithAllWrappers(
      <ImsiSubrangeHeader
        isArchivedVisible={false}
        setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
        setShowForm={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
      />
    );

    expect(screen.getByText(/Export/i)).toBeInTheDocument();
  });

  test("should call the handleExport on button click", async () => {
    // @ts-ignore:next-line
    fetchImsiSubrangeExport.mockImplementation(() => {
      return {
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_SUCCESS,
        payload: { message: "successfull" },
      };
    });
    render(
      <Provider store={store}>
        <ImsiSubrangeHeader
          isArchivedVisible={false}
          setIsArchivedVisible={function (
            value: SetStateAction<boolean>
          ): void {
            throw new Error("Function not implemented.");
          }}
          setShowForm={function (value: SetStateAction<boolean>): void {
            throw new Error("Function not implemented.");
          }}
        />
      </Provider>
    );
    const button = screen.getByRole("export-button");
    await fireEvent.click(button);
    expect(fetchImsiSubrangeExport).toHaveBeenCalled();
  });
});
