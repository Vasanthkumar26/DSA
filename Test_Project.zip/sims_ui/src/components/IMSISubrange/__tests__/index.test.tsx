import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import IMSISubrange from "..";

describe("IMSISubrange", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<IMSISubrange />, {
      route: "/",
    });

    expect(container).toBeInTheDocument();
  });
});
