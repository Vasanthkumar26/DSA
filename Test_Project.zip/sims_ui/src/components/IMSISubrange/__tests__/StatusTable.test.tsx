//@ts-nocheck
import "@testing-library/jest-dom";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import StatusTable from "../StatusTable";
import { screen, waitFor } from "@testing-library/react";
import {
  SUBRANGE_API_FAILURE,
  SUBRANGE_API_SUCCESS
} from "../../../_mocks_/subrangeApiHandlers";

describe("Status table subrange", () => {
  const payload = {
    startIMSIForSearch: "232",
    endIMSIForSearch: "123123"
  };

  describe("SUCCESS", () => {
    createServer(SUBRANGE_API_SUCCESS);

    test("Should render without crash", () => {
      const { container } = renderWithAllWrappers(
        <StatusTable payload={payload} />
      );
      expect(container).toBeInTheDocument();
    });

    test("Table Should shoow correct data", async () => {
      renderWithAllWrappers(<StatusTable payload={payload} />);
      const records = await screen.findAllByTestId(/status-subrange-row/i);
      expect(records).toHaveLength(1);
    });
  });

  describe("FAILURE", () => {
    createServer(SUBRANGE_API_FAILURE);

    test("Should show zero record", async () => {
      renderWithAllWrappers(<StatusTable payload={payload} />);
      await waitFor(async () => {
        const tableRow = screen.queryAllByTestId(/status-subrange-row/i);
        expect(tableRow).toHaveLength(0);
      });
    });
  });
});
