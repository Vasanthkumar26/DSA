import React, { FC, useEffect, useMemo, useState } from "react";
import { Grid } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import {
  fetchImsiSubranges,
  setSelectedImsiSubrange,
  resetImsiSubrangeError
} from "../../redux/actions/imsiSubrangeAction";

import { connect, ConnectedProps } from "react-redux";
import { HeadCell, ImsiSubrange, TableConfig } from "../../models";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";
import CustomSnackBar from "../common/CustomSnackBar";
import { useSearchParams } from "react-router-dom";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
}

const headCells: Array<HeadCell> = [
  { id: "name", label: "Name" },
  { id: "ismiMainrange", label: "IMSI-Mainrange" },
  { id: "imsiDigits12345678", label: "IMSI-Digit 1-8" },
  { id: "startImsi", label: "Start-IMSI" },
  { id: "endImsi", label: "End-IMSI" },
  { id: "productType", label: "Producttype" }
];

const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};

const tableConfig: TableConfig = {
  title: "Subrange Administration",
  orderBy: "lastUpdateDate",
  tableRowTestId: "imsiSubrange-row"
};

const ImsiSubrangeTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchImsiSubranges,
  setSelectedImsiSubrange,
  imsiSubranges = [],
  deleteSuccessMsgFlag,
  deleteSuccessMsg,
  archSuccessMsgFlag,
  archSuccessMsg,
  resetImsiSubrangeError
}) => {
  const [nameFilter, setNameFilter] = useState("");
  const [ismiMainrangeFilter, setIsmiMainrangeFilter] = useState("");
  const [imsiDigitFilter, setImsiDigitFilter] = useState("");
  const [startImsiFilter, setStartImsiFilter] = useState("");
  const [endImsiFilter, setEndImsiFilter] = useState("");
  const [productTypeFilter, setProductTypeFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const t = useTranslation();
  const [searchParams] = useSearchParams();
  const [predefinedImsiMainRange, setPredefinedImsiMainRange] = useState(
    searchParams.get("predefinedImsiMainRange") ?? "0"
  );
  const [showArchived, setShowArchived] = useState("false");

  useEffect(() => {
    if (predefinedImsiMainRange !== "0") {
      setPredefinedImsiMainRange(
        searchParams.get("predefinedImsiMainRange") ?? "0"
      );
    } else {
      setPredefinedImsiMainRange("0");
    }
    setShowArchived(searchParams.get("showArchived") ?? "false");
    (async () =>
      await fetchImsiSubranges(
        isArchivedVisible,
        predefinedImsiMainRange,
        showArchived
      ))();
  }, [
    fetchImsiSubranges,
    isArchivedVisible,
    predefinedImsiMainRange,
    searchParams,
    showArchived
  ]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getArchivedFilter = (imsiSubrange: ImsiSubrange) => {
    if (archivedFilter === "Yes") {
      return !!imsiSubrange.archived;
    }
    return archivedFilter === "No" ? !imsiSubrange.archived : true;
  };

  let visibleSubranges = imsiSubranges?.filter(
    (imsiSubrange) =>
      imsiSubrange.name.includes(nameFilter) &&
      imsiSubrange.ismiMainrange.includes(ismiMainrangeFilter) &&
      imsiSubrange.imsiDigits12345678.includes(imsiDigitFilter) &&
      imsiSubrange.startImsi.includes(startImsiFilter) &&
      imsiSubrange.endImsi.includes(endImsiFilter) &&
      imsiSubrange.productType.includes(productTypeFilter) &&
      getArchivedFilter(imsiSubrange)
  );

  if (!isArchivedVisible) {
    visibleSubranges = visibleSubranges?.filter((hlr) => !hlr.archived);
  }

  const filterHeadCellMap = {
    [headCells[0].id]: {
      filter: nameFilter,
      setFilter: setNameFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[1].id]: {
      filter: ismiMainrangeFilter,
      setFilter: setIsmiMainrangeFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[2].id]: {
      filter: imsiDigitFilter,
      setFilter: setImsiDigitFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[3].id]: {
      filter: startImsiFilter,
      setFilter: setStartImsiFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[4].id]: {
      filter: endImsiFilter,
      setFilter: setEndImsiFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[5].id]: {
      filter: productTypeFilter,
      setFilter: setProductTypeFilter,
      filterComponent: FilterSearchBar(t)
    },
    [archivedCell.id]: {
      filter: archivedFilter,
      setFilter: setArchivedFilter,
      filterComponent: FilterDropdown(archivedCell.values, t)
    }
  };

  const resetAllFilters = useMemo(() => {
    return () => {
      setNameFilter("");
      setIsmiMainrangeFilter("");
      setImsiDigitFilter("");
      setStartImsiFilter("");
      setEndImsiFilter("");
      setProductTypeFilter("");
      setArchivedFilter("");
    };
  }, []);

  const handleRowSelected = (row: any) => {
    setSelectedImsiSubrange(row);
  };

  const handleRefresh = async () => {
    setPredefinedImsiMainRange("0");
    await fetchImsiSubranges(
      isArchivedVisible,
      predefinedImsiMainRange,
      showArchived
    );
    resetAllFilters();
  };

  const visibleHeadCells = [
    ...headCells,
    ...(isArchivedVisible ? [archivedCell] : [])
  ];
  function handleCloseSnackbar(): void {
    resetImsiSubrangeError();
  }
  return (
    <Grid container direction="row" wrap="nowrap">
      <CustomSnackBar
        variant="filled"
        open={deleteSuccessMsgFlag || archSuccessMsgFlag}
        autoHideDuration={3000}
        message={deleteSuccessMsg || archSuccessMsg}
        onClose={handleCloseSnackbar}
        severity="success"
      />
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleSubranges]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.imsiSubrange.isLoadingExport,
  imsiSubranges: state.imsiSubrange.imsiSubranges,
  deleteSuccessMsg: state.imsiSubrange.deleteSuccessMsg,
  deleteSuccessMsgFlag: state.imsiSubrange.deleteSuccessMsgFlag,
  archSuccessMsg: state.imsiSubrange.archSuccessMsg,
  archSuccessMsgFlag: state.imsiSubrange.archSuccessMsgFlag
});

const connector = connect(mapStateToProps, {
  fetchImsiSubranges,
  setSelectedImsiSubrange,
  resetImsiSubrangeError
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ImsiSubrangeTable);
