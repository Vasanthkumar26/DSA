import React, { Dispatch, FC, SetStateAction, useCallback } from "react";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import {
  fetchImsiSubrangeExport,
  resetImsiSubrangeForm,
} from "../../redux/actions/imsiSubrangeAction";
import TableHeader from "../common/TableHeader";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
  isLoadingExport: boolean;
}

const ImsiSubrangeHeader: FC<Props> = ({
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  fetchImsiSubrangeExport,
  isLoadingExport,
  resetImsiSubrangeForm,
}) => {
  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleExport = useCallback(() => {
    fetchImsiSubrangeExport(isArchivedVisible);
  }, [fetchImsiSubrangeExport, isArchivedVisible]);

  const handleAdd = useCallback(() => {
    resetImsiSubrangeForm();
    setShowForm(false);
    setTimeout(() => {
      setShowForm(true);
    }, 0);
  }, [setShowForm, resetImsiSubrangeForm]);

  return (
    <TableHeader
      title="IMSI Subrange Administration"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.imsiSubrange.isLoadingExport,
});

const connector = connect(mapStateToProps, {
  fetchImsiSubrangeExport,
  resetImsiSubrangeForm,
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ImsiSubrangeHeader);
