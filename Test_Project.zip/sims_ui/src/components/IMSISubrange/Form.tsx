import React, {
  Dispatch,
  SetStateAction,
  useEffect,
  useMemo,
  useState
} from "react";
import { Controller, useForm } from "react-hook-form";
import { TextField, Button, InputLabel, Box, Grid, Stack } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import { connect, ConnectedProps } from "react-redux";
import { RootState } from "../../redux/store";
import {
  createImsiSubrange,
  updateImsiSubrange,
  fetchMainRangeProductType,
  fetchImsiSubranges,
  setSelectedImsiSubrange,
  resetImsiSubrangeError,
  resetImsiSubrangeForm,
  archiveImsiSubRange,
  deleteImsiSubrange,
  resetImsiSubrange
} from "../../redux/actions/imsiSubrangeAction";
import CustomSnackBar from "../common/CustomSnackBar";
import Loader from "../UI/Loader";
import { DeleteDailog } from "../common/AddEditForm/DeleteDialog";
import { LastUpdated } from "../common/AddEditForm";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import { useSearchParams } from "react-router-dom";
import { resetPage } from "../../redux/actions/rootAction";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";

const defaultValues = {
  imsiSubRangeName: "",
  imsiStartRange: "",
  imsiEndRange: "",
  productTypeId: { label: "", id: -1 },
  imsiMainRangeId: { label: "", id: -1 },
  archived: false
};

interface ImsiSubrangeFormProps extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
  setSuccessSnackbarOpen: Dispatch<SetStateAction<boolean>>;
  setShowStatusTable: Dispatch<SetStateAction<boolean>>;
}

const ImsiSubrangeForm: React.FC<ImsiSubrangeFormProps> = ({
  productTypeList,
  mainRangeList,
  selectedSubrangeData,
  subrangeList,
  isLoading,
  error,
  createImsiSubrange,
  updateImsiSubrange,
  fetchMainRangeProductType,
  setShowForm,
  resetImsiSubrangeError,
  resetImsiSubrangeForm,
  archiveImsiSubRange,
  deleteImsiSubrange,
  setSelectedImsiSubrange,
  setShowStatusTable,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetImsiSubrange,
  resetPage
}) => {
  const t = useTranslation();
  const [searchParams] = useSearchParams();
  const [predefinedImsiMainRange] = useState(
    searchParams.get("predefinedImsiMainRange") ?? ""
  );
  const [subRangeExists, setSubRangeExists] = useState<boolean | null>(null);
  const [usedNames, setUsedNames] = useState<string[]>([]);
  const [overlap, setOverlap] = useState<boolean | null>(null);
  const [lessThan, setlessThan] = useState<boolean | null>(null);
  const [open, setOpen] = useState<boolean>(false);

  const formData = useMemo(
    () => ({
      imsiSubRangeName:
        selectedSubrangeData?.name || defaultValues.imsiSubRangeName,
      imsiStartRange:
        selectedSubrangeData?.startImsi || defaultValues.imsiStartRange,
      imsiEndRange: selectedSubrangeData?.endImsi || defaultValues.imsiEndRange,
      productTypeId:
        productTypeList?.find(
          (item) => item.id === selectedSubrangeData?.productTypeId
        ) ?? defaultValues.productTypeId,
      imsiMainRangeId:
        mainRangeList?.find(
          (item) => item.id === selectedSubrangeData?.imsiMainRangeId
        ) || defaultValues.imsiMainRangeId,
      archived: false
    }),
    [
      mainRangeList,
      productTypeList,
      selectedSubrangeData?.endImsi,
      selectedSubrangeData?.imsiMainRangeId,
      selectedSubrangeData?.name,
      selectedSubrangeData?.productTypeId,
      selectedSubrangeData?.startImsi
    ]
  );

  const { control, handleSubmit, reset, watch, getFieldState, setValue } =
    useForm({
      mode: "all",
      reValidateMode: "onChange",
      defaultValues: {
        ...formData
      }
    });

  useEffect(() => {
    selectedSubrangeData ? reset({ ...formData }) : reset({ ...defaultValues });
  }, [selectedSubrangeData, reset, formData]);

  const imsiSubRangeName = watch("imsiSubRangeName");
  const imsiStartRange = watch("imsiStartRange");
  const imsiEndRange = watch("imsiEndRange");
  const selectedMainrangeId = watch("imsiMainRangeId");

  useEffect(() => {
    let api;
    api = fetchMainRangeProductType();
    api.then(() => {}).finally();
  }, [fetchMainRangeProductType]);

  useEffect(() => {
    const namesList = subrangeList.reduce((result: Array<string>, obj) => {
      if (obj.name && typeof obj.name === "string" && obj.name.trim() !== "") {
        result.push(obj.name);
      }
      return result;
    }, []);
    setUsedNames(namesList);
  }, [subrangeList]);

  useEffect(() => {
    setSubRangeExists(null);

    const delayedCalculation = setTimeout(() => {
      if (imsiSubRangeName) {
        if (
          selectedSubrangeData &&
          selectedSubrangeData?.name === imsiSubRangeName
        ) {
          setSubRangeExists(false);
        } else {
          setSubRangeExists(usedNames.includes(imsiSubRangeName));
        }
      }
    }, 100);

    return () => {
      clearTimeout(delayedCalculation);
    };
  }, [imsiSubRangeName, usedNames, selectedSubrangeData]);

  useEffect(() => {
    setOverlap(null);
    setlessThan(null);
    const start = parseInt(imsiStartRange);
    const end = parseInt(imsiEndRange);

    if (start > end && end) {
      setlessThan(true);
      return;
    } else setlessThan(false);

    const isOverlap = subrangeList.some((subrange) => {
      if (selectedSubrangeData && selectedSubrangeData.id === subrange.id) {
        return false; // Ignore overlap check for selected subrange
      }
      if (subrange.imsiMainRangeId === selectedMainrangeId?.id) {
        const subrangeStart = parseInt(subrange.startImsi);
        const subrangeEnd = parseInt(subrange.endImsi);
        return (
          (start <= subrangeEnd && end >= subrangeStart) ||
          (start >= subrangeStart && start <= subrangeEnd) ||
          (end >= subrangeStart && end <= subrangeEnd)
        );
      }
      return false;
    });
    if (isOverlap) setOverlap(true);
    else setOverlap(false);
  }, [
    imsiStartRange,
    imsiEndRange,
    subrangeList,
    selectedSubrangeData,
    selectedMainrangeId?.id
  ]);

  const resetThisPage = () => {
    resetImsiSubrange();
    resetPage();
  };

  useEffect(() => {
    const fieldState = getFieldState("imsiMainRangeId");
    if (selectedSubrangeData) {
      return;
    }
    if (fieldState.isDirty) {
      setValue("imsiStartRange", "");
      setValue("imsiEndRange", "");
    }
  }, [
    getFieldState,
    reset,
    selectedMainrangeId,
    setValue,
    selectedSubrangeData
  ]);

  const handleArchiveConfirmation = () => {
    archiveImsiSubRange(
      selectedSubrangeData?.imsisubRangeId!,
      selectedSubrangeData?.archived!
    )
      .then(() =>
        showSuccessSnackbar(
          !selectedSubrangeData?.archived
            ? t("successfully_archived")
            : t("successfully_activated")
        )
      )
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const onSubmit = (data: any) => {
    let promiseAPI;

    const subRangeValues = {
      ...data,
      archived: false,
      userName: "1",
      imsiMainRangeId: data?.imsiMainRangeId?.id,
      productTypeId: data?.productTypeId?.id
    };
    if (selectedSubrangeData) {
      promiseAPI = updateImsiSubrange(
        subRangeValues,
        `${selectedSubrangeData?.id}`
      );
    } else {
      promiseAPI = createImsiSubrange(subRangeValues);
    }
    promiseAPI
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };
  const handleConfirmation = (flag: boolean): any => {
    setOpen(flag);
  };
  const handleCloseConfirmation = () => {
    setOpen(false);
    deleteImsiSubrange(selectedSubrangeData?.imsisubRangeId!)
      .then(() => showSuccessSnackbar(t("successfully_deleted")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  return (
    <>
      <DeleteDailog
        open={open}
        onDelete={handleConfirmation}
        handleCloseConfirmation={handleCloseConfirmation}
        message={"delete_confirmation"}
      ></DeleteDailog>
      <Loader isLoading={isLoading}></Loader>
      <CustomSnackBar
        open={!!error}
        onClose={resetImsiSubrangeError}
        autoHideDuration={2000}
        severity="error"
        variant="filled"
        message={error ? error.toString() : ""}
      />
      <Box
        component="form"
        onSubmit={handleSubmit(onSubmit)}
        sx={{
          backgroundColor: "#F3F4FF",
          padding: "10px"
        }}
      >
        <Grid container spacing={2}>
          <Grid item xs={6}>
            <InputLabel htmlFor="name" required>
              Name
            </InputLabel>
            <Controller
              name="imsiSubRangeName"
              control={control}
              rules={{
                required: true,
                pattern: {
                  value: /^[A-Za-z0-9-]+$/,
                  message: t("please_enter_only_alphanumeric_characters")
                }
              }}
              render={({ field, fieldState: { error } }) => (
                <TextField
                  id="imsiSubRangeName"
                  size="small"
                  {...field}
                  fullWidth
                  error={!!error || subRangeExists || undefined}
                  helperText={
                    error?.message ||
                    (error ? t("subrange_name_required") : "") ||
                    (subRangeExists && t("subrange_name_already_exists"))
                  }
                />
              )}
            />
          </Grid>

          <Grid item xs={6}>
            <FormControllerSelectWithSearch
              control={control}
              controlName="productTypeId"
              inputLabel={t("product_type")}
              options={productTypeList}
            />
          </Grid>
          <Grid item xs={4}>
            <FormControllerSelectWithSearch
              control={control}
              controlName="imsiMainRangeId"
              inputLabel={t("imsi_mainrange")}
              options={mainRangeList}
              required
              isDisabled={predefinedImsiMainRange !== "" ? true : false}
            />
          </Grid>
          <Grid item xs={4}>
            <InputLabel htmlFor="imsi5" required>
              {t("start_imsi_1-5")}
            </InputLabel>
            <Controller
              name="imsiStartRange"
              control={control}
              rules={{
                required: true,
                minLength: 7,
                maxLength: 7,
                pattern: /^[0-9]+$/
              }}
              render={({ field, fieldState: { error } }) => (
                <TextField
                  size="small"
                  {...field}
                  fullWidth
                  inputProps={{ maxLength: 7 }}
                  error={!!error || overlap || undefined}
                  helperText={
                    error?.message ||
                    (overlap && t("overlapping_range_detected")) ||
                    (lessThan && t("less_error")) ||
                    (error ? t("start_imsi_error") : "")
                  }
                />
              )}
            />
          </Grid>
          <Grid item xs={4}>
            <InputLabel htmlFor="imsi8" required>
              {t("end_imsi_9-15")}
            </InputLabel>
            <Controller
              name="imsiEndRange"
              control={control}
              rules={{
                required: true,
                minLength: 7,
                maxLength: 7,
                pattern: /^[0-9]+$/
              }}
              render={({ field, fieldState: { error } }) => (
                <TextField
                  size="small"
                  {...field}
                  fullWidth
                  inputProps={{ maxLength: 7 }}
                  error={!!error || overlap || undefined}
                  helperText={
                    error?.message ||
                    (overlap && t("overlapping_range_detected")) ||
                    (lessThan && t("less_error")) ||
                    (error ? t("end_imsi_error") : "")
                  }
                />
              )}
            />
          </Grid>
        </Grid>
        {selectedSubrangeData && (
          <Grid item xs={12}>
            <LastUpdated
              lastUpdatedDate={selectedSubrangeData?.lastUpdateDate}
            />
          </Grid>
        )}
        <Box mt={2}>
          <Stack
            direction="row"
            justifyContent="space-between"
            spacing={2}
            sx={{ marginY: "1em" }}
          >
            <Stack direction="row" justifyContent="space-between" spacing={2}>
              {selectedSubrangeData && selectedSubrangeData.archived && (
                <Button
                  variant="contained"
                  onClick={() => {
                    handleArchiveConfirmation();
                  }}
                  sx={{
                    textTransform: "none"
                  }}
                  data-testid="archive"
                >
                  {t("button_active")}
                </Button>
              )}
              {selectedSubrangeData && !selectedSubrangeData.archived && (
                <>
                  <Button
                    variant="contained"
                    onClick={() => {
                      handleArchiveConfirmation();
                    }}
                    sx={{
                      textTransform: "none"
                    }}
                    data-testid="archive"
                  >
                    {t("button_archived")}
                  </Button>
                  <Button
                    variant="contained"
                    onClick={() => {
                      handleConfirmation(true);
                    }}
                    data-testid="delete"
                  >
                    {t("button_delete")}
                  </Button>
                </>
              )}
            </Stack>
            <Stack
              direction="row"
              justifyContent="space-between"
              spacing={2}
              sx={{ marginBottom: "1em" }}
            >
              <Button
                variant="outlined"
                disabled={isLoading}
                sx={{
                  textTransform: "none"
                }}
                onClick={() => {
                  reset(defaultValues);
                  resetImsiSubrangeForm();
                }}
              >
                {t("button_cancel")}
              </Button>
              <Button
                disabled={
                  isLoading ||
                  overlap ||
                  lessThan ||
                  subRangeExists ||
                  undefined
                }
                variant="contained"
                sx={{
                  textTransform: "none"
                }}
                type="submit"
              >
                {t("button_save")}
              </Button>
              {selectedSubrangeData && (
                <Button
                  disabled={isLoading || undefined}
                  variant="contained"
                  sx={{
                    textTransform: "none"
                  }}
                  onClick={() => {
                    setShowStatusTable(true);
                  }}
                >
                  {t("View status")}
                </Button>
              )}
            </Stack>
          </Stack>
        </Box>
      </Box>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  productTypeList: state.imsiSubrange.productTypeList?.map((item) => {
    return {
      label: item?.name,
      id: item?.productTypeId
    };
  }),
  mainRangeList: state.imsiSubrange?.imsiMainRangeList?.map((item) => {
    return {
      label: item?.mainRangeCombinedName,
      id: item?.imsiMainRangeId
    };
  }),
  selectedSubrangeData: state.imsiSubrange.selectedImsiSubrange,
  isLoading: state.imsiSubrange.isLoading,
  error: state.imsiSubrange.error,
  subrangeList: state.imsiSubrange.imsiSubranges
});

const connector = connect(mapStateToProps, {
  createImsiSubrange,
  updateImsiSubrange,
  fetchMainRangeProductType,
  fetchImsiSubranges,
  archiveImsiSubRange,
  setSelectedImsiSubrange,
  resetImsiSubrangeError,
  resetImsiSubrangeForm,
  deleteImsiSubrange,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetImsiSubrange,
  resetPage
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ImsiSubrangeForm);
