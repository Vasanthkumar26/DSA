import { HeadCell, TableConfig } from "../../models";

export const headCells: Array<HeadCell> = [
  { id: "startImsi", label: "Start IMSI" },
  { id: "endImsi", label: "End IMSI" },
  { id: "amount", label: "Anzahl" },
  { id: "hlrName", label: "HLR" },
  { id: "status", label: "Status" },
  { id: "productTypeName", label: "Product Type" },
  { id: "oaRefPoPk", label: "orderNumber" },
  { id: "cardTypeName", label: "Card types" },
  { id: "systemStack", label: "serv_provider" }
];

export const tableConfig: TableConfig = {
  title: "Status table",
  orderBy: "lastUpdatedDate",
  tableRowTestId: "status-subrange-row"
};
