import { FC, useEffect } from "react";
import { headCells, tableConfig } from "./Subrange.data";
import TableView from "../common/TableView";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import { fetchImsiSubrangeStatusTable } from "../../redux/actions/imsiSubrangeAction";
import { ImsiSubAndMainRangeStatusRequestPayload } from "../../models/global.model";
interface Props extends PropsFromRedux {
  payload: ImsiSubAndMainRangeStatusRequestPayload;
}
const StatusTable: FC<Props> = ({
  isLoadingTable,
  fetchImsiSubrangeStatusTable,
  payload,
  subrangeStatusDetail
}) => {
  useEffect(() => {
    (async () => await fetchImsiSubrangeStatusTable(payload))();
  }, [fetchImsiSubrangeStatusTable, payload]);

  const handleRefreash = async () => {
    await fetchImsiSubrangeStatusTable(payload);
  };
  return (
    <TableView
      isLoading={isLoadingTable}
      visibleHeadCells={headCells}
      visibleItems={[...subrangeStatusDetail]}
      handleRefresh={handleRefreash}
      tableConfig={tableConfig}
      isFilterSortingVisible={false}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingTable: state.imsiSubrange.isLoadingFetchStatusTable,
  subrangeStatusDetail: state.imsiSubrange.subrangestatusdetail
});

const connector = connect(mapStateToProps, {
  fetchImsiSubrangeStatusTable
});

type PropsFromRedux = ConnectedProps<typeof connector>;
export default connector(StatusTable);
