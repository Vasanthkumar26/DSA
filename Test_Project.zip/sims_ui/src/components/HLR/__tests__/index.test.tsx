import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import HLR from "..";

describe("HLR", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<HLR />, { route: "/" });

    expect(container).toBeInTheDocument();
  });
});
