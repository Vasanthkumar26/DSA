import "@testing-library/jest-dom";
import { SetStateAction } from "react";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import { screen } from "@testing-library/react";
import HlrHeader from "../HlrHeader";

describe("header test", () => {
  test("should load component without failed", () => {
    const { container } = renderWithAllWrappers(
      <HlrHeader
        isArchivedVisible={false}
        setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
        setShowForm={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
      />
    );
    expect(container).toBeInTheDocument();
  });

  test("rende the export button", () => {
    renderWithAllWrappers(
      <HlrHeader
        isArchivedVisible={false}
        setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
        setShowForm={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
      />
    );

    expect(screen.getByText(/Export/i)).toBeInTheDocument();
  });
});
