// @ts-nocheck
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import "@testing-library/jest-dom";
import { screen, waitFor } from "@testing-library/react";
import HlrTable from "../HlrTable";
import { REACT_BASE_URL } from "../../../utils/common";

describe("HlrTable", () => {
  test("should render without crash", () => {
    const setShowForm = jest.fn();
    const { container } = renderWithAllWrappers(
      <HlrTable isArchivedVisible={false} setShowForm={setShowForm} />
    );
    expect(container).toBeInTheDocument();
  });

  describe("API success", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/hlr/loadHLR`,
        res: () => [
          {
            id: 3,
            iccid: 5,
            description: "description5",
            greenIccidImsi: true,
            imsiDigits123: "125",
            imsiDigits45: "45",
            hlrName: "HLRBLUE555",
            archived: false,
            userName: 123,
            lastUpdateDate: "2016-11-09T11:44:44.797",
            imsi_main_range_exists: false,
            imsiDigits12345: "125-45",
            dtoId: 3,
          },
        ],
      },
    ]);

    test("Table should show correct data when archived unchecked", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <HlrTable isArchivedVisible={false} setShowForm={setShowForm} />
      );
      await waitFor(async () => {
        const hlrRows = await screen.findAllByTestId(/hlr-row/i);
        expect(hlrRows).toHaveLength(1);
      });
    });

    test("Table should show correct data when archived checked", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <HlrTable isArchivedVisible={false} setShowForm={setShowForm} />
      );
      await waitFor(async () => {
        const hlrRows = await screen.findAllByTestId(/hlr-row/i);
        expect(hlrRows).toHaveLength(1);
      });
    });
  });
  describe("API Failure", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/hlr/loadHLR`,
        status: 404,
        res: () => ({ message: "Oops! Something went wrong" }),
      },
    ]);

    test("Table should show correct data when server down", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <HlrTable isArchivedVisible={false} setShowForm={setShowForm} />
      );
      await waitFor(async () => {
        const hlrRows = screen.queryAllByTestId(/hlr-row/i);
        expect(hlrRows).toHaveLength(0);
      });
    });
  });
});
