import * as yup from "yup";
import {
  ICCID_DIGIT,
  IMSI_DIGIT_BLUE,
  IMSI_DIGIT_GREEN
} from "../../utils/constants";

export const initData = {
  hlrName: "",
  description: "",
  greenSim: true,
  IMSIDigit: IMSI_DIGIT_GREEN.sort()[0],
  iccidDigit12: ""
};

export const setFormData = (data: any) => ({
  hlrName: data?.hlrName || initData.hlrName,
  description: data?.description || initData.description,
  greenSim:
    data?.greenIccidImsi === true
      ? true
      : data?.greenIccidImsi === false
      ? false
      : initData.greenSim,
  IMSIDigit: data?.imsiDigits12345 || initData.IMSIDigit,
  iccidDigit12: data?.iccid?.toString() || initData.iccidDigit12
});

export const hlrCreateSchema = (t: (key: string | undefined) => string) =>
  yup.object().shape({
    hlrName: yup
      .string()
      .required("hlr_name_is_missing" ?? "")
      .max(20),
    description: yup.string().max(1024),
    greenSim: yup.boolean().default(true),
    IMSIDigit: yup
      .string()
      .default(IMSI_DIGIT_GREEN.sort()[0])
      .when("greenSim", {
        is: true,
        then: (schema) => schema.required().oneOf(["", ...IMSI_DIGIT_GREEN]),
        otherwise: (schema) => schema.required().oneOf(["", ...IMSI_DIGIT_BLUE])
      }),
    iccidDigit12: yup.string().when("greenSim", {
      is: false,
      then: (schema) =>
        schema
          .oneOf(["", ...ICCID_DIGIT])
          .required("ICCID digit 12 must be a digit 0-9")
    })
  });

export const hlrUpdateSchema = (t: (key: string | undefined) => string) =>
  yup.object().shape({
    hlrName: yup
      .string()
      .required(t("hlr_name_is_missing") ?? "")
      .max(20),
    description: yup.string().max(1024),
    greenSim: yup.boolean().default(true),
    IMSIDigit: yup.string().required(),
    iccidDigit12: yup.string().when("greenSim", {
      is: false,
      then: (schema) =>
        schema
          .oneOf(["", ...ICCID_DIGIT])
          .required("ICCID digit 12 must be a digit 0-9")
    })
  });

export const createHlrPayload = (data: any, greenSim: any) => {
  const dataCopy = { ...data };
  if (greenSim) {
    delete dataCopy.iccidDigit12;
  }
  const splitIMSIDigit = dataCopy.IMSIDigit.split("-");
  delete dataCopy.IMSIDigit;
  const body = {
    ...dataCopy,
    imsiDigit123: splitIMSIDigit[0],
    imsiDigit45: splitIMSIDigit[1],
    archived: false,
    lastUpdatedDate: new Date().toISOString(),
    userName: "123"
  };
  return body;
};
