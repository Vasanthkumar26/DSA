// @ts-nocheck
import React, { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import {
  TextField,
  Button,
  InputLabel,
  Select,
  MenuItem,
  Box,
  Grid,
  Stack,
  FormHelperText,
  Typography
} from "@mui/material";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import { useTranslation } from "../../hooks/useTranslation";
import { handleFetchHlrs } from "../../services/HLRApi";
import { DeleteDailog } from "../common/AddEditForm/DeleteDialog";
import {
  ICCID_DIGIT,
  IMSI_DIGIT_BLUE,
  IMSI_DIGIT_GREEN
} from "../../utils/constants";
import {
  createHLR,
  setSelectedHLR,
  updateHLR,
  resetHLRErr,
  deleteHLR,
  archiveHlrs,
  resetHLR
} from "../../redux/actions/hlrAction";
import { connect } from "react-redux";
import dayjs from "dayjs";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import { resetPage } from "../../redux/actions/rootAction";
import {
  createHlrPayload,
  hlrCreateSchema,
  hlrUpdateSchema,
  initData,
  setFormData
} from "./Hlr.data";

const AddEditForm = ({
  setShowForm,
  createHLR,
  updateHLR,
  selectedHLR,
  setSelectedHLR,
  isLoadingCreate,
  isLoadingUpdate,
  deleteHLR,
  archiveHlrs,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetHLR,
  resetPage
}) => {
  const t = useTranslation();
  const [HLRExists, setHLRExists] = useState<boolean | null>(null);
  const [HLRNames, setHLRNames] = useState<string>([]);
  const [open, setOpen] = useState<boolean>(false);
  const resolver = useYupValidationResolver(
    selectedHLR ? hlrUpdateSchema(t) : hlrCreateSchema(t)
  );

  const { control, handleSubmit, reset, watch, setValue } = useForm({
    mode: "all",
    resolver,
    defaultValues: {
      ...initData
    }
  });

  useEffect(() => {
    selectedHLR ? reset(setFormData(selectedHLR)) : reset({ ...initData });
  }, [reset, selectedHLR]);

  const hlrName = watch("hlrName");
  const greenSim = watch("greenSim");

  const IMSIDigitOptions = greenSim
    ? IMSI_DIGIT_GREEN.sort()
    : IMSI_DIGIT_BLUE.sort();

  let IMSIDigitOptionsExtended = [...IMSIDigitOptions];

  if (
    selectedHLR &&
    selectedHLR?.imsiDigits12345 &&
    !IMSIDigitOptionsExtended.includes(selectedHLR?.imsiDigits12345)
  ) {
    IMSIDigitOptionsExtended.unshift(selectedHLR?.imsiDigits12345);
  }

  useEffect(() => {
    handleFetchHlrs(true)?.then((data) => {
      const usedHLRNames = data?.reduce((result: Array<string>, obj) => {
        if (
          obj.hlrName &&
          typeof obj.hlrName === "string" &&
          obj.hlrName.trim() !== ""
        ) {
          result.push(obj.hlrName);
        }
        return result;
      }, []);
      setHLRNames(usedHLRNames);
    });
  }, []);

  useEffect(() => {
    setValue("IMSIDigit", IMSIDigitOptionsExtended[0]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [IMSIDigitOptions, setValue]);

  useEffect(() => {
    setHLRExists(null);
    if (hlrName) {
      if (selectedHLR && selectedHLR?.hlrName === hlrName) {
        setHLRExists(false);
      } else {
        setHLRExists(HLRNames.includes(hlrName));
      }
    }
  }, [hlrName, HLRNames, selectedHLR]);

  const handleChangeSelectedIMSIDigit = (e) => {
    setValue("IMSIDigit", e.target.value);
  };

  const handleArchiveHlrs = () => {
    archiveHlrs(selectedHLR?.id, selectedHLR?.archived)
      .then(() => showSuccessSnackbar(
          !selectedHLR?.archived
            ? t("successfully_archived")
            : t("successfully_activated")
        ))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const resetThisPage = () => {
    resetHLR();
    resetPage();
  };

  const onSubmit = (data) => {
    const body = createHlrPayload(data, greenSim);
    const promiseAPI = selectedHLR
      ? updateHLR(body, selectedHLR?.id)
      : createHLR(body);
    promiseAPI
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const handleConfirmation = (flag): any => {
    setOpen(flag);
  };

  const handleCloseConfirmation = () => {
    deleteHLR(selectedHLR?.id)
      .then(() => showSuccessSnackbar(t("successfully_deleted")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };
  return (
    <>
      <DeleteDailog
        open={open}
        onDelete={handleConfirmation}
        handleCloseConfirmation={handleCloseConfirmation}
        message={"delete_confirmation"}
      ></DeleteDailog>
      <Box component="form" onSubmit={handleSubmit(onSubmit)}>
        <Box
          sx={{
            backgroundColor: "#F3F4FF",
            padding: "20px"
          }}
        >
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6} md={4}>
              <Controller
                name="hlrName"
                control={control}
                render={({ field, fieldState }) => {
                  return (
                    <>
                      <InputLabel htmlFor="hlrName" required>
                        {t("HLR Name")}
                      </InputLabel>
                      <TextField
                        id="hlrName"
                        {...field}
                        error={!!fieldState.error || HLRExists}
                        helperText={
                          t(fieldState.error?.message) ||
                          (HLRExists && t("HLR name already exists"))
                        }
                        fullWidth
                        size="small"
                        sx={{
                          backgroundColor: "white",
                          "& .MuiFormHelperText-root": {
                            ...{ margin: 0, backgroundColor: "#F3F4FF" },
                            ...(!HLRExists && { color: "green" })
                          }
                        }}
                        inputProps={{ maxLength: 20 }}
                      />
                    </>
                  );
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={8}>
              <Controller
                name="description"
                control={control}
                render={({ field, fieldState }) => (
                  <>
                    <InputLabel htmlFor="description">
                      {t("Description")}
                    </InputLabel>
                    <TextField
                      id="description"
                      {...field}
                      error={!!fieldState.error}
                      helperText={fieldState.error?.message}
                      fullWidth
                      size="small"
                      sx={{
                        backgroundColor: "white",
                        "& .MuiFormHelperText-root": {
                          margin: 0,
                          backgroundColor: "#F3F4FF"
                        }
                      }}
                      inputProps={{ maxLength: 1024 }}
                    />
                  </>
                )}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <Controller
                name="greenSim"
                control={control}
                render={({ field }) => (
                  <>
                    <InputLabel htmlFor="greenSim" required>
                      {t("Green ICCID")}
                    </InputLabel>
                    <Select
                      {...field}
                      id="greenSim"
                      size="small"
                      fullWidth
                      defaultValue={true}
                      sx={{ backgroundColor: "white" }}
                      disabled={
                        selectedHLR && selectedHLR?.imsi_main_range_exists
                      }
                      onChange={(e) => {
                        setValue("IMSIDigit", "");
                        if (e.target.value === true) {
                          setValue("iccidDigit12", "");
                        } else if (
                          e.target.value === false &&
                          selectedHLR &&
                          selectedHLR?.iccid
                        ) {
                          setValue("iccidDigit12", selectedHLR?.iccid);
                        }
                        field.onChange(e);
                      }}
                    >
                      <MenuItem value={true}>{t("Yes")}</MenuItem>
                      <MenuItem value={false}>{t("No")}</MenuItem>
                    </Select>
                  </>
                )}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <Controller
                name="IMSIDigit"
                control={control}
                render={({ field }) => (
                  <>
                    <InputLabel htmlFor="IMSIDigit" required>
                      {t("IMSI Digit 123-45")}
                    </InputLabel>
                    <Select
                      {...field}
                      disabled={
                        selectedHLR && selectedHLR?.imsi_main_range_exists
                      }
                      id="IMSIDigit"
                      size="small"
                      fullWidth
                      sx={{ backgroundColor: "white" }}
                      onChange={handleChangeSelectedIMSIDigit}
                    >
                      {IMSIDigitOptionsExtended.map((option) => (
                        <MenuItem key={option} value={option}>
                          {option}
                        </MenuItem>
                      ))}
                    </Select>
                  </>
                )}
              />
            </Grid>
            {selectedHLR && greenSim ? (
              <></>
            ) : (
              <Grid item xs={12} sm={6} md={4}>
                <Controller
                  name="iccidDigit12"
                  control={control}
                  render={({ field, fieldState }) => (
                    <>
                      <InputLabel htmlFor="iccidDigit12" required>
                        {t("ICCID Digit 12")}
                      </InputLabel>
                      <Select
                        {...field}
                        error={!!fieldState.error}
                        id="iccidDigit12"
                        size="small"
                        fullWidth
                        sx={{ backgroundColor: "white" }}
                      >
                        {ICCID_DIGIT.map((option) => (
                          <MenuItem key={option} value={option}>
                            {option}
                          </MenuItem>
                        ))}
                      </Select>
                      {!!fieldState.error ? (
                        <FormHelperText error>
                          {t(fieldState.error?.message)}
                        </FormHelperText>
                      ) : (
                        <></>
                      )}
                    </>
                  )}
                />
              </Grid>
            )}
            {selectedHLR ? (
              <Grid item xs={12}>
                <Stack direction="row" justifyContent="flex-end">
                  <Typography
                    align="center"
                    variant="h8"
                    color="#031a34"
                    sx={{ fontWeight: 500 }}
                  >
                    {t("Last updated") + " : "}
                    {selectedHLR.lastUpdateDate
                      ? `${dayjs(selectedHLR.lastUpdateDate).format(
                          "YYYY-MM-DD HH:mm:ss"
                        )} (${selectedHLR?.userName})`
                      : "N/A"}
                  </Typography>
                </Stack>
              </Grid>
            ) : (
              <></>
            )}
          </Grid>
        </Box>
        <Grid item xs={12}>
          <Stack
            direction="row"
            justifyContent={
              (selectedHLR && !selectedHLR?.imsi_main_range_exists) ||
              (selectedHLR &&
                selectedHLR?.imsi_main_range_exists &&
                !selectedHLR?.archived) ||
              (selectedHLR &&
                selectedHLR?.imsi_main_range_exists &&
                selectedHLR?.archived)
                ? "space-between"
                : "flex-end"
            }
            spacing={2}
            sx={{ marginTop: "1em" }}
          >
            {selectedHLR && !selectedHLR?.imsi_main_range_exists && (
              <Button
                variant="contained"
                onClick={() => {
                  handleConfirmation(true);
                }}
                data-testid="delete"
                sx={{
                  textTransform: "none"
                }}
              >
                {t("button_delete")}
              </Button>
            )}

            {selectedHLR &&
              selectedHLR?.imsi_main_range_exists &&
              !selectedHLR?.archived && (
                <Button
                  variant="contained"
                  onClick={handleArchiveHlrs}
                  data-testid="archived"
                  sx={{
                    textTransform: "none"
                  }}
                >
                  {t("button_archived")}
                </Button>
              )}

            {selectedHLR &&
              selectedHLR?.imsi_main_range_exists &&
              selectedHLR?.archived && (
                <Button
                  variant="contained"
                  onClick={() => {
                    handleArchiveHlrs();
                  }}
                  data-testid="active"
                  sx={{
                    textTransform: "none"
                  }}
                >
                  {t("button_active")}
                </Button>
              )}
            <Stack
              direction="row"
              justifyContent="flex-end"
              spacing={2}
              sx={{ marginBottom: "1em" }}
            >
              <Button
                variant="outlined"
                disabled={isLoadingCreate || isLoadingUpdate}
                sx={{
                  textTransform: "none"
                }}
                onClick={() => {
                  //reset(defaultValues);
                  setSelectedHLR(null);
                  setShowForm(false);
                }}
              >
                {t("button_cancel")}
              </Button>
              <Button
                disabled={isLoadingCreate || isLoadingUpdate}
                variant="contained"
                type="submit"
                sx={{
                  textTransform: "none"
                }}
              >
                {t("button_save")}
              </Button>
            </Stack>
          </Stack>
        </Grid>
      </Box>
    </>
  );
};

const mapStateToProps = ({ hlr }) => ({
  selectedHLR: hlr.selectedHLR,
  isLoadingCreate: hlr.isLoadingCreate,
  errorCreate: hlr.errorCreate,
  isLoadingUpdate: hlr.isLoadingUpdate,
  errorUpdate: hlr.errorUpdate,
  archiveSuccessMsg: hlr.archiveSuccessMsg
});

export default connect(mapStateToProps, {
  createHLR,
  updateHLR,
  setSelectedHLR,
  resetHLRErr,
  deleteHLR,
  archiveHlrs,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetHLR,
  resetPage
})(AddEditForm);
