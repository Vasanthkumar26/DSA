import React, { Dispatch, FC, SetStateAction, useCallback } from "react";
import { ConnectedProps, connect } from "react-redux";
import { fetchHLRExport, setSelectedHLR } from "../../redux/actions/hlrAction";
import { RootState } from "../../redux/store";
import TableHeader from "../common/TableHeader";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const HlrHeader: FC<Props> = ({
  isLoadingExport,
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  setSelectedHLR,
  fetchHLRExport
}) => {
  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleExport = useCallback(() => {
    fetchHLRExport(isArchivedVisible);
  }, [fetchHLRExport, isArchivedVisible]);

  const handleAdd = useCallback(() => {
    setSelectedHLR(null);
    setShowForm(true);
  }, [setSelectedHLR, setShowForm]);

  return (
    <TableHeader
      title="HLR Administration"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.hlr.isLoadingExport
});

const connector = connect(mapStateToProps, { fetchHLRExport, setSelectedHLR });
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(HlrHeader);
