import React, {
  Dispatch,
  FC,
  SetStateAction,
  useEffect,
  useMemo,
  useState,
} from "react";
import { Grid } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import {
  fetchHlrs,
  setSelectedHLR,
  resetHLRErr,
} from "../../redux/actions/hlrAction";

import { connect, ConnectedProps } from "react-redux";
import { HeadCell, Hlr, TableConfig } from "../../models";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";
import CustomSnackBar from "../common/CustomSnackBar";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const headCells: Array<HeadCell> = [
  { id: "hlrName", label: "HLR-Name" },
  { id: "description", label: "Description" },
  { id: "greenIccidImsi", label: "Green ICCID" },
  { id: "imsiDigits12345", label: "IMSI-Digit 1-5" },
  { id: "iccid", label: "ICCID Digit 12" },
];

const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"],
};

const greenICCIDCell = {
  id: "greenIccid",
  label: "Green ICCID",
  values: ["Yes", "No"],
};

const tableConfig: TableConfig = {
  title: "HLR Administration",
  orderBy: "lastUpdateDate",
  tableRowTestId: "hlr-row",
};

const HlrTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchHlrs,
  setSelectedHLR,
  hlrs = [],
  setShowForm,
  deleteSuccessMsg,
  deleteSuccessMsgFlag,
  resetHLRErr,
}) => {
  const [hlrNameFilter, setHlrNameFilter] = useState("");
  const [descriptionFilter, setDescriptionFilter] = useState("");
  const [greenICCIDFilter, setGreenICCIDFilter] = useState("");
  const [imsiDigitFilter, setImsiDigitFilter] = useState("");
  const [iccidDigitFilter, setIccidDigitFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchHlrs(isArchivedVisible))();
  }, [fetchHlrs, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getGreenIccidFilter = (hlr: Hlr) => {
    if (greenICCIDFilter === "Yes") {
      return !!hlr.greenIccidImsi;
    }
    return greenICCIDFilter === "No" ? !hlr.greenIccidImsi : true;
  };

  const getArchivedFilter = (hlr: Hlr) => {
    if (archivedFilter === "Yes") {
      return !!hlr.archived;
    }
    return archivedFilter === "No" ? !hlr.archived : true;
  };

  let visibleHlrs = hlrs?.filter(
    (hlr) =>
      hlr.description.includes(descriptionFilter) &&
      hlr.hlrName.includes(hlrNameFilter) &&
      getGreenIccidFilter(hlr) &&
      hlr.imsiDigits12345.includes(imsiDigitFilter) &&
      `${hlr.iccid}`?.includes(iccidDigitFilter) &&
      getArchivedFilter(hlr)
  );

  if (!isArchivedVisible) {
    visibleHlrs = visibleHlrs?.filter((hlr) => !hlr.archived);
  }

  const filterHeadCellMap = useMemo(
    () => ({
      [headCells[0].id]: {
        filter: hlrNameFilter,
        setFilter: setHlrNameFilter,
        filterComponent: FilterSearchBar(t),
      },
      [headCells[1].id]: {
        filter: descriptionFilter,
        setFilter: setDescriptionFilter,
        filterComponent: FilterSearchBar(t),
      },
      [headCells[2].id]: {
        filter: greenICCIDFilter,
        setFilter: setGreenICCIDFilter,
        filterComponent: FilterDropdown(greenICCIDCell.values, t),
      },
      [headCells[3].id]: {
        filter: imsiDigitFilter,
        setFilter: setImsiDigitFilter,
        filterComponent: FilterSearchBar(t),
      },
      [headCells[4].id]: {
        filter: iccidDigitFilter,
        setFilter: setIccidDigitFilter,
        filterComponent: FilterSearchBar(t),
      },
      [archivedCell.id]: {
        filter: archivedFilter,
        setFilter: setArchivedFilter,
        filterComponent: FilterDropdown(archivedCell.values, t),
      },
    }),
    [
      archivedFilter,
      descriptionFilter,
      greenICCIDFilter,
      hlrNameFilter,
      iccidDigitFilter,
      imsiDigitFilter,
      t,
    ]
  );

  const resetAllFilters = useMemo(() => {
    return () => {
      setHlrNameFilter("");
      setDescriptionFilter("");
      setGreenICCIDFilter("");
      setImsiDigitFilter("");
      setIccidDigitFilter("");
      setArchivedFilter("");
    };
  }, []);

  const visibleHeadCells = useMemo(
    () => [...headCells, ...(isArchivedVisible ? [archivedCell] : [])],
    [isArchivedVisible]
  );

  const handleRowSelected = (row: any) => {
    setSelectedHLR(null);
    setShowForm(false);
    setTimeout(() => {
      setSelectedHLR(row);
    }, 0);
  };

  const handleRefresh = async () => {
    await fetchHlrs(isArchivedVisible);
    resetAllFilters();
  };

  function handleCloseSnackbar(): void {
    resetHLRErr();
  }

  return (
    <Grid container direction="row" wrap="nowrap">
      <CustomSnackBar
        variant="filled"
        open={deleteSuccessMsgFlag}
        autoHideDuration={3000}
        message={deleteSuccessMsg}
        onClose={handleCloseSnackbar}
        severity="success"
      />
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleHlrs]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
      <Grid item display={{ xs: "none", lg: "block" }}>
        <img
          src="/sidebarIcons/Mask_Group_hlr.jpg"
          alt="background"
          style={{
            objectFit: "cover",
            width: "250px",
            height: "100%",
            margin: "1px",
          }}
        />
      </Grid>
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.hlr.isLoadingFetch,
  hlrs: state.hlr.hlrs,
  deleteSuccessMsg: state.hlr.deleteSuccessMsg,
  deleteSuccessMsgFlag: state.hlr.deleteSuccessMsgFlag,
});

const connector = connect(mapStateToProps, {
  fetchHlrs,
  setSelectedHLR,
  resetHLRErr,
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(HlrTable);
