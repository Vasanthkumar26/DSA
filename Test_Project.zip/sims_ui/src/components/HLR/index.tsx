import { Box, Grid } from "@mui/material";
import React, { FC, useState } from "react";
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";
import AddEditForm from "./AddEditForm";
import Header from "./HlrHeader";
import HlrTable from "./HlrTable";

const HLR: FC = () => {
  const [isArchivedVisible, setIsArchivedVisible] = useState<boolean>(false);
  const [showForm, setShowForm] = useState<boolean>(false);

  const selectedHLR = useSelector((state: RootState) => state.hlr.selectedHLR);

  return (
    <>
      <Box sx={{ padding: 2 }}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Header
              isArchivedVisible={isArchivedVisible}
              setIsArchivedVisible={setIsArchivedVisible}
              setShowForm={setShowForm}
            />
            <HlrTable
              isArchivedVisible={isArchivedVisible}
              setShowForm={setShowForm}
            />
          </Grid>
          {showForm || selectedHLR ? (
            <Grid item xs={12}>
              <AddEditForm setShowForm={setShowForm} />
            </Grid>
          ) : (
            <></>
          )}
        </Grid>
      </Box>
    </>
  );
};

export default HLR;
