import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import { Provider } from "react-redux";
import CardTypesHeader from "../CardTypesHeader";
import { screen, fireEvent, render } from "@testing-library/react";
import { fetchCardTypesExport } from "../../../redux/actions/cardTypesAction";
import { CardTypeActionTypes } from "../../../redux/actions/types";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { Store, AnyAction } from "redux";

const mockStore = configureStore([thunk]);

jest.mock("../../../redux/actions/cardTypesAction", () => ({
  fetchCardTypesExport: jest.fn()
}));

describe("ExportToExcel", () => {
  let store: Store<unknown, AnyAction>;

  beforeEach(() => {
    store = mockStore({
      cardType: {},
      lang: {
        language: "en"
      }
    });
  });

  test("should load", () => {
    const { container } = renderWithAllWrappers(
      <CardTypesHeader
        isArchivedVisible={false}
        setIsArchivedVisible={jest.fn()}
      />
    );
    expect(container).toBeInTheDocument();
  });
  test("should download card types as excel", async () => {
    // @ts-ignore: Unreachable code error
    fetchCardTypesExport.mockImplementation(() => {
      return {
        type: CardTypeActionTypes.FETCH_CARD_TYPES_EXPORT_SUCCESS,
        payload: { message: "successful" }
      };
    });
    render(
      <Provider store={store}>
        <CardTypesHeader
          isArchivedVisible={false}
          setIsArchivedVisible={jest.fn()}
        />
      </Provider>
    );
    const button = screen.getByRole("export-button");
    fireEvent.click(button);
    expect(fetchCardTypesExport).toHaveBeenCalled();
  });
});
