// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import CardTypesAddEditForm from "../CardTypesAddEditForm";

describe("ExternalSystemsAddEditForm", () => {
  test("should render without crash", async () => {
    const { container } = renderWithAllWrappers(<CardTypesAddEditForm />);

    expect(container).toBeInTheDocument();
  });
});
