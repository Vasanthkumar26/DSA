import React, { FC, useEffect, useMemo, useState } from "react";
import { Grid } from "@mui/material";
import { RootState } from "../../redux/store";
import { connect, ConnectedProps } from "react-redux";
import { useTranslation } from "../../hooks/useTranslation";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import CustomSnackBar from "../common/CustomSnackBar";
import TableView from "../common/TableView";
import {
  fetchCardTypes,
  loadAllAkaHLRValues,
  setSelectedCardType,
  resetCardTypesErr
} from "../../redux/actions/cardTypesAction";
import {
  cardTypeArchivedCell,
  cardTypeHeadCells,
  cardTypeOneSim,
  cardTypePrepaid,
  cardTypeTableConfig
} from "./CardTypes.data";
import { CardTypeData } from "../../models";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
}

const CardTypesTable: FC<Props> = ({
  isArchivedVisible,
  fetchCardTypes,
  isLoadingFetch,
  cardTypes = [],
  loadAllAkaHLRValues,
  setSelectedCardType,
  resetCardTypesErr,
  deleteSuccessMsgFlag,
  deleteSuccessMsg,
  severity
}) => {
  const [nameFilter, setNameFilter] = useState("");
  const [technicalGuyFilter, setTechnicalGuyFilter] = useState("");
  const [versionFilter, setVersionFilter] = useState("");
  const [generationFilter, setGenerationFilter] = useState("");
  const [oneSimFilter, setOneSimFilter] = useState("");
  const [prepaidFilter, setPrepaidFilter] = useState("");
  const [hlrFilter, setHlrFilter] = useState("");
  const [iccidFilter, setIccidFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const t = useTranslation();

  useEffect(() => {
    fetchCardTypes(isArchivedVisible);
  }, [isArchivedVisible, fetchCardTypes]);

  useEffect(() => {
    loadAllAkaHLRValues();
  }, [loadAllAkaHLRValues]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const filterHeadCellMap = {
    [cardTypeHeadCells[0].id]: {
      filter: nameFilter,
      setFilter: setNameFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cardTypeHeadCells[1].id]: {
      filter: technicalGuyFilter,
      setFilter: setTechnicalGuyFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cardTypeHeadCells[2].id]: {
      filter: versionFilter,
      setFilter: setVersionFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cardTypeHeadCells[3].id]: {
      filter: generationFilter,
      setFilter: setGenerationFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cardTypeOneSim.id]: {
      filter: oneSimFilter,
      setFilter: setOneSimFilter,
      filterComponent: FilterDropdown(cardTypeOneSim.values, t)
    },
    [cardTypePrepaid.id]: {
      filter: prepaidFilter,
      setFilter: setPrepaidFilter,
      filterComponent: FilterDropdown(cardTypePrepaid.values, t)
    },
    [cardTypeHeadCells[6].id]: {
      filter: hlrFilter,
      setFilter: setHlrFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cardTypeHeadCells[7].id]: {
      filter: iccidFilter,
      setFilter: setIccidFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cardTypeArchivedCell.id]: {
      filter: archivedFilter,
      setFilter: setArchivedFilter,
      filterComponent: FilterDropdown(cardTypeArchivedCell.values, t)
    }
  };

  const visibleHeadCells = [
    ...cardTypeHeadCells,
    ...(isArchivedVisible ? [cardTypeArchivedCell] : [])
  ];

  const getArchivedFilter = (cardType: CardTypeData) => {
    if (archivedFilter === "Yes") {
      return !!cardType.archived;
    }
    return archivedFilter === "No" ? !cardType.archived : true;
  };

  const getOneSimFilter = (cardType: CardTypeData) => {
    if (oneSimFilter === "Yes") {
      return !!cardType.oneSim;
    }
    return oneSimFilter === "No" ? !cardType.oneSim : true;
  };

  const getPrepaidFilter = (cardType: CardTypeData) => {
    if (prepaidFilter === "Yes") {
      return !!cardType.prepaid;
    }
    return prepaidFilter === "No" ? !cardType.prepaid : true;
  };

  let visibleCardTypes = [...cardTypes].filter(
    (cardType) =>
      cardType.name?.toString()?.includes(nameFilter) &&
      cardType.technicalType?.toString()?.includes(technicalGuyFilter) &&
      cardType.version?.toString()?.includes(versionFilter) &&
      cardType.generation?.toString()?.includes(generationFilter) &&
      cardType.akaHlr?.toString()?.includes(hlrFilter) &&
      cardType?.iccId?.toString()?.includes(iccidFilter) &&
      getArchivedFilter(cardType) &&
      getOneSimFilter(cardType) &&
      getPrepaidFilter(cardType)
  );

  const resetAllFilters = useMemo(() => {
    return () => {
      setNameFilter("");
      setTechnicalGuyFilter("");
      setVersionFilter("");
      setGenerationFilter("");
      setOneSimFilter("");
      setPrepaidFilter("");
      setHlrFilter("");
      setIccidFilter("");
    };
  }, []);

  const handleRefresh = async () => {
    await fetchCardTypes(isArchivedVisible);
    resetAllFilters();
  };

  const handleRowSelected = async (row: any) => {
    setSelectedCardType(row);
  };
  function handleCloseSnackbar(): void {
    resetCardTypesErr();
  }

  const getSeverity = (notation: string | undefined) => {
    switch (notation) {
      case "error":
        return "error";
      default:
        return "success";
    }
  };

  return (
    <Grid container direction="row" wrap="nowrap">
      <CustomSnackBar
        variant="filled"
        open={deleteSuccessMsgFlag}
        autoHideDuration={3000}
        message={deleteSuccessMsg}
        onClose={handleCloseSnackbar}
        severity={getSeverity(severity)}
      />
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={visibleCardTypes}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={cardTypeTableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.cardType.isLoadingFetch,
  cardTypes: state.cardType.cardTypes,
  deleteSuccessMsg: state.cardType.deleteSuccessMsg,
  deleteSuccessMsgFlag: state.cardType.deleteSuccessMsgFlag,
  severity: state.cardType.severity
});

const connector = connect(mapStateToProps, {
  fetchCardTypes,
  loadAllAkaHLRValues,
  setSelectedCardType,
  resetCardTypesErr
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(CardTypesTable);
