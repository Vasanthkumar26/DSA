import { FC } from "react";
import { Grid } from "@mui/material";
import { manufacturerTitle, manufacturerTableConfig } from "./CardTypes.data";
import TableView from "../common/TableView";
interface Props {
  title: any;
  reload: boolean;
  refresh: () => void;
}

const SecondaryTable: FC<Props> = ({ title, reload, refresh }) => {
  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={reload}
        visibleHeadCells={manufacturerTitle}
        visibleItems={title}
        tableConfig={manufacturerTableConfig}
        handleRefresh={refresh}
      />
    </Grid>
  );
};

export default SecondaryTable;
