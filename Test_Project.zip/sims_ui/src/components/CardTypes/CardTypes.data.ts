import * as yup from "yup";
import {
  HeadCell,
  TableConfig,
  CardTypeData,
  CardTypesPayload,
  updateCardTypePayload
} from "../../models";

const initDropDown = { label: "", id: "" };

export const initData: any = {
  id: 1,
  iccId: initDropDown,
  name: "",
  provisioningIdentifier: "id",
  oneSim: true,
  prepaid: false,
  lte: true,
  version: "",
  generation: "",
  manufacturers: [],
  archived: true,
  akaHlr: initDropDown,
  simArticleList: [""],
  lastUpdatedBy: 1,
  lastUpdatedDate: "",
  technicalType: "",
  dtoId: 1
};

export const manufacturerTitle = [
  { id: "manufacturerName", label: "Manufacturer" },
  { id: "iccIdDigit7", label: "ID-(Digit7)" }
];

export const associatedManufacturerTitle = [
  { id: "manufacturerName", label: "Associated_Manufacturer" },
  { id: "iccIdDigit7", label: "ID-(Digit7)" }
];

export const cardTypeHeadCells: Array<HeadCell> = [
  { id: "name", label: "Name" },
  { id: "technicalType", label: "Techincal Type" },
  { id: "version", label: "Version" },
  { id: "generation", label: "Generation" },
  { id: "oneSim", label: "One Sim" },
  { id: "prepaid", label: "Prepaid" },
  { id: "akaHlr", label: "AKA_HLR" },
  { id: "iccId", label: "ICCID_13_Digit" }
];

export const cardTypeArchivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};

export const cardTypeOneSim = {
  id: "oneSim",
  label: "One Sim",
  values: ["Yes", "No"]
};

export const cardTypePrepaid = {
  id: "prepaid",
  label: "Prepaid",
  values: ["Yes", "No"]
};

export const cardTypeTableConfig: TableConfig = {
  title: "Card Types Management",
  orderBy: "lastUpdateDate",
  tableRowTestId: "externalSystems-row"
};

export const manufacturerTableConfig: TableConfig = {
  title: "manufacturer Table",
  orderBy: "lastUpdateDate",
  tableRowTestId: "externalSystems-row"
};

export const cardTypeSchema = (
  t: (key: string | undefined) => string,
  cardNames: string[],
  isCreate: boolean
) =>
  yup.object().shape({
    name: yup
      .string()
      .required("Name is missing")
      .notOneOf(
        [...(isCreate ? cardNames ?? [] : [])],
        t("name_already_exists")
      ),
    technicalType: yup.string().required("Technical Type is missing"),
    version: yup.string().required("Version is missing"),
    akaHlr: yup
      .object()
      .shape({
        label: yup.string().required(),
        id: yup.string().required()
      })
      .typeError("AKA HLR is missing")
      .required("AKA HLR is missing"),
    generation: yup.string().required("Generation is missing"),
    iccId: yup
      .object()
      .shape({
        label: yup.string().required(),
        id: yup.string().required()
      })
      .typeError("ICCID digit 12 must be a digit 0-9")
      .required("ICCID digit 12 must be a digit 0-9")
  });

export const setFormData = (
  data: CardTypeData,
  hlrValues: any,
  iccidDropDownValues: any
): CardTypesPayload => ({
  id: data?.id ?? "1",
  name: data?.name ?? "",
  provisioningIdentifier: data?.provisioningIdentifier ?? "id",
  iccId:
    iccidDropDownValues.find((item: any) => item?.id === data?.iccId) ??
    initDropDown,
  oneSim: data?.oneSim ?? "",
  prepaid: data?.prepaid ?? "",
  lte: true,
  archived: data?.archived ?? "false",
  akaHlr:
    hlrValues.find((item: any) => item?.label === data?.akaHlr) ?? initDropDown,
  lastUpdatedBy: data?.lastUpdatedBy ?? "",
  technicalType: data?.technicalType ?? "",
  generation: data?.generation ?? "",
  version: data?.version ?? "",
  manufacturers: data?.manufacturers ?? [],
  dtoId: data?.dtoId ?? "",
  lastUpdatedDate: data?.lastUpdatedDate ?? "",
  simArticleList: data?.simArticleList ?? ""
});

export const cardTypeCreatePayload = (
  data: any,
  oneSim: boolean,
  prePaid: boolean
) =>
  ({
    id: data?.id ?? "",
    name: data?.name ?? "",
    provisioningIdentifier: data?.provisioningIdentifier ?? "id",
    iccId: data?.iccId.id ?? "",
    oneSim: oneSim,
    prepaid: prePaid,
    lte: true,
    archived: data?.archived ?? "false",
    akaHlr: data?.akaHlr.id ?? "",
    lastUpdatedBy: data?.lastUpdatedBy ?? "",
    technicalType: data?.technicalType ?? "",
    generation: data?.generation ?? "",
    version: data?.version ?? "",
    manufacturers: data?.manufacturers ?? [],
    dtoId: data?.dtoId ?? "",
    lastUpdatedDate: data?.lastUpdatedDate ?? "",
    simArticleList: data?.simArticleList ?? ""
  } as CardTypesPayload);

export const cardTypeUpdatePayload = (
  data: any,
  oneSim: boolean,
  prePaid: boolean
) =>
  ({
    id: data?.id,
    name: data?.name,
    provisioningIdentifier: data?.provisioningIdentifier,
    iccId: data?.iccId?.id,
    oneSim: oneSim,
    prepaid: prePaid,
    lte: true,
    archived: data?.archived,
    akaHlr: data?.akaHlr?.id,
    lastUpdatedBy: data?.lastUpdatedBy,
    technicalType: data?.technicalType,
    generation: data?.generation,
    version: data?.version,
    lastUpdatedDate: data?.lastUpdatedDate,
    manufacturers: data?.manufacturers
  } as updateCardTypePayload);
