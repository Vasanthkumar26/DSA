import React, { FC, useState } from "react";
import { Box, Grid } from "@mui/material";
import { RootState } from "../../redux/store";
import { useSelector } from "react-redux";
import CardTypesHeader from "./CardTypesHeader";
import CardTypesTable from "./CardTypesTable";
import CardTypesAddEditForm from "./CardTypesAddEditForm";

const CardTypes: FC = () => {
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const selectedCardType = useSelector(
    (state: RootState) => state.cardType.selectedCardType
  );

  const hlrValues = useSelector((state: RootState) => state.cardType.hlrValues);

  const akaHlrDropDownValues = hlrValues?.map((value: any, i: number) => {
    return { label: value.displayValue, id: value.id };
  });

  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <CardTypesHeader
            isArchivedVisible={isArchivedVisible}
            setIsArchivedVisible={setIsArchivedVisible}
            setShowForm={setShowForm}
          />
          <CardTypesTable isArchivedVisible={isArchivedVisible} />
          {(showForm || selectedCardType) && (
            <Grid item xs={12}>
              <CardTypesAddEditForm
                setShowForm={setShowForm}
                isArchivedVisible={isArchivedVisible}
                akaHlrDropDownValues={akaHlrDropDownValues}
              />
            </Grid>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default CardTypes;
