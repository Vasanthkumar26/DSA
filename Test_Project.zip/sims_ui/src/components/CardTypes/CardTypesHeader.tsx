import { RootState } from "../../redux/store";
import { connect, ConnectedProps } from "react-redux";
import { Dispatch, FC, SetStateAction, useCallback } from "react";
import TableHeader from "../common/TableHeader";
import {
  fetchCardTypesExport,
  setSelectedCardType
} from "../../redux/actions/cardTypesAction";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const CardTypesHeader: FC<Props> = ({
  isArchivedVisible,
  setIsArchivedVisible,
  isLoadingExport = false,
  fetchCardTypesExport,
  setShowForm,
  setSelectedCardType
}) => {
  const handleArchiveChange = () => {
    setIsArchivedVisible(!isArchivedVisible);
  };
  const handleExport = useCallback(() => {
    fetchCardTypesExport(isArchivedVisible);
  }, [fetchCardTypesExport, isArchivedVisible]);

  const handleAdd = useCallback(() => {
    setShowForm(true);
    setSelectedCardType(null);
  }, [setSelectedCardType, setShowForm]);

  return (
    <TableHeader
      title="Card Types Management"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.cardType.isLoadingExport
});

const connector = connect(mapStateToProps, {
  fetchCardTypesExport,
  setSelectedCardType
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(CardTypesHeader);
