import {
  Dispatch,
  FC,
  SetStateAction,
  useCallback,
  useEffect,
  useState
} from "react";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import { DeleteDailog } from "../common/AddEditForm/DeleteDialog";
import {
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  Grid,
  Stack
} from "@mui/material";
import { Controller, useForm } from "react-hook-form";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import {
  initData,
  cardTypeSchema,
  associatedManufacturerTitle,
  setFormData,
  cardTypeCreatePayload,
  cardTypeUpdatePayload,
  manufacturerTableConfig,
  manufacturerTitle
} from "./CardTypes.data";
import SecondaryHeader from "../common/SecondaryHeader";
import { StyledFormBox } from "../common/styles/shared";
import { useTranslation } from "../../hooks/useTranslation";
import {
  FormActionButtons,
  FormControllerTextField
} from "../common/AddEditForm";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import {
  createCardType,
  setSelectedCardType,
  loadManufacturers,
  updateCardType,
  DeleteCardTypes,
  ArchiveCardTypes,
  fetchCardTypes,
  resetCardTypes
} from "../../redux/actions/cardTypesAction";
import { resetPage } from "../../redux/actions/rootAction";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import TableWithCheckBox from "../common/TableWithCheckBox";
import { ManufacturerValue } from "../../models";

interface Props extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
  isArchivedVisible: boolean;
  akaHlrDropDownValues: any;
}

const data = [...Array(10).keys()];

const iccidDropDownValues = data?.map((value: any, i: number) => {
  return { label: value.toString(), id: value };
});

const CardTypesAddEditForm: FC<Props> = ({
  setShowForm,
  cardTypeNames,
  errorCreate,
  errorUpdate,
  createCardType,
  selectedCardType,
  akaHlrDropDownValues,
  setSelectedCardType,
  loadManufacturers,
  manufacturersDetails,
  updateCardType,
  DeleteCardTypes,
  isLoadingManufacturer,
  ArchiveCardTypes,
  isArchivedVisible,
  showSuccessSnackbar,
  fetchCardTypes,
  resetCardTypes,
  resetPage
}) => {
  const t = useTranslation();
  const resolver = useYupValidationResolver(
    cardTypeSchema(t, [...(cardTypeNames ?? [])], !selectedCardType)
  );
  const [oneSim, setOneSim] = useState<boolean>(true);
  const [prePaid, setPrePaid] = useState<boolean>(false);
  const [prePaidDisable, setPrePaidDisable] = useState<boolean>(true);
  const [manufacturerSelectionList, setManufacturerSelectionList] = useState<
    Array<ManufacturerValue>
  >([]);
  const [
    associatedManufacturerSelectionList,
    setAssociatedManufacturerSelectionList
  ] = useState<Array<ManufacturerValue>>([]);
  const [open, setOpen] = useState<boolean>(false);
  const { control, handleSubmit, reset, getValues, setValue } = useForm({
    mode: "all",
    resolver,
    reValidateMode: "onSubmit",
    defaultValues: { ...initData }
  });

  useEffect(() => {
    if (errorCreate || errorUpdate) {
      showFailureSnackbar(errorCreate || errorUpdate || "");
    }
  }, [errorCreate, errorUpdate]);

  useEffect(() => {
    loadManufacturers();
    setManufacturerSelectionList([]);
    setAssociatedManufacturerSelectionList([]);
    selectedCardType
      ? reset(
          setFormData(
            selectedCardType,
            akaHlrDropDownValues ?? [],
            iccidDropDownValues
          )
        )
      : reset({ ...initData });
  }, [reset, selectedCardType, akaHlrDropDownValues, loadManufacturers]);

  const resetThisPage = () => {
    resetCardTypes();
    resetPage();
  };

  const onSubmit = (data: any) => {
    const createPayload = cardTypeCreatePayload(data, oneSim, prePaid);
    const updatePayload = cardTypeUpdatePayload(data, oneSim, prePaid);
    const cardTypeApi = selectedCardType
      ? updateCardType(updatePayload)
      : createCardType(createPayload);

    cardTypeApi
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .catch(() => showFailureSnackbar("error_while_submitting_data"))
      .finally(() => resetThisPage());
  };

  const handleOneSimChange = useCallback(() => {
    setOneSim((prev) => !prev);
    setPrePaidDisable((prev) => !prev);
  }, [setOneSim]);

  const handlePrePaidChange = useCallback(() => {
    setPrePaid((prev) => !prev);
  }, [setPrePaid]);

  const handleReset = useCallback(() => {
    reset({ ...initData });
    setSelectedCardType(null);
    setShowForm(false);
  }, [reset, setSelectedCardType, setShowForm]);

  const handleConfirmation: any = (flag: boolean): any => {
    setOpen(flag);
  };

  const popupCommonFunction = () => {
    handleConfirmation(false);
    handleReset();
    fetchCardTypes(isArchivedVisible);
  };

  const handleCloseConfirmation = () => {
    DeleteCardTypes(selectedCardType?.id!); //state variable selectedCardType.id //
    popupCommonFunction();
  };

  const handleArchive = () => {
    ArchiveCardTypes(selectedCardType?.id, !selectedCardType?.archived)
      .then(() =>
        showSuccessSnackbar(
          !selectedCardType?.archived
            ? t("successfully_archived")
            : t("successfully_activated")
        )
      )
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  useEffect(() => {
    if (oneSim && prePaid) {
      setPrePaid(false);
    }
  }, [oneSim, prePaid, setPrePaid]);

  const handleAssociatedManufacturerSelection = (
    checked: boolean,
    value: any
  ) => {
    if (checked) {
      setAssociatedManufacturerSelectionList([
        ...associatedManufacturerSelectionList,
        value
      ]);
    } else {
      const filteredList: any = associatedManufacturerSelectionList.filter(
        (content) => content.id !== value.id
      );
      setAssociatedManufacturerSelectionList([...filteredList]);
    }
  };

  const handleManufacturerSelection = (checked: boolean, value: any) => {
    if (checked) {
      setManufacturerSelectionList([...manufacturerSelectionList, value]);
    } else {
      const filteredList: any = manufacturerSelectionList.filter(
        (content) => content.id !== value.id
      );
      setManufacturerSelectionList([...filteredList]);
    }
  };

  const addAssociatedManufacturer: any = () => {
    const combinedArray = [
      ...getValues("manufacturers"),
      ...manufacturerSelectionList
    ];
    const uniqueArray = [
      ...new Set(combinedArray.map((Obj: any) => Obj.id))
    ].map((id) => combinedArray.find((Obj: any) => Obj.id === id));
    setValue("manufacturers", uniqueArray);
  };

  const removeAssociatedManufacturer: any = () => {
    const filteredArray = getValues("manufacturers").filter((item: any) =>
      associatedManufacturerSelectionList.some((e) => e.id !== item.id)
    );
    setValue("manufacturers", filteredArray);
    setAssociatedManufacturerSelectionList([]);
  };

  return (
    <>
      <DeleteDailog
        open={open}
        onDelete={() => handleConfirmation(false)}
        handleCloseConfirmation={() => handleCloseConfirmation()}
        message={"delete_confirmation"}
      ></DeleteDailog>
      <Box component="form" onSubmit={handleSubmit(onSubmit)}>
        <StyledFormBox>
          <Grid container spacing={2}>
            <Grid item xs={12}>
              <FormControllerTextField
                control={control}
                controlName="name"
                inputLabel="Name"
                required
              />
            </Grid>
            <Grid item xs={12}>
              <Grid container spacing={2} alignItems="flex-end">
                <Grid item xs={8}>
                  <FormControllerTextField
                    control={control}
                    controlName="technicalType"
                    inputLabel="Technical_Type"
                    required
                  />
                </Grid>
                <Grid item xs={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        role="archive-checkbox"
                        size="small"
                        checked={oneSim}
                        onChange={handleOneSimChange}
                      />
                    }
                    label={t("One_Sim")}
                    labelPlacement="start"
                  />
                </Grid>
                <Grid item xs={2}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        role="archive-checkbox"
                        size="small"
                        checked={prePaid}
                        disabled={prePaidDisable}
                        onChange={handlePrePaidChange}
                      />
                    }
                    label={t("Prepaid")}
                    labelPlacement="start"
                  />
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={12}>
              <Grid container spacing={2}>
                <Grid item xs={4}>
                  <FormControllerTextField
                    control={control}
                    controlName="version"
                    inputLabel="Version"
                    required
                  />
                </Grid>
                <Grid item xs={4}>
                  <FormControllerSelectWithSearch
                    control={control}
                    controlName="akaHlr"
                    inputLabel={t("AKA HLR")}
                    options={akaHlrDropDownValues ?? []}
                    required
                  />
                </Grid>
                <Grid item xs={4}>
                  <FormControllerTextField
                    control={control}
                    controlName="generation"
                    inputLabel="Generation"
                    required
                  />
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={4}>
              <FormControllerSelectWithSearch
                control={control}
                controlName="iccId"
                inputLabel={t("ICCID 13 Digit (only for 'blue' orders")}
                options={iccidDropDownValues}
                required
              />
            </Grid>
          </Grid>
        </StyledFormBox>
        <Stack direction="row" mt={2}>
          <Grid container spacing={2}>
            <Grid item xs={5}>
              <SecondaryHeader title={"Manufacturer"} />
              <TableWithCheckBox
                isLoading={isLoadingManufacturer}
                visibleHeadCells={manufacturerTitle}
                visibleItems={manufacturersDetails}
                handleCheckBoxClick={(checked, value) => {
                  handleManufacturerSelection(checked, value);
                }}
                tableConfig={manufacturerTableConfig}
              />
            </Grid>
            <Grid item xs={2} alignItems="center" sx={{ marginTop: "8rem" }}>
              <Stack spacing={2} alignItems="center">
                <Button
                  variant="contained"
                  style={{
                    backgroundColor: `${
                      associatedManufacturerSelectionList.length
                        ? "blue"
                        : " #c3c4c7"
                    }`
                  }}
                  disabled={!associatedManufacturerSelectionList.length}
                  onClick={removeAssociatedManufacturer}
                >
                  <KeyboardArrowLeftIcon />
                </Button>
                <Button
                  variant="contained"
                  style={{
                    backgroundColor: `${
                      manufacturerSelectionList.length ? "blue" : " #c3c4c7"
                    }`
                  }}
                  disabled={!manufacturerSelectionList.length}
                  onClick={addAssociatedManufacturer}
                >
                  <KeyboardArrowRightIcon />
                </Button>
              </Stack>
            </Grid>
            <Grid item xs={5}>
              <SecondaryHeader title={"Associated_Manufacturer"} />
              <Controller
                name={"manufacturers"}
                control={control}
                render={({ field, fieldState }) => {
                  return (
                    <TableWithCheckBox
                      isLoading={isLoadingManufacturer}
                      visibleHeadCells={associatedManufacturerTitle}
                      visibleItems={field.value}
                      handleCheckBoxClick={(checked, value) => {
                        handleAssociatedManufacturerSelection(checked, value);
                      }}
                      tableConfig={manufacturerTableConfig}
                    />
                  );
                }}
              />
            </Grid>
          </Grid>
        </Stack>
        <Grid xs={12} paddingTop={2}>
          <FormActionButtons
            onCancel={handleReset}
            onDelete={handleConfirmation}
            selectedData={selectedCardType}
            onActiveNArchive={handleArchive}
            isArchiveVisible={
              !selectedCardType?.archived && selectedCardType?.isReferenceExist
            }
            isDeleteVisible={!selectedCardType?.isReferenceExist}
            isActiveVisible={
              selectedCardType?.archived && selectedCardType?.isReferenceExist
            }
          />
        </Grid>
      </Box>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  errorCreate: state.cardType.errorCreate,
  errorUpdate: state.cardType.errorUpdate,
  selectedCardType: state.cardType.selectedCardType,
  manufacturersDetails: state.cardType.manufacturersDetails,
  isLoadingManufacturer: state.cardType.isLoadingManufacturer,
  cardTypeNames: state.cardType.cardTypes.map((item) => item.name)
});

const connector = connect(mapStateToProps, {
  showSuccessSnackbar,
  showFailureSnackbar,
  createCardType,
  setSelectedCardType,
  loadManufacturers,
  updateCardType,
  DeleteCardTypes,
  ArchiveCardTypes,
  fetchCardTypes,
  resetCardTypes,
  resetPage
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(CardTypesAddEditForm);
