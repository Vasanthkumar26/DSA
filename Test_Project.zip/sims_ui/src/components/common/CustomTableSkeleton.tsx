import React, { FC } from "react";
import { Skeleton, TableBody, TableCell, TableRow } from "@mui/material";

interface Props {
  colSpan: number;
}

const CustomTableSkeleton: FC<Props> = (props) => {
  const { colSpan } = props;

  return (
    <TableBody>
      {Array(5)
        .fill("")
        .map((_, i) => (
          <TableRow key={i}>
            <TableCell role="progressbar" colSpan={colSpan}>
              <Skeleton />
            </TableCell>
          </TableRow>
        ))}
    </TableBody>
  );
};

export default CustomTableSkeleton;
