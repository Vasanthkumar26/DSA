import React from "react";
import { IconButton, Stack, TextField } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { useRef } from "react";

type T = (key: string | undefined) => string | undefined;
interface InnerProps {
  setFilterBy: React.Dispatch<React.SetStateAction<string>>;
  filterHeadCell: any;
}

const FilterSearchBar = (t: T) => {
  const textFieldRef = useRef<HTMLInputElement>(null);

  return ({ filterHeadCell, setFilterBy }: InnerProps) => {
    const handleClick = () => {
      filterHeadCell?.setFilter(textFieldRef?.current?.value || "");
      setFilterBy("");
    };
    return (
      <Stack direction="row">
        <TextField
          inputRef={textFieldRef}
          label={t("Search")}
          variant="standard"
          size="small"
          defaultValue={filterHeadCell?.filter}
          onKeyPress={(event) => {
            if (event.key === "Enter") {
              handleClick();
            }
          }}
          InputProps={{
            disableUnderline: true,
          }}
          fullWidth
        />
        <IconButton onClick={handleClick} sx={{ marginTop: "8px" }}>
          <SearchIcon />
        </IconButton>
      </Stack>
    );
  };
};

export default FilterSearchBar;
