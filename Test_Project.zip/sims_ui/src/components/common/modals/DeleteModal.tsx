import { Button, Dialog, DialogActions, DialogTitle } from "@mui/material";
import { FC } from "react";
import { useTranslation } from "../../../hooks/useTranslation";

interface Props {
  isOpen: boolean;
  handleConfirm: () => void;
  handleCancel: () => void;
}

const DeleteModal: FC<Props> = ({ isOpen, handleConfirm, handleCancel }) => {
  const t = useTranslation();

  return (
    <Dialog open={isOpen} onClose={handleCancel} fullWidth maxWidth="xs">
      <DialogTitle id="alert-dialog-title">
        {t("delete_confirmation")}
      </DialogTitle>
      <DialogActions>
        <Button variant="contained" onClick={handleConfirm}>
          {t("button_ok")}
        </Button>
        <Button variant="outlined" onClick={handleCancel}>
          {t("button_cancel_dialog")}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default DeleteModal;
