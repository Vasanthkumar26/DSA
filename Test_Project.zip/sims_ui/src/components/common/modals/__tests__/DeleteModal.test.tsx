// @ts-nocheck
import "@testing-library/jest-dom";
import DeleteModal from "../DeleteModal";
import { renderWithAllWrappers } from "../../../../utils/testUtils";

describe("DeleteModal", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<DeleteModal />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
