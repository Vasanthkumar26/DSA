import { Button, Dialog, DialogActions, DialogTitle } from "@mui/material";
import { FC } from "react";
import { useTranslation } from "../../../hooks/useTranslation";

interface Props {
  isOpen: boolean;
  handleConfirm: () => void;
  handleCancel: () => void;
  confirmMessage: string;
}
//cancel_confirmation
const CancelModal: FC<Props> = ({
  isOpen,
  handleConfirm,
  handleCancel,
  confirmMessage
}) => {
  const t = useTranslation();

  return (
    <Dialog open={isOpen} onClose={handleCancel} fullWidth maxWidth="xs">
      <DialogTitle id="alert-dialog-title">{t(confirmMessage)}</DialogTitle>
      <DialogActions>
        <Button variant="contained" onClick={handleConfirm}>
          {t("button_ok")}
        </Button>
        <Button variant="outlined" onClick={handleCancel}>
          {t("button_cancel_dialog")}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default CancelModal;
