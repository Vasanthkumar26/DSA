import { FC, ReactNode } from "react";
import { FormControl, FormLabel, RadioGroup } from "@mui/material";
import { Control, Controller } from "react-hook-form";
import { useTranslation } from "../../../hooks/useTranslation";

interface Props {
  control: Control<any, any>;
  controlName: string;
  inputLabel: string;
  children: ReactNode;
  required?: boolean;
}

export const FormControllerRadioGroup: FC<Props> = ({
  control,
  controlName,
  inputLabel,
  children,
  required = false
}) => {
  const t = useTranslation();

  return (
    <Controller
      name={controlName ?? ""}
      control={control}
      render={({ field }) => {
        return (
          <FormControl>
            <FormLabel required={required}>{t(inputLabel ?? "")}</FormLabel>
            <RadioGroup row {...field}>
              {children}
            </RadioGroup>
          </FormControl>
        );
      }}
    />
  );
};
