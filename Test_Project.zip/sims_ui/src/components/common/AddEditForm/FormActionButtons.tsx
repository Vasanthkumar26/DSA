import { Button, Stack } from "@mui/material";
import { FC } from "react";
import { useTranslation } from "../../../hooks/useTranslation";

interface Props {
  onCancel: () => void;
  onDelete: (flag: boolean) => void;
  onActiveNArchive?: () => void;
  submitDisabled?: boolean;
  cancelDisabled?: boolean;
  isDeleteVisible?: boolean;
  isArchiveVisible?: boolean;
  isActiveVisible?: boolean;
  selectedData?: any;
}

export const FormActionButtons: FC<Props> = ({
  onCancel,
  onDelete,
  onActiveNArchive,
  submitDisabled = false,
  cancelDisabled = false,
  isDeleteVisible = false,
  isArchiveVisible = false,
  isActiveVisible = false,
  selectedData
}) => {
  const t = useTranslation();

  return (
    <Stack direction="row" justifyContent="space-between">
      <Stack direction="row" spacing={2}>
        {selectedData && (
          <>
            {isDeleteVisible && (
              <Button
                variant="contained"
                disabled={cancelDisabled}
                onClick={() => onDelete(true)}
              >
                {t("button_delete")}
              </Button>
            )}
            {isActiveVisible && onActiveNArchive && (
              <Button
                variant="contained"
                disabled={cancelDisabled}
                onClick={() => onActiveNArchive()}
              >
                {t("button_active")}
              </Button>
            )}
            {isArchiveVisible && onActiveNArchive && (
              <Button
                variant="contained"
                disabled={cancelDisabled}
                onClick={() => onActiveNArchive()}
              >
                {t("button_archived")}
              </Button>
            )}
          </>
        )}
      </Stack>
      <Stack direction="row" spacing={2}>
        <Button variant="outlined" disabled={cancelDisabled} onClick={onCancel}>
          {t("button_cancel")}
        </Button>
        <Button disabled={submitDisabled} variant="contained" type="submit">
          {t("button_save")}
        </Button>
      </Stack>
    </Stack>
  );
};
