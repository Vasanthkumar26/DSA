import { Control, UseFormSetValue } from "react-hook-form";
import { FC, useEffect, useState } from "react";
import { ISelectionOption } from "../../../models/global.model";
import { handleFetchServiceProviders } from "../../../services/commonApi";
import { FormControllerSelectWithSearch } from "./FormControllerSelectWithSearch";
import { store } from "../../../redux/store";
import { showFailureSnackbar } from "../../../redux/actions/snackbarAction";
import { sortDropDown } from "../../../utils/common";

interface Props {
  control: Control<any, any>;
  controlName: string;
  inputLabel: string;
  required?: boolean;
  setValue?: UseFormSetValue<any>;
  spid?: number | null;
  isDisabled?: boolean;
}
export const SPSelectWithSearch: FC<Props> = ({
  spid,
  controlName,
  setValue,
  ...props
}) => {
  const [sProviders, setSProviders] = useState<ISelectionOption[] | null>(null);

  useEffect(() => {
    if (!sProviders) {
      handleFetchServiceProviders()
        .then((res) => {
          if (res.length !== 0) {
            setSProviders(sortDropDown(res));
          } else {
            setSProviders(res);
          }
        })
        .catch((err: any) =>
          store.dispatch(showFailureSnackbar(err?.message || err))
        );
    }
  }, [sProviders]);

  return (
    <FormControllerSelectWithSearch
      {...props}
      options={sProviders ?? []}
      id={`${spid}`}
      controlName={controlName}
      setValue={setValue}
    />
  );
};
