import TextField from "@mui/material/TextField";
import Autocomplete from "@mui/material/Autocomplete";
import { FormHelperText, InputLabel } from "@mui/material";
import { useTranslation } from "../../../hooks/useTranslation";
import { Control, Controller, UseFormSetValue } from "react-hook-form";
import { FC, useEffect } from "react";
import { ISelectionOption } from "../../../models/global.model";
import { sortDropDown } from "../../../utils/common";

interface Props {
  control: Control<any, any>;
  controlName: string;
  inputLabel?: string;
  options: ISelectionOption[];
  id?: string | number | null;
  setValue?: UseFormSetValue<any>;
  required?: boolean;
  isDisabled?: boolean;
  isSorting?: boolean;
  defaultValue?: any;
}
export const FormControllerSelectWithSearch: FC<Props> = ({
  control,
  controlName,
  inputLabel,
  required = false,
  options,
  setValue = null,
  id = null,
  isDisabled,
  isSorting = true
}) => {
  const t = useTranslation();

  useEffect(() => {
    const value = options?.find((item) => +item.id === +(id ?? 0));
    if (value && setValue) {
      setValue(controlName, value);
    }
  }, [controlName, id, options, setValue]);

  // sorting on the basis of label
  if (options.length !== 0 && isSorting) {
    options = sortDropDown(options);
  }

  return (
    <Controller
      name={controlName ?? ""}
      control={control}
      rules={{
        required: inputLabel ? `${inputLabel} is required` : `required`
      }}
      render={({ field: { onChange, value }, fieldState }) => {
        return (
          <>
            <InputLabel htmlFor={inputLabel} required={required}>
              {t(inputLabel ?? "")}
            </InputLabel>
            <Autocomplete
              disablePortal
              id={controlName}
              data-testid={inputLabel}
              getOptionLabel={(option) => option.label}
              size="small"
              sx={{ width: "100%" }}
              options={options?.length !== 0 ? options : []}
              onChange={(event, values) => onChange(values)}
              value={{ label: t(value?.label), id: value?.id }}
              disabled={isDisabled}
              renderInput={(params) => (
                <TextField
                  {...params}
                  inputProps={{
                    ...params.inputProps,
                    autoComplete: ""
                  }}
                  placeholder={`${t("search")} ${t(inputLabel)}`}
                />
              )}
            />
            {fieldState.error ? (
              <FormHelperText error>
                {t(fieldState.error.message)}
              </FormHelperText>
            ) : (
              <></>
            )}
          </>
        );
      }}
    />
  );
};
