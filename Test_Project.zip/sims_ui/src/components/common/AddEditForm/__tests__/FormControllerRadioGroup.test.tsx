// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../../utils/testUtils";
import { useForm } from "react-hook-form";
import { renderHook } from "@testing-library/react";
import { FormControllerRadioGroup } from "../FormControllerRadioGroup";

describe("FormControllerRadioGroup", () => {
  const { result } = renderHook(() => useForm());
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(
      <FormControllerRadioGroup control={result.current.control} />,
      {
        route: "/"
      }
    );

    expect(container).toBeInTheDocument();
  });
});
