//@ts-nocheck
import "@testing-library/jest-dom";
import React from "react";
import { render, screen, renderHook } from "@testing-library/react";
import { FormControllerSelectWithSearch } from "../FormControllerSelectWithSearch";
import { useForm } from "react-hook-form";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { Store, AnyAction } from "redux";

const options = [
  { id: 1, label: "Option 1" },
  { id: 2, label: "Option 2" },
  { id: 3, label: "Option 3" }
];
const mockStore = configureStore([thunk]);

describe("test", () => {
  let store: Store<unknown, AnyAction>;
  beforeEach(() => {
    store = mockStore({
      lang: {
        language: "en"
      }
    });
  });
  const testId = "TestLabel";
  const RenderComponent = () => {
    // eslint-disable-next-line
    const abc = renderHook(() => useForm());
    return render(
      <Provider store={store}>
        <FormControllerSelectWithSearch
          control={abc.result.current.control}
          controlName="test-control"
          inputLabel="TestLabel"
          options={options}
          id={testId}
        />
      </Provider>
    );
  };

  it("should render the component with the correct props", () => {
    RenderComponent();

    expect(screen.getByText("TestLabel")).toBeInTheDocument();
    expect(screen.getByTestId(testId)).toBeInTheDocument();
  });

  it("should render the options in the autocomplete list", () => {
    RenderComponent();

    const optionsList = screen.getByTestId("TestLabel");
    optionsList.focus();

    expect(optionsList).toBeInTheDocument();
  });
});
