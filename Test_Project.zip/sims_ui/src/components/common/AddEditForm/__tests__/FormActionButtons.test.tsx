// @ts-nocheck
import "@testing-library/jest-dom";
import { FormActionButtons } from "../FormActionButtons";
import { renderWithAllWrappers } from "../../../../utils/testUtils";
import { render, screen } from "@testing-library/react";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { Store, AnyAction } from "redux";
import { Provider } from "react-redux";

const mockStore = configureStore([thunk]);

describe("FormActionButtons", () => {
  let store = Store<unknown, AnyAction>;
  beforeAll(() => {
    store = mockStore({
      lang: {
        language: "en"
      }
    });
  });

  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<FormActionButtons />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });

  describe("Buttons should be visible", () => {
    test("archive button", () => {
      const params = {
        onActiveNArchive: jest.fn(),
        selectedData: {},
        isArchiveVisible: true
      };
      render(
        <Provider store={store}>
          <FormActionButtons {...params} />
        </Provider>
      );
      //Archived//Archivieren
      const label = "Archived";
      const button = screen.queryByText(label);
      expect(button).not.toBeNull();
    });
    test("active button", () => {
      const params = {
        onActiveNArchive: jest.fn(),
        selectedData: {},
        isActiveVisible: true
      };
      render(
        <Provider store={store}>
          <FormActionButtons {...params} />
        </Provider>
      );
      //Archived//Archivieren
      const label = "Active";
      const button = screen.queryByText(label);
      expect(button).not.toBeNull();
    });
    test("delete button", () => {
      const params = {
        onActiveNArchive: jest.fn(),
        selectedData: {},
        isDeleteVisible: true
      };
      render(
        <Provider store={store}>
          <FormActionButtons {...params} />
        </Provider>
      );
      //Archived//Archivieren
      const label = "Delete";
      const button = screen.queryByText(label);
      expect(button).not.toBeNull();
      //expect(screen.getByText(label)).toBeInTheDocument();
    });
  });

  describe("Buttons should not be visible", () => {
    test("archive button", () => {
      const params = {
        onActiveNArchive: jest.fn(),
        selectedData: {},
        isArchiveVisible: false
      };
      render(
        <Provider store={store}>
          <FormActionButtons {...params} />
        </Provider>
      );
      //Archived//Archivieren
      const label = "Archived";
      const button = screen.queryByText(label);
      expect(button).toBeNull();
    });
    test("active button", () => {
      const params = {
        onActiveNArchive: jest.fn(),
        selectedData: {},
        isActiveVisible: false
      };
      render(
        <Provider store={store}>
          <FormActionButtons {...params} />
        </Provider>
      );
      //Archived//Archivieren
      const label = "Active";
      const button = screen.queryByText(label);
      expect(button).toBeNull();
    });
    test("delete button", () => {
      const params = {
        onActiveNArchive: jest.fn(),
        selectedData: {},
        isDeleteVisible: false
      };
      render(
        <Provider store={store}>
          <FormActionButtons {...params} />
        </Provider>
      );
      //Archived//Archivieren
      const label = "Delete";
      const button = screen.queryByText(label);
      expect(button).toBeNull();
      //expect(screen.getByText(label)).toBeInTheDocument();
    });
  });
});
