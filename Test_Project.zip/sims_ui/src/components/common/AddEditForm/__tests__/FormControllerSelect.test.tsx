// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../../utils/testUtils";
import { FormControllerSelect } from "../FormControllerSelect";
import { renderHook } from "@testing-library/react";
import { useForm } from "react-hook-form";

describe("FormControllerSelect", () => {
  const { result } = renderHook(() => useForm());
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(
      <FormControllerSelect control={result.current.control} />,
      {
        route: "/"
      }
    );

    expect(container).toBeInTheDocument();
  });
});
