// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../../utils/testUtils";
import { FormControllerTextField } from "../FormControllerTextField";
import { useForm } from "react-hook-form";
import { renderHook } from "@testing-library/react";

describe("FormControllerTextField", () => {
  const { result } = renderHook(() => useForm());
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(
      <FormControllerTextField control={result.current.control} />,
      {
        route: "/"
      }
    );

    expect(container).toBeInTheDocument();
  });
});
