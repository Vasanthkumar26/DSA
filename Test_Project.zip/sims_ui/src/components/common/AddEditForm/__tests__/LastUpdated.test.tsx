// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../../utils/testUtils";
import { LastUpdated } from "../LastUpdated";

describe("LastUpdated", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<LastUpdated />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
