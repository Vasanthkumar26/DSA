import { FC } from "react";
import { InputLabel } from "@mui/material";
import { Control, Controller } from "react-hook-form";
import { StyledFormTextField } from "../styles/shared";
import { useTranslation } from "../../../hooks/useTranslation";

interface Props {
  control: Control<any, any>;
  controlName: string;
  inputLabel: string;
  rows?: number;
  multiline?: boolean;
  required?: boolean;
  inputProps?: Record<string, any>;
  disabled?: boolean;
}

export const FormControllerTextField: FC<Props> = ({
  control,
  controlName,
  inputLabel,
  rows,
  multiline = false,
  required = false,
  inputProps,
  disabled = false
}) => {
  const t = useTranslation();
  return (
    <Controller
      name={controlName ?? ""}
      control={control}
      render={({ field, fieldState }) => {
        return (
          <>
            <InputLabel required={required} htmlFor={controlName}>
              {t(inputLabel ?? "")}
            </InputLabel>
            <StyledFormTextField
              id={controlName}
              fullWidth
              size="small"
              multiline={multiline}
              rows={rows}
              {...field}
              error={!!fieldState.error}
              helperText={t(fieldState.error?.message)}
              data-testid={inputLabel}
              inputProps={inputProps}
              disabled={disabled}
            />
          </>
        );
      }}
    />
  );
};
