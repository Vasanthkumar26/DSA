import { FC, ReactNode } from "react";
import { FormHelperText, InputLabel, Select } from "@mui/material";
import { Control, Controller } from "react-hook-form";
import { useTranslation } from "../../../hooks/useTranslation";

interface Props {
  control: Control<any, any>;
  controlName: string;
  inputLabel: string;
  children: ReactNode;
  required?: boolean;
  multiple?: boolean;
}

export const FormControllerSelect: FC<Props> = ({
  control,
  controlName,
  inputLabel,
  children,
  required,
  multiple = false
}) => {
  const t = useTranslation();

  return (
    <Controller
      name={controlName ?? ""}
      control={control}
      render={({ field, fieldState }) => {
        return (
          <>
            <InputLabel required={required}>{t(inputLabel ?? "")}</InputLabel>
            <Select
              {...field}
              size="small"
              fullWidth
              multiple={multiple}
              data-testid={controlName}
              sx={{ backgroundColor: "white" }}
              error={!!fieldState.error}
            >
              {children}
            </Select>
            {fieldState.error ? (
              <FormHelperText error>
                {t(fieldState.error.message)}
              </FormHelperText>
            ) : (
              <></>
            )}
          </>
        );
      }}
    />
  );
};
