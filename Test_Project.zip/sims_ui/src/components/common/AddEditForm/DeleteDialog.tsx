import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle
} from "@mui/material";
import { FC } from "react";
import { useTranslation } from "../../../hooks/useTranslation";

interface Props {
  onDelete: (flag: boolean) => boolean;
  handleCloseConfirmation: () => void;
  open?: boolean;
  message: string;
}

export const DeleteDailog: FC<Props> = ({
  onDelete,
  handleCloseConfirmation,
  open = false,
  message
}) => {
  const t = useTranslation();

  return (
    <Dialog
      open={open}
      onClose={() => onDelete(false)}
      aria-labelledby="alert-dialog-title"
      aria-describedby="alert-dialog-description"
      fullWidth
      maxWidth="xs"
    >
      <DialogTitle id="alert-dialog-title">{t(message)}</DialogTitle>
      <DialogContent>
        <DialogContentText id="alert-dialog-description"></DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button
          variant="contained"
          onClick={() => {
            handleCloseConfirmation();
          }}
        >
          {t("button_ok")}
        </Button>
        <Button variant="outlined" onClick={() => onDelete(false)}>
          {t("button_cancel_dialog")}
        </Button>
      </DialogActions>
    </Dialog>
  );
};
