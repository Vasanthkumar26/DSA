import { FC } from "react";
import { Control, Controller } from "react-hook-form";
import { useTranslation } from "../../../hooks/useTranslation";
import { InputLabel } from "@mui/material";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";

interface Props {
  control: Control<any, any>;
  controlName: string;
  inputLabel: string;
  isFutureDisable?: boolean;
  handleDisableDate?: (date: Date) => boolean;
}

export const FormControllerDatePicker: FC<Props> = ({
  control,
  controlName,
  inputLabel,
  isFutureDisable,
  handleDisableDate
}) => {
  const t = useTranslation();

  return (
    <Controller
      name={controlName ?? ""}
      control={control}
      render={({ field, fieldState: { error } }) => {
        return (
          <>
            <InputLabel required>{t(inputLabel ?? "")}</InputLabel>
            <LocalizationProvider dateAdapter={AdapterDayjs}>
              <DatePicker
                sx={{
                  backgroundColor: "white",
                  "& .MuiFormHelperText-root": {
                    margin: 0,
                    backgroundColor: "#F3F4FF"
                  }
                }}
                slotProps={{
                  textField: {
                    size: "small",
                    fullWidth: true,
                    error: !!error,
                    helperText: error?.message,
                    inputProps: {
                      "data-testid": inputLabel ?? ""
                    }
                  }
                }}
                {...field}
                format="DD.MM.YYYY"
                disableFuture={!!isFutureDisable}
                shouldDisableDate={(date) =>
                  !!handleDisableDate && handleDisableDate(date)
                }
              />
            </LocalizationProvider>
          </>
        );
      }}
    />
  );
};
