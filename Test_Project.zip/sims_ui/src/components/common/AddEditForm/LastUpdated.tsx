import { Stack, Typography } from "@mui/material";
import { useTranslation } from "../../../hooks/useTranslation";
import { FC } from "react";

interface Props {
  lastUpdatedDate: Date | string;
  lastUpdatedBy?: string | number;
}

export const LastUpdated: FC<Props> = ({
  lastUpdatedDate,
  lastUpdatedBy = "user"
}) => {
  const t = useTranslation();

  return (
    <Stack direction="row-reverse">
      <Typography
        align="center"
        color="#031a34"
        sx={{ fontWeight: 500, marginTop: "1em" }}
      >
        ({lastUpdatedBy})
      </Typography>
      <Typography
        align="center"
        color="#031a34"
        sx={{ fontWeight: 500, marginTop: "1em" }}
      >
        {t("Last updated") + " : "}
        {lastUpdatedDate?.toString()?.slice(0, 19)?.replace("T", " ") ?? "N/A"}
      </Typography>
    </Stack>
  );
};
