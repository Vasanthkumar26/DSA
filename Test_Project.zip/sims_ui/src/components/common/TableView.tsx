import React, { FC, ReactNode, useCallback, useEffect, useState } from "react";
import {
  Box,
  Grid,
  IconButton,
  Paper,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableRow,
  Typography
} from "@mui/material";
import RefreshIcon from "@mui/icons-material/Refresh";

import CustomTableHeader from "./CustomTableHeader";
import CustomTableSkeleton from "./CustomTableSkeleton";
import { useTranslation } from "../../hooks/useTranslation";
import { HeadCell, Order, TableConfig } from "../../models";
import { getComparator } from "../../utils/common";

interface Props {
  isLoading: boolean;
  visibleItems: Array<Record<string, any>>;
  visibleHeadCells: Array<HeadCell>;
  filterHeadCellMap?: any;
  handleRowSelected?: (row: any) => void;
  handleRefresh: () => void;
  tableConfig: TableConfig;
  tableFooter?: ReactNode;
  isFilterSortingVisible?: boolean;
}

const rowCellStyle = {
  borderRight: "1px solid #cac8ca",
  paddingY: 0,
  borderBottomColor: "white",
  borderBottomWidth: "3px"
};

const TableView: FC<Props> = ({
  isLoading,
  visibleItems,
  visibleHeadCells,
  filterHeadCellMap,
  handleRowSelected,
  handleRefresh,
  tableConfig,
  tableFooter,
  isFilterSortingVisible = true
}) => {
  const [order, setOrder] = useState<Order>("desc");
  const [orderBy, setOrderBy] = useState(tableConfig.orderBy);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const [filterBy, setFilterBy] = useState("");
  const t = useTranslation();

  useEffect(() => {
    setOrderBy(tableConfig.orderBy);
    setOrder("desc");
  }, [tableConfig.orderBy]);

  const handleRowClick = (row: any, i: number) => {
    setSelectedIndex(i);
    handleRowSelected?.(row);
  };

  const handleRequestSort = useCallback(
    (property: string) => {
      const isAsc = orderBy === property && order === "asc";
      setOrder(isAsc ? "desc" : "asc");
      setOrderBy(property);
    },
    [order, orderBy]
  );

  const handleRequestFilter = (property: string) => {
    setFilterBy(property);
  };

  const isSelected = (index: number) => selectedIndex === index;
  return (
    <Grid item xs>
      <Paper sx={{ maxWidth: "100%", overflow: "hidden" }}>
        <TableContainer sx={{ maxHeight: 406 }}>
          <Table
            stickyHeader
            aria-label={t(tableConfig.title)}
            size="small"
            sx={{ backgroundColor: "#F3F4FF" }}
          >
            <CustomTableHeader
              onRequestSort={handleRequestSort}
              onRequestFilter={handleRequestFilter}
              headCells={visibleHeadCells}
              order={order}
              orderBy={orderBy}
              filterBy={filterHeadCellMap && filterBy}
              onCloseModal={() => setFilterBy("")}
              filterHeadCellMap={filterHeadCellMap}
              isFilterSortingVisible={isFilterSortingVisible}
            >
              <Box paddingLeft={2} paddingRight={1} paddingBottom={1}>
                {filterHeadCellMap?.[filterBy]?.filterComponent({
                  setFilterBy,
                  filterHeadCell: filterHeadCellMap?.[filterBy]
                })}
              </Box>
            </CustomTableHeader>
            {isLoading ? (
              <CustomTableSkeleton colSpan={visibleHeadCells.length * 2 - 1} />
            ) : (
              <TableBody>
                {visibleItems?.length === 0 ? (
                  <TableRow>
                    <TableCell
                      colSpan={visibleHeadCells.length * 2 - 1}
                      align="center"
                    >
                      {t("Sorry! There is nothing to show here")}
                    </TableCell>
                  </TableRow>
                ) : (
                  [...visibleItems]
                    ?.sort(getComparator(order, orderBy))
                    ?.map((row: any, i: number) => (
                      <TableRow
                        selected={isSelected(i)}
                        data-testid={`${
                          tableConfig.tableRowTestId ?? "row"
                        }-${i}`}
                        hover
                        tabIndex={-1}
                        key={row.id}
                        sx={{
                          cursor: "pointer",
                          backgroundColor: row?.backgroundColor ?? "transparent"
                        }}
                        onClick={() => handleRowClick(row, i)}
                      >
                        {visibleHeadCells?.map((value: any, i: number) => {
                          if (typeof row[value?.id] === "boolean") {
                            return (
                              <TableCell sx={rowCellStyle} key={value.id}>
                                {row[value?.id] ? t("Yes") : t("No")}
                              </TableCell>
                            );
                          }
                          return (
                            <TableCell sx={rowCellStyle} key={value.id}>
                              {row[value?.id]}
                            </TableCell>
                          );
                        })}
                      </TableRow>
                    ))
                )}
              </TableBody>
            )}
          </Table>
        </TableContainer>
      </Paper>
      <Stack
        direction="row-reverse"
        alignItems="center"
        justifyContent="space-between"
      >
        <Stack direction="row" alignItems="center">
          <Typography color="#031a34" sx={{ fontWeight: 600 }}>
            {t("Total number of entries: ")} {visibleItems.length ?? 0}
          </Typography>
          <IconButton
            aria-label={t("Refresh")}
            disabled={isLoading}
            onClick={handleRefresh}
          >
            <RefreshIcon
              data-testid="refresh-button"
              sx={{ color: isLoading ? "#bdbdbd" : "#031a34" }}
            />
          </IconButton>
        </Stack>
        {tableFooter}
      </Stack>
    </Grid>
  );
};

export default TableView;
