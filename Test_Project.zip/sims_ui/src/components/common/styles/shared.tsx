import styled from "@emotion/styled";
import { Box, TextField } from "@mui/material";

/*======== FORM ============*/
export const StyledFormTextField = styled(TextField)({
  backgroundColor: "white",
  "& .MuiFormHelperText-root": {
    margin: 0,
    backgroundColor: "#F3F4FF"
  }
});

export const StyledFormBox = styled(Box)({
  backgroundColor: "#F3F4FF",
  padding: "20px"
});
