import {
  Button,
  Checkbox,
  FormControlLabel,
  Stack,
  Typography
} from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import UploadFileRoundedIcon from "@mui/icons-material/UploadFileRounded";
import { FC } from "react";
import PageTitle from "./PageTitle";

interface Props {
  title: string;
  isLoadingExport: boolean;
  isArchivedVisible: boolean;
  handleArchiveChange: () => void;
  handleExport: () => void;
  handleAdd: () => void;
  isArchive?: boolean;
  noShowArchive?: boolean;
  noShowAdd?: boolean;
  showPreview?: boolean;
}

const TableHeader: FC<Props> = ({
  title,
  isLoadingExport,
  isArchivedVisible,
  handleArchiveChange,
  handleExport,
  handleAdd,
  noShowArchive,
  noShowAdd,
  showPreview
}) => {
  const t = useTranslation();

  return (
    <Stack direction="row" paddingBottom={1} justifyContent="space-between">
      <PageTitle title={t(title)} />
      <Stack direction="row" justifyContent="flex-end">
        <Button
          sx={{
            textTransform: "none",
            color: "black",
            textDecoration: "underline"
          }}
          role="export-button"
          disabled={isLoadingExport}
          onClick={handleExport}
          startIcon={<UploadFileRoundedIcon color="primary" />}
        >
          <Typography>{t("Export")}</Typography>
        </Button>

        {noShowArchive ? (
          ""
        ) : (
          <FormControlLabel
            control={
              <Checkbox
                role="archive-checkbox"
                size="small"
                checked={isArchivedVisible}
                onChange={handleArchiveChange}
              />
            }
            label={t("Archived")}
          />
        )}
        {noShowAdd ? (
          ""
        ) : (
          <Button
            variant="contained"
            sx={{
              textTransform: "none"
            }}
            onClick={handleAdd}
          >
            {t("Add")}
          </Button>
        )}
        {showPreview ? (
          <Button
            variant="contained"
            sx={{
              textTransform: "none"
            }}
          >
            {t("Preview")}
          </Button>
        ) : (
          ""
        )}
      </Stack>
    </Stack>
  );
};

export default TableHeader;
