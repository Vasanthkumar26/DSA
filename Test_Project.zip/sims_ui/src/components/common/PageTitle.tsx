import { Stack, Typography } from "@mui/material";
import { FC } from "react";
import { useTranslation } from "../../hooks/useTranslation";

interface Props {
  title: string;
}

const PageTitle: FC<Props> = ({ title }) => {
  const t = useTranslation();

  return (
    <Stack direction="row">
      <Typography
        align="center"
        variant="h5"
        color="#031a34"
        sx={{ fontWeight: 600 }}
      >
        {t(title ?? "")}
      </Typography>
    </Stack>
  );
};

export default PageTitle;
