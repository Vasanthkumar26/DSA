import { FC } from "react";
import { Grid, Typography } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";

interface Props {
  title: string;
}

const SecondaryHeader: FC<Props> = ({ title }) => {
  const t = useTranslation();
  return (
    <Grid container spacing={3}>
      <Grid item>
        <Typography variant="h6" color="#031a34" sx={{ fontWeight: 600 }}>
          {t(title)}
        </Typography>
      </Grid>
    </Grid>
  );
};

export default SecondaryHeader;
