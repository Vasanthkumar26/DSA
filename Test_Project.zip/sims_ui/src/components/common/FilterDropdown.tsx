import {
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  Stack,
} from "@mui/material";

type T = (key: string | undefined) => string | undefined;
interface InnerProps {
  setFilterBy: React.Dispatch<React.SetStateAction<string>>;
  filterHeadCell: any;
}

const FilterDropdown = (values: Array<any>, t: T) => {
  return ({ filterHeadCell, setFilterBy }: InnerProps) => {
    return (
      <Stack direction="row">
        <FormControl fullWidth variant="standard">
          <InputLabel size="small" id="select-label">
            {t("Select")}
          </InputLabel>
          <Select
            labelId="select-label"
            value={filterHeadCell?.filter}
            label={t("Select")}
            onChange={(e) => {
              filterHeadCell?.setFilter(e.target.value);
            }}
            size="small"
            disableUnderline
          >
            <MenuItem
              role="option"
              value={""}
              key={"default_none_value"}
              onClick={() => {
                setFilterBy("");
              }}
            >
              <em>{t("none")}</em>
            </MenuItem>
            {(values || []).map((value, i) => {
              return (
                <MenuItem
                  role="option"
                  value={value}
                  key={value}
                  onClick={() => {
                    setFilterBy("");
                  }}
                >
                  {t(value)}
                </MenuItem>
              );
            })}
          </Select>
        </FormControl>
      </Stack>
    );
  };
};

export default FilterDropdown;
