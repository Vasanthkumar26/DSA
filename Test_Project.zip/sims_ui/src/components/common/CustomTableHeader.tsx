import React, { FC, ReactNode, useEffect, useState } from "react";
import {
  Box,
  IconButton,
  Popover,
  Stack,
  TableCell,
  TableHead,
  TableRow,
  TableSortLabel
} from "@mui/material";
import UnfoldMoreIcon from "@mui/icons-material/UnfoldMore";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";
import FilterAltIcon from "@mui/icons-material/FilterAlt";
import { useTranslation } from "../../hooks/useTranslation";
import { HeadCell, Order } from "../../models";

interface Props {
  onRequestSort: (property: string) => void;
  headCells: Array<HeadCell>;
  order: Order;
  orderBy: string;
  onRequestFilter: (property: string) => void;
  filterBy: string;
  onCloseModal: () => void;
  filterHeadCellMap: Record<string, any>;
  isFilterSortingVisible: boolean;
  children: ReactNode;
}

const id = "popover";

const CustomTableHeader: FC<Props> = (props) => {
  const {
    onRequestSort,
    headCells,
    order,
    orderBy,
    onRequestFilter,
    filterBy,
    onCloseModal,
    filterHeadCellMap,
    isFilterSortingVisible = true,
    children
  } = props;

  const [anchorEl, setAnchorEl] = useState<HTMLElement | null>(null);

  useEffect(() => {
    if (filterBy) {
      setAnchorEl(document.getElementById(id));
    }
  }, [filterBy]);

  const handleClose = () => {
    setAnchorEl(null);
    onCloseModal();
  };

  const createSortHandler = (property: string) => () => {
    onRequestSort(property);
  };
  const createFilterHandler = (property: string) => () => {
    onRequestFilter(property);
  };

  const t = useTranslation();

  const WhiteUnfoldMoreIcon = () => <UnfoldMoreIcon sx={{ color: "white" }} />;
  const WhiteKeyboardArrowDownIcon = () => (
    <KeyboardArrowDownIcon sx={{ color: "white" }} />
  );
  const WhiteKeyboardArrowUpIcon = () => (
    <KeyboardArrowUpIcon sx={{ color: "white" }} />
  );

  return (
    <TableHead>
      <TableRow>
        {(headCells || []).map((headCell, i) => (
          <TableCell
            role="cell"
            key={headCell.id}
            align="center"
            sx={{
              backgroundColor: "#031a34",
              color: "white",
              borderRight: i !== headCells.length - 1 ? "1px solid white" : "",
              paddingY: isFilterSortingVisible ? 0 : 1
            }}
            id={filterBy === headCell.id ? id : undefined}
          >
            <Stack
              direction="row"
              justifyContent="space-between"
              alignItems="center"
            >
              {t(headCell.label)}
              {isFilterSortingVisible && (
                <Stack direction="row" justifyContent="space-between">
                  {filterHeadCellMap ? (
                    <IconButton
                      aria-label={t("Filter")}
                      onClick={createFilterHandler(headCell.id)}
                    >
                      <FilterAltIcon
                        data-testid="filter-button"
                        sx={{
                          color: filterHeadCellMap?.[headCell.id]?.filter
                            ? "blue"
                            : "white"
                        }}
                      />
                    </IconButton>
                  ) : (
                    <Box py={3} />
                  )}
                  <TableSortLabel
                    role="sort-icon"
                    active={true}
                    onClick={createSortHandler(headCell.id)}
                    IconComponent={
                      orderBy !== headCell.id
                        ? WhiteUnfoldMoreIcon
                        : order === "asc"
                        ? WhiteKeyboardArrowUpIcon
                        : WhiteKeyboardArrowDownIcon
                    }
                  />
                </Stack>
              )}
            </Stack>
            <Popover
              role="popover"
              open={filterBy === headCell.id && !!anchorEl}
              onClose={handleClose}
              anchorEl={anchorEl}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "center"
              }}
              transformOrigin={{
                vertical: "top",
                horizontal: "center"
              }}
              PaperProps={{
                style: {
                  width: anchorEl ? anchorEl.clientWidth : "auto"
                }
              }}
            >
              {children}
            </Popover>
            {filterBy === headCell.id && !!anchorEl ? (
              <div aria-label="Outside-test-element" onClick={handleClose} />
            ) : (
              <></>
            )}
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
};

export default CustomTableHeader;
