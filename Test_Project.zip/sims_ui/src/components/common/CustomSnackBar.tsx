import { Snackbar, Alert } from "@mui/material";
import { FC } from "react";

export type serverity = "error" | "warning" | "info" | "success";
type variant = "outlined" | "filled";

interface Iprops {
  autoHideDuration?: number | null | undefined;
  open?: boolean;
  onClose: () => void;
  message?: string;
  severity?: serverity;
  variant?: variant;
}

const CustomSnackBar: FC<Iprops> = ({
  autoHideDuration,
  open,
  onClose,
  message,
  severity,
  variant
}) => {
  return (
    <Snackbar
      anchorOrigin={{ vertical: "top", horizontal: "center" }}
      open={open}
      onClose={onClose}
      autoHideDuration={autoHideDuration || 5000}
    >
      <Alert
        onClose={onClose}
        severity={severity || "success"}
        elevation={6}
        variant={variant || "filled"}
        sx={{ width: "100%" }}
      >
        {message}
      </Alert>
    </Snackbar>
  );
};

export default CustomSnackBar;
