import { IconButton, TextField } from "@mui/material";
import { fireEvent, render, screen } from "@testing-library/react";
import React, { useRef } from "react";
import FilterSearchBar from "../FilterSearchBar";

jest.mock("react", () => ({
  ...jest.requireActual("react"),
  useRef: jest.fn(),
}));

jest.mock("@mui/material", () => ({
  ...jest.requireActual("@mui/material"),
  IconButton: jest.fn(),
  TextField: jest.fn(),
}));

describe.only("FilterSearchBar component", () => {
  const t = (key) => key; // mock translation function
  const filterHeadCell = {
    setFilter: jest.fn(),
    filter: "",
  };
  const setFilterBy = jest.fn();

  afterEach(() => {
    useRef.mockClear();
    IconButton.mockClear();
    TextField.mockClear();
  });

  test("search bar renders correctly", () => {
    useRef.mockReturnValue({ current: { value: "test" } });
    const Component = FilterSearchBar(t);

    const { container } = render(
      <Component setFilterBy={setFilterBy} filterHeadCell={filterHeadCell} />
    );
    expect(container).toMatchSnapshot();
  });

  test("sets filter on button click", () => {
    useRef.mockReturnValueOnce({ current: { value: "test" } });
    const Component = FilterSearchBar(t);
    TextField.mockImplementation(() => {
      return (
        <div>
          <label htmlFor="Search">Search</label>
          <input type="text" id="Search" name="Search" />
        </div>
      );
    });
    IconButton.mockImplementation(({ onClick }) => {
      return <button onClick={onClick}>click me!</button>;
    });

    render(
      <Component setFilterBy={setFilterBy} filterHeadCell={filterHeadCell} />
    );

    const input = screen.getByLabelText("Search");
    const button = screen.getByRole("button");

    fireEvent.change(input, { target: { value: "test" } });
    fireEvent.click(button);

    expect(filterHeadCell.setFilter).toHaveBeenCalledWith("test");
    expect(setFilterBy).toHaveBeenCalledWith("");
  });

  test("sets filter on Enter key press", () => {
    useRef.mockReturnValueOnce({ current: { value: "test" } });
    const Component = FilterSearchBar(t);
    TextField.mockImplementation(({ onKeyPress }) => {
      return (
        <div>
          <label htmlFor="Search">Search</label>
          <input
            type="text"
            id="Search"
            name="Search"
            onKeyPress={onKeyPress}
          />
        </div>
      );
    });

    render(
      <Component setFilterBy={setFilterBy} filterHeadCell={filterHeadCell} />
    );

    const input = screen.getByLabelText("Search");

    fireEvent.change(input, { target: { value: "test" } });
    fireEvent.keyPress(input, { key: "Enter", code: 13, charCode: 13 });

    expect(filterHeadCell.setFilter).toHaveBeenCalledWith("test");
    expect(setFilterBy).toHaveBeenCalledWith("");
  });

  test("should not submit on any other key than enter", () => {
    useRef.mockReturnValueOnce({ current: { value: "test" } });
    const Component = FilterSearchBar(t);
    TextField.mockImplementation(({ onKeyPress }) => {
      return (
        <div>
          <label htmlFor="Search">Search</label>
          <input
            type="text"
            id="Search"
            name="Search"
            onKeyPress={onKeyPress}
          />
        </div>
      );
    });

    render(
      <Component setFilterBy={setFilterBy} filterHeadCell={filterHeadCell} />
    );

    const input = screen.getByLabelText("Search");

    fireEvent.change(input, { target: { value: "test" } });
    fireEvent.keyPress(input, { key: "Esc", code: 27, charCode: 27 });

    expect(filterHeadCell.setFilter).toBeCalledTimes(0);
    expect(setFilterBy).toBeCalledTimes(0);
  });
});
