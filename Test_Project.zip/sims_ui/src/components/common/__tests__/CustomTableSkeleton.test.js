import { render, screen } from "@testing-library/react";
import CustomTableSkeleton from "../CustomTableSkeleton";

describe("CustomTableSkeleton", () => {
  test("renders a skeleton for each row", () => {
    render(
      <table>
        <CustomTableSkeleton colSpan={3} />
      </table>
    );
    const skeletons = screen.getAllByRole("progressbar");
    expect(skeletons).toHaveLength(5);
  });
});
