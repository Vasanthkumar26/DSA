import React from "react";
import { render, screen } from "@testing-library/react";
import "@testing-library/jest-dom";
import userEvent from "@testing-library/user-event";
import FilterDropdown from "../FilterDropdown";

describe("FilterDropdown", () => {
  const values = ["value1", "value2", "value3"];
  const t = (key) => key; // mock translation function
  const filterHeadCell = {
    filter: "value2",
    setFilter: jest.fn(),
  };
  const setFilterBy = jest.fn();

  test("should render Select element with correct options", () => {
    const Component = FilterDropdown(values, t);
    render(
      <Component filterHeadCell={filterHeadCell} setFilterBy={setFilterBy} />
    );

    // Check if Select element is present
    const selectElement = screen.getByLabelText("Select");
    expect(selectElement).toBeInTheDocument();
    userEvent.click(selectElement);

    // Check if options are rendered correctly
    const options = screen.getAllByRole("option");
    expect(options).toHaveLength(values.length + 1); // +1 for 'none' option
    expect(options[0]).toHaveTextContent("none"); // check if 'none' option is present
    values.forEach((value, index) => {
      expect(options[index + 1]).toHaveTextContent(value); // check if other options are present
    });
  });

  test("should call setFilterBy and filterHeadCell.setFilter when an option is selected", () => {
    const Component = FilterDropdown(values, t);
    render(
      <Component filterHeadCell={filterHeadCell} setFilterBy={setFilterBy} />
    );

    // Select an option
    const selectElement = screen.getByLabelText("Select");
    userEvent.click(selectElement);
    const options = screen.getAllByRole("option");
    userEvent.click(options[1]);

    // Check if setFilterBy and filterHeadCell.setFilter are called with correct value
    expect(filterHeadCell.setFilter).toHaveBeenCalledWith("value1");
    expect(setFilterBy).toHaveBeenCalledWith("");
  });

  test("should work for none value", () => {
    const Component = FilterDropdown(values, t);
    render(
      <Component filterHeadCell={filterHeadCell} setFilterBy={setFilterBy} />
    );

    // Select an option
    const selectElement = screen.getByLabelText("Select");
    userEvent.click(selectElement);
    const options = screen.getAllByRole("option");
    userEvent.click(options[0]);

    // Check if setFilterBy and filterHeadCell.setFilter are called with correct value
    expect(filterHeadCell.setFilter).toHaveBeenCalledWith("");
    expect(setFilterBy).toHaveBeenCalledWith("");
  });

  test("should not break for undefined values", () => {
    const values = undefined;
    const filterHeadCell = {
      filter: "",
      setFilter: jest.fn(),
    };
    const Component = FilterDropdown(values, t);
    render(
      <Component filterHeadCell={filterHeadCell} setFilterBy={setFilterBy} />
    );

    // Select an option
    const selectElement = screen.getByLabelText("Select");
    userEvent.click(selectElement);
    const options = screen.getAllByRole("option");
    userEvent.click(options[0]);

    // Check if setFilterBy and filterHeadCell.setFilter are called with correct value
    expect(filterHeadCell.setFilter).toHaveBeenCalledTimes(0);
    expect(setFilterBy).toHaveBeenCalledWith("");
  });
});
