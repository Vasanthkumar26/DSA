// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import TableView from "../TableView";

const tableConfig = {
  title: "Test",
  orderBy: "lastUpdateDate",
  tableRowTestId: "test",
};

const headCells = [
  { id: "test1", label: "test 1" },
  { id: "test2", label: "test 2" },
  { id: "archive", label: "archive" },
];

const visibleItems = [{ test1: "test1", test2: "test2", archive: false }];

describe("TableView", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(
      <TableView
        tableConfig={tableConfig}
        visibleItems={visibleItems}
        visibleHeadCells={headCells}
        isLoading={false}
      />,
      {
        route: "/",
      }
    );

    expect(container).toBeInTheDocument();
  });
});
