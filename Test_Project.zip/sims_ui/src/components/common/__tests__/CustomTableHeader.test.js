import { Provider } from "react-redux";
import { legacy_createStore as createStore } from "redux";
import React from "react";
import { screen, render, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import userEvent from "@testing-library/user-event";
import reducer from "../../../redux/reducers";
import CustomTableHeader from "../CustomTableHeader";

const store = createStore(reducer);

describe("CustomTableHeader", () => {
  const headCells = [
    { id: "id1", label: "Label 1" },
    { id: "id2", label: "Label 2" }
  ];
  const order = "asc";
  const orderBy = "id1";
  const onRequestSort = jest.fn();
  const onRequestFilter = jest.fn();
  const filterBy = null;
  const onCloseModal = jest.fn();
  const children = <div>Filter content</div>;

  test("renders a table head row with the correct number of cells", () => {
    render(
      <Provider store={store}>
        <table>
          <CustomTableHeader
            filterHeadCellMap={[]}
            headCells={headCells}
            order={order}
            orderBy={orderBy}
            onRequestSort={onRequestSort}
            onRequestFilter={onRequestFilter}
            filterBy={filterBy}
            onCloseModal={onCloseModal}
            children={children}
          />
        </table>
      </Provider>
    );
    const cells = screen.getAllByRole("cell");
    expect(cells.length).toBe(headCells.length);
  });
  test("should not fail for undefined headcell", () => {
    const headCells = undefined;
    render(
      <Provider store={store}>
        <table>
          <CustomTableHeader
            filterHeadCellMap={[]}
            headCells={headCells}
            order={order}
            orderBy={orderBy}
            onRequestSort={onRequestSort}
            onRequestFilter={onRequestFilter}
            filterBy={filterBy}
            onCloseModal={onCloseModal}
            children={children}
          />
        </table>
      </Provider>
    );
    const cells = screen.queryByRole("cell");
    expect(cells).not.toBeInTheDocument();
  });

  test("renders the head cell labels", () => {
    render(
      <Provider store={store}>
        <table>
          <CustomTableHeader
            filterHeadCellMap={[]}
            headCells={headCells}
            order={order}
            orderBy={orderBy}
            onRequestSort={onRequestSort}
            onRequestFilter={onRequestFilter}
            filterBy={filterBy}
            onCloseModal={onCloseModal}
            children={children}
          />
        </table>
      </Provider>
    );
    headCells.forEach((headCell) => {
      expect(screen.getByText(headCell.label)).toBeInTheDocument();
    });
  });

  test("renders the filter icon for each head cell", () => {
    render(
      <Provider store={store}>
        <table>
          <CustomTableHeader
            filterHeadCellMap={[]}
            headCells={headCells}
            order={order}
            orderBy={orderBy}
            onRequestSort={onRequestSort}
            onRequestFilter={onRequestFilter}
            filterBy={filterBy}
            onCloseModal={onCloseModal}
            children={children}
          />
        </table>
      </Provider>
    );
    const filterIcons = screen.getAllByLabelText("Filter");
    expect(filterIcons.length).toBe(headCells.length);
  });

  test("calls the onRequestSort function when a table sort label is clicked", async () => {
    render(
      <Provider store={store}>
        <table>
          <CustomTableHeader
            filterHeadCellMap={[]}
            headCells={headCells}
            order={order}
            orderBy={orderBy}
            onRequestSort={onRequestSort}
            onRequestFilter={onRequestFilter}
            filterBy={filterBy}
            onCloseModal={onCloseModal}
            children={children}
          />
        </table>
      </Provider>
    );
    const sortLabel = screen.getAllByRole("sort-icon")[0];
    fireEvent.click(sortLabel);
    expect(onRequestSort).toHaveBeenCalledWith("id1");
  });

  test("calls the onRequestFilter function when a filter icon is clicked", () => {
    render(
      <Provider store={store}>
        <table>
          <CustomTableHeader
            filterHeadCellMap={[]}
            headCells={headCells}
            order={order}
            orderBy={orderBy}
            onRequestSort={onRequestSort}
            onRequestFilter={onRequestFilter}
            filterBy={filterBy}
            onCloseModal={onCloseModal}
            children={children}
          />
        </table>
      </Provider>
    );
    const filterIcons = screen.getAllByLabelText("Filter");
    fireEvent.click(filterIcons[0]);
    expect(onRequestFilter).toHaveBeenCalledWith("id1");
  });

  test("sets anchorEl when filterBy is truthy", () => {
    const filterBy = "id1";
    render(
      <Provider store={store}>
        <table>
          <CustomTableHeader
            filterHeadCellMap={[]}
            headCells={headCells}
            order={order}
            orderBy={orderBy}
            onRequestSort={onRequestSort}
            onRequestFilter={onRequestFilter}
            filterBy={filterBy}
            onCloseModal={onCloseModal}
            children={children}
          />
        </table>
      </Provider>
    );
    const popover = screen.getByRole("popover");
    expect(popover).toBeInTheDocument();
  });

  test("sets anchorEl when filterBy is truthy (desc order)", () => {
    const filterBy = "id1";
    const order = "desc";
    render(
      <Provider store={store}>
        <table>
          <CustomTableHeader
            filterHeadCellMap={[]}
            headCells={headCells}
            order={order}
            orderBy={orderBy}
            onRequestSort={onRequestSort}
            onRequestFilter={onRequestFilter}
            filterBy={filterBy}
            onCloseModal={onCloseModal}
            children={children}
          />
        </table>
      </Provider>
    );
    const popover = screen.getByRole("popover");
    expect(popover).toBeInTheDocument();
  });

  test("does not set anchorEl when filterBy is falsy", () => {
    render(
      <Provider store={store}>
        <table>
          <CustomTableHeader
            filterHeadCellMap={[]}
            headCells={headCells}
            order={order}
            orderBy={orderBy}
            onRequestSort={onRequestSort}
            onRequestFilter={onRequestFilter}
            filterBy={null}
            onCloseModal={onCloseModal}
            children={children}
          />
        </table>
      </Provider>
    );
    const popover = screen.queryByRole("popover");
    expect(popover).not.toBeInTheDocument();
  });

  test("closes modal when handleClose is called", () => {
    const filterBy = "id1";
    render(
      <Provider store={store}>
        <table>
          <CustomTableHeader
            filterHeadCellMap={[]}
            headCells={headCells}
            order={order}
            orderBy={orderBy}
            onRequestSort={onRequestSort}
            onRequestFilter={onRequestFilter}
            filterBy={filterBy}
            onCloseModal={onCloseModal}
            children={children}
          />
        </table>
      </Provider>
    );
    const filterButton = screen.getAllByLabelText("Filter");
    userEvent.click(filterButton[0]);
    const modal = screen.getByRole("popover");
    expect(modal).toBeInTheDocument();
    userEvent.click(screen.getByLabelText("Outside-test-element"));
    expect(onCloseModal).toHaveBeenCalledTimes(1);
  });
});
