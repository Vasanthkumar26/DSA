import { render} from "@testing-library/react";
import CustomSnackBar from "../CustomSnackBar";

describe("shoudl render customsnackbar",() => {
    test("it should render the sanckbar with specified message",async() => {
        const onClose =  jest.fn();
        const message =  "successfull";
        const {container} = render(<CustomSnackBar open onClose={onClose} message={message}  severity="success"
        variant="filled" autoHideDuration={6000}/>);
        expect(container).toMatchSnapshot();     
    });
});

