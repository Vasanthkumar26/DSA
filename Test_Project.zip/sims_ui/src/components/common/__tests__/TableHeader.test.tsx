// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import TableHeader from "../TableHeader";

describe("TableHeader", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<TableHeader />, {
      route: "/",
    });

    expect(container).toBeInTheDocument();
  });
});
