import {
  Box,
  FormControl,
  FormControlLabel,
  FormLabel,
  Grid,
  Radio,
  RadioGroup
} from "@mui/material";
import {
  FormActionButtons,
  FormControllerTextField
} from "../common/AddEditForm";
import { useForm } from "react-hook-form";
import { StyledFormBox } from "../common/styles/shared";
import {
  CreateUpdatePayload,
  TaskEscalationSchema,
  initData,
  setFormData
} from "./TaskEscalation.data";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import { RootState } from "../../redux/store";
import {
  createTaskEscalation,
  updateTaskEscalation,
  setSelectedTaskEscalation
} from "../../redux/actions/taskEscalationAction";
import {
  FC,
  SetStateAction,
  Dispatch,
  useCallback,
  useState,
  useEffect
} from "react";
import { ConnectedProps, connect } from "react-redux";
// import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import { TaskEscalationDropdownValue } from "../../models/taskEscalation.model";
import { handleDeleteTaskEscalation } from "../../services/taskEscalationApi";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import { useTranslation } from "../../hooks/useTranslation";
import DeleteModal from "../common/modals/DeleteModal";
interface Props extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
  dropdownValue: TaskEscalationDropdownValue;
}

const TaskEscalationForm: FC<Props> = ({
  createTaskEscalation,
  updateTaskEscalation,
  setSelectedTaskEscalation,
  // dropdownValue,
  setShowForm,
  showSuccessSnackbar,
  showFailureSnackbar,
  selectedTaskEscalation
}) => {
  const resolver = useYupValidationResolver(TaskEscalationSchema);

  // const [taskDropdownValue, setTaskDropDownValue] =
  //   useState<TaskEscalationDropdownValue>();
  const t = useTranslation();
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [, setIsDay] = useState<boolean>(true);
  const [isHour, setIsHour] = useState<boolean>(false);

  const { control, handleSubmit, reset } = useForm({
    mode: "all",
    reValidateMode: "onChange",
    resolver,
    defaultValues: { ...initData }
  });

  // useEffect(() => {
  //   setTaskDropDownValue(dropdownValue);
  // }, [dropdownValue]);

  const handleTime = useCallback(() => {
    setIsHour((prev) => !prev);
  }, [setIsHour]);

  const handleDay = useCallback(() => {
    setIsDay((prev) => !prev);
  }, [setIsDay]);

  const onSubmit = (data: any) => {
    let promiseAPI;
    const payload = CreateUpdatePayload(data);
    const updatedPayload = isHour 
    ? { ...payload, time: `${payload.time} hours` }
    :  { ...payload, time: `${payload.time} days` };

    if (selectedTaskEscalation) {
      setSelectedTaskEscalation(null);
      promiseAPI = updateTaskEscalation(selectedTaskEscalation?.id, updatedPayload);
      console.log(promiseAPI);
    } else {
      setShowForm(false);
      reset({ ...initData });
      promiseAPI = createTaskEscalation(updatedPayload);
    }
    promiseAPI
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => handleReset());
  };

  useEffect(() => {
    selectedTaskEscalation
      ? reset(setFormData(selectedTaskEscalation))
      : reset({ ...initData });
  }, [reset, selectedTaskEscalation]);

  const handleActiveNArchive = () => { };

  const handleDelete = () => {
    setIsModalOpen(false);
    handleDeleteTaskEscalation(selectedTaskEscalation?.id ?? 0)
      .then(() => showSuccessSnackbar(t("successfully_deleted")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => handleReset());
  };

  const handleReset = useCallback(() => {
    reset({ ...initData });
    setSelectedTaskEscalation(null);
    setShowForm(false);
  }, [reset, setSelectedTaskEscalation, setShowForm]);

  return (
    <>
      <DeleteModal
        isOpen={isModalOpen}
        handleConfirm={handleDelete}
        handleCancel={() => setIsModalOpen(false)}
      />
      <StyledFormBox component="form" onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={2} sx={{ paddingBottom: "12px" }}>
          <Grid item xs={8} sm={8} md={8}>
            <Grid container spacing={2}>
              {/* <Grid item xs={6} sm={6} md={6}>
                <FormControllerSelectWithSearch
                  options={taskDropdownValue?.allTaskValues ?? []}
                  required
                  controlName="workFlowEventId"
                  inputLabel="Task"
                  control={control}
                />
              </Grid> */}
              <Grid item xs={3} sm={3} md={3}>
                <FormControllerTextField
                  control={control}
                  controlName="task"
                  inputLabel="Task"
                  required
                />
              </Grid>
              <Grid item xs={3} sm={3} md={3}>
                <FormControllerTextField
                  control={control}
                  controlName="time"
                  inputLabel="Time"
                  required
                />
              </Grid>
              <Grid item xs={3} sm={3} md={3}>
                <FormControl>
                  <FormLabel id="time-radio-buttons-group-label">
                    &nbsp;
                  </FormLabel>
                  <RadioGroup
                    row
                    aria-labelledby="time-radio-buttons-group-label"
                    defaultValue="day"
                    name="radio-buttons-group"
                  >
                    <FormControlLabel
                      value="day"
                      control={<Radio />}
                      label="Day"
                      onChange={handleDay}
                    />
                    <FormControlLabel
                      value="hours"
                      control={<Radio />}
                      label="Hours"
                      checked={isHour}
                      onChange={handleTime}
                    />
                  </RadioGroup>
                </FormControl>
              </Grid>
              <Grid item xs={6} sm={6} md={6}>
                <FormControllerTextField
                  control={control}
                  controlName="emailAddress"
                  inputLabel="Email Address"
                  required
                />
              </Grid>
              <Grid item xs={6} sm={6} md={6}>
                <FormControllerTextField
                  control={control}
                  controlName="subject"
                  inputLabel="Subject"
                  required
                />
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={4}>
            <FormControllerTextField
              control={control}
              controlName="text"
              inputLabel="Description"
              multiline
              rows={4.4}
              required
            />
          </Grid>
        </Grid>
        <Box mt={2}>
          <Grid item xs={12}>
            <FormActionButtons
              onCancel={handleReset}
              onDelete={() => setIsModalOpen(true)}
              onActiveNArchive={handleActiveNArchive}
              submitDisabled={false}
              cancelDisabled={false}
              isDeleteVisible={!!selectedTaskEscalation}
              isArchiveVisible={false}
              isActiveVisible={false}
              selectedData={selectedTaskEscalation}
            />
          </Grid>
        </Box>
      </StyledFormBox>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedTaskEscalation: state.taskEscalation.selectedTaskEscalation
});

const connector = connect(mapStateToProps, {
  createTaskEscalation,
  updateTaskEscalation,
  setSelectedTaskEscalation,
  showSuccessSnackbar,
  showFailureSnackbar
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(TaskEscalationForm);
