import { Grid } from "@mui/material";
import { TableConfig } from "../../models";
import {
  Dispatch,
  FC,
  SetStateAction,
  useEffect,
  useMemo,
  useState
} from "react";
import TableView from "../common/TableView";
import { headCells, archivedCell } from "./TaskEscalation.data";
import { connect, ConnectedProps } from "react-redux";
import { RootState } from "../../redux/store";

import {
  fetchTaskEscalations,
  setSelectedTaskEscalation
} from "../../redux/actions/taskEscalationAction";
import { useTranslation } from "../../hooks/useTranslation";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import { TaskEscalations } from "../../models/taskEscalation.model";
interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const tableConfig: TableConfig = {
  title: "Task Escalation",
  orderBy: "lastUpdateDate",
  tableRowTestId: "taskEscalation-row"
};

const TaskEscalationTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchTaskEscalations,
  taskEscalations,
  setSelectedTaskEscalation
}) => {
  const [taskFilter, setTaskFilter] = useState("");
  const [emailAddressFilter, setEmailAddressFilter] = useState("");
  const [timeFilter, setTimeFilter] = useState("");
  const [subjectFilter, setSubjectFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");

  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchTaskEscalations(isArchivedVisible))();
  }, [fetchTaskEscalations, isArchivedVisible]);

  const getArchivedFilter = (TaskEscalation: TaskEscalations) => {
    if (archivedFilter === "Yes") {
      return !!TaskEscalation.archived;
    }
    return archivedFilter === "No" ? !TaskEscalation.archived : true;
  };

  const visibleHeadCells = [
    ...headCells,
    ...(isArchivedVisible ? [archivedCell] : [])
  ];

  let visibleTaskEscalations = taskEscalations?.filter(
    (taskEscalation) =>
      taskEscalation?.task?.includes(taskFilter) &&
      taskEscalation?.emailAddress?.includes(emailAddressFilter) &&
      taskEscalation?.time?.includes(timeFilter) &&
      taskEscalation?.subject?.includes(subjectFilter) &&
      getArchivedFilter(taskEscalation)
  );

  const filterHeadCellMap = {
    [headCells[0].id]: {
      filter: taskFilter,
      setFilter: setTaskFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[1].id]: {
      filter: timeFilter,
      setFilter: setTimeFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[2].id]: {
      filter: emailAddressFilter,
      setFilter: setEmailAddressFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[3].id]: {
      filter: subjectFilter,
      setFilter: setSubjectFilter,
      filterComponent: FilterSearchBar(t)
    },
    [archivedCell.id]: {
      filter: archivedFilter,
      setFilter: setArchivedFilter,
      filterComponent: FilterDropdown(archivedCell.values, t)
    }
  };

  const resetAllFilters = useMemo(() => {
    return () => {
      setEmailAddressFilter("");
      setSubjectFilter("");
      setTaskFilter("");
      setTimeFilter("");
      setArchivedFilter("");
    };
  }, []);

  const handleRefresh = async () => {
    await fetchTaskEscalations(isArchivedVisible);
    resetAllFilters();
  };

  const handleRowSelected = async (row: any) => {
    setSelectedTaskEscalation(row);
  };

  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleTaskEscalations]}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
        handleRowSelected={handleRowSelected}
      />
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.simArticle.isLoadingFetch,
  taskEscalations: state.taskEscalation.taskEscalations
});

const connector = connect(mapStateToProps, {
  fetchTaskEscalations,
  setSelectedTaskEscalation
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(TaskEscalationTable);
