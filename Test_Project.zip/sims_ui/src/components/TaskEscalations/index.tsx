import { Box, Grid } from "@mui/material";
import { FC, useEffect, useState } from "react";
import TaskEscalationHeader from "./TaskEscalationHeader";
import TaskEscalationTable from "./TaskEscalationTable";
import TaskEscalationForm from "./TaskEscalationForm";
import { TaskEscalationDropdownValue } from "../../models/taskEscalation.model";
import { handleTaskEscalationDropdown } from "../../services/taskEscalationApi";
import { ConnectedProps, connect } from "react-redux";
import { showFailureSnackbar } from "../../redux/actions/snackbarAction";
import { RootState } from "../../redux/store";

interface Props extends PropsFromRedux {}

const TaskEscalation: FC<Props> = ({ selectedTaskEscalation }) => {
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [taskEscalationDropdownValue, setTaskEscalationDropdownValue] =
    useState<TaskEscalationDropdownValue>();

  useEffect(() => {
    handleTaskEscalationDropdown()
      .then((res) => {
        setTaskEscalationDropdownValue(res);
      })
      .catch((err) => {
        setTaskEscalationDropdownValue(undefined);
      });
  }, []);

  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <TaskEscalationHeader
            isArchivedVisible={isArchivedVisible}
            setIsArchivedVisible={setIsArchivedVisible}
            setShowForm={setShowForm}
          />
          <TaskEscalationTable
            setShowForm={setShowForm}
            isArchivedVisible={isArchivedVisible}
          />
          {(showForm || selectedTaskEscalation) && (
            <Grid item xs={12}>
              <TaskEscalationForm
                setShowForm={setShowForm}
                dropdownValue={
                  taskEscalationDropdownValue as TaskEscalationDropdownValue
                }
              />
            </Grid>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedTaskEscalation: state.taskEscalation.selectedTaskEscalation
});

const connector = connect(mapStateToProps, {
  showFailureSnackbar
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(TaskEscalation);
