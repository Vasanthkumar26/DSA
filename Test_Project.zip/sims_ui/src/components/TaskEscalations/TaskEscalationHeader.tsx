import { FC, Dispatch, SetStateAction, useCallback } from "react";
import TableHeader from "../common/TableHeader";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import {
  fetchTaskEscalationExport,
  setSelectedTaskEscalation
} from "../../redux/actions/taskEscalationAction";
interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const TaskEscalationHeader: FC<Props> = ({
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  fetchTaskEscalationExport
}) => {
  // const [isLoadingExport, setIsLoadingExport] = useState(false);
  const isLoadingExport = false;

  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleAdd = useCallback(() => {
    setSelectedTaskEscalation(null);
    setShowForm(true);
  }, [setShowForm]);

  const handleExport = useCallback(() => {
    fetchTaskEscalationExport(isArchivedVisible);
  }, [fetchTaskEscalationExport, isArchivedVisible]);

  return (
    <TableHeader
      title="Task Escalation"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.taskEscalation.isLoadingExport
});

const connector = connect(mapStateToProps, {
  fetchTaskEscalationExport
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(TaskEscalationHeader);
