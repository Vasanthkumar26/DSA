import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import { screen, fireEvent, render } from "@testing-library/react";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { Store, AnyAction } from "redux";
import { fetchTaskEscalationExport } from "../../../redux/actions/taskEscalationAction";
import { TaskEscalationActionTypes } from "../../../redux/actions/types";
import TaskEscalationHeader from "../TaskEscalationHeader";

const mockStore = configureStore([thunk]);

jest.mock("../../../redux/actions/taskEscalationAction", () => ({
  fetchTaskEscalationExport: jest.fn()
}));

describe("header test", () => {
  let store: Store<unknown, AnyAction>;
  beforeEach(() => {
    store = mockStore({
      taskEscalation: {
        taskEscalation: ["a", "b"]
      },
      lang: {
        language: "en"
      }
    });
  });
  test("should load component without failed", () => {
    const { container } = renderWithAllWrappers(
      <TaskEscalationHeader
        isArchivedVisible={false}
        setIsArchivedVisible={jest.fn()}
      />
    );
    expect(container).toBeInTheDocument();
  });

  test("should render the export button", () => {
    renderWithAllWrappers(
      <TaskEscalationHeader
        isArchivedVisible={false}
        setIsArchivedVisible={jest.fn()}
      />
    );

    expect(screen.getByText(/Export/i)).toBeInTheDocument();
  });

  test("should call the handleExport on button click", async () => {
    // @ts-ignore: Unreachable code error
    fetchTaskEscalationExport.mockImplementation(() => {
      return {
        type: TaskEscalationActionTypes.FETCH_TASK_ESCALATION_EXPORT_SUCCESS,
        payload: { message: "successfull" }
      };
    });

    render(
      <Provider store={store}>
        <TaskEscalationHeader
          isArchivedVisible={false}
          setIsArchivedVisible={jest.fn()}
        />
      </Provider>
    );

    const button = screen.getByRole("export-button");
    await fireEvent.click(button);
    expect(fetchTaskEscalationExport).toHaveBeenCalled();
  });
});
