import { HeadCell } from "../../models";
import * as yup from "yup";

export const headCells: Array<HeadCell> = [
  { id: "task", label: "Task" },
  { id: "time", label: "Time" },
  { id: "emailAddress", label: "Email-Address" },
  { id: "subject", label: "Subject" }
];

export const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};

export const initData = {
  task: "",
  time: "",
  emailAddress: "",
  subject: ""
};

export const TaskEscalationSchema = yup.object().shape({
  task: yup.string().required("task_is_missing"),
  time: yup.string().required("time_is_missing"),
  subject: yup.string().required("subject_is_missing"),
  text: yup.string().required("description_is_missing"),
  emailAddress: yup
    .string()
    .trim()
    .test("Valid Email", "", function (value) {
      if (value) {
        yup.object().shape({
          emails: yup
            .string()
            .required("es_please_provide_a_valid_email_address")
        });
        const emailSchema = yup.array().of(yup.string().email());
        const emails = value.split(",").map((email) => email.trim());
        if (!emailSchema.isValidSync(emails)) {
          return this.createError({
            message: `es_please_provide_a_valid_email_address`
          });
        }
      } else {
        return this.createError({
          message: `es_please_provide_a_valid_email_address`
        });
      }
      return true;
    }),
});

export const CreateUpdatePayload = (data: any) => ({
  task: data?.task,
  time: data?.time,
  emailAddress: data?.emailAddress,
  subject: data?.subject,
  text: data?.text
});

export const setFormData = (data: any) => ({
  task: data?.task ?? "",
  time: data?.time ?? "",
  emailAddress: data?.emailAddress ?? "",
  subject: data?.subject ?? ""
  // partnerDeliveryAddressId:
  //   partnerAddress.find(
  //     (item) => item.id === data?.partnerDeliveryAddressId.toString()
  //   ) ?? "",
});
