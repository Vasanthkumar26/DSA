import { Dispatch, FC, SetStateAction, useCallback } from "react";
import { ConnectedProps, connect } from "react-redux";
import TableHeader from "../common/TableHeader";
import { RootState } from "../../redux/store";
import {
  fetchSimVendorExport,
  setSelectedSimVendor
} from "../../redux/actions/simVendorAction";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
  isLoadingExport: boolean;
}

const SimVendorHeader: FC<Props> = ({
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  isLoadingExport,
  fetchSimVendorExport,
  setSelectedSimVendor
}) => {
  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleExport = useCallback(() => {
    fetchSimVendorExport(isArchivedVisible);
  }, [fetchSimVendorExport, isArchivedVisible]);

  const handleAdd = useCallback(() => {
    setSelectedSimVendor(null);
    setShowForm(true);
  }, [setSelectedSimVendor, setShowForm]);
  return (
    <TableHeader
      title="Sim Vendor Administration"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.simVendor.isLoadingExport
});

const connector = connect(mapStateToProps, {
  fetchSimVendorExport,
  setSelectedSimVendor
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(SimVendorHeader);
