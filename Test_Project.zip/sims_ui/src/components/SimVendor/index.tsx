import { FC, useState } from "react";
import { Box, Grid } from "@mui/material";
import Header from "./SimVendorHeader";
import SimVendorTable from "./SimVendorTable";
import SimVendorForm from "./SimVendorAddEdit";
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";

const SimVendor: FC = () => {
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const selectedSimVendor = useSelector(
    (state: RootState) => state.simVendor.selectedSimVendor
  );

  return (
    <>
      <Box sx={{ padding: 2 }}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Header
              isArchivedVisible={isArchivedVisible}
              setIsArchivedVisible={setIsArchivedVisible}
              setShowForm={setShowForm}
            />
            <SimVendorTable isArchivedVisible={isArchivedVisible} />
          </Grid>
          <Grid item xs={12}>
            {showForm || selectedSimVendor ? (
              <Grid item xs={12}>
                <SimVendorForm setShowForm={setShowForm} />
              </Grid>
            ) : (
              <></>
            )}
          </Grid>
        </Grid>
      </Box>
    </>
  );
};

export default SimVendor;
