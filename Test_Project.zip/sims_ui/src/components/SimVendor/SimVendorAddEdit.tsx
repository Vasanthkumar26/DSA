import React, { Dispatch, SetStateAction, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { MenuItem, Box, Grid } from "@mui/material";
import { connect, ConnectedProps } from "react-redux";
import { RootState } from "../../redux/store";
import {
  createSimVendor,
  updateSimVendor,
  fetchSimVendors,
  setSelectedSimVendor,
  deleteSimVendor,
  resetSimVendorError,
  resetSimVendorForm,
  loadExternalNameList,
  resetSimVendor,
  archiveSimVendor
} from "../../redux/actions/simVendorAction";
import DeleteModal from "../common/modals/DeleteModal";
import {
  FormActionButtons,
  FormControllerTextField
  // LastUpdated,
} from "../common/AddEditForm";
import { FormControllerSelect } from "../common/AddEditForm/FormControllerSelect";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import { SimVendorSchema, initData, setFormData } from "./SimVendor.data";
import { StyledFormBox } from "../common/styles/shared";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import { resetPage } from "../../redux/actions/rootAction";
import { useTranslation } from "../../hooks/useTranslation";
interface SimVendorFormProps extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const SimVendorForm: React.FC<SimVendorFormProps> = ({
  selectedSimVendor,
  isLoadingCreate,
  isLoadingUpdate,
  createSimVendor,
  updateSimVendor,
  fetchSimVendors,
  setShowForm,
  deleteSimVendor,
  setSelectedSimVendor,
  resetSimVendorForm,
  externalNameList,
  inputFile,
  loadExternalNameList,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetSimVendor,
  resetPage,
  archiveSimVendor,
  cardTypeNames
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const t = useTranslation();
  const resolver = useYupValidationResolver(
    SimVendorSchema(t, [...(cardTypeNames ?? [])], !selectedSimVendor)
  );
  const { control, handleSubmit, reset } = useForm({
    mode: "all",
    reValidateMode: "onChange",
    resolver,
    defaultValues: { ...initData }
  });

  useEffect(() => {
    selectedSimVendor
      ? reset(setFormData(selectedSimVendor))
      : reset({ ...initData });
  }, [reset, selectedSimVendor]);

  useEffect(() => {
    (async () => await loadExternalNameList())();
  }, [loadExternalNameList]);

  const resetThisPage = () => {
    resetSimVendor();
    resetPage();
  };

  const productListItems = externalNameList?.map(
    ({ businessPartnerId, externalName }) => {
      return (
        <MenuItem key={businessPartnerId} value={externalName}>
          {externalName}
        </MenuItem>
      );
    }
  );

  const inputFileItems = inputFile?.map(({ name, value }) => {
    return (
      <MenuItem key={name} value={value}>
        {t(name)}
      </MenuItem>
    );
  });

  const onSubmit = (data: any) => {
    let businessPartner = externalNameList.find(
      (e) => e.externalName === data.externalName
    );
    let promiseAPI;
    const simvendorValues = {
      ...data,
      userName: "userName",
      lastUpdatedBy: 1,
      businessPartnerId: businessPartner?.businessPartnerId,
      sapVendorNo: businessPartner?.businessPartnerId
    };
    if (selectedSimVendor) {
      promiseAPI = updateSimVendor({
        id: selectedSimVendor.id,
        ...simvendorValues
      });
    } else {
      promiseAPI = createSimVendor({ archived: true, ...simvendorValues });
    }
    promiseAPI
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const handleConfirmation = (flag: boolean): any => {
    setIsModalOpen(flag);
  };

  const handleReset = () => {
    reset(initData);
    resetSimVendorForm();
    setShowForm(false);
  };
  const handleDelete = () => {
    setIsModalOpen(false);
    deleteSimVendor(selectedSimVendor?.id ?? 0)
      .then(() => showSuccessSnackbar(t("successfully_deleted")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const handleActiveNArchive = () => {
    archiveSimVendor(
      selectedSimVendor?.id ?? 0,
      selectedSimVendor?.archived ?? false
    )
      .then(() =>
        showSuccessSnackbar(
          !selectedSimVendor?.archived
            ? t("successfully_archived")
            : t("successfully_activated")
        )
      )
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  return (
    <>
      <DeleteModal
        isOpen={isModalOpen}
        handleConfirm={handleDelete}
        handleCancel={() => setIsModalOpen(false)}
      />
      <StyledFormBox component="form" onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={2} sx={{ paddingBottom: "12px" }}>
          <Grid item xs={8}>
            <FormControllerTextField
              control={control}
              controlName="manufacturerName"
              inputLabel="Name"
              required={true}
            />
          </Grid>
          <Grid item xs={4}>
            <FormControllerSelect
              control={control}
              controlName="externalName"
              inputLabel="External Name"
              required
            >
              {productListItems}
            </FormControllerSelect>
          </Grid>
        </Grid>
        <Grid container spacing={2}>
          <Grid container spacing={1} item xs={8}>
            <Grid item xs={6}>
              <FormControllerTextField
                control={control}
                controlName="iccIdDigit7"
                inputLabel="ICCD Digits 7(blue)"
                required
              />
            </Grid>
            <Grid item xs={6}>
              <FormControllerSelect
                control={control}
                controlName="deliveryType"
                inputLabel="Input-File Shipping"
              >
                {inputFileItems}
              </FormControllerSelect>
            </Grid>
            <Grid item xs={6}>
              <FormControllerTextField
                control={control}
                controlName="sftpOutboundUser"
                inputLabel="SFTP Outbound User"
                required
              />
            </Grid>
            <Grid item xs={6}>
              <FormControllerTextField
                control={control}
                controlName="sftpOutboundPath"
                inputLabel="SFTP Outbound Path"
                required
              />
            </Grid>
            <Grid item xs={6}>
              <FormControllerTextField
                control={control}
                controlName="sftpInboundUser"
                inputLabel="SFTP Inbound User"
              />
            </Grid>
            <Grid item xs={6}>
              <FormControllerTextField
                control={control}
                controlName="sftpInboundPath"
                inputLabel="SFTP Inbound Path"
              />
            </Grid>
          </Grid>
          <Grid container spacing={1} item xs={4}>
            <Grid item xs={12}>
              <FormControllerTextField
                control={control}
                controlName="pgpKey"
                inputLabel="Public PGP Key"
                multiline
                rows={7}
              />
            </Grid>
          </Grid>
        </Grid>
        <Grid container spacing={2} sx={{ paddingTop: "12px" }}>
          <Grid item xs={4}>
            <FormControllerTextField
              control={control}
              controlName="emailIdDelivery"
              inputLabel="Email-Adress Shipping confirmation"
              required
            />
          </Grid>
        </Grid>
        <Box mt={2}>
          <Grid item xs={12}>
            <FormActionButtons
              onCancel={handleReset}
              onDelete={handleConfirmation}
              selectedData={selectedSimVendor}
              onActiveNArchive={() => handleActiveNArchive()}
              submitDisabled={isLoadingCreate || isLoadingUpdate}
              cancelDisabled={isLoadingCreate || isLoadingUpdate}
              isArchiveVisible={
                selectedSimVendor?.isReferenceExist &&
                !selectedSimVendor?.archived
              }
              isDeleteVisible={!selectedSimVendor?.isReferenceExist}
              isActiveVisible={
                selectedSimVendor?.isReferenceExist &&
                selectedSimVendor?.archived
              }
            />
          </Grid>
        </Box>
      </StyledFormBox>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedSimVendor: state.simVendor.selectedSimVendor,
  externalNameList: state.simVendor.externalName,
  inputFile: state.simVendor.inputFile,
  isLoadingCreate: state.simVendor.isLoadingCreate,
  isLoadingUpdate: state.simVendor.isLoadingUpdate,
  errorCreate: state.simVendor.errorCreate,
  errorUpdate: state.simVendor.errorUpdate,
  cardTypeNames: state.simVendor.simVendros.map((item) => item.name)
});

const connector = connect(mapStateToProps, {
  createSimVendor,
  updateSimVendor,
  deleteSimVendor,
  fetchSimVendors,
  setSelectedSimVendor,
  resetSimVendorError,
  resetSimVendorForm,
  loadExternalNameList,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetSimVendor,
  resetPage,
  archiveSimVendor
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(SimVendorForm);
