import React, { FC, useEffect, useMemo, useState } from "react";
import { Grid } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import {
  fetchSimVendors,
  setSelectedSimVendor
} from "../../redux/actions/simVendorAction";
import { connect, ConnectedProps } from "react-redux";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";
import { SimVendor } from "../../models/simVendor.model";
import {
  simVendorArchivedCell,
  simVendorHeadCells,
  simVendorTableConfig
} from "./SimVendorTable.data";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
}

const SimVendorTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchSimVendors,
  setSelectedSimVendor,
  simVendors = []
}) => {
  const [nameFilter, setNameFilter] = useState("");
  const [externerNameFilter, setExternerNameFilter] = useState("");
  const [iccidDigit7Filter, setIccidDigit7Filter] = useState("");
  const [inputFileFilter, setInputFileFilter] = useState("");
  const [emailAddressFilter, setEmailAddressFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchSimVendors(isArchivedVisible))();
  }, [fetchSimVendors, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getArchivedFilter = (simVendor: SimVendor) => {
    if (archivedFilter === "Yes") {
      return !!simVendor.archived;
    }
    return archivedFilter === "No" ? !simVendor.archived : true;
  };

  let visibleMainranges = simVendors?.filter(
    (simVendor) =>
      simVendor.name.includes(nameFilter) &&
      simVendor.externerName.includes(externerNameFilter) &&
      `${simVendor.iccidDigit7 ?? ""}`.includes(iccidDigit7Filter) &&
      simVendor.inputFile.includes(inputFileFilter) &&
      simVendor.emailAddress.includes(emailAddressFilter) &&
      getArchivedFilter(simVendor)
  );

  if (!isArchivedVisible) {
    visibleMainranges = visibleMainranges?.filter(
      (mainrange) => !mainrange.archived
    );
  }

  const filterHeadCellMap = {
    [simVendorHeadCells[0].id]: {
      filter: nameFilter,
      setFilter: setNameFilter,
      filterComponent: FilterSearchBar(t)
    },
    [simVendorHeadCells[1].id]: {
      filter: externerNameFilter,
      setFilter: setExternerNameFilter,
      filterComponent: FilterSearchBar(t)
    },
    [simVendorHeadCells[2].id]: {
      filter: iccidDigit7Filter,
      setFilter: setIccidDigit7Filter,
      filterComponent: FilterSearchBar(t)
    },
    [simVendorHeadCells[3].id]: {
      filter: inputFileFilter,
      setFilter: setInputFileFilter,
      filterComponent: FilterSearchBar(t)
    },
    [simVendorHeadCells[3].id]: {
      filter: emailAddressFilter,
      setFilter: setEmailAddressFilter,
      filterComponent: FilterSearchBar(t)
    },
    [simVendorArchivedCell.id]: {
      filter: archivedFilter,
      setFilter: setArchivedFilter,
      filterComponent: FilterDropdown(simVendorArchivedCell.values, t)
    }
  };

  const resetAllFilters = useMemo(() => {
    return () => {
      setNameFilter("");
      setExternerNameFilter("");
      setIccidDigit7Filter("");
      setInputFileFilter("");
      setEmailAddressFilter("");
      setArchivedFilter("");
    };
  }, []);

  const handleRowSelected = async (row: any) => {
    setSelectedSimVendor(null);
    setSelectedSimVendor(row);
  };

  const handleRefresh = async () => {
    await fetchSimVendors(isArchivedVisible);
    resetAllFilters();
  };

  const visibleHeadCells = [
    ...simVendorHeadCells,
    ...(isArchivedVisible ? [simVendorArchivedCell] : [])
  ];

  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleMainranges]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={simVendorTableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.simVendor.isLoadingFetch,
  simVendors: state.simVendor.simVendros
});

const connector = connect(mapStateToProps, {
  fetchSimVendors,
  setSelectedSimVendor
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(SimVendorTable);
