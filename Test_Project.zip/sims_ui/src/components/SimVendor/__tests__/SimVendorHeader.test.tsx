import "@testing-library/jest-dom";
import { Provider } from "react-redux";
import { SetStateAction } from "react";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { fetchSimVendorExport } from "../../../redux/actions/simVendorAction";
import { Store, AnyAction } from "redux";
import SimVendorHeader from "../SimVendorHeader";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import { fireEvent, render, screen } from "@testing-library/react";
import { SimVendorActionTypes } from "../../../redux/actions/types";

const mockStore = configureStore([thunk]);

jest.mock("../../../redux/actions/simVendorAction", () => ({
  fetchSimVendorExport: jest.fn(),
}));

describe("header test", () => {
  let store: Store<unknown, AnyAction>;
  beforeEach(() => {
    store = mockStore({
      simVendor: {
        simVendros: ["ad", "asd"],
      },
      lang: {
        language: "en",
      },
    });
  });

  test("should load compoment without failure", () => {
    const { container } = renderWithAllWrappers(
      <SimVendorHeader
        isArchivedVisible={false}
        setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
        setShowForm={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
      />
    );
    expect(container).toBeInTheDocument();
  });

  test("should render the export button", () => {
    renderWithAllWrappers(
      <SimVendorHeader
        isArchivedVisible={false}
        setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
        setShowForm={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
      />
    );

    expect(screen.getByText(/Export/i)).toBeInTheDocument();
  });

  test("should call the handleExport on button Click", async () => {
    // @ts-ignore:next-line
    fetchSimVendorExport.mockImplementation(() => {
      return {
        type: SimVendorActionTypes.FETCH_SIM_VENDOR_EXPORT_SUCCESS,
        payload: { message: "successfull" },
      };
    });

    render(
      <Provider store={store}>
        <SimVendorHeader
          isArchivedVisible={false}
          setIsArchivedVisible={function (
            value: SetStateAction<boolean>
          ): void {
            throw new Error("Function not implemented.");
          }}
          setShowForm={function (value: SetStateAction<boolean>): void {
            throw new Error("Function not implemented.");
          }}
        />
      </Provider>
    );

    const button = screen.getByRole("export-button");
    await fireEvent.click(button);
    expect(fetchSimVendorExport).toHaveBeenCalled();
  });
});
