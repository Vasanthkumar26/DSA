import * as yup from "yup";
// import { SimVendor } from "../../models/simVendor.model";

export const initData = {
  id: 1,
  manufacturerName: "",
  externalName: "",
  iccIdDigit7: "",
  emailIdDelivery: "",
  sftpOutboundPath: "",
  sftpOutboundUser: "",
  sftpInboundPath: "",
  sftpInboundUser: "",
  userName: "userName",
  lastUpdatedBy: 1,
  pgpKey: "",
  archived: true,
  deliveryType: 1
};

export const setFormData = (data: any) => ({
  manufacturerName: data?.manufacturerName ?? "",
  id: data?.id ?? "",
  externalName: data?.externalName ?? "",
  iccIdDigit7: data?.iccIdDigit7 ?? "",
  sapVendorNo: data?.sapVendorNo ?? "",
  emailIdDelivery: data?.emailIdDelivery ?? "",
  sftpOutboundPath: data?.sftpOutboundPath ?? "",
  sftpOutboundUser: data?.sftpOutboundUser ?? "",
  sftpInboundPath: data?.sftpInboundPath ?? "",
  sftpInboundUser: data?.sftpInboundUser ?? "",
  userName: data?.userName ?? "",
  lastUpdatedBy: 1,
  pgpKey: data?.pgpKey ?? "",
  deliveryType: data?.deliveryType ?? 1
});
export const SimVendorSchema = (
  t: (key: string | undefined) => string,
  cardNames: string[],
  isCreate: boolean
) =>
  yup.object().shape({
    manufacturerName: yup
      .string()
      .required("name_is_missing")
      .notOneOf(
        [...(isCreate ? cardNames ?? [] : [])],
        t("name_already_exists")
      ),
    externalName: yup.string().required("external_name_must_be_selected"),
    iccIdDigit7: yup
      .number()
      .typeError("ICCID digit 7 must be a digit 0-9")
      .required("ICCID digit 7 must be a digit 0-9"),
    emailIdDelivery: yup
      .string()
      .trim()
      .test("Valid Email", "", function (value) {
        if (value) {
          yup.object().shape({
            emails: yup
              .string()
              .required("please_provide_a_valid_email_address")
          });
          const emailSchema = yup.array().of(yup.string().email());
          const emails = value.split(",").map((email) => email.trim());
          if (!emailSchema.isValidSync(emails)) {
            return this.createError({
              message: `please_provide_a_valid_email_address`
            });
          }
        } else {
          return this.createError({
            message: `please_provide_a_valid_email_address`
          });
        }
        return true;
      }),
    deliveryType: yup.number(),
    sftpInboundUser: yup.string(),
    sftpOutboundPath: yup.string().when("deliveryType", {
      is: (v: any) => v === 1,
      then: (schema) => schema.required("SFTP Outbound Path is required")
    }),
    sftpOutboundUser: yup.string().when("deliveryType", {
      is: (v: any) => v === 1,
      then: (schema) => schema.required("SFTP Outbound User is required")
    }),
    sftpInboundPath: yup.string().when("sftpInboundUser", {
      is: (v: any) => v !== "",
      then: (schema) => schema.required("SFTP Inbound Path is required")
    }),
    pgpKey: yup.string().when("deliveryType", {
      is: (v: any) => v === 1,
      then: (schema) => schema.required("PgpKey_should_not_be_empty")
    })
  });
