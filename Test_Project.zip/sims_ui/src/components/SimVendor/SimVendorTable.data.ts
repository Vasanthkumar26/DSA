import { HeadCell, TableConfig } from "../../models";

export const simVendorHeadCells: Array<HeadCell> = [
  { id: "name", label: "Name" },
  { id: "externerName", label: "Externer Name" },
  { id: "iccidDigit7", label: "ICCD Digits 7(blue)" },
  { id: "inputFile", label: "Input-File Shipping" },
  { id: "emailAddress", label: "Email-Adress Shipping confirmation" }
];

export const simVendorArchivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};

export const simVendorTableConfig: TableConfig = {
  title: "Sim Vendor Administration",
  orderBy: "lastUpdateDate",
  tableRowTestId: "simVendor-row"
};
