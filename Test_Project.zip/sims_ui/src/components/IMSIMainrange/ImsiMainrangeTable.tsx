import React, {
  Dispatch,
  FC,
  SetStateAction,
  useEffect,
  useMemo,
  useState
} from "react";
import { Grid } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import {
  fetchImsiMainranges,
  setSelectedImsiMainrange,
  resetIMSIMainRangeErr
} from "../../redux/actions/imsiMainrangeAction";
import { connect, ConnectedProps } from "react-redux";
import { HeadCell, ImsiMainrange, TableConfig } from "../../models";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";
import CustomSnackBar from "../common/CustomSnackBar";

const headCells: Array<HeadCell> = [
  { id: "imsiName", label: "Name" },
  { id: "hlrCombinedName", label: "HLR - IMSI Digit 1-5" },
  { id: "imsiDigits678", label: "IMSI Digits 6-8" },
  { id: "serviceProvider", label: "serv_provider" }
];

const archivedCell = {
  id: "archive",
  label: "Archived",
  values: ["Yes", "No"]
};

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const tableConfig: TableConfig = {
  title: "Mainrange Administration",
  orderBy: "lastUpdatedDate",
  tableRowTestId: "imsiMainrange-row"
};

const ImsiMainrangeTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchImsiMainranges,
  setSelectedImsiMainrange,
  setShowForm,
  deleteSuccessMsgFlag,
  deleteSuccessMsg,
  archiveSuccessMsg,
  archiveSuccessMsgFlag,
  resetIMSIMainRangeErr,
  imsiMainranges = []
}) => {
  const [imsiNameFilter, setImsiNameFilter] = useState("");
  const [hlrCombinedNameFilter, setHlrCombinedNameFilter] = useState("");
  const [imsiDigits678Filter, setImsiDigits678Filter] = useState("");
  const [serviceProviderFilter, setServiceProviderFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchImsiMainranges(isArchivedVisible))();
  }, [fetchImsiMainranges, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getArchivedFilter = (imsiMainrange: ImsiMainrange) => {
    if (archivedFilter === "Yes") {
      return !!imsiMainrange.archive;
    }
    return archivedFilter === "No" ? !imsiMainrange.archive : true;
  };

  let visibleMainranges = imsiMainranges?.filter(
    (imsiMainrange) =>
      imsiMainrange.imsiName.includes(imsiNameFilter) &&
      imsiMainrange.hlrCombinedName.includes(hlrCombinedNameFilter) &&
      imsiMainrange.imsiDigits678.includes(imsiDigits678Filter) &&
      (imsiMainrange.serviceProvider ?? "").includes(serviceProviderFilter) &&
      getArchivedFilter(imsiMainrange)
  );

  if (!isArchivedVisible) {
    visibleMainranges = visibleMainranges?.filter(
      (mainrange) => !mainrange.archive
    );
  }

  const filterHeadCellMap = {
    [headCells[0].id]: {
      filter: imsiNameFilter,
      setFilter: setImsiNameFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[1].id]: {
      filter: hlrCombinedNameFilter,
      setFilter: setHlrCombinedNameFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[2].id]: {
      filter: imsiDigits678Filter,
      setFilter: setImsiDigits678Filter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[3].id]: {
      filter: serviceProviderFilter,
      setFilter: setServiceProviderFilter,
      filterComponent: FilterSearchBar(t)
    },
    [archivedCell.id]: {
      filter: archivedFilter,
      setFilter: setArchivedFilter,
      filterComponent: FilterDropdown(archivedCell.values, t)
    }
  };

  const resetAllFilters = useMemo(() => {
    return () => {
      setImsiNameFilter("");
      setHlrCombinedNameFilter("");
      setImsiDigits678Filter("");
      setServiceProviderFilter("");
      setArchivedFilter("");
    };
  }, []);

  const handleRowSelected = (row: any) => {
    setSelectedImsiMainrange(null);
    setShowForm(false);
    setTimeout(() => {
      setSelectedImsiMainrange(row);
    }, 0);
  };
  function handleCloseSnackbar(): void {
    resetIMSIMainRangeErr();
  }
  const handleRefresh = async () => {
    await fetchImsiMainranges(isArchivedVisible);
    resetAllFilters();
  };

  const visibleHeadCells = [
    ...headCells,
    ...(isArchivedVisible ? [archivedCell] : [])
  ];

  return (
    <Grid container direction="row" wrap="nowrap">
      <CustomSnackBar
        variant="filled"
        open={deleteSuccessMsgFlag || archiveSuccessMsgFlag}
        autoHideDuration={3000}
        message={deleteSuccessMsg || archiveSuccessMsg}
        onClose={handleCloseSnackbar}
        severity="success"
      />
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleMainranges]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
      <Grid item display={{ xs: "none", lg: "block" }}>
        <img
          src="/sidebarIcons/Mask_Group_hlr.jpg"
          alt="background"
          style={{
            objectFit: "cover",
            width: "250px",
            height: "100%",
            margin: "1px"
          }}
        />
      </Grid>
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.imsiMainrange.isLoadingExport,
  imsiMainranges: state.imsiMainrange.imsiMainranges,
  deleteSuccessMsg: state.imsiMainrange.deleteSuccessMsg,
  archiveSuccessMsg: state.imsiMainrange.archiveSuccessMsg,
  deleteSuccessMsgFlag: state.imsiMainrange.deleteSuccessMsgFlag,
  archiveSuccessMsgFlag: state.imsiMainrange.archiveSuccessMsgFlag
});

const connector = connect(mapStateToProps, {
  fetchImsiMainranges,
  setSelectedImsiMainrange,
  resetIMSIMainRangeErr
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ImsiMainrangeTable);
