import React, { Dispatch, FC, SetStateAction, useCallback } from "react";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import {
  fetchimsiMainRangeExport,
  setSelectedImsiMainrange
} from "../../redux/actions/imsiMainrangeAction";
import TableHeader from "../common/TableHeader";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
  isLoadingExport: boolean;
}

const ImsiMainrangeHeader: FC<Props> = ({
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  fetchimsiMainRangeExport,
  setSelectedImsiMainrange,
  isLoadingExport
}) => {
  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleExport = useCallback(() => {
    fetchimsiMainRangeExport(isArchivedVisible);
  }, [fetchimsiMainRangeExport, isArchivedVisible]);

  const handleAdd = useCallback(() => {
    setSelectedImsiMainrange(null);
    setShowForm(true);
  }, [setSelectedImsiMainrange, setShowForm]);

  return (
    <TableHeader
      title="IMSI Mainrange Administration"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.imsiMainrange.isLoadingExport
});

const connector = connect(mapStateToProps, {
  fetchimsiMainRangeExport,
  setSelectedImsiMainrange
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ImsiMainrangeHeader);
