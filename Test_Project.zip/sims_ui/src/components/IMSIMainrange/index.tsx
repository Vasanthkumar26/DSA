import { Alert, Box, Grid, Snackbar } from "@mui/material";
import React, { FC, useMemo, useState } from "react";
import { useSelector } from "react-redux";
import { useTranslation } from "../../hooks/useTranslation";
import { RootState } from "../../redux/store";
import AddEditForm from "./AddEditForm";
import Header from "./ImsiMainrangeHeader";
import ImsiMainrangeTable from "./ImsiMainrangeTable";
import StatusTable from "./StatusTable";

const IMSIMainrange: FC = () => {
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [showStatusTable, setShowStatusTable] = useState(false);
  const [successSnackbarOpen, setSuccessSnackbarOpen] =
    useState<boolean>(false);

  const t = useTranslation();

  const selectedIMSIMainRange = useSelector(
    (state: RootState) => state.imsiMainrange.selectedImsiMainrange
  );

  const startIMSIFunc = useMemo(() => {
    let imsiStartSearch = "";
    const splitValue =
      selectedIMSIMainRange?.hlrCombinedName?.trim().split("-") ?? [];
    if (splitValue?.length >= 3) {
      imsiStartSearch =
        splitValue[1]?.trim() +
        splitValue[2]?.trim() +
        selectedIMSIMainRange?.imsiDigits678?.trim();
    }
    return {
      startIMSIForSearch: imsiStartSearch ?? "",
      endIMSIForSearch: imsiStartSearch ?? ""
    };
  }, [selectedIMSIMainRange]);

  return (
    <>
      <Snackbar
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        open={successSnackbarOpen}
        onClose={() => {
          setSuccessSnackbarOpen(false);
        }}
        autoHideDuration={2000}
      >
        <Alert
          onClose={() => {
            setSuccessSnackbarOpen(false);
          }}
          severity="success"
          elevation={6}
          variant="filled"
          sx={{ width: "100%" }}
        >
          {t("Request processed successfully")}
        </Alert>
      </Snackbar>
      <Box sx={{ padding: 2 }}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Header
              isArchivedVisible={isArchivedVisible}
              setIsArchivedVisible={setIsArchivedVisible}
              setShowForm={setShowForm}
            />
            <ImsiMainrangeTable
              isArchivedVisible={isArchivedVisible}
              setShowForm={setShowForm}
            />
          </Grid>
          {showForm || selectedIMSIMainRange ? (
            <Grid item xs={12}>
              <AddEditForm
                setShowForm={setShowForm}
                setSuccessSnackbarOpen={setSuccessSnackbarOpen}
                setShowStatusTable={setShowStatusTable}
              />
            </Grid>
          ) : (
            <></>
          )}
          {selectedIMSIMainRange && showStatusTable && (
            <StatusTable payload={startIMSIFunc} />
          )}
        </Grid>
      </Box>
    </>
  );
};

export default IMSIMainrange;
