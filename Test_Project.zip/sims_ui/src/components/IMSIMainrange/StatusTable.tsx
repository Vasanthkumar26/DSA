import { FC, useEffect } from "react";
import { headCellsStatusTable, tableConfigStatusTable } from "./MainRange.data";
import TableView from "../common/TableView";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import { ImsiSubAndMainRangeStatusRequestPayload } from "../../models";
import { fetchIMSIMainRangeStatusTable } from "../../redux/actions/imsiMainrangeAction";

interface Props extends PropsFromRedux {
  payload: ImsiSubAndMainRangeStatusRequestPayload;
}
const StatusTable: FC<Props> = ({
  isLoadingTable,
  fetchIMSIMainRangeStatusTable,
  payload,
  mainrangeStatusDetail
}) => {
  useEffect(() => {
    (async () => await fetchIMSIMainRangeStatusTable(payload))();
  }, [fetchIMSIMainRangeStatusTable, payload]);

  const handleRefreash = async () => {
    await fetchIMSIMainRangeStatusTable(payload);
  };

  return (
    <TableView
      isLoading={isLoadingTable}
      visibleHeadCells={headCellsStatusTable}
      visibleItems={[...mainrangeStatusDetail]}
      handleRefresh={handleRefreash}
      tableConfig={tableConfigStatusTable}
      isFilterSortingVisible={false}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingTable: state.imsiMainrange.isLoadingStatusTable,
  mainrangeStatusDetail: state.imsiMainrange.mainrangeStatusDetail
});

const connnector = connect(mapStateToProps, {
  fetchIMSIMainRangeStatusTable
});

type PropsFromRedux = ConnectedProps<typeof connnector>;
export default connnector(StatusTable);
