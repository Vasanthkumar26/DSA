import {
  Dispatch,
  FC,
  SetStateAction,
  useEffect,
  useMemo,
  useState
} from "react";
import { connect, ConnectedProps } from "react-redux";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import { RootState } from "../../redux/store";
import { useTranslation } from "../../hooks/useTranslation";
import { Controller, useForm } from "react-hook-form";
import { handleFetchImsiMainranges } from "../../services/ImsiMainrangeApi";
import {
  ICreateIMSIMainRangeRequestBody,
  ISelectionOption
} from "../../models";
import {
  createIMSIMainRange,
  fetchImsiMainranges,
  resetIMSIMainRangeErr,
  setSelectedImsiMainrange,
  updateIMSIMainRange,
  deleteImsiMainrange,
  archiveImsiMainrange,
  resetIMSIMainRange
} from "../../redux/actions/imsiMainrangeAction";
import { fetchServiceProviders } from "../../redux/actions/serviceProviderAction";
import {
  TextField,
  Button,
  InputLabel,
  Box,
  Grid,
  Stack,
  Typography
} from "@mui/material";
import { fetchHlrs } from "../../redux/actions/hlrAction";
import { DeleteDailog } from "../common/AddEditForm/DeleteDialog";
import dayjs from "dayjs";
import {
  createMRPayload,
  mainRangeSchema,
  mrInitData,
  setFormData
} from "./MainRange.data";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import { resetPage } from "../../redux/actions/rootAction";
import { SPSelectWithSearch } from "../common/AddEditForm/SPSelectWithSearch";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import { useNavigate } from "react-router-dom";

interface Props extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
  setSuccessSnackbarOpen: Dispatch<SetStateAction<boolean>>;
  setShowStatusTable: Dispatch<SetStateAction<boolean>>;
}

const AddEditForm: FC<Props> = ({
  hlrs,
  serviceProviders,
  isLoadingCreate,
  isLoadingUpdate,
  selectedImsiMainrange,
  createIMSIMainRange,
  updateIMSIMainRange,
  fetchHlrs,
  fetchServiceProviders,
  deleteImsiMainrange,
  archiveImsiMainrange,
  setShowStatusTable,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetIMSIMainRange,
  resetPage
}) => {
  const [IMSIMainRangeExists, setIMSIMainRangeExists] = useState<
    boolean | null
  >(null);
  const [IMSIDigitExists, setIMSIDigitExists] = useState<boolean | null>(null);
  const [IMSIMainRangeNames, setIMSIMainRangeNames] = useState<string[]>([]);
  const [usedIMSIDigits, setUsedIMSIDigits] = useState<Set<string>>(new Set());
  const resolver = useYupValidationResolver(mainRangeSchema);
  const [open, setOpen] = useState<boolean>(false);
  const t = useTranslation();
  const { control, handleSubmit, reset, watch, setValue } = useForm({
    mode: "all",
    resolver,
    defaultValues: {
      ...mrInitData
    }
  });

  const {
    imsiMainRangeId = "",
    archive = false,
    hlrCombinedName = "",
    imsiSubRangeLinked = false,
    spid = null,
    hlrid = null
  } = selectedImsiMainrange ?? {};

  useEffect(() => {
    selectedImsiMainrange
      ? reset(setFormData(selectedImsiMainrange))
      : reset({ ...mrInitData });
  }, [reset, selectedImsiMainrange]);

  const imsiName = watch("imsiName");
  const hlr = watch("hlr");
  const imsiDigits678 = watch("imsiDigits678");

  const navigate = useNavigate();

  useEffect(() => {
    handleFetchImsiMainranges(false)
      .then((data) => {
        const usedImsiDigitsInMainRange = new Set<string>();
        const usedIMSIMainRangeNames = data.reduce(
          (result: Array<string>, obj) => {
            if (
              obj.imsiName &&
              typeof obj.imsiName === "string" &&
              obj.imsiName?.trim() !== ""
            ) {
              result.push(obj.imsiName);
            }

            const lastIndex = obj.hlrCombinedName?.lastIndexOf("-");
            const secondLastIndex = obj.hlrCombinedName?.lastIndexOf(
              "-",
              lastIndex - 1
            );

            const imsiDigit123 = obj.hlrCombinedName
              ?.substring(secondLastIndex + 1, lastIndex)
              ?.trim();
            const imsiDigit45 = obj.hlrCombinedName
              ?.substring(lastIndex + 1)
              ?.trim();

            if (imsiDigit123 && imsiDigit45 && obj.imsiDigits678) {
              const usedImsiDigit = `${imsiDigit123}-${imsiDigit45}-${obj.imsiDigits678}`;
              usedImsiDigitsInMainRange.add(usedImsiDigit);
            }
            return result;
          },
          []
        );
        setIMSIMainRangeNames(usedIMSIMainRangeNames);
        setUsedIMSIDigits(usedImsiDigitsInMainRange);
      })
      .catch((err) => {
        console.log(err); //TODO: @Amrit please handle the error,ui was breaking
      });
    fetchHlrs(true);
    fetchServiceProviders(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    setIMSIDigitExists(null);

    let imsiDigit123: string;
    let imsiDigit45: string;

    const hlrName = (hlrs ?? []).find((x) => x.hlrName === hlr)?.hlrName ?? "";

    if (hlrName) {
      const lastIndex = hlrName?.lastIndexOf("-");
      const secondLastIndex = hlrName?.lastIndexOf("-", lastIndex - 1);

      imsiDigit123 = hlrName?.substring(secondLastIndex + 1, lastIndex)?.trim();
      imsiDigit45 = hlrName?.substring(lastIndex + 1)?.trim();

      if (imsiDigit123 && imsiDigit45 && imsiDigits678) {
        if (selectedImsiMainrange) {
          const selectedImsiDigit = hlrCombinedName;
          const lastIndex = selectedImsiDigit?.lastIndexOf("-");
          const secondLastIndex = selectedImsiDigit?.lastIndexOf(
            "-",
            lastIndex - 1
          );

          const selectedImsiDigit123 = selectedImsiDigit
            ?.substring(secondLastIndex + 1, lastIndex)
            ?.trim();
          const selectedImsiDigit45 = selectedImsiDigit
            ?.substring(lastIndex + 1)
            ?.trim();

          if (
            `${imsiDigit123}${imsiDigit45}${imsiDigits678}` ===
            `${selectedImsiDigit123}${selectedImsiDigit45}${selectedImsiMainrange.imsiDigits678}`
          ) {
            setIMSIDigitExists(false);
          } else {
            setIMSIDigitExists(
              [...usedIMSIDigits].includes(
                `${imsiDigit123}-${imsiDigit45}-${imsiDigits678}`
              )
            );
          }
        } else {
          setIMSIDigitExists(
            [...usedIMSIDigits].includes(
              `${imsiDigit123}-${imsiDigit45}-${imsiDigits678}`
            )
          );
        }
      }
    }
  }, [
    hlr,
    hlrCombinedName,
    hlrs,
    imsiDigits678,
    selectedImsiMainrange,
    usedIMSIDigits
  ]);

  useEffect(() => {
    setIMSIMainRangeExists(null);
    if (imsiName) {
      if (selectedImsiMainrange?.imsiName === imsiName) {
        setIMSIMainRangeExists(false);
      } else {
        setIMSIMainRangeExists(IMSIMainRangeNames.includes(imsiName));
      }
    }
  }, [imsiName, IMSIMainRangeNames, selectedImsiMainrange]);

  const resetThisPage = () => {
    resetIMSIMainRange();
    resetPage();
  };

  const onSubmit = (data: ICreateIMSIMainRangeRequestBody) => {
    const body = createMRPayload(data, hlr);
    const promiseAPI = selectedImsiMainrange
      ? updateIMSIMainRange({ ...body, archived: false }, `${imsiMainRangeId}`)
      : createIMSIMainRange(body);

    promiseAPI
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const handleConfirmation = (flag: boolean): any => {
    setOpen(flag);
  };

  const navigateToIMSISubrange = () => {
    navigate(
      `/imsi-management/imsi-subranges?predefinedImsiMainRange=${selectedImsiMainrange?.imsiMainRangeId}&showArchived=${selectedImsiMainrange?.archive}` ??
        ""
    );
  };
  const handleCloseConfirmation = () => {
    deleteImsiMainrange(+imsiMainRangeId)
      .then(() => showSuccessSnackbar(t("successfully_deleted")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const handleArchiveConfirmation = () => {
    archiveImsiMainrange(+imsiMainRangeId, archive)
      .then(() =>
        showSuccessSnackbar(
          !archive ? t("successfully_archived") : t("successfully_activated")
        )
      )
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const hlrsDropdownList = useMemo(
    () =>
      hlrs.flatMap((hlr) => {
        const {
          id = 0,
          hlrName = "",
          imsiDigits12345 = "",
          archived = false
        } = hlr ?? {};
        const labelText = `${hlrName} - ${imsiDigits12345}`;
        const imis12345 = hlrCombinedName?.split(/-(.*)/s)[1]?.trim() ?? "";
        if (imsiSubRangeLinked && imis12345 !== imsiDigits12345) {
          return [];
        }
        return {
          label: archived ? `${labelText}[${t("archived")}]` : labelText,
          id: `${id}`
        };
      }),
    // eslint-disable-next-line
    [hlrCombinedName, hlrs, imsiSubRangeLinked]
  );

  return (
    <>
      <DeleteDailog
        open={open}
        onDelete={handleConfirmation}
        handleCloseConfirmation={handleCloseConfirmation}
        message={"delete_confirmation"}
      ></DeleteDailog>
      <Box component="form" onSubmit={handleSubmit(onSubmit)}>
        <Box
          sx={{
            backgroundColor: "#F3F4FF",
            padding: "20px"
          }}
        >
          <Grid container spacing={2}>
            <Grid item xs={12} sm={12} md={12}>
              <Controller
                name="imsiName"
                control={control}
                render={({ field, fieldState }) => {
                  return (
                    <>
                      <InputLabel htmlFor="imsiName" required>
                        {t("Name")}
                      </InputLabel>
                      <TextField
                        id="imsiName"
                        {...field}
                        error={
                          !!fieldState.error || IMSIMainRangeExists || undefined
                        }
                        helperText={
                          t(fieldState.error?.message) ||
                          (IMSIMainRangeExists &&
                            t("IMSI Main Range name already exists"))
                        }
                        fullWidth
                        size="small"
                        sx={{
                          backgroundColor: "white",
                          "& .MuiFormHelperText-root": {
                            margin: 0,
                            backgroundColor: "#F3F4FF"
                          }
                        }}
                        inputProps={{ maxLength: 255 }}
                      />
                    </>
                  );
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <FormControllerSelectWithSearch
                controlName="hlr"
                control={control}
                options={hlrsDropdownList as ISelectionOption[]}
                inputLabel={t("HLR - IMSI Digit 1-5")}
                required
                setValue={setValue}
                id={hlrid}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <Controller
                name="imsiDigits678"
                control={control}
                render={({ field, fieldState }) => {
                  return (
                    <>
                      <InputLabel htmlFor="imsiDigits678" required>
                        {t("IMSI Digits 6-8")}
                      </InputLabel>
                      <TextField
                        id="imsiDigits678"
                        {...field}
                        error={
                          !!fieldState.error || IMSIDigitExists || undefined
                        }
                        helperText={
                          t(fieldState.error?.message) ||
                          (IMSIDigitExists &&
                            t("IMSI digits 1-8 must be unique"))
                        }
                        fullWidth
                        size="small"
                        disabled={selectedImsiMainrange?.imsiSubRangeLinked}
                        sx={{
                          backgroundColor: "white",
                          "& .MuiFormHelperText-root": {
                            margin: 0,
                            backgroundColor: "#F3F4FF"
                          }
                        }}
                        inputProps={{ maxLength: 3 }}
                      />
                    </>
                  );
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6} md={4}>
              <SPSelectWithSearch
                setValue={setValue}
                control={control}
                controlName="serviceProvider"
                inputLabel={"serv_provider"}
                spid={spid}
                isDisabled={imsiSubRangeLinked}
              />
            </Grid>
          </Grid>
          {selectedImsiMainrange ? (
            <Grid item xs={12}>
              <Stack direction="row" justifyContent="flex-end">
                <Typography
                  align="center"
                  color="#031a34"
                  sx={{ fontWeight: 500, marginTop: "1em" }}
                >
                  {t("Last updated") + " : "}
                  {selectedImsiMainrange.lastUpdatedDate
                    ? `${dayjs(
                        selectedImsiMainrange?.lastUpdatedDate ?? ""
                      ).format("YYYY-MM-DD HH:mm:ss")} (${
                        selectedImsiMainrange?.userName ?? ""
                      })`
                    : "N/A"}
                </Typography>
              </Stack>
            </Grid>
          ) : (
            <></>
          )}
        </Box>
        <Grid item xs={12}>
          <Stack
            direction="row"
            justifyContent={
              !imsiSubRangeLinked ||
              (imsiSubRangeLinked && !archive) ||
              (imsiSubRangeLinked && archive)
                ? "space-between"
                : "flex-end"
            }
            spacing={2}
            sx={{ marginTop: "1em" }}
          >
            {!imsiSubRangeLinked && (
              <Button
                variant="contained"
                onClick={() => {
                  handleConfirmation(true);
                }}
                data-testid="delete"
              >
                {t("button_delete")}
              </Button>
            )}

            {imsiSubRangeLinked && !archive && (
              <Button
                variant="contained"
                onClick={() => {
                  handleArchiveConfirmation();
                }}
                data-testid="archive"
              >
                {t("button_archived")}
              </Button>
            )}

            {!imsiSubRangeLinked && archive && (
              <Button
                variant="contained"
                onClick={() => {
                  handleArchiveConfirmation();
                }}
                data-testid="active"
              >
                {t("button_active")}
              </Button>
            )}

            <Stack
              direction="row"
              justifyContent="flex-end"
              spacing={2}
              sx={{ marginY: "1em" }}
            >
              <Button
                variant="outlined"
                disabled={isLoadingCreate || isLoadingUpdate}
                onClick={() => resetThisPage()}
              >
                {t("button_cancel")}
              </Button>
              {selectedImsiMainrange && (
                <Button
                  variant="contained"
                  onClick={() => {
                    setShowStatusTable(true);
                  }}
                  data-testid="status-table"
                >
                  {t("View status")}
                </Button>
              )}

              <Button
                disabled={isLoadingCreate || isLoadingUpdate}
                variant="contained"
                type="submit"
              >
                {t("button_save")}
              </Button>
              {selectedImsiMainrange && (
                <Button
                  disabled={isLoadingCreate || isLoadingUpdate}
                  variant="contained"
                  onClick={() => navigateToIMSISubrange()}
                >
                  {t("Manage IMSI Subranges")}
                </Button>
              )}
            </Stack>
          </Stack>
        </Grid>
      </Box>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedImsiMainrange: state.imsiMainrange.selectedImsiMainrange,
  isLoadingCreate: state.imsiMainrange.isLoadingCreate,
  errorCreate: state.imsiMainrange.errorCreate,
  isLoadingUpdate: state.imsiMainrange.isLoadingUpdate,
  errorUpdate: state.imsiMainrange.errorUpdate,
  hlrs: state.hlr.hlrs,
  serviceProviders: state.serviceProvider.serviceProviders
});

const connector = connect(mapStateToProps, {
  createIMSIMainRange,
  updateIMSIMainRange,
  resetIMSIMainRangeErr,
  setSelectedImsiMainrange,
  fetchImsiMainranges,
  fetchHlrs,
  deleteImsiMainrange,
  archiveImsiMainrange,
  fetchServiceProviders,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetIMSIMainRange,
  resetPage
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(AddEditForm);
