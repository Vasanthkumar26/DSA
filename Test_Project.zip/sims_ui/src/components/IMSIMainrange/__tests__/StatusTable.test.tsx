//@ts-nocheck
import "@testing-library/jest-dom";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import StatusTable from "../StatusTable";
import {
  MAINRANGE_FAILURE_API_HANDLERS,
  MAINRANGE_SUCCESS_API_HANDLERS
} from "../../../_mocks_/mainrangeApiHandlers";
import { screen, waitFor } from "@testing-library/react";

describe("StatusTable", () => {
  const payload = {
    startIMSIForSearch: "232",
    endIMSIForSearch: "123123"
  };
  describe("SUCCESS", () => {
    createServer(MAINRANGE_SUCCESS_API_HANDLERS);
    test("should render without crash", () => {
      const { container } = renderWithAllWrappers(
        <StatusTable payload={payload} />
      );
      expect(container).toBeInTheDocument();
    });

    test("Table shoudl show correct data", async () => {
      renderWithAllWrappers(<StatusTable payload={payload} />);

      const statusRecords = await screen.findAllByTestId(
        /status-mainrange-row/i
      );
      expect(statusRecords).toHaveLength(1);
    });
  });

  describe("FAILURE", () => {
    createServer(MAINRANGE_FAILURE_API_HANDLERS);
    test("Table should show zero record", async () => {
      renderWithAllWrappers(<StatusTable payload={payload} />);
      await waitFor(async () => {
        const tableRow = screen.queryAllByTestId(/status-mainrange-row/i);
        expect(tableRow).toHaveLength(0);
      });
    });
  });
});
