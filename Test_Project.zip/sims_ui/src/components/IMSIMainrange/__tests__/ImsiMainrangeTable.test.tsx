//@ts-nocheck
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import "@testing-library/jest-dom";
import { screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import ImsiMainrangeTable from "../ImsiMainrangeTable";
import { REACT_BASE_URL } from "../../../utils/common";

describe("TableView", () => {
  test("should render without crash", () => {
    const { container } = renderWithAllWrappers(
      <ImsiMainrangeTable isArchivedVisible={false} />
    );
    expect(container).toBeInTheDocument();
  });

  describe("API success", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/imsi/loadIMSIMainRange`,
        res: () => [
          {
            imsiName: "testImsi6",
            hlrCombinedName: "HLRBLACK - 123-45",
            imsiDigits678: "234",
            serviceProvider: "BCS (SP995)"
          },
          {
            imsiName: "description2",
            hlrCombinedName: "HLRBLACK - 123-45",
            imsiDigits678: "245",
            serviceProvider: "BCS (SP995)"
          }
        ]
      }
    ]);

    test("Table should show correct data when archived unchecked", async () => {
      renderWithAllWrappers(<ImsiMainrangeTable isArchivedVisible={false} />);
      await waitFor(async () => {
        const mainrangeRows = await screen.findAllByTestId(
          /imsiMainrange-row/i
        );
        expect(mainrangeRows).toHaveLength(2);
      });
    });

    test("Table should show correct data when archived checked", async () => {
      renderWithAllWrappers(<ImsiMainrangeTable isArchivedVisible={true} />);
      await waitFor(async () => {
        const mainrangeRows = await screen.findAllByTestId(
          /imsiMainrange-row/i
        );
        expect(mainrangeRows).toHaveLength(2);
      });
    });

    test("Table should refresh on clicking refresh button", async () => {
      renderWithAllWrappers(<ImsiMainrangeTable isArchivedVisible={true} />);
      const refreshBtn = await screen.findByTestId(/refresh-button/);
      userEvent.click(refreshBtn);

      await waitFor(async () => {
        const mainrangeRows = await screen.findAllByTestId(
          /imsiMainrange-row/i
        );
        expect(mainrangeRows).toHaveLength(2);
      });
    });
  });

  describe("API Failure", () => {
    createServer([
      {
        path: `${REACT_BASE_URL}/imsi/loadIMSIMainRange`,
        status: 404,
        res: () => ({ message: "Oops! Something went wrong" })
      }
    ]);

    test("Table should show correct message when server down", async () => {
      renderWithAllWrappers(<ImsiMainrangeTable isArchivedVisible={false} />);
      await waitFor(async () => {
        const hlrRows = screen.queryAllByTestId(/imsiMainrange-row/i);
        expect(hlrRows).toHaveLength(0);
      });
    });
  });
});
