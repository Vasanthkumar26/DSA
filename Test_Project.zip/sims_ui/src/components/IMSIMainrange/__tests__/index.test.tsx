import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import IMSIMainrange from "..";

describe("IMSIMainrange", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<IMSIMainrange />, {
      route: "/",
    });

    expect(container).toBeInTheDocument();
  });
});
