import "@testing-library/jest-dom";
import { SetStateAction } from "react";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import { screen, fireEvent, render } from "@testing-library/react";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { Store, AnyAction } from "redux";
import { fetchimsiMainRangeExport } from "../../../redux/actions/imsiMainrangeAction";
import { ImsiMainrangeActionTypes } from "../../../redux/actions/types";
import ImsiMainrangeHeader from "../ImsiMainrangeHeader";

const mockStore = configureStore([thunk]);

jest.mock("../../../redux/actions/imsiMainrangeAction", () => ({
  fetchimsiMainRangeExport: jest.fn(),
}));

describe("header test", () => {
  let store: Store<unknown, AnyAction>;
  beforeEach(() => {
    store = mockStore({
      imsiMainrange: {
        imsiMainranges: ["a", "b"],
      },
      lang: {
        language: "en",
      },
    });
  });
  test("should load component without failed", () => {
    const { container } = renderWithAllWrappers(
      <ImsiMainrangeHeader
        isArchivedVisible={false}
        setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
        setShowForm={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
      />
    );
    expect(container).toBeInTheDocument();
  });

  test("rende the export button", () => {
    renderWithAllWrappers(
      <ImsiMainrangeHeader
        isArchivedVisible={false}
        setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
        setShowForm={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
      />
    );

    expect(screen.getByText(/Export/i)).toBeInTheDocument();
  });

  test("should call the handleExport on button click", async () => {
      // @ts-ignore: Unreachable code error
    fetchimsiMainRangeExport.mockImplementation(() => {
      return {
        type: ImsiMainrangeActionTypes.FETCH_IMSI_MAINRANGE_EXPORT_SUCCESS,
        payload: { message: "successfull" },
      };
    });
    render(
      <Provider store={store}>
        <ImsiMainrangeHeader
          isArchivedVisible={false}
          setIsArchivedVisible={function (
            value: SetStateAction<boolean>
          ): void {
            throw new Error("Function not implemented.");
          }}
          setShowForm={function (value: SetStateAction<boolean>): void {
            throw new Error("Function not implemented.");
          }}
        />
      </Provider>
    );
    const button = screen.getByRole("export-button");
    await fireEvent.click(button);
    expect(fetchimsiMainRangeExport).toHaveBeenCalled();
  });
});
