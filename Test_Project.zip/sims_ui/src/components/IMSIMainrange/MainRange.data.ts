import * as yup from "yup";
import { HeadCell, TableConfig } from "../../models";

export const headCells: Array<HeadCell> = [
  { id: "startImsi", label: "Start IMSI" },
  { id: "endImsi", label: "End IMSI" },
  { id: "number", label: "Anzahl" },
  { id: "hlr", label: "HLR" },
  { id: "status", label: "Status" },
  { id: "Produkttyp", label: "Product Type" },
  { id: "orderNumber", label: "orderNumber" },
  { id: "CardType", label: "Card types" },
  { id: "serviceProvider", label: "serv_provider" }
];

export const tableConfig: TableConfig = {
  title: "Status table",
  orderBy: "lastUpdatedDate",
  tableRowTestId: "status-mainrange-row"
};

export const mainRangeSchema = yup.object().shape({
  imsiName: yup.string().required("name_is_missing"),
  imsiDigits678: yup
    .string()
    .required("IMSI Ziffern 6-8 müssen genau 3 Ziffern sein")
    .min(3, "IMSI Ziffern 6-8 müssen genau 3 Ziffern sein")
    .max(3, "IMSI Ziffern 6-8 müssen genau 3 Ziffern sein")
    .test(
      "numeric value",
      "IMSI digits 6-8 must be exactly 3 digits",
      (value) => /^\d+$/.test(value)
    )
});

export const mrInitData = {
  imsiName: "",
  hlr: null,
  imsiDigit1to5: "",
  imsiDigits678: "",
  serviceProvider: null
};

export const setFormData = (data: any) => ({
  imsiName: data?.imsiName || mrInitData.imsiName,
  hlr: `${data?.hlrid}` || mrInitData.hlr,
  imsiDigits678: data?.imsiDigits678 || mrInitData.imsiDigits678,
  serviceProvider: data?.spid || mrInitData.serviceProvider
});

export const createMRPayload = (data: any, hlr: any) => ({
  imsiName: data?.imsiName ?? "",
  hlr: parseInt(hlr?.id) ?? 0,
  spid: data?.serviceProvider?.id ?? 0,
  imsiDigits678: data?.imsiDigits678 ?? "",
  userName: "123"
});

export const headCellsStatusTable: Array<HeadCell> = [
  { id: "startImsi", label: "Start IMSI" },
  { id: "endImsi", label: "End IMSI" },
  { id: "amount", label: "Anzahl" },
  { id: "hlrName", label: "HLR" },
  { id: "status", label: "Status" },
  { id: "productTypeName", label: "Product Type" },
  { id: "oaRefPoPk", label: "orderNumber" },
  { id: "cardTypeName", label: "Card types" },
  { id: "systemStack", label: "serv_provider" }
];

export const tableConfigStatusTable: TableConfig = {
  title: "Status table",
  orderBy: "lastUpdatedDate",
  tableRowTestId: "status-mainrange-row"
};
