import {
  Dispatch,
  FC,
  SetStateAction,
  useCallback,
  useEffect,
  useState
} from "react";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import { Grid } from "@mui/material";
import { useForm } from "react-hook-form";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import {
  createSCPayload,
  shortCodeSchema,
  initData,
  setFormData
} from "./ShortCode.data";
import { StyledFormBox } from "../common/styles/shared";
import { SCUser } from "../../models";
import {
  FormActionButtons,
  FormControllerTextField,
  LastUpdated
} from "../common/AddEditForm";
import {
  createShortCode,
  setSelectedShortCode,
  updateShortCode,
  deleteShortCode,
  archiveShortCode,
  resetShortCode,
  loadShortCodeSPIDList
} from "../../redux/actions/shortCodeAction";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import { useTranslation } from "../../hooks/useTranslation";
import { resetPage } from "../../redux/actions/rootAction";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import DeleteModal from "../common/modals/DeleteModal";

interface Props extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
  scUsers: Array<SCUser> | null;
}

const ShortCodeAddEditForm: FC<Props> = ({
  scSpid,
  selectedShortCode,
  scUsers,
  isLoadingCreate,
  errorCreate,
  isLoadingUpdate,
  errorUpdate,
  setShowForm,
  setSelectedShortCode,
  createShortCode,
  updateShortCode,
  showSuccessSnackbar,
  showFailureSnackbar,
  deleteShortCode,
  archiveShortCode,
  resetShortCode,
  shortCodeValue,
  resetPage,
  loadShortCodeSPIDList
}) => {
  const t = useTranslation();
  const resolver = useYupValidationResolver(
    shortCodeSchema(t, [...(scSpid ?? [])])
  );
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { control, handleSubmit, reset, setValue } = useForm({
    mode: "all",
    resolver,
    defaultValues: { ...initData }
  });
  const {
    lastUpdateDate = "",
    archived = false,
    productTypeRefExists = false,
    serviceProviderId = "",
    id = 0
  } = selectedShortCode ?? {};

  useEffect(() => {
    selectedShortCode
      ? reset(setFormData(selectedShortCode, shortCodeValue))
      : reset({ ...initData });
  }, [reset, selectedShortCode, shortCodeValue]);

  useEffect(() => {
    (async () => await loadShortCodeSPIDList())();
  }, [loadShortCodeSPIDList]);

  useEffect(() => {
    if (errorCreate || errorUpdate) {
      showFailureSnackbar(errorCreate || errorUpdate || "");
    }
  }, [errorCreate, errorUpdate, showFailureSnackbar]);

  const handleReset = useCallback(() => {
    reset({ ...initData });
    setSelectedShortCode(null);
    setShowForm(false);
  }, [reset, setSelectedShortCode, setShowForm]);

  const onActiveNArchive = () => {
    archiveShortCode(id.toString(), !archived)
      .then(() =>
        showSuccessSnackbar(
          !archived ? t("successfully_archived") : t("successfully_activated")
        )
      )
      .catch(() => showFailureSnackbar("Error while processing data"));
    resetShortCode();
    resetPage();
  };

  const handleDelete = () => {
    setIsModalOpen(false);
    deleteShortCode(id.toString())
      .then(() => showSuccessSnackbar(t("successfully_deleted")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => {
        resetShortCode();
        resetPage();
      });
  };

  const onSubmit = (data: any) => {
    const payload = createSCPayload(data);
    const esApi = selectedShortCode
      ? updateShortCode(
          {
            ...payload,
            archived: false,
            serviceProvider: serviceProviderId.toString()
          },
          `${id}`
        )
      : createShortCode({ ...payload });
    esApi
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => {
        resetShortCode();
        resetPage();
      });
  };

  return (
    <>
      <DeleteModal
        isOpen={isModalOpen}
        handleConfirm={handleDelete}
        handleCancel={() => setIsModalOpen(false)}
      />
      <StyledFormBox component="form" onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerSelectWithSearch
              control={control}
              controlName="spid"
              inputLabel="Service  Provider"
              options={shortCodeValue}
              required
              id={serviceProviderId}
              setValue={setValue}
            />
          </Grid>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerTextField
              control={control}
              controlName="shortCode"
              inputLabel="Short Code"
            />
          </Grid>
          {lastUpdateDate && (
            <Grid item xs={12}>
              <LastUpdated lastUpdatedDate={lastUpdateDate} />
            </Grid>
          )}
          <Grid item xs={12}>
            <FormActionButtons
              onCancel={handleReset}
              onDelete={() => setIsModalOpen(true)}
              onActiveNArchive={onActiveNArchive}
              selectedData={selectedShortCode}
              submitDisabled={isLoadingCreate || isLoadingUpdate}
              cancelDisabled={isLoadingCreate || isLoadingUpdate}
              isArchiveVisible={!archived && productTypeRefExists}
              isDeleteVisible={!productTypeRefExists}
              isActiveVisible={archived && productTypeRefExists}
            />
          </Grid>
        </Grid>
      </StyledFormBox>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  scSpid: state.shortCode.scSpid,
  selectedShortCode: state.shortCode.selectedShortCode,
  isLoadingCreate: state.shortCode.isLoadingCreate,
  errorCreate: state.shortCode.errorCreate,
  isLoadingUpdate: state.shortCode.isLoadingUpdate,
  errorUpdate: state.shortCode.errorUpdate,
  shortCodeValue: state.shortCode.shortCodeValue
});

const connector = connect(mapStateToProps, {
  createShortCode,
  updateShortCode,
  setSelectedShortCode,
  showSuccessSnackbar,
  showFailureSnackbar,
  deleteShortCode,
  archiveShortCode,
  resetShortCode,
  resetPage,
  loadShortCodeSPIDList
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ShortCodeAddEditForm);
