import React, { FC, useEffect, useState } from "react";
import { Box, Grid } from "@mui/material";
import ShortCodeHeader from "./ShortCodeHeader";
import ShortCodeTable from "./ShortCodeTable";
import ShortCodeAddEditForm from "./ShortCodeAddEditForm";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
//import { fetchShortCodeSPID } from "../../redux/actions/shortCodeAction";
import { fetchShortCodeSPID } from "../../services/ShortCodeApi";
import { SCUser } from "../../models";
import { showFailureSnackbar } from "../../redux/actions/snackbarAction";

interface Props extends PropsFromRedux {}

const ShortCodes: FC<Props> = ({ selectedShortCode, showFailureSnackbar }) => {
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [scUsers, setScUsers] = useState<SCUser[] | null>(null);

  useEffect(() => {
    if (!scUsers) {
      fetchShortCodeSPID()
        .then((result: SCUser[]) => setScUsers(result))
        .catch(() => showFailureSnackbar("Error while loading spids"));
    }
  }, [scUsers, showFailureSnackbar]);

  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <ShortCodeHeader
            isArchivedVisible={isArchivedVisible}
            setIsArchivedVisible={setIsArchivedVisible}
            setShowForm={setShowForm}
          />
          <ShortCodeTable isArchivedVisible={isArchivedVisible} />
        </Grid>
        {(showForm || selectedShortCode) && (
          <Grid item xs={12}>
            <ShortCodeAddEditForm setShowForm={setShowForm} scUsers={scUsers} />
          </Grid>
        )}
      </Grid>
    </Box>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedShortCode: state.shortCode.selectedShortCode
});

const connector = connect(mapStateToProps, {
  showFailureSnackbar
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ShortCodes);
