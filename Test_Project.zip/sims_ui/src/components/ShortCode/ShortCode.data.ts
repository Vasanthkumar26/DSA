import * as yup from "yup";
import { ShortCodePayload, ISelectionOption } from "../../models";

export const initData = {
  spid: null,
  shortCode: ""
};

export const setFormData = (data: any, shortCodeValue: ISelectionOption[]) => ({
  spid:
    shortCodeValue.find((item: any) => item?.id === data?.serviceProviderId) ??
    "",
  shortCode: data?.shortCode ?? ""
});

export const shortCodeSchema = (
  t: (key: string | undefined) => string,
  scSpid: string[]
) =>
  yup.object().shape({
    shortCode: yup
      .string()
      .required(t("shortCode_is_missing"))
      .max(3, "max_3_character")
      .min(3, "min_3_character")
  });

export const createSCPayload = (data: any) =>
  ({
    spid: data?.spid?.id ?? "",
    shortCode: data?.shortCode ?? ""
  } as ShortCodePayload);
