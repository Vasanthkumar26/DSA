import { Dispatch, FC, SetStateAction, useCallback } from "react";
import { ConnectedProps, connect } from "react-redux";
import TableHeader from "../common/TableHeader";
import { RootState } from "../../redux/store";
import // fetchExtertnalSystemExport,
//setSelectedExternalSystem,
"../../redux/actions/extenalSystemsAction";
import {
  fetchShortCodeExport,
  setSelectedShortCode
} from "../../redux/actions/shortCodeAction";
interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const ShortCodeHeader: FC<Props> = ({
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  isLoadingExport,
  fetchShortCodeExport,
  setSelectedShortCode
}) => {
  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleExport = useCallback(() => {
    fetchShortCodeExport(isArchivedVisible);
  }, [fetchShortCodeExport, isArchivedVisible]);

  const handleAdd = useCallback(() => {
    setSelectedShortCode(null);
    setShowForm(true);
  }, [setSelectedShortCode, setShowForm]);

  return (
    <TableHeader
      title="Service Provider ShortCode Administration"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.externalSystem.isLoadingExport
});

const connector = connect(mapStateToProps, {
  fetchShortCodeExport,
  setSelectedShortCode
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ShortCodeHeader);
