// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import ShortCodeAddEditForm from "../ShortCodeAddEditForm";

describe("ShortCodeAddEditForm", () => {
  test("should render without crash", async () => {
    const { container } = renderWithAllWrappers(<ShortCodeAddEditForm />);

    expect(container).toBeInTheDocument();
  });
});
