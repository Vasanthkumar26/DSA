import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import ShortCode from "..";

describe("ShortCode", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<ShortCode />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
