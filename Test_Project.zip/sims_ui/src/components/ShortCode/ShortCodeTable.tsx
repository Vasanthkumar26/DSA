import React, { FC, useEffect, useMemo, useState } from "react";
import { Grid } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import {
  fetchShortCode,
  setSelectedShortCode,
  resetShortCodeErr
} from "../../redux/actions/shortCodeAction";
import { connect, ConnectedProps } from "react-redux";
import { ShortCode, HeadCell, TableConfig } from "../../models";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";

const headCells: Array<HeadCell> = [
  { id: "spid", label: "Service  Provider" },
  { id: "shortCode", label: "Short Code" }
];

const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
}

const tableConfig: TableConfig = {
  title: "Service Provider ShortCode Administration",
  orderBy: "lastUpdateDate",
  tableRowTestId: "shortCode-row"
};

const ShortCodeTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchShortCode,
  setSelectedShortCode,
  deleteSuccessMsgFlag,
  deleteSuccessMsg,
  shortCodes = [],
  resetShortCodeErr
}) => {
  const [spidFilter, setspidFilter] = useState("");
  const [shortCodeFilter, setShortCodeFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchShortCode(isArchivedVisible))();
  }, [fetchShortCode, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getArchivedFilter = (shortCode: ShortCode) => {
    if (archivedFilter === "Yes") {
      return !!shortCode.archived;
    }
    return archivedFilter === "No" ? !shortCode.archived : true;
  };

  let visibleMainranges = shortCodes?.filter(
    (shortCode) =>
      shortCode.spid.includes(spidFilter) &&
      shortCode.shortCode.includes(shortCodeFilter) &&
      getArchivedFilter(shortCode)
  );

  if (!isArchivedVisible) {
    visibleMainranges = visibleMainranges?.filter(
      (mainrange) => !mainrange.archived
    );
  }

  const filterHeadCellMap = {
    [headCells[0].id]: {
      filter: spidFilter,
      setFilter: setspidFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[1].id]: {
      filter: shortCodeFilter,
      setFilter: setShortCodeFilter,
      filterComponent: FilterSearchBar(t)
    },
    [archivedCell.id]: {
      filter: archivedFilter,
      setFilter: setArchivedFilter,
      filterComponent: FilterDropdown(archivedCell.values, t)
    }
  };

  const resetAllFilters = useMemo(() => {
    return () => {
      setspidFilter("");
      setShortCodeFilter("");
      setArchivedFilter("");
    };
  }, []);

  const handleRowSelected = async (row: any) => {
    setSelectedShortCode(row);
  };

  const handleRefresh = async () => {
    await fetchShortCode(isArchivedVisible);
    resetAllFilters();
  };

  const visibleHeadCells = [
    ...headCells,
    ...(isArchivedVisible ? [archivedCell] : [])
  ];

  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleMainranges]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
      <Grid item display={{ xs: "none", lg: "block" }}>
        <img
          src="/sidebarIcons/Mask_Group_hlr.jpg"
          alt="background"
          style={{
            objectFit: "cover",
            width: "300px",
            height: "100%",
            margin: "1px"
          }}
        />
      </Grid>
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.shortCode.isLoadingFetch,
  shortCodes: state.shortCode.shortCodes,
  deleteSuccessMsg: state.shortCode.deleteSuccessMsg,
  archiveSuccessMsg: state.shortCode.archiveSuccessMsg,
  deleteSuccessMsgFlag: state.shortCode.deleteSuccessMsgFlag
});

const connector = connect(mapStateToProps, {
  fetchShortCode,
  setSelectedShortCode,
  resetShortCodeErr
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ShortCodeTable);
