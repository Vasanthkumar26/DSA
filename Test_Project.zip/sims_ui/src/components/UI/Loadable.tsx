import { CircularProgress } from "@mui/material";
import React, { Suspense } from "react";

export const SuspenseLoader = () => (
  <div className="suspenseLoader">
    <CircularProgress size={64} disableShrink thickness={3} />
  </div>
);

const Loadable =
  (Component: React.LazyExoticComponent<React.FC>) => (props: any) =>
    (
      <Suspense fallback={<SuspenseLoader />}>
        <Component {...props} />
      </Suspense>
    );

export default Loadable;
