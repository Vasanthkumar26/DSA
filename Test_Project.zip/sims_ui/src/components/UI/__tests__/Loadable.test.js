import { render, screen, waitFor } from "@testing-library/react";
import "@testing-library/jest-dom";

import Loadable, { SuspenseLoader } from "../Loadable";

function MockedComponent() {
  return <div>mocked component</div>;
}

describe("Loadable", () => {
  test("should render without crash", async () => {
    const LoadableComp = Loadable(MockedComponent);
    render(<LoadableComp />);
    await waitFor(async () => {
      expect(screen.getByText(/mocked component/i)).toBeInTheDocument();
    });
  });
});

describe("SuspenseLoader", () => {
  test("should render without crash", async () => {
    const { container } = render(<SuspenseLoader />);
    expect(container).toBeInTheDocument();
  });
});
