import React, { FC, useEffect, useMemo, useState } from "react";
import { Grid } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import { fetchEmail, setSelectedEmail } from "../../redux/actions/emailAction";

import { connect, ConnectedProps } from "react-redux";
import { HeadCell, TableConfig } from "../../models";
import FilterSearchBar from "../common/FilterSearchBar";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";

const headCells: Array<HeadCell> = [
  { id: "eventname", label: "Action" },
  { id: "emailAddress", label: "Email-Address" },
  { id: "replyAddress", label: "Reply-Address" },
  { id: "subject", label: "Subject" }
];

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
}

const tableConfig: TableConfig = {
  title: "Email Administration",
  orderBy: "lastUpdateDate",
  tableRowTestId: "email-row"
};

const EmailTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchEmail,
  setSelectedEmail,
  emails = []
}) => {
  const [eventNameFilter, setEventNameFilter] = useState("");
  const [emailAddressFilter, setEmailAddressFilter] = useState("");
  const [replyAddressFilter, setReplyAddressFilter] = useState("");
  const [subjectFilter, setSubjectFilter] = useState("");
  const [textFilter, setTextFilter] = useState("");
  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchEmail(isArchivedVisible))();
  }, [fetchEmail, isArchivedVisible]);

  let visibleMainranges = emails?.filter(
    (email: any) =>
      email.eventname.includes(eventNameFilter) &&
      email.emailAddress.includes(emailAddressFilter) &&
      email.replyAddress.includes(replyAddressFilter) &&
      email.subject.includes(subjectFilter) &&
      email.text.includes(textFilter)
  );

  const filterHeadCellMap = {
    [headCells[0].id]: {
      filter: eventNameFilter,
      setFilter: setEventNameFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[1].id]: {
      filter: emailAddressFilter,
      setFilter: setEmailAddressFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[2].id]: {
      filter: replyAddressFilter,
      setFilter: setReplyAddressFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[3].id]: {
      filter: subjectFilter,
      setFilter: setSubjectFilter,
      filterComponent: FilterSearchBar(t)
    }
  };

  const resetAllFilters = useMemo(() => {
    return () => {
      setEventNameFilter("");
      setEmailAddressFilter("");
      setReplyAddressFilter("");
      setSubjectFilter("");
      setTextFilter("");
    };
  }, []);

  const handleRowSelected = async (row: any) => {
    setSelectedEmail(row);
  };

  const handleRefresh = async () => {
    await fetchEmail(isArchivedVisible);
    resetAllFilters();
  };

  const visibleHeadCells = [...headCells];

  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleMainranges]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
      <Grid item display={{ xs: "none", lg: "block" }}>
        <img
          src="/sidebarIcons/Mask_Group.jpg"
          alt="background"
          style={{
            objectFit: "cover",
            width: "200px",
            height: "100%",
            margin: "1px"
          }}
        />
      </Grid>
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.email.isLoadingFetch,
  emails: state.email.emails
});

const connector = connect(mapStateToProps, {
  fetchEmail,
  setSelectedEmail
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(EmailTable);
