import React, { FC, useState } from "react";
import { Box, Grid } from "@mui/material";
import EmailHeader from "./EmailHeader";
import EmailTable from "./EmailTable";
import EmailAddEditForm from "./EmailAddEditForm";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import { showFailureSnackbar } from "../../redux/actions/snackbarAction";

interface Props extends PropsFromRedux {}

const Email: FC<Props> = ({ selectedEmail, showFailureSnackbar }) => {
  const [isArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);

  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <EmailHeader isArchivedVisible={isArchivedVisible} />
          <EmailTable isArchivedVisible={isArchivedVisible} />
        </Grid>
        {(showForm || selectedEmail) && (
          <Grid item xs={12}>
            <EmailAddEditForm setShowForm={setShowForm} />
          </Grid>
        )}
      </Grid>
    </Box>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedEmail: state.email.selectedEmail
});

const connector = connect(mapStateToProps, {
  showFailureSnackbar
});
type PropsFromRedux = ConnectedProps<typeof connector>;
export default connector(Email);
