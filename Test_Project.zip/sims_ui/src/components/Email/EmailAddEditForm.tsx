import { Dispatch, FC, SetStateAction, useCallback, useEffect } from "react";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import { Grid } from "@mui/material";
import { useForm } from "react-hook-form";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import {
  createEmailPayload,
  EmailSchema,
  initData,
  setFormData
} from "./Email.data";
import { StyledFormBox } from "../common/styles/shared";
import {
  FormActionButtons,
  FormControllerTextField,
  LastUpdated
} from "../common/AddEditForm";
import {
  setSelectedEmail,
  updateEmail,
  resetEmail
} from "../../redux/actions/emailAction";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import { useTranslation } from "../../hooks/useTranslation";
import { resetPage } from "../../redux/actions/rootAction";

interface Props extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const EmailAddEditForm: FC<Props> = ({
  emNames,
  selectedEmail,
  isLoadingUpdate,
  errorUpdate,
  setShowForm,
  setSelectedEmail,
  updateEmail,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetEmail,
  resetPage
}) => {
  const t = useTranslation();
  const resolver = useYupValidationResolver(
    EmailSchema(t, [...(emNames ?? [])], !selectedEmail)
  );
  const { control, handleSubmit, reset } = useForm({
    mode: "all",
    resolver,
    defaultValues: { ...initData }
  });
  const { lastUpdateDate = "", id = 0 } = selectedEmail ?? {};

  useEffect(() => {
    selectedEmail ? reset(setFormData(selectedEmail)) : reset({ ...initData });
  }, [reset, selectedEmail]);

  useEffect(() => {
    if (errorUpdate) {
      showFailureSnackbar(errorUpdate || "");
    }
  }, [errorUpdate, showFailureSnackbar]);

  const handleReset = useCallback(() => {
    reset({ ...initData });
    setSelectedEmail(null);
    setShowForm(false);
  }, [reset, setSelectedEmail, setShowForm]);

  // const handleConfirmation = (flag: boolean): any => {
  //   setOpen(flag);
  // };

  const onSubmit = (data: any) => {
    const payload = createEmailPayload(data);
    if (selectedEmail) {
      updateEmail({ ...payload }, `${id}`);
    }
    resetEmail();
    resetPage();
  };

  return (
    <>
      <StyledFormBox component="form" onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={2}>
          <Grid item xs={8} sm={8} md={8}>
            <Grid container spacing={2}>
              <Grid item xs={6} sm={6} md={6}>
                <FormControllerTextField
                  control={control}
                  controlName="eventname"
                  inputLabel="Action"
                  required
                  inputProps={{ maxLength: 50 }}
                  disabled
                />
              </Grid>
              <Grid item xs={6} sm={6} md={6}>
                <FormControllerTextField
                  control={control}
                  controlName="emailAddress"
                  inputLabel="Email-Address"
                  required
                />
              </Grid>
              <Grid item xs={6} sm={6} md={6}>
                <FormControllerTextField
                  control={control}
                  controlName="replyAddress"
                  inputLabel="Reply-Address"
                  required
                />
              </Grid>
              <Grid item xs={6} sm={6} md={6}>
                <FormControllerTextField
                  control={control}
                  controlName="subject"
                  inputLabel="Subject"
                  required
                  inputProps={{ maxLength: 200 }}
                />
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={4} sm={4} md={4}>
            <Grid container spacing={2}>
              <Grid item xs={12} sm={12} md={12}>
                <FormControllerTextField
                  control={control}
                  controlName="text"
                  inputLabel="Text"
                  multiline
                  rows={4.4}
                  inputProps={{ maxLength: 4000 }}
                />
              </Grid>
            </Grid>
          </Grid>
          {lastUpdateDate && (
            <Grid item xs={12}>
              <LastUpdated lastUpdatedDate={lastUpdateDate} />
            </Grid>
          )}
          <Grid item xs={12}>
            <FormActionButtons
              onCancel={handleReset}
              onDelete={() => void {}}
              selectedData={selectedEmail}
              submitDisabled={isLoadingUpdate}
              cancelDisabled={isLoadingUpdate}
            />
          </Grid>
        </Grid>
      </StyledFormBox>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  emNames: state.email.emNames,
  selectedEmail: state.email.selectedEmail,
  isLoadingUpdate: state.email.isLoadingUpdate,
  errorUpdate: state.email.errorUpdate
});

const connector = connect(mapStateToProps, {
  updateEmail,
  setSelectedEmail,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetEmail,
  resetPage
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(EmailAddEditForm);
