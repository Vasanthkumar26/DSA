import { FC, useCallback } from "react";
import { ConnectedProps, connect } from "react-redux";
import TableHeader from "../common/TableHeader";
import { RootState } from "../../redux/store";
import { fetchEmailExport } from "../../redux/actions/emailAction";
import { useTranslation } from "../../hooks/useTranslation";
interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
}

const EmailHeader: FC<Props> = ({
  isLoadingExport,
  fetchEmailExport,
  isArchivedVisible
}) => {
  const t = useTranslation();

  const handleExport = useCallback(() => {
    fetchEmailExport(isArchivedVisible);
  }, [fetchEmailExport, isArchivedVisible]);

  return (
    <TableHeader
      title={t("Email Administration")}
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={() => void {}}
      handleExport={handleExport}
      handleAdd={() => void {}}
      noShowArchive={true}
      noShowAdd={true}
      showPreview={false}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.email.isLoadingExport
});

const connector = connect(mapStateToProps, {
  fetchEmailExport
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(EmailHeader);
