// @ts-nocheck
import { renderWithAllWrappers } from "../../../utils/testUtils";
import "@testing-library/jest-dom";
import { screen, waitFor } from "@testing-library/react";
import EmailTable from "../EmailTable";

describe("EmailTable", () => {
  test("should render without crash", () => {
    const setShowForm = jest.fn();
    const { container } = renderWithAllWrappers(
      <EmailTable isArchivedVisible={false} setShowForm={setShowForm} />
    );
    expect(container).toBeInTheDocument();
  });

  describe("API Failure", () => {
    test("Table should show correct data when server down", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <EmailTable isArchivedVisible={false} setShowForm={setShowForm} />
      );
      await waitFor(async () => {
        const emailRows = screen.queryAllByTestId(/email-row/i);
        expect(emailRows).toHaveLength(0);
      });
    });
  });
});
