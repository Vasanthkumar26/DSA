import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import Email from "..";

describe("Email", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<Email />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
