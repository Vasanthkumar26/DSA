// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import EmailAddEditForm from "../EmailAddEditForm";

describe("EmailAddEditForm", () => {
  test("should render without crash", async () => {
    const { container } = renderWithAllWrappers(<EmailAddEditForm />);

    expect(container).toBeInTheDocument();
  });
});
