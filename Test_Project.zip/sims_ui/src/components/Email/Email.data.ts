import * as yup from "yup";
import { Email, EmailPayload } from "../../models/email.model";

export const initData = {
  eventname: "",
  emailAddress: "",
  replyAddress: "",
  subject: "",
  text: ""
};

export const setFormData = (data: Email): EmailPayload => ({
  eventname: data?.eventname ?? "",
  emailAddress: data?.emailAddress ?? "",
  replyAddress: data?.replyAddress ?? "",
  subject: data?.subject ?? "",
  text: data?.text ?? ""
});

export const EmailSchema = (
  t: (key: string | undefined) => string,
  emNames: string[],
  isCreate: boolean
) =>
  yup.object().shape({
    eventname: yup.string().required("action_is_missing"),
    emailAddress: yup
      .string()
      .trim()
      .test("Valid Email", "", function (value) {
        if (value) {
          yup.object().shape({
            emails: yup
              .string()
              .required("es_please_provide_a_valid_email_address")
          });
          const emailSchema = yup.array().of(yup.string().email());
          const emails = value.split(",").map((email) => email.trim());
          if (!emailSchema.isValidSync(emails)) {
            return this.createError({
              message: `es_please_provide_a_valid_email_address`
            });
          }
        } else {
          return this.createError({
            message: `es_please_provide_a_valid_email_address`
          });
        }
        return true;
      }),
    replyAddress: yup
      .string()
      .trim()
      .test("Valid Email", "", function (value) {
        if (value) {
          yup.object().shape({
            emails: yup
              .string()
              .required("es_please_provide_a_valid_reply_address")
          });
          const emailSchema = yup.array().of(yup.string().email());
          const emails = value.split(",").map((email) => email.trim());
          if (!emailSchema.isValidSync(emails)) {
            return this.createError({
              message: `es_please_provide_a_valid_reply_address`
            });
          }
        } else {
          return this.createError({
            message: `es_please_provide_a_valid_reply_address`
          });
        }
        return true;
      }),
    subject: yup
      .string()
      .required(t("es_subject_is_missing"))
      .max(199, t("max_200_character")),
    text: yup.string().max(3999, t("max_4000_character"))
  });

export const createEmailPayload = (data: any) =>
  ({
    eventname: data?.eventname ?? "",
    emailAddress: data?.emailAddress ?? "",
    replyAddress: data?.replyAddress ?? "",
    subject: data?.subject ?? "",
    text: data?.text ?? ""
  } as EmailPayload);
