import { Grid } from "@mui/material";
import { TableConfig } from "../../models";
import {
  Dispatch,
  FC,
  SetStateAction,
  useEffect,
  useMemo,
  useState
} from "react";
import TableView from "../common/TableView";
import { headCells, archivedCell } from "./SimArticle.data";
import { connect, ConnectedProps } from "react-redux";
import { RootState } from "../../redux/store";

import {
  fetchSimArticles,
  setSelectedSimArticle
} from "../../redux/actions/simArticleAction";
import { useTranslation } from "../../hooks/useTranslation";
import { SimArticles } from "../../models/simArticle.model";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const tableConfig: TableConfig = {
  title: "Sim Article",
  orderBy: "lastUpdateDate",
  tableRowTestId: "simArticle-row"
};

const SimArticleTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  simArticles,
  fetchSimArticles,
  setSelectedSimArticle,
  setShowForm
}) => {
  const [articleNumFilter, setArticleNumFilter] = useState("");
  const [serviceProviderFilter, setServiceProviderFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [deliveryAddFilter, setDeliveryAddFilter] = useState("");
  const [productTypeFilter, setProductTypeFilter] = useState("");
  const [simManufacturerFilter, setSimManufacturerFilter] = useState("");
  const [electricalProfilesFilter, setElectricalProfilesFilter] = useState("");
  const [customProfileFilter, setCustomProfileFilter] = useState("");
  const [formFactorFilter, setFormFactorFilter] = useState("");
  const [articleDescFilter, setArticleDescFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");

  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchSimArticles(isArchivedVisible))();
  }, [fetchSimArticles, isArchivedVisible]);

  const getArchivedFilter = (simArticle: SimArticles) => {
    if (archivedFilter === "Yes") {
      return !!simArticle.archived;
    }
    return archivedFilter === "No" ? !simArticle.archived : true;
  };

  const visibleHeadCells = [
    ...headCells,
    ...(isArchivedVisible ? [archivedCell] : [])
  ];

  let visibleSimArticles = simArticles?.filter(
    (simArticles) =>
      simArticles?.name?.includes(articleNumFilter) &&
      simArticles?.serviceProviderId
        .toString()
        ?.includes(serviceProviderFilter) &&
      simArticles?.articleStatusName?.includes(statusFilter) &&
      simArticles?.deliveryAddressId.toString()?.includes(deliveryAddFilter) &&
      simArticles?.productTypeId.toString()?.includes(productTypeFilter) &&
      simArticles?.cardTypeId.toString()?.includes(productTypeFilter) &&
      simArticles?.simVendorId.toString()?.includes(electricalProfilesFilter) &&
      simArticles?.electricalProfileId
        .toString()
        ?.includes(simManufacturerFilter) &&
      simArticles?.customProfileId.toString()?.includes(customProfileFilter) &&
      simArticles?.formFactorId.toString()?.includes(formFactorFilter) &&
      simArticles?.description?.includes(articleDescFilter) &&
      getArchivedFilter(simArticles)
  );

  const filterHeadCellMap = {
    [headCells[0].id]: {
      filter: articleNumFilter,
      setFilter: setArticleNumFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[1].id]: {
      filter: serviceProviderFilter,
      setFilter: setServiceProviderFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[2].id]: {
      filter: statusFilter,
      setFilter: setStatusFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[3].id]: {
      filter: deliveryAddFilter,
      setFilter: setDeliveryAddFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[4].id]: {
      filter: productTypeFilter,
      setFilter: setProductTypeFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[5].id]: {
      filter: electricalProfilesFilter,
      setFilter: setElectricalProfilesFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[6].id]: {
      filter: simManufacturerFilter,
      setFilter: setSimManufacturerFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[7].id]: {
      filter: customProfileFilter,
      setFilter: setCustomProfileFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[8].id]: {
      filter: formFactorFilter,
      setFilter: setFormFactorFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[9].id]: {
      filter: articleDescFilter,
      setFilter: setArticleDescFilter,
      filterComponent: FilterSearchBar(t)
    },
    [archivedCell.id]: {
      filter: archivedFilter,
      setFilter: setArchivedFilter,
      filterComponent: FilterDropdown(archivedCell.values, t)
    }
  };

  const resetAllFilters = useMemo(() => {
    return () => {
      setArticleNumFilter("");
      setServiceProviderFilter("");
      setStatusFilter("");
      setDeliveryAddFilter("");
      setProductTypeFilter("");
      setElectricalProfilesFilter("");
      setSimManufacturerFilter("");
      setCustomProfileFilter("");
      setFormFactorFilter("");
      setArticleDescFilter("");
      setArchivedFilter("");
    };
  }, []);

  const handleRefresh = async () => {
    await fetchSimArticles(isArchivedVisible);
    resetAllFilters();
  };

  const handleRowSelected = (row: any) => {
    setSelectedSimArticle(null);

    setSelectedSimArticle(row);
    setShowForm(true);
  };
  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleSimArticles]}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
        handleRowSelected={handleRowSelected}
      />
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.simArticle.isLoadingFetch,
  simArticles: state.simArticle.simArticles
});

const connector = connect(mapStateToProps, {
  fetchSimArticles,
  setSelectedSimArticle
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(SimArticleTable);
