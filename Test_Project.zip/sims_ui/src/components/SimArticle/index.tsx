import { Box, Grid } from "@mui/material";
import { FC, useEffect, useState } from "react";
import SimArticleTable from "./SimArticleTable";
import SimArticleHeader from "./SimArticleHeader";
import SimArticleForm from "./SimArticleForm";
import { SimArticleDropdownValue } from "../../models/simArticle.model";
import { handleFetchLoadSimArticleDropdown } from "../../services/simArticleApi";
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";
import { filterArchivedData } from "./SimArticle.data";

const SimArticle: FC = () => {
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [simArticleDropdownValues, setSimArticleDropdownValues] =
    useState<SimArticleDropdownValue>();
  const selectedSimArticle = useSelector(
    (state: RootState) => state.simArticle.selectedSimArticle
  );

  useEffect(() => {
    handleFetchLoadSimArticleDropdown()
      .then((res) => {
        if (selectedSimArticle !== null) {
          const data = filterArchivedData(res, true);
          setSimArticleDropdownValues(data);
        } else {
          const data = filterArchivedData(res, false);
          setSimArticleDropdownValues(data);
        }
      })
      .catch((err) => {
        setSimArticleDropdownValues(undefined);
      });
  }, [selectedSimArticle]);

  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <SimArticleHeader
            isArchivedVisible={isArchivedVisible}
            setIsArchivedVisible={setIsArchivedVisible}
            setShowForm={setShowForm}
          />
          <SimArticleTable
            setShowForm={setShowForm}
            isArchivedVisible={isArchivedVisible}
          />

          {showForm && (
            <SimArticleForm
              setShowForm={setShowForm}
              dropdownValue={
                simArticleDropdownValues as SimArticleDropdownValue
              }
            />
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default SimArticle;
