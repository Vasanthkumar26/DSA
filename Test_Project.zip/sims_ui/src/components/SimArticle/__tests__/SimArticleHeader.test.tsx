import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import { screen, fireEvent, render } from "@testing-library/react";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { Store, AnyAction } from "redux";
import { fetchSimArticleExport } from "../../../redux/actions/simArticleAction";
import { SimArticleActionTypes } from "../../../redux/actions/types";
import SimArticleHeader from "../SimArticleHeader";

const mockStore = configureStore([thunk]);

jest.mock("../../../redux/actions/simArticleAction", () => ({
  fetchSimArticleExport: jest.fn()
}));

describe("header test", () => {
  let store: Store<unknown, AnyAction>;
  beforeEach(() => {
    store = mockStore({
      simArticle: {
        simArticle: ["a", "b"]
      },
      lang: {
        language: "en"
      }
    });
  });
  test("should load component without failed", () => {
    const { container } = renderWithAllWrappers(
      <SimArticleHeader
        isArchivedVisible={false}
        setIsArchivedVisible={jest.fn()}
        setShowForm={jest.fn()}
      />
    );
    expect(container).toBeInTheDocument();
  });

  test("should render the export button", () => {
    renderWithAllWrappers(
      <SimArticleHeader
        isArchivedVisible={false}
        setIsArchivedVisible={jest.fn()}
        setShowForm={jest.fn()}
      />
    );

    expect(screen.getByText(/Export/i)).toBeInTheDocument();
  });

  test("should call the handleExport on button click", async () => {
    // @ts-ignore: Unreachable code error
    fetchSimArticleExport.mockImplementation(() => {
      return {
        type: SimArticleActionTypes.FETCH_SIM_ARTICLE_EXPORT_SUCCESS,
        payload: { message: "successfull" }
      };
    });

    render(
      <Provider store={store}>
        <SimArticleHeader
          isArchivedVisible={false}
          setIsArchivedVisible={jest.fn()}
          setShowForm={jest.fn()}
        />
      </Provider>
    );

    const button = screen.getByRole("export-button");
    await fireEvent.click(button);
    expect(fetchSimArticleExport).toHaveBeenCalled();
  });
});
