import { FC } from "react";
import { useTranslation } from "../../hooks/useTranslation";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle
} from "@mui/material";

interface Props {
  handleClose: () => void;
  open: boolean;
  htmlElement: any;
}

export const InputFileDialog: FC<Props> = ({
  handleClose,
  open,
  htmlElement
}) => {
  const t = useTranslation();
  return (
    <Dialog
      PaperProps={{
        sx: {
          width: "100%",
          paddingBottom: 0
        }
      }}
      open={open}
      onClose={() => {
        handleClose();
      }}
    >
      <DialogTitle>{t("Show input file")}</DialogTitle>
      <DialogContent>
        <DialogContentText>
          {" "}
          <div
            style={{ backgroundColor: "#F3F4FF", padding: "10px" }}
            dangerouslySetInnerHTML={{ __html: htmlElement }}
          />
        </DialogContentText>
      </DialogContent>
      <DialogActions>
        <Button size="small" onClick={handleClose} variant="contained">
          OK
        </Button>
      </DialogActions>
    </Dialog>
  );
};
