import { HeadCell } from "../../models";
import * as yup from "yup";
import {
  ISelectArchive,
  SimArticleDropdownValue
} from "../../models/simArticle.model";
export const headCells: Array<HeadCell> = [
  { id: "articleId", label: "Article_number" },
  { id: "deliveryAddressId", label: "Delivery_address" },
  { id: "productTypeId", label: "Product_type" },
  { id: "cardTypeId", label: "Card_type" },
  { id: "simVendorId", label: "Sim_manufacturer" },
  { id: "electricalProfileId", label: "Electrical_profiles" },
  { id: "formFactorId", label: "Form_factor" },
  { id: "description", label: "Article_description" },
  { id: "serviceProviderId", label: "service_provider" },
  { id: "articleStatusName", label: "status" },
  { id: "customProfileId", label: "Custom_profile" }
];

//In case of update we have to show archive=true and false data
export function filterArchivedData(
  obj: SimArticleDropdownValue,
  isArchive: boolean
): SimArticleDropdownValue {
  const filteredObj: SimArticleDropdownValue = {} as SimArticleDropdownValue; // Create a new object
  for (const key in obj) {
    if (isArchive) {
      filteredObj[key] = obj[key].map((item: ISelectArchive) => {
        if (item?.archive === true) {
          return { ...item, label: `${item.label} [Archiviert]` };
        }
        if (item.archive === undefined) {
          return item;
        }
        return item;
      });
    } else {
      filteredObj[key] = obj[key].filter(
        (item: ISelectArchive) =>
          item.archive === false || item.archive === undefined
      );
    }
  }
  return filteredObj;
}

export const init = {
  name: "",
  cardsPerFile: 10000,
  defwert: null,
  chipType: "",
  description: "",
  cardTypeId: null,
  serviceProviderId: null,
  electricalProfileId: null,
  simVendorId: null,
  customProfileId: null,
  formFactorId: null,
  productTypeId: null,
  comment: "",
  deliveryAddressId: null,
  smDpHostId: { label: "Physical SIM - no SMDP host", id: 0 },
  starterPackId: null,
  starterPackName: "",
  articleId: null,
  starterPackReq: false,
  userName: 1,
  aritcleStatusId: { label: "Neu", id: 7 },
  additionalInputFile: null
};

export const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};

export const simArticlSchema = yup.object().shape({
  articleId: yup
    .number()
    .required("articleId is required")
    .typeError("articleId must be number"),
  serviceProviderId: yup
    .object()
    .shape({
      label: yup.string().required(),
      id: yup.number().required()
    })
    .typeError("Service Provider is missing")
    .required("Service Provider is missing"),
  deliveryAddressId: yup
    .object()
    .shape({
      label: yup.string().required(),
      id: yup.number().required()
    })
    .typeError("Delivery Address is missing")
    .required("Delivery Address is missing"),
  customProfileId: yup
    .object()
    .shape({
      label: yup.string().required(),
      id: yup.number().required()
    })
    .typeError("Custom Profile is missing")
    .required("Custom Profile is missing"),
  productTypeId: yup
    .object()
    .shape({
      label: yup.string().required(),
      id: yup.number().required(),
      serviceProviderShortCodeId: yup.number().required()
    })
    .typeError("Product type is missing")
    .required("Product type is missing"),
  smDpHostId: yup
    .object()
    .shape({
      label: yup.string().required(),
      id: yup.number().required()
    })
    .typeError("eSIM SMDP Host is missing")
    .required("eSIM SMDP Host is missing"),
  cardTypeId: yup
    .object()
    .shape({
      label: yup.string().required(),
      id: yup.number().required()
    })
    .typeError("Card type is missing")
    .required("Card type is missing"),
  simVendorId: yup
    .object()
    .shape({
      label: yup.string().required(),
      id: yup.number().required(),
      cartTypeId: yup.number().required()
    })
    .typeError("SIM-Manufacturer is missing")
    .required("SIM-Manufacturer is missing"),
  formFactorId: yup
    .object()
    .shape({
      label: yup.string().required(),
      id: yup.number().required()
    })
    .typeError("Form Factor is missing")
    .required("Form Factor is missing"),
  cardsPerFile: yup
    .number()
    .required("")
    .typeError("Cards_per_file_must_be_a_positive_integer")
    .max(10000, "Cards_per_file_can_be_a_maximum_of_10000"),
  starterPackId: yup
    .object()
    .shape({
      label: yup.string().required(),
      id: yup.number().required(),
      spId: yup.number().required()
    })
    .typeError("")
    .when("starterPackReq", {
      is: (v: any) => v === true,
      then: (schema) => schema.required("Starter pack is missing")
    }),
  description: yup.string().max(1024, "Maximum 1024 character is expected")
});

export const setFormData = (data: any, dropDownValues: any) => ({
  name: data?.name ?? init.name,
  cardsPerFile: data?.cardPerFile ?? init.cardsPerFile,
  defwert: data?.defwert ?? init.defwert,
  chipType: data?.chipType ?? init.chipType,
  description: data?.description ?? init.description,
  cardTypeId:
    dropDownValues?.allCardType?.find(
      (item: any) => item?.id === data?.cardTypeId
    ) ?? init.cardTypeId,
  serviceProviderId:
    dropDownValues?.allServiceProviderDetails?.find(
      (item: any) => item?.id === data?.serviceProviderId
    ) ?? init.serviceProviderId,
  electricalProfileId:
    dropDownValues?.allElectricalProfile?.find(
      (item: any) => item?.id === data?.electricalProfileId
    ) ?? init.electricalProfileId,
  simVendorId:
    dropDownValues?.allSimVendor?.find(
      (item: any) => item?.id === data?.simVendorId
    ) ?? init.simVendorId,
  customProfileId:
    dropDownValues?.allCustomProfile?.find(
      (item: any) => item?.id === data?.customProfileId
    ) ?? init.customProfileId,
  formFactorId:
    dropDownValues?.allFormFactor?.find(
      (item: any) => item?.id === data?.formFactorId
    ) ?? init.formFactorId,
  productTypeId:
    dropDownValues?.allProductType?.find(
      (item: any) => item?.id === data?.productTypeId
    ) ?? init.productTypeId,
  comment: data?.comment ?? init.comment,
  deliveryAddressId:
    dropDownValues?.allDeliveryAddress?.find(
      (item: any) => item?.id === data?.deliveryAddressId
    ) ?? init.deliveryAddressId,
  smDpHostId:
    dropDownValues?.allSmdpHost?.find(
      (item: any) => item?.id === data?.smDpHostId
    ) ?? init.smDpHostId,
  starterPackId:
    dropDownValues?.allStarterPack?.find(
      (item: any) => item?.id === data?.starterPackId
    ) ?? init.starterPackId,
  starterPackName: data?.starterPackName ?? init.starterPackName,
  articleId: data?.articleId ?? init.articleId,
  starterPackReq: data?.starterPackReq ?? init.starterPackReq,
  userName: 1,
  aritcleStatusId:
    dropDownValues?.allSimArticleStatus?.find(
      (item: any) => item?.id === data?.aritcleStatusId
    ) ?? init.aritcleStatusId,
  additionalInputFile:
    dropDownValues?.allDeliveryAddressOutputFile?.find(
      (item: any) => item?.id === data?.additionalInputFile
    ) ?? init.additionalInputFile
});

export const CreateUpdatePayload = (data: any) => ({
  name: "",
  cardsPerFile: data?.cardsPerFile,
  defwert: 11,
  chipType: data?.chipType,
  description: data?.description,
  cardTypeId: data?.cardTypeId?.id,
  serviceProviderId: data?.serviceProviderId?.id,
  electricalProfileId: data?.electricalProfileId?.id,
  simVendorId: data?.simVendorId?.id,
  customProfileId: data?.customProfileId?.id,
  formFactorId: data?.formFactorId?.id,
  productTypeId: data?.productTypeId?.id,
  comment: data?.comment,
  deliveryAddressId: data?.deliveryAddressId?.id,
  smDpHostId: data?.smDpHostId?.id === 0 ? null : data?.smDpHostId?.id,
  starterPackId: data?.starterPackId?.id,
  starterPackName: data?.starterPackId?.name,
  articleId: data?.articleId,
  starterPackReq: data?.starterPackReq,
  userName: 1,
  additionalInputFile: data?.additionalInputFile
});
