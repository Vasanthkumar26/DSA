import {
  Box,
  Button,
  Checkbox,
  FormControlLabel,
  Grid,
  Stack
} from "@mui/material";
import { FC, SetStateAction, Dispatch, useEffect, useState } from "react";
import { StyledFormBox } from "../common/styles/shared";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import { useForm, Controller } from "react-hook-form";
import { FormControllerTextField, LastUpdated } from "../common/AddEditForm";
import {
  ICPOrEP,
  IProductTypes,
  ISimVendors,
  IStarterPack,
  SimArticleDropdownValue
} from "../../models/simArticle.model";
import { useTranslation } from "../../hooks/useTranslation";
import {
  CreateUpdatePayload,
  init,
  setFormData,
  simArticlSchema
} from "./SimArticle.data";
import {
  createSimArticle,
  resetSimArticle,
  setSelectedSimArticle,
  updateSimArticle,
  deleteSimArticle,
  archiveSimArticle
} from "../../redux/actions/simArticleAction";
import { InputFileDialog } from "./InputFileDialog";
import { handleInputFile } from "../../services/simArticleApi";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";

import { resetPage } from "../../redux/actions/rootAction";

import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import DeleteModal from "../common/modals/DeleteModal";
interface Props extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
  dropdownValue: SimArticleDropdownValue;
}

const SimArticleForm: FC<Props> = ({
  setShowForm,
  dropdownValue,
  selectedSimArticle,
  setSelectedSimArticle,
  createSimArticle,
  updateSimArticle,
  isLoading,
  successMessage,
  showSuccessSnackbar,
  resetPage,
  resetSimArticle,
  archiveSimArticle,
  deleteSimArticle
}) => {
  const [openInputFile, setOpenInputFile] = useState(false);
  const [html, setHtml] = useState();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [productTypeDropdownValue, setProductTypeDropDownValue] = useState<
    IProductTypes[]
  >([]);
  const [simVendorDropdownValue, setSimVendorDropDownValue] = useState<
    ISimVendors[]
  >([]);
  const [customProfileDrowpdownValue, setCustomProfileDropDownValue] = useState<
    ICPOrEP[]
  >([]);
  const [StarterPackDropDownValue, setStarterPackDropDownValue] = useState<
    IStarterPack[]
  >([]);
  const [ElectricalProfileDropDownValue, setElectricalProfileDropDownValue] =
    useState<ICPOrEP[]>([]);

  const resolver = useYupValidationResolver(simArticlSchema);
  const { control, reset, setValue, watch, handleSubmit, formState } = useForm({
    mode: "onChange",
    resolver,
    reValidateMode: "onChange",
    defaultValues: { ...init }
  });

  const t = useTranslation();

  useEffect(() => {
    selectedSimArticle
      ? reset(setFormData(selectedSimArticle, dropdownValue))
      : reset({ ...init });
  }, [dropdownValue, reset, selectedSimArticle]);

  const selectedserviceProvider = watch("serviceProviderId");
  const selectedCartType = watch("cardTypeId");
  const selectedSimVendor = watch("simVendorId");
  const isstarterPackReq = watch("starterPackReq");

  useEffect(() => {
    if (!isLoading) {
      if (successMessage) {
        showSuccessSnackbar(successMessage);
        resetSimArticle();
        resetPage();
      }
    }
  }, [
    isLoading,
    resetPage,
    resetSimArticle,
    showSuccessSnackbar,
    successMessage
  ]);

  useEffect(() => {
    setProductTypeDropDownValue([]);
    if (selectedserviceProvider !== null) {
      setValue("productTypeId", null);
      setValue("starterPackId", null);
      const productTypes = dropdownValue?.allProductType?.filter(
        (item: IProductTypes) =>
          // @ts-ignore: Unreachable code error
          item?.serviceProviderShortCodeId === selectedserviceProvider?.id
      );
      if (productTypes) {
        setProductTypeDropDownValue(productTypes);
      } else {
        setValue("productTypeId", null);
      }
    } else {
      setValue("productTypeId", null);
    }
  }, [
    dropdownValue?.allProductType,
    selectedserviceProvider,
    setValue,
    selectedSimArticle
  ]);

  useEffect(() => {
    setStarterPackDropDownValue([]);
    if (isstarterPackReq === true && selectedserviceProvider !== null) {
      const starterPack = dropdownValue?.allStarterPack?.filter(
        (item: IStarterPack) =>
          // @ts-ignore: Unreachable code error
          item.spId === selectedserviceProvider?.id
      );
      if (starterPack) {
        setStarterPackDropDownValue(starterPack);
      } else {
        setValue("starterPackId", null);
      }
    } else {
      setValue("starterPackId", null);
    }
  }, [
    dropdownValue?.allStarterPack,
    isstarterPackReq,
    selectedserviceProvider,
    setValue
  ]);

  useEffect(() => {
    setSimVendorDropDownValue([]);
    if (selectedCartType !== null) {
      setValue("simVendorId", null);
      const simVendors = dropdownValue?.allSimVendor?.filter(
        // @ts-ignore: Unreachable code error
        (item: ISimVendors) => item?.cartTypeId === selectedCartType?.id
      );
      if (simVendors) {
        setSimVendorDropDownValue(simVendors);
      } else {
        setValue("simVendorId", null);
      }
    } else {
      setValue("simVendorId", null);
    }
  }, [dropdownValue?.allSimVendor, selectedCartType, setValue]);

  useEffect(() => {
    setCustomProfileDropDownValue([]);
    setElectricalProfileDropDownValue([]);
    if (selectedSimVendor !== null) {
      setValue("customProfileId", null);
      setValue("electricalProfileId", null);
      const customProfiles = dropdownValue?.allCustomProfile?.filter(
        // @ts-ignore: Unreachable code error
        (item: ICPOrEP) => item?.simVendorId === selectedSimVendor?.id
      );
      if (customProfiles) {
        setCustomProfileDropDownValue(customProfiles);
      } else {
        setValue("customProfileId", null);
      }
      const eps = dropdownValue?.allElectricalProfile?.filter(
        (item: ICPOrEP) => item?.simVendorId === selectedSimVendor?.id
      );
      if (eps) {
        setElectricalProfileDropDownValue(eps);
      } else {
        setValue("electricalProfileId", null);
      }
    } else {
      setValue("customProfileId", null);
      setValue("electricalProfileId", null);
      //   setElectricalProfileDropDownValue(dropdownValue?.allElectricalProfile);
    }
  }, [
    selectedSimVendor,
    selectedCartType,
    setValue,
    dropdownValue?.allCustomProfile,
    dropdownValue?.allElectricalProfile
  ]);

  const {
    productTypeId,
    starterPackId,
    customProfileId,
    simVendorId,
    additionalInputFile
  } = selectedSimArticle ?? {};

  const handleClose = () => {
    setOpenInputFile(!openInputFile);
  };

  const downloadInputFile = async (id: number) => {
    try {
      const res = await handleInputFile(id);
      if (res) {
        setOpenInputFile(true);
        setHtml(res);
      }
    } catch (error) {
      setOpenInputFile(false);
      setHtml(undefined);
    }
  };
  const handleCancle = () => {
    setSelectedSimArticle(null);
    reset(init);
    setShowForm(false);
    resetPage();
  };

  const onSubmit = (data: any) => {
    const payload = CreateUpdatePayload(data);
    if (selectedSimArticle) {
      updateSimArticle(selectedSimArticle?.id, payload);
    } else {
      createSimArticle(payload);
    }
  };

  const handleArchive = () => {
    if (selectedSimArticle) {
      const { id, archived, name } = selectedSimArticle;
      archiveSimArticle(id, archived, name)
        .then(() => {
          showSuccessSnackbar(
            !selectedSimArticle?.archived
              ? t("successfully_archived")
              : t("successfully_activated")
          );
          handleCancle();
        })
        .catch(() => {
          showFailureSnackbar(`${t("Archiving_failed")} ${name}`);
          handleCancle();
        });
    }
  };

  const handleDelete = () => {
    setIsModalOpen(false);
    deleteSimArticle(selectedSimArticle?.id ?? 0)
      .then(() => showSuccessSnackbar(t("successfully_deleted")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => setShowForm(false));
  };

  return (
    <>
      <DeleteModal
        isOpen={isModalOpen}
        handleConfirm={handleDelete}
        handleCancel={() => setIsModalOpen(false)}
      />
      <InputFileDialog
        open={openInputFile}
        handleClose={handleClose}
        htmlElement={html}
      />
      <Box component="form" onSubmit={handleSubmit(onSubmit)}>
        <StyledFormBox component="form" onSubmit={handleSubmit(onSubmit)}>
          <Grid container spacing={2}>
            <Grid item xs={8} sm={8} md={8}>
              <Grid container spacing={2}>
                <Grid item xs={6} sm={6} md={6}>
                  <FormControllerTextField
                    inputLabel="ArticleNumber"
                    controlName="articleId"
                    required
                    control={control}
                    disabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={6} sm={6} md={6}>
                  <FormControllerSelectWithSearch
                    options={dropdownValue?.allServiceProviderDetails ?? []}
                    required
                    inputLabel="serv_provider"
                    controlName="serviceProviderId"
                    control={control}
                    isDisabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={6} sm={6} md={6}>
                  <FormControllerSelectWithSearch
                    options={productTypeDropdownValue ?? []}
                    required
                    inputLabel="Product types"
                    controlName="productTypeId"
                    control={control}
                    id={productTypeId}
                    setValue={setValue}
                    isDisabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={6} sm={6} md={6}>
                  <FormControllerTextField
                    required
                    control={control}
                    controlName="cardsPerFile"
                    inputLabel="Cards_per_file"
                    disabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={6} sm={6} md={6}>
                  <FormControllerSelectWithSearch
                    options={dropdownValue?.allCardType ?? []}
                    required
                    inputLabel="card_type"
                    controlName="cardTypeId"
                    control={control}
                    isDisabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={6} sm={6} md={6}>
                  <FormControllerSelectWithSearch
                    options={simVendorDropdownValue ?? []}
                    required
                    inputLabel="SIM-Manufacturer"
                    controlName="simVendorId"
                    control={control}
                    setValue={setValue}
                    id={simVendorId}
                    isDisabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={6} sm={6} md={6}>
                  <FormControllerSelectWithSearch
                    options={dropdownValue?.allSmdpHost ?? []}
                    required
                    inputLabel="eSIM SMDP Host"
                    controlName="smDpHostId"
                    control={control}
                    isDisabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={6} sm={6} md={6}>
                  <FormControllerSelectWithSearch
                    options={dropdownValue?.allDeliveryAddress ?? []}
                    required
                    inputLabel="Delivery Addresses"
                    controlName="deliveryAddressId"
                    control={control}
                    isDisabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={6} sm={6} md={6}>
                  <FormControllerSelectWithSearch
                    options={ElectricalProfileDropDownValue ?? []}
                    inputLabel="Electrical profile"
                    controlName="electricalProfileId"
                    control={control}
                    isDisabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={6} sm={6} md={6}>
                  <FormControllerSelectWithSearch
                    options={customProfileDrowpdownValue ?? []}
                    required
                    inputLabel="Custom profile"
                    controlName="customProfileId"
                    control={control}
                    setValue={setValue}
                    id={customProfileId}
                    isDisabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={6} sm={6} md={6}>
                  <FormControllerSelectWithSearch
                    options={dropdownValue?.allSimArticleStatus ?? []}
                    required
                    isDisabled
                    inputLabel="Status"
                    controlName="aritcleStatusId"
                    control={control}
                  />
                </Grid>
                <Grid item xs={6} sm={6} md={6}>
                  <Controller
                    control={control}
                    name="starterPackReq"
                    defaultValue={false}
                    render={({ field: { onChange, value } }) => (
                      <FormControlLabel
                        disabled={selectedSimArticle?.aritcleStatusId === 4}
                        control={
                          <Checkbox checked={value} onChange={onChange} />
                        }
                        label={t("Starter pack product required")}
                        labelPlacement="start"
                        sx={{ mt: -3, ml: 0 }}
                      />
                    )}
                  />
                  {isstarterPackReq === true && (
                    <FormControllerSelectWithSearch
                      options={StarterPackDropDownValue ?? []}
                      controlName="starterPackId"
                      control={control}
                      setValue={setValue}
                      id={starterPackId}
                      isDisabled={selectedSimArticle?.aritcleStatusId === 4}
                    />
                  )}
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={4} sm={4} md={4}>
              <Grid container spacing={2}>
                <Grid item xs={12} sm={12} md={12}>
                  <FormControllerTextField
                    control={control}
                    controlName="description"
                    multiline
                    inputLabel="Description"
                    rows={4.4}
                    disabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={12} sm={12} md={12}>
                  <FormControllerTextField
                    control={control}
                    controlName="chipType"
                    inputLabel="ChipTyp"
                    disabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={12} sm={12} md={12}>
                  <FormControllerSelectWithSearch
                    options={dropdownValue?.allDeliveryAddressOutputFile ?? []}
                    inputLabel="Additional_output_file_delivery"
                    controlName="test"
                    control={control}
                    id={additionalInputFile}
                    setValue={setValue}
                    isDisabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={12} sm={12} md={12}>
                  <FormControllerSelectWithSearch
                    options={dropdownValue?.allFormFactor ?? []}
                    required
                    inputLabel="Form_factor"
                    controlName="formFactorId"
                    control={control}
                    isDisabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
                <Grid item xs={12} sm={12} md={12}>
                  <FormControllerTextField
                    control={control}
                    controlName="comment"
                    multiline
                    inputLabel="comment"
                    rows={4.4}
                    disabled={selectedSimArticle?.aritcleStatusId === 4}
                  />
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </StyledFormBox>
        {selectedSimArticle && (
          <>
            {" "}
            <Grid>
              <LastUpdated
                lastUpdatedDate={selectedSimArticle?.lastUpdateDate}
              />
            </Grid>
          </>
        )}
        <Stack
          mt={1}
          flexDirection="row"
          justifyContent="flex-end"
          alignContent="space-between"
        >
          <Button
            sx={{ marginRight: "18px" }}
            variant="outlined"
            size="small"
            onClick={handleCancle}
          >
            {t("button_cancel")}
          </Button>
          {selectedSimArticle?.aritcleStatusId !== 4 && (
            <Button
              type="submit"
              size="small"
              sx={{ marginRight: "18px" }}
              variant="contained"
              disabled={!formState.isValid}
            >
              {t("button_submit")}
            </Button>
          )}

          <Stack mt={1} flexDirection="row" justifyContent="space-between">
            {selectedSimArticle && (
              <Stack spacing={2} direction="row">
                <Button
                  onClick={() => downloadInputFile(selectedSimArticle?.id)}
                  variant="contained"
                >
                  {t("Show input file")}
                </Button>
                {selectedSimArticle?.aritcleStatusId !== 4 && (
                  <Button variant="contained">{t("release")}</Button>
                )}
                {selectedSimArticle.simCardOrderExist && (
                  <Button
                    variant="contained"
                    sx={{
                      textTransform: "none"
                    }}
                    onClick={handleArchive}
                  >
                    {t("Archived")}
                  </Button>
                )}
                <Button
                  variant="contained"
                  sx={{
                    textTransform: "none"
                  }}
                  onClick={() => setIsModalOpen(true)}
                >
                  {t("button_delete")}
                </Button>
              </Stack>
            )}
          </Stack>
        </Stack>
      </Box>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedSimArticle: state.simArticle.selectedSimArticle,
  isLoading: state.simArticle.isCreateOrUpdate,
  successMessage: state.simArticle.createOrUpdateSuccess,
  archiveMsg: state.simArticle.archiveMsg
});

const connector = connect(mapStateToProps, {
  setSelectedSimArticle,
  createSimArticle,
  updateSimArticle,
  showSuccessSnackbar,
  resetPage,
  resetSimArticle,
  archiveSimArticle,
  showFailureSnackbar,
  deleteSimArticle
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(SimArticleForm);
