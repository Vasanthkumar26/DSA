import { FC, Dispatch, SetStateAction, useCallback } from "react";
import TableHeader from "../common/TableHeader";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import {
  fetchSimArticleExport,
  setSelectedSimArticle
} from "../../redux/actions/simArticleAction";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const SimArticleHeader: FC<Props> = ({
  isArchivedVisible,
  setIsArchivedVisible,
  isLoadingExport,
  fetchSimArticleExport,
  setShowForm,
  setSelectedSimArticle
}) => {
  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleExport = useCallback(() => {
    fetchSimArticleExport(isArchivedVisible);
  }, [fetchSimArticleExport, isArchivedVisible]);

  const handleAdd = useCallback(() => {
    setSelectedSimArticle(null);
    setShowForm(true);
  }, [setSelectedSimArticle, setShowForm]);

  return (
    <TableHeader
      title="Sim Article"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.simArticle.isLoadingExport
});

const connector = connect(mapStateToProps, {
  fetchSimArticleExport,
  setSelectedSimArticle
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(SimArticleHeader);
