import * as yup from "yup";
import {
  HeadCell,
  TableConfig,
  productTypePayload,
  productTypeUpdatePayload
} from "../../models";

export const headCells: Array<HeadCell> = [
  { id: "name", label: "Name" },
  { id: "serviceproviderShortcode", label: "Service Provider" },
  { id: "simType", label: "SIM-Typ" },
  { id: "confirmationExternalSystem", label: "Ext. System" },
  { id: "greenIccidImsi", label: "Green ICCID" },
  { id: "ntUDBAucReq", label: "ProvisioningUDB" },
  { id: "ntOtapReq", label: "ProvisioningOTAP" }
];

export const archivedCell = {
  id: "archived",
  label: "Arvhived",
  values: ["Yes", "No"]
};

export const greenICCIDCell = {
  id: "greenICCID",
  label: "Green ICCID",
  values: ["Yes", "No"]
};

export const provisioningUDBCell = {
  id: "provisioningUDB",
  label: "ProvisioningUDB",
  values: ["Yes", "No"]
};

export const provisioningOTAPCell = {
  id: "provisioningOTAP",
  label: "ProvisioningOTAP",
  values: ["Yes", "No"]
};

export const ConfirmationExternalCell = {
  id: "confirmationExternalSystem",
  label: "Ext. System",
  values: ["Yes", "No"]
};

export const tableConfig: TableConfig = {
  title: "Product Type Table",
  orderBy: "lastUpdateDate",
  tableRowTestId: "ep-row"
};

export const initData = {
  name: "",
  simType: 5,
  serviceProviderShortCodeId: null,
  Confirmation3rdParty: false,
  greenIccidImsi: true,
  ntUDBAucReq: true,
  ntOtapReq: true,
  imsiThreshold: 1,
  biggestFreeRange: 1,
  externalSystemId: null,
  freeImsis: 0,
  userUpdatedBy: null
};

export const setFormData = (
  data: any,
  serviceProviders: any
): productTypePayload => ({
  name: data ? data.name : "",
  simType: data ? data.simType : 5,
  serviceProviderShortCodeId:
    serviceProviders.find(
      (item: any) => item.id === data?.serviceProviderShortCodeId
    ) ?? "",
  confirmationExternalSystem: data ? data.Confirmation3rdParty : false,
  greenIccidImsi: data ? data.greenIccidImsi : true,
  ntUDBAucReq: data ? data.ntOtapReq : true,
  ntOtapReq: data ? data.ntUDBAucReq : true,
  imsiThreshold: data ? data.imsiThreshold : 1,
  biggestFreeRange: data ? data.biggestFreeRange : 1,
  externalSystemId: data ? data.externalSystemId : false,
  freeImsis: data ? data?.freeImsis : 0,
  userUpdatedBy: data ? data?.lastUpdatedBy : 1
});

export const createProductTypePayload = (data: any): productTypePayload => ({
  name: data?.name ?? "",
  simType: data?.simType ?? 5,
  serviceProviderShortCodeId: data?.serviceProviderShortCodeId?.id ?? 1,
  confirmationExternalSystem: data?.Confirmation3rdParty ?? false,
  greenIccidImsi: data?.greenIccidImsi ?? false,
  ntUDBAucReq: data?.ntUDBAucReq ?? false,
  ntOtapReq: data?.ntOtapReq ?? false,
  imsiThreshold: data?.imsiThreshold > 0 ? data?.imsiThreshold : 1,
  biggestFreeRange: data?.biggestFreeRange ?? 1,
  externalSystemId: data?.externalSystemId ?? 1,
  freeImsis: data?.freeImsis ?? 1,
  userUpdatedBy: data?.userUpdatedBy ?? 1
});

export const updateProductTypePayload = (
  data: any,
  selectedProduct: any
): productTypeUpdatePayload => ({
  productTypeId: selectedProduct?.productTypeId ?? "",
  name: data?.name ?? "",
  simType: data?.simType ?? 5,
  serviceProviderShortCodeId: data?.serviceProviderShortCodeId?.id ?? 1,
  confirmationExternalSystem: data?.Confirmation3rdParty ?? false,
  greenIccidImsi: data?.greenIccidImsi ?? false,
  ntUDBAucReq: data?.ntUDBAucReq ?? false,
  ntOtapReq: data?.ntOtapReq ?? false,
  imsiThreshold: data?.imsiThreshold > 0 ? data?.imsiThreshold : 1,
  biggestFreeRange: data?.biggestFreeRange ?? 1,
  externalSystemId: data?.externalSystemId ?? 1,
  freeImsis: data?.freeImsis ?? 1,
  userUpdatedBy: data?.userUpdatedBy ?? 1
});

export const imsiSubRangeHeaderContent = [
  { label: "Description", id: "description" },
  { label: "Start IMSI", id: "startImsi" },
  { label: "End IMSI", id: "endImsi" },
  { label: "Free IMSIs", id: "freeImsi" }
];

export const productTypeSchema = (
  t: (key: string | undefined) => string,
  productNames: string[],
  isCreate: boolean
) =>
  yup.object().shape({
    name: yup
      .string()
      .required("Name is missing")
      .notOneOf(
        [...(isCreate ? productNames ?? [] : [])],
        t("name_already_exists")
      )
  });
