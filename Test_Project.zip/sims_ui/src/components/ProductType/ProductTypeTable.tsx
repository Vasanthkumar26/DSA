import {
  FC,
  Dispatch,
  SetStateAction,
  useEffect,
  useState,
  useMemo
} from "react";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import {
  fetchProductType,
  setSelectedProductType
} from "../../redux/actions/productTypeAction";
import { ProductTypeData } from "../../models";
import FilterSearchBar from "../common/FilterSearchBar";
import { useTranslation } from "../../hooks/useTranslation";
import FilterDropdown from "../common/FilterDropdown";
import { Grid } from "@mui/material";
import TableView from "../common/TableView";
import {
  headCells,
  archivedCell,
  greenICCIDCell,
  provisioningOTAPCell,
  provisioningUDBCell,
  ConfirmationExternalCell,
  tableConfig
} from "./ProductType.data";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const ProductTypeTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  setShowForm,
  fetchProductType,
  setSelectedProductType,
  productTypes = []
}) => {
  const [nameFilter, setNameFilter] = useState("");
  const [serviceProviderFilter, setServiceProviderFilter] = useState("");
  const [simTypeFilter, setSimTypeFilter] = useState("");
  const [externalSystemFilter, setExternalSystemFilter] = useState("");
  const [greenICCIDFilter, setGreenICCIDFilter] = useState("");
  const [provisioningUDBFilter, setProvisioningUDBFilter] = useState("");
  const [provisioningOTAPFilter, setProvisioningOTAPFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");

  const t = useTranslation();
  useEffect(() => {
    (async () => await fetchProductType(isArchivedVisible))();
  }, [fetchProductType, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getArchivedFilter = (productTypes: ProductTypeData) => {
    if (archivedFilter === "Yes") {
      return !!productTypes.archived;
    }
    return archivedFilter === "No" ? !productTypes.archived : true;
  };

  const getGreenICCIDFilter = (productTypes: ProductTypeData) => {
    if (greenICCIDFilter === "Yes") {
      return !!productTypes.greenIccidImsi;
    }
    return greenICCIDFilter === "No" ? !productTypes.greenIccidImsi : true;
  };

  const getProvisioningUDBFilter = (productTypes: ProductTypeData) => {
    if (provisioningUDBFilter === "Yes") {
      return !!productTypes.ntUDBAucReq;
    }
    return provisioningUDBFilter === "No" ? !productTypes.ntUDBAucReq : true;
  };

  const getProvisioningOTAPFilter = (productTypes: ProductTypeData) => {
    if (provisioningOTAPFilter === "Yes") {
      return !!productTypes.ntOtapReq;
    }
    return provisioningUDBFilter === "No" ? !productTypes.ntOtapReq : true;
  };

  const getConfirmationExternalFilter = (prodcutTypes: ProductTypeData) => {
    if (externalSystemFilter === "Yes") {
      return !!prodcutTypes.confirmationExternalSystem;
    }
    return externalSystemFilter === "No"
      ? !prodcutTypes.confirmationExternalSystem
      : true;
  };

  let visibleProductTypes = productTypes?.filter(
    (productTypes: ProductTypeData) =>
      productTypes?.name?.includes(nameFilter) &&
      productTypes?.serviceproviderShortcode?.includes(serviceProviderFilter) &&
      `${productTypes.simType}`?.includes(simTypeFilter) &&
      getConfirmationExternalFilter(productTypes) &&
      getGreenICCIDFilter(productTypes) &&
      getProvisioningUDBFilter(productTypes) &&
      getProvisioningOTAPFilter(productTypes) &&
      getArchivedFilter(productTypes)
  );
  if (!isArchivedVisible) {
    visibleProductTypes = visibleProductTypes?.filter(
      (prodcutType: ProductTypeData) => !prodcutType.archived
    );
  }

  const filterHeadCellMap = useMemo(
    () => ({
      [headCells[0].id]: {
        filter: nameFilter,
        setFilter: setNameFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[1].id]: {
        filter: serviceProviderFilter,
        setFilter: setServiceProviderFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[2].id]: {
        filter: simTypeFilter,
        setFilter: setSimTypeFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[3].id]: {
        filter: externalSystemFilter,
        setFilter: setExternalSystemFilter,
        filterComponent: FilterDropdown(ConfirmationExternalCell.values, t)
      },
      [headCells[4].id]: {
        filter: greenICCIDFilter,
        setFilter: setGreenICCIDFilter,
        filterComponent: FilterDropdown(greenICCIDCell.values, t)
      },
      [headCells[5].id]: {
        filter: provisioningUDBFilter,
        setFilter: setProvisioningUDBFilter,
        filterComponent: FilterDropdown(provisioningUDBCell.values, t)
      },
      [headCells[6].id]: {
        filter: provisioningOTAPFilter,
        setFilter: setProvisioningOTAPFilter,
        filterComponent: FilterDropdown(provisioningOTAPCell.values, t)
      },
      [archivedCell.id]: {
        filter: archivedFilter,
        setFilter: setArchivedFilter,
        filterComponent: FilterDropdown(archivedCell.values, t)
      }
    }),
    [
      archivedFilter,
      externalSystemFilter,
      greenICCIDFilter,
      nameFilter,
      provisioningOTAPFilter,
      provisioningUDBFilter,
      serviceProviderFilter,
      simTypeFilter,
      t
    ]
  );

  const resetFilters = useMemo(() => {
    return () => {
      setNameFilter("");
      setArchivedFilter("");
      setExternalSystemFilter("");
      setGreenICCIDFilter("");
      setProvisioningOTAPFilter("");
      setProvisioningUDBFilter("");
      setServiceProviderFilter("");
      setSimTypeFilter("");
    };
  }, []);

  const visibleHeadCells = useMemo(
    () => [...headCells, ...(isArchivedVisible ? [archivedCell] : [])],
    [isArchivedVisible]
  );

  const handleRowSelected = (row: any) => {
    setShowForm(true);
    setSelectedProductType(row);
  };

  const handleRefreash = async () => {
    await fetchProductType(isArchivedVisible);
    resetFilters();
  };
  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleProductTypes]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefreash}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.productType.isLoadingFetch,
  productTypes: state.productType.productTypes
});

const connector = connect(mapStateToProps, {
  setSelectedProductType,
  fetchProductType
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(ProductTypeTable);
