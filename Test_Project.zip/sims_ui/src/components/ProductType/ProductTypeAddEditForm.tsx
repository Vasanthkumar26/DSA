// @ts-nocheck
import { Fragment, useState, useEffect, useMemo, useCallback } from "react";
import { useForm } from "react-hook-form";
import { Box, Button, Stack, Grid, MenuItem } from "@mui/material";
import { StyledFormBox } from "../common/styles/shared";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import { connect } from "react-redux";
import { RootState } from "../../redux/store";
import { fetchServiceProviders } from "../../redux/actions/serviceProviderAction";
import {
  fetchAssignedImsiSubRanges,
  fetchAllImsiSubRanges
} from "../../redux/actions/productTypeAction";
import { useTranslation } from "../../hooks/useTranslation";
import SecondaryHeader from "../common/SecondaryHeader";
import {
  initData,
  setFormData,
  createProductTypePayload,
  updateProductTypePayload,
  imsiSubRangeHeaderContent,
  tableConfig,
  productTypeSchema
} from "./ProductType.data";
import { SPSelectWithSearch } from "../common/AddEditForm/SPSelectWithSearch";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import {
  createProductType,
  deleteProductType,
  resetProductType,
  setSelectedProductType,
  updateProductType,
  archiveProductType
} from "../../redux/actions/productTypeAction";
import {
  FormActionButtons,
  FormControllerSelect,
  FormControllerTextField
} from "../common/AddEditForm";
import { DeleteDailog } from "../common/AddEditForm/DeleteDialog";
import { resetPage } from "../../redux/actions/rootAction";
import TableWithCheckBox from "../common/TableWithCheckBox";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";

const ProductTypeAddEditForm = ({
  productDropDown,
  productSimType,
  fetchServiceProviders,
  setShowForm,
  selectedProduct,
  deleteProductType,
  showSuccessSnackbar,
  showFailureSnackbar,
  serviceProviderList,
  createProductType,
  updateProductType,
  errorCreate,
  resetProductType,
  resetPage,
  archiveProductType,
  fetchAssignedImsiSubRanges,
  isLoadingAssignedImsiSubrange,
  assignedImsiSubranges,
  fetchAllImsiSubRanges,
  allImsiSubranges,
  isLoadingAllImsiSubrange,
  productTypeNames
}) => {
  const t = useTranslation();
  const resolver = useYupValidationResolver(
    productTypeSchema(t, [...(productTypeNames ?? [])], !selectedProduct)
  );
  const [open, setOpen] = useState<boolean>(false);
  const [showExtSys, setShowExtSys] = useState<boolean>(false);
  const [serviceProviders, setServiceProviders] = useState([
    { label: "", id: -1 }
  ]);

  const { control, handleSubmit, reset, setValue, watch } = useForm({
    mode: "all",
    resolver,
    reValidateMode: "onSubmit",
    defaultValues: { ...initData }
  });

  const { serviceProviderShortCodeId = "" } = selectedProduct ?? {};

  const handleReset = useCallback(() => {
    reset({ ...initData });
    setShowForm(false);
  }, [reset, setShowForm]);

  const resetThisPage = () => {
    resetProductType();
    resetPage();
  };

  const handleConfirmation = (flag: boolean): any => {
    setOpen(flag);
  };

  const confThirdParty = watch("Confirmation3rdParty");

  useEffect(() => {
    setShowExtSys(false);
    if (confThirdParty) {
      setShowExtSys(true);
    }
  }, [confThirdParty]);

  const handleCloseConfirmation = () => {
    setOpen(false);
    deleteProductType(selectedProduct?.productTypeId)
      .then(() => showSuccessSnackbar(t("successfully_deleted")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  useEffect(() => {
    selectedProduct &&
      fetchAssignedImsiSubRanges(selectedProduct?.productTypeId);
    selectedProduct
      ? reset(setFormData(selectedProduct, serviceProviders))
      : reset({ ...initData });
  }, [reset, selectedProduct, serviceProviders, fetchAssignedImsiSubRanges]);

  useEffect(() => {
    watch((formValues) => {
      if (
        (formValues?.greenIccidImsi || !formValues?.greenIccidImsi) &&
        formValues?.serviceProviderShortCodeId?.id
      ) {
        fetchAllImsiSubRanges(
          formValues?.greenIccidImsi,
          formValues?.serviceProviderShortCodeId?.id
        );
      }
    });
  }, [fetchAllImsiSubRanges, watch]);

  const onSubmit = (data: ProductTypeData) => {
    const createPayload = createProductTypePayload(data);
    const updatePayload = updateProductTypePayload(data, selectedProduct);
    const productTypeApi = selectedProduct
      ? updateProductType(updatePayload)
      : createProductType(createPayload);
    productTypeApi
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const handleActiveNArchive = () => {
    archiveProductType(
      selectedProduct?.productTypeId,
      selectedProduct?.archived
    )
      .then(() => showSuccessSnackbar("Successfully archived"))
      .catch(() => showFailureSnackbar("Error while processing data"));
    // archiveProductType(
    //   selectedProduct?.productTypeId ?? 0,
    //   selectedProduct?.archived ?? false
    // );
    //await fetchElectricalProfiles(isArchivedVisible);
  };

  useMemo(() => {
    if (serviceProviderList !== undefined || serviceProviderList !== null) {
      const serviceProviderArray = serviceProviderList?.map((item) => {
        return {
          label: `${item.spid}(${item.description})`,
          id: item.id
        };
      });
      setServiceProviders(serviceProviderArray);
    }
  }, [serviceProviderList]);

  useEffect(() => {
    fetchServiceProviders(true);
  }, [fetchServiceProviders]);

  const simType = productSimType?.map(({ name, value }) => {
    return (
      <MenuItem key={name} value={value}>
        {t(name)}
      </MenuItem>
    );
  });
  const dropDown = productDropDown?.map(({ name, value }) => {
    return (
      <MenuItem key={name} value={value}>
        {t(name)}
      </MenuItem>
    );
  });

  return (
    <Fragment>
      <DeleteDailog
        open={open}
        onDelete={handleConfirmation}
        handleCloseConfirmation={handleCloseConfirmation}
        message={"delete_confirmation"}
      ></DeleteDailog>
      <Box component="form" onSubmit={handleSubmit(onSubmit)}>
        <StyledFormBox>
          <Grid container spacing={2}>
            <Grid item xs={4} sm={4} md={4}>
              <FormControllerTextField
                control={control}
                controlName="name"
                inputLabel="name"
                required
              />
            </Grid>
            <Grid item xs={4} sm={4} md={4}>
              <SPSelectWithSearch
                control={control}
                controlName="serviceProviderShortCodeId"
                spid={serviceProviderShortCodeId}
                inputLabel={t("service_provider")}
                required
                setValue={setValue}
              />
            </Grid>
            <Grid item xs={4} sm={4} md={4}>
              <FormControllerSelect
                control={control}
                controlName="simType"
                inputLabel="sim-typ"
              >
                {simType}
              </FormControllerSelect>
            </Grid>
            <Grid item xs={4} sm={4} md={4}>
              <FormControllerSelect
                control={control}
                controlName="Confirmation3rdParty"
                inputLabel="Confirmation_3rd_Party_required"
              >
                {dropDown}
              </FormControllerSelect>
            </Grid>
            {showExtSys ? (
              <Grid item xs={4} sm={4} md={4}>
                <FormControllerSelect
                  control={control}
                  controlName="External Systems"
                  inputLabel="External Systems"
                >
                  {}
                </FormControllerSelect>
              </Grid>
            ) : (
              ""
            )}
            <Grid item xs={4} sm={4} md={4}>
              <FormControllerSelect
                control={control}
                controlName="greenIccidImsi"
                inputLabel="Green ICCID"
              >
                {dropDown}
              </FormControllerSelect>
            </Grid>
            {!showExtSys ? <Grid item xs={4} sm={4} md={4}></Grid> : ""}
            <Grid item xs={4} sm={4} md={4}>
              <FormControllerSelect
                control={control}
                controlName="ntUDBAucReq"
                inputLabel="Provisioning_UDB_AUC_Required"
              >
                {dropDown}
              </FormControllerSelect>
            </Grid>
            <Grid item xs={4} sm={4} md={4}>
              <FormControllerSelect
                control={control}
                controlName="ntOtapReq"
                inputLabel="Provisioning_OTAP_required"
              >
                {dropDown}
              </FormControllerSelect>
            </Grid>
            <Grid item xs={4} sm={4} md={4}>
              <FormControllerTextField
                control={control}
                controlName="freeImsis"
                inputLabel="Warning_threshold_for_free_IMSIs"
                required
              />
            </Grid>
          </Grid>
        </StyledFormBox>
        <Grid container spacing={2}>
          <Grid item xs={5}>
            <SecondaryHeader title={t("IMSI Subranges")} />
            <TableWithCheckBox
              isLoading={isLoadingAllImsiSubrange}
              visibleHeadCells={imsiSubRangeHeaderContent}
              visibleItems={allImsiSubranges}
              handleCheckBoxClick={() => {}}
              tableConfig={tableConfig}
            />
          </Grid>
          <Grid item xs={2} alignItems="center" sx={{ marginTop: "8rem" }}>
            <Stack spacing={2} alignItems="center">
              <Button
                variant="contained"
                style={{ backgroundColor: "#c3c4c7" }}
              >
                <KeyboardArrowLeftIcon />
              </Button>
              <Button
                variant="contained"
                style={{ backgroundColor: "#c3c4c7" }}
              >
                <KeyboardArrowRightIcon />
              </Button>
            </Stack>
          </Grid>
          <Grid item xs={5}>
            <SecondaryHeader title={t("Assigned IMSI Sub ranges")} />
            <TableWithCheckBox
              isLoading={isLoadingAssignedImsiSubrange}
              visibleHeadCells={imsiSubRangeHeaderContent}
              visibleItems={assignedImsiSubranges}
              handleCheckBoxClick={() => {}}
              tableConfig={tableConfig}
            />
          </Grid>
        </Grid>
        <Grid item xs={12}>
          <FormActionButtons
            onCancel={handleReset}
            onDelete={handleConfirmation}
            selectedData={selectedProduct}
            onActiveNArchive={handleActiveNArchive}
            isArchiveVisible={
              selectedProduct?.isReferenceExist && !selectedProduct?.archived
            }
            isDeleteVisible={!selectedProduct?.isReferenceExist}
            isActiveVisible={
              selectedProduct?.isReferenceExist && selectedProduct?.archived
            }
          />
        </Grid>
      </Box>
    </Fragment>
  );
};

const mapStateToProps = (state: RootState) => ({
  productDropDown: state.productType.productDropDown,
  productSimType: state.productType.productSimType,
  serviceProviderList: state.serviceProvider.serviceProviders,
  selectedProduct: state.productType.selectedProductType,
  errorCreate: state.productType.errorCreate,
  isLoadingAssignedImsiSubrange:
    state.productType.isLoadingAssignedImsiSubrange,
  assignedImsiSubranges: state.productType.assignedImsiSubranges,
  allImsiSubranges: state.productType.allImsiSubranges,
  isLoadingAllImsiSubrange: state.productType.isLoadingAllImsiSubrange,
  productTypeNames: state.productType.productTypes.map((item) => item.name)
});

const connector = connect(mapStateToProps, {
  fetchServiceProviders,
  deleteProductType,
  showSuccessSnackbar,
  showFailureSnackbar,
  createProductType,
  updateProductType,
  setSelectedProductType,
  resetProductType,
  resetPage,
  archiveProductType,
  fetchAssignedImsiSubRanges,
  fetchAllImsiSubRanges
});

export default connector(ProductTypeAddEditForm);
