import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import ProductType from "..";

describe("ProductType", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<ProductType />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
