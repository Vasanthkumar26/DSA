//@ts-nocheck
import "@testing-library/jest-dom";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import {
  PRODUCT_TYPE_FAILURE_HANDLERS,
  PRODUCT_TYPE_SUCCESS_HANDLERS
} from "../../../_mocks_";
import ProductTypeTable from "../ProductTypeTable";
import { screen, waitFor } from "@testing-library/react";

describe("Product Type Table", () => {
  const setShowForm = jest.fn();
  describe("SUCCESS", () => {
    createServer(PRODUCT_TYPE_SUCCESS_HANDLERS);
    test("Should render component without crash", () => {
      const { container } = renderWithAllWrappers(
        <ProductTypeTable setShowForm={setShowForm} isArchivedVisible={false} />
      );

      expect(container).toBeInTheDocument();
    });
    test("Table should show correct data when archive is checked", async () => {
      renderWithAllWrappers(
        <ProductTypeTable setShowForm={setShowForm} isArchivedVisible={false} />
      );
      const records = await screen.findAllByTestId(/ep-row/i);
      expect(records).toHaveLength(1);
    });
  });
  describe("FAILURE", () => {
    createServer(PRODUCT_TYPE_FAILURE_HANDLERS);
    test("Should show zero record if there is API failure", async () => {
      renderWithAllWrappers(
        <ProductTypeTable setShowForm={setShowForm} isArchivedVisible={false} />
      );

      await waitFor(async () => {
        const records = screen.queryAllByTestId(/ep-row/i);
        expect(records).toHaveLength(0);
      });
    });
  });
});
