// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import ProductTypeAddEditForm from "../ProductTypeAddEditForm";

describe("ProductTypeAddEditForm", () => {
  test("should render without crash", async () => {
    const setShowForm = jest.fn();
    const { container } = renderWithAllWrappers(
      <ProductTypeAddEditForm setShowForm={setShowForm} />
    );
    expect(container).toBeInTheDocument();
  });
});
