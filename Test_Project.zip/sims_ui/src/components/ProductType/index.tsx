// @ts-nocheck
import { FC, useState } from "react";
import { Box, Grid } from "@mui/material";
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";
import ProductTypeHeader from "./ProductTypeHeader";
import ProductTypeTable from "./ProductTypeTable";
import ProductTypeAddEditForm from "./ProductTypeAddEditForm";

const ProductType: FC = () => {
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const selectedProduct = useSelector(
    (state: RootState) => state.productType.selectedProductType
  );

  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <ProductTypeHeader
            isArchivedVisible={isArchivedVisible}
            setIsArchivedVisible={setIsArchivedVisible}
            setShowForm={setShowForm}
          />
          <ProductTypeTable
            setShowForm={setShowForm}
            isArchivedVisible={isArchivedVisible}
          />
          {(showForm || selectedProduct) && (
            <ProductTypeAddEditForm setShowForm={setShowForm} />
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default ProductType;
