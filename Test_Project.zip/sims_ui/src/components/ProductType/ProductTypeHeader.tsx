import { connect, ConnectedProps } from "react-redux";
import { RootState } from "../../redux/store";
import { Dispatch, FC, SetStateAction, useCallback } from "react";
import { useTranslation } from "../../hooks/useTranslation";
import {
  Stack,
  Typography,
  Button,
  FormControlLabel,
  Checkbox
} from "@mui/material";
import { fetchElectricalProfileExport } from "../../redux/actions/electricalProfileAction";
import { fetchProductTypesExport } from "../../redux/actions/productTypeAction";

import UploadFileRoundedIcon from "@mui/icons-material/UploadFileRounded";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const ProductTypeHeader: FC<Props> = ({
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  fetchProductTypesExport,
  fetchElectricalProfileExport
}) => {
  const t = useTranslation();

  const handleAdd = useCallback(() => {
    setShowForm(true);
  }, [setShowForm]);

  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  return (
    <>
      <Stack direction="row" paddingBottom={1} justifyContent="space-between">
        <Typography
          align="center"
          variant="h5"
          color="#031a34"
          sx={{ fontWeight: 600 }}
        >
          {t("Product types")}
        </Typography>
        <Stack direction="row" spacing={1} justifyContent="flex-end">
          <Button
            sx={{
              textTransform: "none",
              color: "black",
              textDecoration: "underline"
            }}
            disabled={false}
            role="export-button"
            onClick={() => {
              fetchElectricalProfileExport(isArchivedVisible);
            }}
            startIcon={<UploadFileRoundedIcon color="primary" />}
          >
            <Typography>{t("Export Free IMSIs")}</Typography>
          </Button>
          <Button
            sx={{
              textTransform: "none",
              color: "black",
              textDecoration: "underline"
            }}
            disabled={false}
            role="export-button"
            onClick={() => {
              fetchProductTypesExport(isArchivedVisible);
            }}
            startIcon={<UploadFileRoundedIcon color="primary" />}
          >
            <Typography>{t("Export")}</Typography>
          </Button>

          <FormControlLabel
            control={
              <Checkbox
                role="archive-checkbox"
                size="small"
                checked={isArchivedVisible}
                onChange={handleArchiveChange}
              />
            }
            label={t("Archived")}
          />
          {/* <Button
            variant="contained"
            sx={{
              textTransform: "none"
            }}
            onClick={() => alert("test")} //TODO:Need to change after discussion with Manish
          >
            {t("Duplicate")}
          </Button> */}
          <Button
            variant="contained"
            sx={{
              textTransform: "none"
            }}
            onClick={handleAdd}
          >
            {t("Add")}
          </Button>
        </Stack>
      </Stack>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({});

const connector = connect(mapStateToProps, {
  fetchProductTypesExport,
  fetchElectricalProfileExport
});

type PropsFromRedux = ConnectedProps<typeof connector>;
export default connector(ProductTypeHeader);
