import {
  Dispatch,
  FC,
  SetStateAction,
  useEffect,
  useMemo,
  useState
} from "react";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import {
  fetchCustomProfiles,
  setSelectedCustomProfile
} from "../../redux/actions/customProfileAction";
import { Grid } from "@mui/material";
import TableView from "../common/TableView";
import { useTranslation } from "../../hooks/useTranslation";
import { CustomProfile } from "../../models/customProfile.model";
import { archivedCell, headCells, tableConfig } from "./CustomProfile.data";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const CustomProfileTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchCustomProfiles,
  setShowForm,
  customProfiles,
  setSelectedCustomProfile
}) => {
  const [nameFilter, setNameFilter] = useState("");
  const [descriptionFilter, setDescriptionFilter] = useState("");
  const [simVendorFilter, setSimVendroFilter] = useState("");
  const [xmlFileNameFilter, setXmlFileNameFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");

  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchCustomProfiles(isArchivedVisible))();
  }, [fetchCustomProfiles, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getArchivedFilter = (customProfile: CustomProfile) => {
    if (archivedFilter === "Yes") {
      return !!customProfile.archived;
    }
    return archivedFilter === "No" ? !customProfile.archived : true;
  };

  let visibleCustomProfiles = customProfiles?.filter(
    (customProfile: CustomProfile) =>
      customProfile?.name?.includes(nameFilter) &&
      customProfile?.description?.includes(descriptionFilter) &&
      customProfile?.simVendor?.includes(simVendorFilter) &&
      customProfile?.xmlFileName?.includes(xmlFileNameFilter) &&
      getArchivedFilter(customProfile)
  );

  if (!isArchivedVisible) {
    visibleCustomProfiles = visibleCustomProfiles?.filter(
      (customProfile: CustomProfile) => !customProfile.archived
    );
  }

  const filterHeadCellMap = useMemo(
    () => ({
      [headCells[0].id]: {
        filter: nameFilter,
        setFilter: setNameFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[1].id]: {
        filter: simVendorFilter,
        setFilter: setSimVendroFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[2].id]: {
        filter: descriptionFilter,
        setFilter: setDescriptionFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[3].id]: {
        filter: xmlFileNameFilter,
        setFilter: setXmlFileNameFilter,
        filterComponent: FilterSearchBar(t)
      },
      [archivedCell.id]: {
        filter: archivedFilter,
        setFilter: setArchivedFilter,
        filterComponent: FilterDropdown(archivedCell.values, t)
      }
    }),
    [
      archivedFilter,
      descriptionFilter,
      nameFilter,
      simVendorFilter,
      t,
      xmlFileNameFilter
    ]
  );

  const resetAllFilters = useMemo(() => {
    return () => {
      setNameFilter("");
      setDescriptionFilter("");
      setSimVendroFilter("");
      setXmlFileNameFilter("");
      setArchivedFilter("");
    };
  }, []);

  const handleRowSelected = (row: any) => {
    setSelectedCustomProfile(null);
    setShowForm(false);
    setSelectedCustomProfile(row);
    setShowForm(true);
  };

  const visibleHeadCells = useMemo(
    () => [...headCells, ...(isArchivedVisible ? [archivedCell] : [])],
    [isArchivedVisible]
  );

  const handleRefreash = async () => {
    await fetchCustomProfiles(isArchivedVisible);
    resetAllFilters();
  };

  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleCustomProfiles]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefreash}
        filterHeadCellMap={filterHeadCellMap}
        tableConfig={tableConfig}
      />
    </Grid>
  );
};
const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.customProfile.isLoadingFetch,
  customProfiles: state.customProfile.customProfiles
});

const connector = connect(mapStateToProps, {
  fetchCustomProfiles,
  setSelectedCustomProfile
});

type PropsFromRedux = ConnectedProps<typeof connector>;
export default connector(CustomProfileTable);
