import * as yup from "yup";
import { HeadCell, ISelectionOption, TableConfig } from "../../models";
import { CustomProfile } from "../../models/customProfile.model";

export const headCells: Array<HeadCell> = [
  { id: "name", label: "Name" },
  { id: "simVendor", label: "SIM-Manufacturer" },
  { id: "description", label: "Description" },
  { id: "xmlFileName", label: "XML Filename" }
];

export const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};
export const tableConfig: TableConfig = {
  title: "Custom Profle Administration",
  orderBy: "lastUpdatedDate",
  tableRowTestId: "customprofile-row"
};

export const customProfileSchema = (
  t: (key: string | undefined) => string,
  cpNames: string[],
  isCreate: boolean
) =>
  yup.object().shape({
    name: yup
      .string()
      .required("name_is_missing")
      .notOneOf([...(isCreate ? cpNames : [])], t("name_already_exists")),
    description: yup.string(),
    simVendorId: yup.object().required("sim_manufacturer_is_missing")
  });

export const initData = {
  name: "",
  description: "",
  simVendorId: null,
  xmlFileName: "",
  file: null
};

export const setFormData = (
  data: CustomProfile,
  simVendors: ISelectionOption[]
) => ({
  name: data?.name ?? "",
  description: data?.description ?? "",
  simVendorId:
    simVendors.find(
      (item: ISelectionOption) => item.label === data?.simVendor
    ) ?? null,
  xmlFileName: data?.xmlFileName ?? ""
});

export const createCPPayload = (data: any) => {
  const formData = new FormData();
  formData.append("name", data?.name ?? "");
  formData.append("description", data?.description ?? "");
  formData.append("userUpdatedBy", data?.userUpdatedBy ?? "1");
  formData.append("simVendorId", data?.simVendorId?.id);
  data?.file?.[0] && formData.append("file", data?.file?.[0] ?? null);
  return formData;
};
