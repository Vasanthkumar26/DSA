// @ts-nocheck
import { screen, waitFor } from "@testing-library/react";
import {
  CustomProfile_FAILURE_API_HANDLERS,
  CustomProfile_SUCCESS_API_HANDLERS
} from "../../../_mocks_";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import CustomProfileTable from "../CustomProfileTable";

describe("CustomProfile Table", () => {
  const setShowForm = jest.fn();

  describe("SUCCESS", () => {
    createServer(CustomProfile_SUCCESS_API_HANDLERS);

    test("Table Shoudl show correct data when archive is unchecked", async () => {
      renderWithAllWrappers(
        <CustomProfileTable
          setShowForm={setShowForm}
          isArchivedVisible={true}
        />
      );
      const customProfileRows = await screen.findAllByTestId(
        /customprofile-row/i
      );
      expect(customProfileRows).toHaveLength(2);
    });
  });

  describe("API Failure", () => {
    createServer(CustomProfile_FAILURE_API_HANDLERS);

    test("Table should show correct data when server down", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <CustomProfileTable
          isArchivedVisible={false}
          setShowForm={setShowForm}
        />
      );
      await waitFor(async () => {
        const tableRow = screen.queryAllByTestId(/customprofile-row/i);
        expect(tableRow).toHaveLength(0);
      });
    });
  });
});
