import {
  Dispatch,
  FC,
  SetStateAction,
  useCallback,
  useEffect,
  useState
} from "react";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import { Box, Button, Grid } from "@mui/material";
import { useForm } from "react-hook-form";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import {
  createCPPayload,
  customProfileSchema,
  initData,
  setFormData
} from "./CustomProfile.data";
import {
  FormActionButtons,
  FormControllerTextField,
  LastUpdated
} from "../common/AddEditForm";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import { useTranslation } from "../../hooks/useTranslation";
import { resetPage } from "../../redux/actions/rootAction";
import {
  createCustomProfile,
  deleteCustomProfile,
  resetCustomProfile,
  updateCustomProfile,
  archiveCustomProfile
} from "../../redux/actions/customProfileAction";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import { ISelectionOption } from "../../models";
import { handleDownloadXML } from "../../services/customProfileApi";
import { DeleteDailog } from "../common/AddEditForm/DeleteDialog";

interface Props extends PropsFromRedux {
  simVendors: ISelectionOption[] | null;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const CustomProfileAddEditForm: FC<Props> = ({
  cpNames,
  simVendors,
  selectedCustomProfile,
  isLoadingCreate,
  errorCreate,
  isLoadingUpdate,
  errorUpdate,
  createCustomProfile,
  updateCustomProfile,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetCustomProfile,
  deleteCustomProfile,
  archiveCustomProfile,
  resetPage
}) => {
  const t = useTranslation();
  const [open, setOpen] = useState<boolean>(false);
  const resolver = useYupValidationResolver(
    customProfileSchema(t, [...(cpNames ?? [])], !selectedCustomProfile)
  );
  const { control, handleSubmit, reset, register, watch, setValue } = useForm({
    mode: "all",
    resolver,
    defaultValues: { ...initData }
  });

  const {
    id = -1,
    xmlFileName = "",
    lastUpdateDate = "",
    userName = "",
    archived = false
  } = selectedCustomProfile ?? {};

  const file = watch("file");

  useEffect(() => {
    file && setValue("xmlFileName", file?.[0]?.name ?? "");
  }, [file, setValue]);

  useEffect(() => {
    selectedCustomProfile
      ? reset(setFormData(selectedCustomProfile, simVendors ?? []))
      : reset({ ...initData });
  }, [reset, selectedCustomProfile, simVendors]);

  useEffect(() => {
    if (errorCreate || errorUpdate) {
      showFailureSnackbar(errorCreate || errorUpdate || "");
    }
  }, [errorCreate, errorUpdate, showFailureSnackbar]);

  const resetThisPage = () => {
    resetCustomProfile();
    resetPage();
  };

  const onSubmit = (data: any) => {
    const formData = createCPPayload(data);
    let promiseAPI: Promise<void>;
    if (selectedCustomProfile) {
      formData.append("id", `${id}`);
      formData.append("archived", `${selectedCustomProfile?.archived}`);
      promiseAPI = updateCustomProfile(formData);
    } else {
      promiseAPI = createCustomProfile(formData);
    }
    promiseAPI
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .finally(() => resetThisPage());
  };

  const handleConfirmation = (flag: boolean): any => {
    setOpen(flag);
  };

  const handleCloseConfirmation = () => {
    setOpen(false);
    deleteCustomProfile(id)
      .then(() => showSuccessSnackbar(t("successfully_deleted")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
    resetThisPage();
  };

  const onActiveNArchive = () => {
    archiveCustomProfile(id, archived)
      .then(() =>
        showSuccessSnackbar(
          !archived ? t("successfully_archived") : t("successfully_activated")
        )
      )
      .catch(() => showFailureSnackbar("Error while processing data"))
      .finally(() => resetThisPage());
  };

  const onDownloadXML = useCallback(() => {
    handleDownloadXML(id, xmlFileName).then(() =>
      showSuccessSnackbar(t("successfully_exported"))
    );
  }, [id, showSuccessSnackbar, t, xmlFileName]);

  return (
    <>
      <DeleteDailog
        open={open}
        onDelete={handleConfirmation}
        handleCloseConfirmation={handleCloseConfirmation}
        message={"delete_confirmation"}
      ></DeleteDailog>
      <Box
        component="form"
        onSubmit={handleSubmit(onSubmit)}
        sx={{ backgroundColor: "#F3F4FF" }}
      >
        <Grid container spacing={2} padding="20px">
          <Grid item md={8}>
            <FormControllerTextField
              control={control}
              controlName="name"
              inputLabel="Name"
              required
            />
          </Grid>
          <Grid item md={4}>
            <FormControllerSelectWithSearch
              control={control}
              controlName="simVendorId"
              inputLabel="SIM-Manufacturer"
              options={simVendors ?? []}
              required={!selectedCustomProfile?.isReferenceExist}
              isDisabled={selectedCustomProfile?.isReferenceExist}
            />
          </Grid>
          <Grid item xs={12}>
            <FormControllerTextField
              control={control}
              controlName="description"
              inputLabel="Description"
              multiline
              rows={2}
            />
          </Grid>
          <Grid item md={4}>
            <FormControllerTextField
              control={control}
              controlName="xmlFileName"
              inputLabel="XML Filename"
              disabled={true}
            />
          </Grid>
          {!selectedCustomProfile?.isReferenceExist && (
            <Grid item md={8}>
              <Box
                height="100%"
                sx={{ display: "flex", alignItems: "flex-end" }}
              >
                <Button size="large" variant="contained" component="label">
                  {t("choose_file")}
                  <input
                    {...register("file")}
                    accept=".xml"
                    type="file"
                    hidden
                  />
                </Button>
              </Box>
            </Grid>
          )}
          <Grid item md={12}>
            <Box height="100%" sx={{ display: "flex", alignItems: "flex-end" }}>
              <Button size="large" variant="contained" onClick={onDownloadXML}>
                {t("download")}
              </Button>
            </Box>
          </Grid>
        </Grid>
        {lastUpdateDate && (
          <Grid item xs={12} sx={{ background: "white" }}>
            <LastUpdated
              lastUpdatedDate={lastUpdateDate}
              lastUpdatedBy={userName}
            />
          </Grid>
        )}
        <Grid item xs={12} pt={2} sx={{ background: "white" }}>
          <FormActionButtons
            onCancel={resetThisPage}
            onDelete={handleConfirmation}
            onActiveNArchive={onActiveNArchive}
            selectedData={selectedCustomProfile}
            submitDisabled={isLoadingCreate || isLoadingUpdate}
            cancelDisabled={isLoadingCreate || isLoadingUpdate}
            isArchiveVisible={
              selectedCustomProfile?.isReferenceExist && !archived
            }
            isDeleteVisible={!selectedCustomProfile?.isReferenceExist}
            isActiveVisible={
              selectedCustomProfile?.isReferenceExist && archived
            }
          />
        </Grid>
      </Box>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  cpNames: state.customProfile.cpNames,
  selectedCustomProfile: state.customProfile.selectedCustomProfile,
  isLoadingCreate: state.customProfile.isLoadingCreate,
  errorCreate: state.customProfile.errorCreate,
  isLoadingUpdate: state.customProfile.isLoadingUpdate,
  errorUpdate: state.customProfile.errorUpdate
});

const connector = connect(mapStateToProps, {
  createCustomProfile,
  updateCustomProfile,
  showSuccessSnackbar,
  showFailureSnackbar,
  resetCustomProfile,
  deleteCustomProfile,
  archiveCustomProfile,
  resetPage
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(CustomProfileAddEditForm);
