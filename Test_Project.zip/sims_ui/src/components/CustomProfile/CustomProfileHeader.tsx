import { Dispatch, FC, SetStateAction, useCallback } from "react";
import TableHeader from "../common/TableHeader";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import {
  setSelectedCustomProfile,
  fetchCustomProfilerExport
} from "../../redux/actions/customProfileAction";
import { useTranslation } from "../../hooks/useTranslation";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const CustomProfileHeader: FC<Props> = ({
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  setSelectedCustomProfile,
  fetchCustomProfilerExport
}) => {
  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleExport = useCallback(() => {
    fetchCustomProfilerExport(isArchivedVisible);
  }, [fetchCustomProfilerExport, isArchivedVisible]);

  const handleAdd = useCallback(() => {
    setSelectedCustomProfile(null);
    setShowForm(true);
  }, [setSelectedCustomProfile, setShowForm]);

  const t = useTranslation();
  return (
    <TableHeader
      title={t("Custom Profile Administration")}
      isLoadingExport={false}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({});
const connector = connect(mapStateToProps, {
  setSelectedCustomProfile,
  fetchCustomProfilerExport
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(CustomProfileHeader);
