import { Box, Grid } from "@mui/material";
import { FC, useEffect, useState } from "react";
import CustomProfileHeader from "./CustomProfileHeader";
import CustomProfileTable from "./CustomProfileTable";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import CustomProfileAddEditForm from "./CustomProfileAddEditForm";
import { handleFetchSimVendors } from "../../services/SimVendorApi";
import { SimVendor } from "../../models/simVendor.model";
import { showFailureSnackbar } from "../../redux/actions/snackbarAction";
import { ISelectionOption } from "../../models";
import { useTranslation } from "../../hooks/useTranslation";

interface Props extends PropsFromRedux {}

const CustomProfile: FC<Props> = ({ selectedCustomProfile }) => {
  const [isArchiveVisible, setIsArchiveVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [simVendors, setSimVendors] = useState<ISelectionOption[] | null>(null);
  const t = useTranslation();

  useEffect(() => {
    if (!simVendors) {
      handleFetchSimVendors(true).then((result: SimVendor[]) =>
        setSimVendors(
          (result ?? []).map((x) => ({
            label: x.archived ? `${x.name}[${t("archived")}]` : x.name,
            id: x.id
          }))
        )
      );
    }
  }, [simVendors, t]);

  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <CustomProfileHeader
            isArchivedVisible={isArchiveVisible}
            setIsArchivedVisible={setIsArchiveVisible}
            setShowForm={setShowForm}
          />
          <CustomProfileTable
            isArchivedVisible={isArchiveVisible}
            setShowForm={setShowForm}
          />
        </Grid>
        {(showForm || selectedCustomProfile) && (
          <Grid item xs={12}>
            <CustomProfileAddEditForm
              setShowForm={setShowForm}
              simVendors={simVendors}
            />
          </Grid>
        )}
      </Grid>
    </Box>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedCustomProfile: state.customProfile.selectedCustomProfile
});

const connector = connect(mapStateToProps, {
  showFailureSnackbar
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(CustomProfile);
