import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";

import AkaAddEditForm from "../AkaAddEditForm";

describe("Aka AddEditForm", () => {
  test("should load component without failed", () => {
    const setShowForm = jest.fn();
    const { container } = renderWithAllWrappers(
      <AkaAddEditForm setShowForm={setShowForm} isArchivedVisible={true} />
    );
    expect(container).toBeInTheDocument();
  });
});
