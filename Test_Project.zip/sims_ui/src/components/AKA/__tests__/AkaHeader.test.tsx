import "@testing-library/jest-dom";
import { SetStateAction } from "react";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import { screen, fireEvent, render } from "@testing-library/react";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { Store, AnyAction } from "redux";
import { fetchAkaExport } from "../../../redux/actions/akaAction";
import { AkaActionTypes } from "../../../redux/actions/types";
import AkaHeader from "../AkaHeader";

const mockStore = configureStore([thunk]);

jest.mock("../../../redux/actions/akaAction", () => ({
  fetchAkaExport: jest.fn(),
}));

describe("header test", () => {
  let store: Store<unknown, AnyAction>;
  beforeEach(() => {
    store = mockStore({
      aka: {
        aka: ["a", "b"],
      },
      lang: {
        language: "en",
      },
    });
  });

  test("should load component without failed", () => {
    const { container } = renderWithAllWrappers(
      <AkaHeader
        isArchivedVisible={false}
        setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
        setShowForm={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
      />
    );
    expect(container).toBeInTheDocument();
  });

  test("should render the export button", () => {
    renderWithAllWrappers(
      <AkaHeader
        isArchivedVisible={false}
        setIsArchivedVisible={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
        setShowForm={function (value: SetStateAction<boolean>): void {
          throw new Error("Function not implemented.");
        }}
      />
    );
    expect(screen.getByText(/Export/i)).toBeInTheDocument();
  });

  test("should call the handle Export on button click", async () => {
    // @ts-ignore:next-line
    fetchAkaExport.mockImplementation(() => {
      return {
        type: AkaActionTypes.FETCH_AKA_EXPORT_SUCCESS,
        payload: { message: "successfull" },
      };
    });
    render(
      <Provider store={store}>
        <AkaHeader
          isArchivedVisible={false}
          setIsArchivedVisible={function (
            value: SetStateAction<boolean>
          ): void {
            throw new Error("Function not implemented.");
          }}
          setShowForm={function (value: SetStateAction<boolean>): void {
            throw new Error("Function not implemented.");
          }}
        />
      </Provider>
    );

    const button = screen.getByRole("export-button");
    await fireEvent.click(button);
    expect(fetchAkaExport).toHaveBeenCalled();
  });
});
