// @ts-nocheck
import "@testing-library/jest-dom";
import AkaTable from "../AkaTable";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import {
  AKA_FAILURE_API_HANDLERS,
  AKA_SUCCESS_API_HANDLERS
} from "../../../_mocks_";
import { screen, waitFor } from "@testing-library/react";

describe("AkaTable", () => {
  test("should render without crash", () => {
    const setShowForm = jest.fn();
    const { container } = renderWithAllWrappers(
      <AkaTable isArchivedVisible={false} setShowForm={setShowForm} />
    );
    expect(container).toBeInTheDocument();
  });

  describe("API success", () => {
    createServer(AKA_SUCCESS_API_HANDLERS);

    test("Table should show correct data when archived unchecked", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <AkaTable isArchivedVisible={false} setShowForm={setShowForm} />
      );
      await waitFor(async () => {
        const akaRows = await screen.findAllByTestId(/aka-row/i);
        expect(akaRows).toHaveLength(1);
      });
    });

    test("Table should show correct data when archived checked", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <AkaTable isArchivedVisible={true} setShowForm={setShowForm} />
      );
      await waitFor(async () => {
        const akaRows = await screen.findAllByTestId(/aka-row/i);
        expect(akaRows).toHaveLength(1);
      });
    });
  });

  describe("API Failure", () => {
    createServer(AKA_FAILURE_API_HANDLERS);

    test("Table should show correct data when server down", async () => {
      const setShowForm = jest.fn();
      renderWithAllWrappers(
        <AkaTable isArchivedVisible={false} setShowForm={setShowForm} />
      );
      await waitFor(async () => {
        const akaRows = screen.queryAllByTestId(/aka-row/i);
        expect(akaRows).toHaveLength(0);
      });
    });
  });
});
