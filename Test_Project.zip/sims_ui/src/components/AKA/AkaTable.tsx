import React, {
  Dispatch,
  FC,
  SetStateAction,
  useEffect,
  useMemo,
  useState
} from "react";
import { Grid } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import { fetchAkas, setSelectedAKA } from "../../redux/actions/akaAction";

import { connect, ConnectedProps } from "react-redux";
import { Aka, HeadCell } from "../../models";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";
import { tableConfig } from "./Aka.data";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const headCells: Array<HeadCell> = [
  { id: "akaHlrName", label: "AKA HLR Name" },
  { id: "inputFileValue", label: "Input File-Value" },
  { id: "fileExtension", label: "File extension" }
];

const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};

const AkaTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchAkas,
  setSelectedAKA,
  akas = [],
  setShowForm
}) => {
  const [akaHlrNameFilter, setAkaHlrNameFilter] = useState("");
  const [inputFileValueFilter, setInputFileValueFilter] = useState("");
  const [fileExtensionFilter, setFileExtensionFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchAkas(isArchivedVisible))();
  }, [fetchAkas, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getArchivedFilter = (aka: Aka) => {
    if (archivedFilter === "Yes") {
      return !!aka.archived;
    }
    return archivedFilter === "No" ? !aka.archived : true;
  };

  let visibleAkas = akas?.filter(
    (aka) =>
      aka.akaHlrName.includes(akaHlrNameFilter) &&
      aka.inputFileValue.includes(inputFileValueFilter) &&
      aka.fileExtension.includes(fileExtensionFilter) &&
      getArchivedFilter(aka)
  );

  if (!isArchivedVisible) {
    visibleAkas = visibleAkas?.filter((aka) => !aka.archived);
  }

  const filterHeadCellMap = useMemo(
    () => ({
      [headCells[0].id]: {
        filter: akaHlrNameFilter,
        setFilter: setAkaHlrNameFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[1].id]: {
        filter: inputFileValueFilter,
        setFilter: setInputFileValueFilter,
        filterComponent: FilterSearchBar(t)
      },
      [headCells[2].id]: {
        filter: fileExtensionFilter,
        setFilter: setFileExtensionFilter,
        filterComponent: FilterSearchBar(t)
      },
      [archivedCell.id]: {
        filter: archivedFilter,
        setFilter: setArchivedFilter,
        filterComponent: FilterDropdown(archivedCell.values, t)
      }
    }),
    [
      akaHlrNameFilter,
      inputFileValueFilter,
      fileExtensionFilter,
      archivedFilter,
      t
    ]
  );

  const resetAllFilters = useMemo(() => {
    return () => {
      setAkaHlrNameFilter("");
      setInputFileValueFilter("");
      setFileExtensionFilter("");
      setArchivedFilter("");
    };
  }, []);

  const visibleHeadCells = useMemo(
    () => [...headCells, ...(isArchivedVisible ? [archivedCell] : [])],
    [isArchivedVisible]
  );

  const handleRowSelected = (row: any) => {
    setShowForm(false);
    setSelectedAKA(row);
  };

  const handleRefresh = async () => {
    await fetchAkas(isArchivedVisible);
    resetAllFilters();
  };

  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleAkas]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
      <Grid item display={{ xs: "none", lg: "block" }}>
        <img
          src="/sidebarIcons/Mask_Group_hlr.jpg"
          alt="background"
          style={{
            objectFit: "cover",
            width: "250px",
            height: "100%",
            margin: "1px"
          }}
        />
      </Grid>
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.aka.isLoadingFetch,
  akas: state.aka.akas
});

const connector = connect(mapStateToProps, {
  fetchAkas,
  setSelectedAKA
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(AkaTable);
