import React, { Dispatch, FC, SetStateAction, useCallback } from "react";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import TableHeader from "../common/TableHeader";
import { fetchAkaExport, setSelectedAKA } from "../../redux/actions/akaAction";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const AkaHeader: FC<Props> = ({
  isLoadingExport,
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  fetchAkaExport,
  setSelectedAKA
}) => {
  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleExport = useCallback(() => {
    fetchAkaExport(isArchivedVisible);
  }, [fetchAkaExport, isArchivedVisible]);

  const handleAdd = useCallback(() => {
    setShowForm(true);
    setSelectedAKA(null);
  }, [setSelectedAKA, setShowForm]);

  return (
    <TableHeader
      title="AKA Administration"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.aka.isLoadingExport
});

const connector = connect(mapStateToProps, { fetchAkaExport, setSelectedAKA });
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(AkaHeader);
