import React, {
  Dispatch,
  FC,
  SetStateAction,
  useCallback,
  useEffect,
  useState
} from "react";
import {
  Autocomplete,
  Box,
  Button,
  Grid,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField
} from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import {
  FormActionButtons,
  FormControllerTextField,
  LastUpdated
} from "../common/AddEditForm";
import {
  akaAlgorithmDropDown,
  customProfileSchema,
  fileExtension,
  initAkaHlrData,
  initialAkaAlgorithmIdValues,
  initialAkaAlgorithmKeyIdValues,
  secondaryTableHeader,
  tableConfig,
  tertiaryTableHeader
} from "./Aka.data";
import { Controller, useForm } from "react-hook-form";
import KeyboardArrowLeftIcon from "@mui/icons-material/KeyboardArrowLeft";
import KeyboardArrowRightIcon from "@mui/icons-material/KeyboardArrowRight";
import SecondaryHeader from "../common/SecondaryHeader";
import { RootState } from "../../redux/store";
import { connect, ConnectedProps } from "react-redux";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import {
  createAka,
  fetchAkas,
  updateAka,
  setSelectedAKA,
  deleteAka,
  archiveAka,
  resetAka
} from "../../redux/actions/akaAction";
import { loadAllAkaHLRValues } from "../../redux/actions/cardTypesAction";
import { fetchSimVendors } from "../../redux/actions/simVendorAction";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import DeleteModal from "../common/modals/DeleteModal";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import TableWithCheckBox from "../common/TableWithCheckBox";
import { akaAlgorithm, akaTpKey } from "../../models";

interface akaHlrProps extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
  isArchivedVisible: boolean;
}

const AkaAddEditForm: FC<akaHlrProps> = ({
  selectedAka,
  createAka,
  setShowForm,
  fetchAkas,
  isArchivedVisible,
  isLoadingCreate,
  isLoadingUpdate,
  simVendors,
  updateAka,
  setSelectedAKA,
  deleteAka,
  showSuccessSnackbar,
  showFailureSnackbar,
  fetchSimVendors,
  archiveAka,
  resetAka,
  loadAllAkaHLRValues,
  allHlrNames
}) => {
  const t = useTranslation();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [akaAlgorithmIdValues, setAkaAlgorithmIdValues] = useState([
    initialAkaAlgorithmIdValues
  ]);
  const [akaAlgorithmKeyIdValues, setAkaAlgorithmKeyIdValues] = useState([
    initialAkaAlgorithmKeyIdValues
  ]);
  const [tempAkaAlgorithm, setTempAkaAlgorithm] = useState<any>([]);
  const [reloadAssocAkaKeyId, setReloadAssocAkaKeyId] = useState(false);
  const [reloadAssocAkaAlgId, setReloadAssocAkaAlgId] = useState(false);
  const [tempAkaKeyId, setTempAkaKeyId] = useState<any>([]);
  const fetchedHlrNames = allHlrNames
    .map((e: any) => e.displayValue)
    ?.filter((e: any) => e !== selectedAka?.akaHlrName);
  const resolver = useYupValidationResolver(
    customProfileSchema(fetchedHlrNames)
  );
  const { control, handleSubmit, reset, setValue, getValues } = useForm({
    defaultValues: { ...initAkaHlrData },
    resolver,
    mode: "all"
  });

  const initialzeAkaTpKeyInput = () => {
    setAkaAlgorithmKeyIdValues([
      {
        akaAlgTypeId: { label: "TBD", value: "tbd", key: 0, id: 0 },
        akaTpKeyIdValue: "",
        manufactureId: { id: simVendors[0]?.id, label: simVendors[0]?.name }
      }
    ]);
  };

  const initializeAkaAlgId = () => {
    setAkaAlgorithmIdValues([
      {
        akaAlgTypeId: { label: "TBD", value: "tbd", key: 0, id: 0 },
        akaAlgIdValue: ""
      }
    ]);
  };

  useEffect(() => {
    selectedAka
      ? reset({
          akaHlrName: selectedAka.akaHlrName,
          fileEnding: {
            label: selectedAka.fileExtension,
            id: selectedAka.fileExtension
          },
          inputFileValue: selectedAka.inputFileValue,
          assocAkaTpKeyId: selectedAka?.assocAkaTpKeyId.map((e: any) => ({
            akaAlgTypeId: e?.akaAlgTypeValue,
            manufactureId: e?.manufacture?.manufacturerName,
            akaTpKeyIdValue: e?.akaTpKeyIdValue,
            id: e?.id
          })),
          assocAkaAlgId: selectedAka?.assocAkaAlgId.map((e: any) => ({
            akaAlgTypeId: e?.akaAlgTypeValue,
            akaAlgIdValue: e?.akaAlgIdValue,
            id: e?.id
          })),
          userUpdated: selectedAka.userUpdated
        })
      : reset({ ...initAkaHlrData });
  }, [reset, selectedAka, fetchSimVendors]);

  useEffect(() => {
    loadAllAkaHLRValues();
  }, [loadAllAkaHLRValues]);

  useEffect(() => {
    setReloadAssocAkaAlgId(true);
    setReloadAssocAkaKeyId(true);
    setAkaAlgorithmKeyIdValues([
      {
        akaAlgTypeId: { label: "TBD", value: "tbd", key: 0, id: 0 },
        akaTpKeyIdValue: "",
        manufactureId: { id: simVendors[0]?.id, label: simVendors[0]?.name }
      }
    ]);
    initializeAkaAlgId();
    setTempAkaAlgorithm([]);
    setTempAkaKeyId([]);
    setReloadAssocAkaAlgId(false);
    setReloadAssocAkaKeyId(false);
  }, [simVendors, reset, selectedAka]);

  useEffect(() => {
    fetchSimVendors(false);
  }, [fetchSimVendors]);

  const onSubmit = (data: any) => {
    const fileEndingText =
      "label" in data["fileEnding"]
        ? data["fileEnding"]["label"]
        : data["fileEnding"];
    const assocAkaAlgIdValues = data?.assocAkaAlgId?.map((value: any) => {
      return {
        akaAlgIdValue: value?.akaAlgIdValue,
        akaAlgTypeId: akaAlgorithmDropDown?.find(
          ({ label }) => label === value?.akaAlgTypeId
        )?.id
      };
    });
    const assocAkaTpKeyIdValues = data?.assocAkaTpKeyId?.map((value: any) => {
      return {
        akaTpKeyIdValue: value?.akaTpKeyIdValue,
        akaAlgTypeId: akaAlgorithmDropDown?.find(
          ({ label }) => label === value?.akaAlgTypeId
        )?.id,
        manufactureId: simVendors?.find((e) => e?.name === value?.manufactureId)
          ?.id
      };
    });
    const finalData = {
      ...data,
      fileEnding: fileEndingText,
      assocAkaAlgId: assocAkaAlgIdValues,
      assocAkaTpKeyId: assocAkaTpKeyIdValues,
      archived: false
    };
    const payload = {
      ...data,
      id: selectedAka?.id,
      fileEnding: fileEndingText,
      assocAkaAlgId: assocAkaAlgIdValues,
      assocAkaTpKeyId: assocAkaTpKeyIdValues,
      archived: selectedAka?.archived,
      userUpdated: selectedAka?.userUpdated
    };
    const akaApi = selectedAka ? updateAka(payload) : createAka(finalData);
    akaApi
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => {
        setShowForm(false);
        setSelectedAKA(null);
        fetchAkas(isArchivedVisible);
      });
  };

  const cancelAllChanges = () => {
    initializeAkaAlgId();
    setAkaAlgorithmKeyIdValues([
      {
        akaAlgTypeId: { label: "TBD", value: "tbd", key: 0, id: 0 },
        akaTpKeyIdValue: "",
        manufactureId: { id: simVendors[0]?.id, label: simVendors[0]?.name }
      }
    ]);
    handleReset();
  };

  const handleReset = useCallback(() => {
    reset({ ...initAkaHlrData });
    setSelectedAKA(null);
    setShowForm(false);
  }, [reset, setSelectedAKA, setShowForm]);

  const handleDelete = () => {
    setIsModalOpen(false);
    deleteAka(selectedAka?.id ?? 0)
      .then(() => {
        showSuccessSnackbar(t("request_processed_successfully"));
        setSelectedAKA(null);
        setShowForm(false);
        handleReset();
      })
      .catch((error: any) => {
        showFailureSnackbar(t("error_while_submitting_data"));
      });
  };

  const handleDeleteConfirmation = () => {
    setIsModalOpen(true);
  };

  const checkValidAkaAlgorithm = (array: any) => {
    return array.every(
      (item: akaAlgorithm) =>
        item?.akaAlgTypeId !== null && item?.akaAlgIdValue !== ""
    );
  };

  const checkValidAlgorithmId = (array: any) => {
    return array.every(
      (item: akaTpKey) =>
        item?.akaAlgTypeId !== null &&
        item?.manufactureId !== null &&
        item?.akaTpKeyIdValue !== ""
    );
  };

  const akaAlgorithmRightIconClickHandler = () => {
    if (checkValidAkaAlgorithm(akaAlgorithmIdValues)) {
      const value = akaAlgorithmIdValues.map(
        (akaAlgorithmIdValue: akaAlgorithm) => {
          return {
            akaAlgTypeId: akaAlgorithmIdValue?.akaAlgTypeId?.label,
            akaAlgIdValue: akaAlgorithmIdValue?.akaAlgIdValue
          };
        }
      );
      setValue("assocAkaAlgId", [...getValues("assocAkaAlgId"), ...value]);
      initializeAkaAlgId();
    }
  };

  const akaAlgorithmKeyIdRightIconClickHandler = () => {
    if (checkValidAlgorithmId(akaAlgorithmKeyIdValues)) {
      const value = akaAlgorithmKeyIdValues.map(
        (akaAlgorithmKeyIdValue: akaTpKey) => {
          return {
            akaAlgTypeId: akaAlgorithmKeyIdValue?.akaAlgTypeId?.label,
            manufactureId: akaAlgorithmKeyIdValue?.manufactureId?.label,
            akaTpKeyIdValue: akaAlgorithmKeyIdValue?.akaTpKeyIdValue
          };
        }
      );
      setValue("assocAkaTpKeyId", [...getValues("assocAkaTpKeyId"), ...value]);
      initialzeAkaTpKeyInput();
    }
  };

  const akaAlgorithmLeftIconClickHandler = () => {
    for (let i = 0; i < tempAkaAlgorithm.length; i++) {
      const index = getValues("assocAkaAlgId").findIndex(
        (e: any) =>
          e.akaAlgIdValue === tempAkaAlgorithm[i].akaAlgIdValue &&
          e.akaAlgTypeId === tempAkaAlgorithm[i].akaAlgTypeId
      );
      const assocAkaId = getValues("assocAkaAlgId");
      assocAkaId.splice(index, 1);
      setValue("assocAkaAlgId", [...assocAkaId]);
    }
    setReloadAssocAkaAlgId(true);
    const value = tempAkaAlgorithm.map((tempAkaAlgorithmValue: any) => {
      return {
        akaAlgIdValue: tempAkaAlgorithmValue?.akaAlgIdValue,
        akaAlgTypeId: akaAlgorithmDropDown?.find(
          ({ label }) => label === tempAkaAlgorithmValue?.akaAlgTypeId
        )
      };
    });
    setAkaAlgorithmIdValues(value);
    setTempAkaAlgorithm([]);
    setReloadAssocAkaAlgId(false);
  };

  const akaAlgorithmKeyIdLeftIconClickHandler = () => {
    for (let i = 0; i < tempAkaKeyId.length; i++) {
      const index = getValues("assocAkaTpKeyId").findIndex(
        (e: any) =>
          e.akaTpKeyIdValue === tempAkaKeyId[i].akaTpKeyIdValue &&
          e.akaAlgTypeId === tempAkaKeyId[i].akaAlgTypeId &&
          e.manufactureId === tempAkaKeyId[i].manufactureId
      );
      const assocAkaTpId = getValues("assocAkaTpKeyId");
      assocAkaTpId.splice(index, 1);
      setValue("assocAkaTpKeyId", [...assocAkaTpId]);
    }
    setReloadAssocAkaKeyId(true);
    const value = tempAkaKeyId.map((tempAkaKeyIdValue: any) => {
      const manufacturerDetails = simVendors?.find(
        (e: any) => e?.name === tempAkaKeyIdValue?.manufactureId
      );
      return {
        akaTpKeyIdValue: tempAkaKeyIdValue?.akaTpKeyIdValue,
        akaAlgTypeId: akaAlgorithmDropDown?.find(
          ({ label }) => label === tempAkaKeyIdValue?.akaAlgTypeId
        ),
        manufactureId: {
          label: manufacturerDetails?.name,
          id: manufacturerDetails?.id
        }
      };
    });
    setAkaAlgorithmKeyIdValues(value);
    setTempAkaKeyId([]);
    setReloadAssocAkaKeyId(false);
  };

  const handleArchiveAkas = () => {
    if (selectedAka) {
      archiveAka(selectedAka.id, selectedAka.archived, selectedAka.akaHlrName)
        .then(() => showSuccessSnackbar(t("successfully_archived")))
        .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
        .finally(() => {
          setSelectedAKA(null);
        });
    }
  };

  const handleAssignmentAlgIdSelection = (checked: boolean, value: any) => {
    if (checked) {
      setTempAkaAlgorithm([...tempAkaAlgorithm, value]);
    } else {
      const gettingIndex: any = tempAkaAlgorithm.findIndex(
        (e: any) =>
          e.akaAlgTypeId === value.akaAlgTypeId &&
          e.akaAlgIdValue === value.akaAlgIdValue
      );
      const akaRequiredArray = [...tempAkaAlgorithm];
      akaRequiredArray.splice(gettingIndex, 1);
      setTempAkaAlgorithm([...akaRequiredArray]);
    }
  };

  const handleAssignmentTpKeySelection = (checked: boolean, value: any) => {
    if (checked) {
      setTempAkaKeyId([...tempAkaKeyId, value]);
    } else {
      const gettingIndex: any = tempAkaKeyId.findIndex(
        (e: any) =>
          e.akaTpKeyIdValue === value.akaTpKeyIdValue &&
          e.akaAlgTypeId === value.akaAlgTypeId &&
          e.manufactureId === value.manufactureId
      );
      const akaRequiredArray = [...tempAkaKeyId];
      akaRequiredArray.splice(gettingIndex, 1);
      setTempAkaKeyId([...akaRequiredArray]);
    }
  };

  return (
    <>
      <DeleteModal
        isOpen={isModalOpen}
        handleConfirm={handleDelete}
        handleCancel={() => setIsModalOpen(false)}
      />
      <Box component="form" onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={1}>
          <Grid item xs={12}>
            <Box
              sx={{
                backgroundColor: "#F3F4FF",
                padding: "20px"
              }}
            >
              <Grid container spacing={2}>
                <Grid item xs={4}>
                  <FormControllerTextField
                    control={control}
                    controlName="akaHlrName"
                    inputLabel="AKA HLR Name"
                    required
                  />
                </Grid>
                <Grid item xs={4}>
                  <FormControllerTextField
                    control={control}
                    controlName="inputFileValue"
                    inputLabel="Input File-Value"
                    required
                  />
                </Grid>
                <Grid item xs={4}>
                  <FormControllerSelectWithSearch
                    control={control}
                    controlName="fileEnding"
                    inputLabel="File Ending"
                    options={fileExtension}
                  />
                </Grid>
              </Grid>
              {selectedAka && (
                <LastUpdated lastUpdatedDate={selectedAka?.dateUpdated} />
              )}
            </Box>
          </Grid>
          <Grid item xs={12} spacing={1}>
            <Grid container>
              <Grid item xs={6}>
                <SecondaryHeader title={"AKA Algorithm ID Input"} />
              </Grid>
              <Grid item xs={6}>
                <SecondaryHeader
                  title={"Assignment of the AKA Algorithm IDs"}
                />
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12} spacing={2}>
            <Grid container>
              <Grid item xs={5}>
                <Table
                  stickyHeader
                  size="small"
                  sx={{ backgroundColor: "#F3F4FF" }}
                >
                  <TableHead>
                    <TableRow>
                      {secondaryTableHeader.map(({ label, id }, i) => {
                        return (
                          <TableCell
                            sx={{
                              backgroundColor: "#031a34",
                              color: "white",
                              borderRight:
                                i !== secondaryTableHeader.length - 1
                                  ? "1px solid white"
                                  : ""
                            }}
                            key={label}
                          >
                            {t(label)}
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {akaAlgorithmIdValues.map((akaAlgorithmIdValue, index) => (
                      <TableRow>
                        <TableCell
                          align="center"
                          sx={{
                            color: "white",
                            borderRight: "1px solid white",
                            padding: 0
                          }}
                        >
                          <Autocomplete
                            id="akaAlgorithm"
                            value={akaAlgorithmIdValue?.akaAlgTypeId}
                            options={akaAlgorithmDropDown}
                            onChange={(e, val) => {
                              const akaAlg = [...akaAlgorithmIdValues];
                              akaAlg[index].akaAlgTypeId = val;
                              setAkaAlgorithmIdValues(akaAlg);
                            }}
                            renderInput={(params) => <TextField {...params} />}
                          />
                        </TableCell>
                        <TableCell sx={{ padding: 0 }}>
                          <TextField
                            value={akaAlgorithmIdValue?.akaAlgIdValue}
                            onChange={(e) => {
                              if (
                                /^\d+$/.test(e.target.value) ||
                                e.target.value === ""
                              ) {
                                const akaAlg = [...akaAlgorithmIdValues];
                                akaAlg[index].akaAlgIdValue = e.target.value;
                                setAkaAlgorithmIdValues(akaAlg);
                              }
                            }}
                            style={{ background: "none", width: "100%" }}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </Grid>
              <Grid item xs={1}>
                <Stack spacing={2} alignItems="center">
                  <Button
                    variant="contained"
                    style={{
                      backgroundColor: checkValidAkaAlgorithm(
                        akaAlgorithmIdValues
                      )
                        ? "blue"
                        : "#c3c4c7"
                    }}
                    onClick={akaAlgorithmRightIconClickHandler}
                    disabled={!checkValidAkaAlgorithm(akaAlgorithmIdValues)}
                  >
                    <KeyboardArrowRightIcon />
                  </Button>
                  <Button
                    variant="contained"
                    style={{
                      backgroundColor: `${
                        tempAkaAlgorithm?.length ? "blue" : " #c3c4c7"
                      }`
                    }}
                    onClick={akaAlgorithmLeftIconClickHandler}
                    disabled={!tempAkaAlgorithm?.length}
                  >
                    <KeyboardArrowLeftIcon />
                  </Button>
                </Stack>
              </Grid>
              <Grid item xs={6}>
                <Controller
                  name={"assocAkaAlgId"}
                  control={control}
                  rules={{ required: false }}
                  render={({ field, fieldState }) => {
                    return (
                      <>
                        <TableWithCheckBox
                          isLoading={reloadAssocAkaAlgId}
                          visibleHeadCells={secondaryTableHeader}
                          visibleItems={field.value}
                          handleCheckBoxClick={(checked, value) => {
                            handleAssignmentAlgIdSelection(checked, value);
                          }}
                          tableConfig={tableConfig}
                        />
                      </>
                    );
                  }}
                />
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12} spacing={1}>
            <Grid container>
              <Grid item xs={6}>
                <SecondaryHeader title={"AKA TP Key ID Input"} />
              </Grid>
              <Grid item xs={6}>
                <SecondaryHeader title={"Assignment of the AKA TP Key IDs"} />
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12} spacing={2}>
            <Grid container>
              <Grid item xs={5}>
                <Table
                  stickyHeader
                  size="small"
                  sx={{ backgroundColor: "#F3F4FF" }}
                >
                  <TableHead>
                    <TableRow>
                      {tertiaryTableHeader.map(({ label, id }, i) => {
                        return (
                          <TableCell
                            sx={{
                              backgroundColor: "#031a34",
                              color: "white",
                              borderRight:
                                i !== tertiaryTableHeader.length - 1
                                  ? "1px solid white"
                                  : ""
                            }}
                            key={label}
                          >
                            {t(label)}
                          </TableCell>
                        );
                      })}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {akaAlgorithmKeyIdValues.map(
                      (akaAlgorithmKeyIdValue, index) => (
                        <TableRow>
                          <TableCell
                            align="center"
                            sx={{
                              borderRight: "1px solid white",
                              padding: 0
                            }}
                          >
                            <Autocomplete
                              id="akaAlgorithmKeyIdAlg"
                              value={akaAlgorithmKeyIdValue?.akaAlgTypeId}
                              options={akaAlgorithmDropDown}
                              onChange={(e, val) => {
                                const akaAlg = [...akaAlgorithmKeyIdValues];
                                akaAlg[index].akaAlgTypeId = val;
                                setAkaAlgorithmKeyIdValues(akaAlg);
                              }}
                              renderInput={(params) => (
                                <TextField
                                  {...params}
                                  sx={{ background: "none" }}
                                />
                              )}
                            />
                          </TableCell>
                          <TableCell
                            align="center"
                            sx={{
                              borderRight: "1px solid white",
                              padding: 0
                            }}
                          >
                            <Autocomplete
                              id="akaAlgorithmKeyIdMfg"
                              value={
                                akaAlgorithmKeyIdValue?.manufactureId?.label
                              }
                              options={simVendors.map((e) => {
                                return { id: e.id, label: e.name };
                              })}
                              onChange={(e, val) => {
                                const akaAlg = [...akaAlgorithmKeyIdValues];
                                akaAlg[index].manufactureId = val;
                                setAkaAlgorithmKeyIdValues(akaAlg);
                              }}
                              renderInput={(params) => (
                                <TextField {...params} />
                              )}
                            />
                          </TableCell>
                          <TableCell sx={{ padding: 0 }}>
                            <TextField
                              value={akaAlgorithmKeyIdValue.akaTpKeyIdValue}
                              onChange={(e) => {
                                if (
                                  (/^\d+$/.test(e.target.value) ||
                                    /-/.test(e.target.value) ||
                                    e.target.value === "") &&
                                  !e.target.value.startsWith("-")
                                ) {
                                  const akaAlg = [...akaAlgorithmKeyIdValues];
                                  akaAlg[index].akaTpKeyIdValue =
                                    e.target.value;
                                  setAkaAlgorithmKeyIdValues(akaAlg);
                                }
                              }}
                              style={{ background: "none", width: "100%" }}
                            />
                          </TableCell>
                        </TableRow>
                      )
                    )}
                  </TableBody>
                </Table>
              </Grid>
              <Grid item xs={1}>
                <Stack spacing={2} alignItems="center">
                  <Button
                    variant="contained"
                    disabled={!checkValidAlgorithmId(akaAlgorithmKeyIdValues)}
                    style={{
                      backgroundColor: `${
                        checkValidAlgorithmId(akaAlgorithmKeyIdValues)
                          ? "blue"
                          : " #c3c4c7"
                      }`
                    }}
                    onClick={akaAlgorithmKeyIdRightIconClickHandler}
                  >
                    <KeyboardArrowRightIcon />
                  </Button>
                  <Button
                    variant="contained"
                    style={{
                      backgroundColor: `${
                        tempAkaKeyId?.length ? "blue" : " #c3c4c7"
                      }`
                    }}
                    onClick={akaAlgorithmKeyIdLeftIconClickHandler}
                    disabled={!tempAkaKeyId?.length}
                  >
                    <KeyboardArrowLeftIcon />
                  </Button>
                </Stack>
              </Grid>
              <Grid item xs={6}>
                <Controller
                  name={"assocAkaTpKeyId"}
                  control={control}
                  rules={{ required: false }}
                  render={({ field, fieldState }) => {
                    return (
                      <>
                        <TableWithCheckBox
                          isLoading={reloadAssocAkaKeyId}
                          visibleHeadCells={tertiaryTableHeader}
                          visibleItems={field.value}
                          handleCheckBoxClick={(checked, value) => {
                            handleAssignmentTpKeySelection(checked, value);
                          }}
                          tableConfig={tableConfig}
                        />
                      </>
                    );
                  }}
                />
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12}>
            <Grid container>
              <Grid item xs={12}>
                <FormActionButtons
                  onCancel={cancelAllChanges}
                  onDelete={handleDeleteConfirmation}
                  onActiveNArchive={handleArchiveAkas}
                  selectedData={selectedAka}
                  submitDisabled={isLoadingCreate || isLoadingUpdate}
                  cancelDisabled={isLoadingCreate || isLoadingUpdate}
                  isArchiveVisible={!selectedAka?.archived}
                  isActiveVisible={selectedAka?.archived}
                  isDeleteVisible={!selectedAka?.isReferenceExist}
                />
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Box>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedAka: state.aka.selectedAka,
  simVendors: state.simVendor.simVendros,
  isLoadingCreate: state.aka.isLoadingCreate,
  isLoadingUpdate: state.aka.isLoadingUpdate,
  archiveMsg: state.aka.archiveMsg,
  isArchiveRequestSuccessful: state.aka.isArchiveRequestSuccessful,
  allHlrNames: state.cardType.hlrValues
});

const connector = connect(mapStateToProps, {
  createAka,
  fetchAkas,
  fetchSimVendors,
  updateAka,
  setSelectedAKA,
  deleteAka,
  archiveAka,
  resetAka,
  showFailureSnackbar,
  showSuccessSnackbar,
  loadAllAkaHLRValues
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(AkaAddEditForm);
