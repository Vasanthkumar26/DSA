import React, { FC, useState } from "react";
import { Box, Grid } from "@mui/material";
import Header from "./AkaHeader";
import AkaTable from "./AkaTable";
import AkaAddEditForm from "./AkaAddEditForm";
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";

const AKA: FC = () => {
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);

  const selectedAka = useSelector((state: RootState) => state.aka.selectedAka);

  return (
    <>
      <Box sx={{ padding: 2 }}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <Header
              isArchivedVisible={isArchivedVisible}
              setIsArchivedVisible={setIsArchivedVisible}
              setShowForm={setShowForm}
            />
            <AkaTable
              isArchivedVisible={isArchivedVisible}
              setShowForm={setShowForm}
            />
          </Grid>
        </Grid>
      </Box>
      <Grid container sx={{ padding: 2 }}>
        <Grid item xs={12}>
          {(selectedAka || showForm) && (
            <AkaAddEditForm
              setShowForm={setShowForm}
              isArchivedVisible={isArchivedVisible}
            />
          )}
        </Grid>
      </Grid>
    </>
  );
};

export default AKA;
