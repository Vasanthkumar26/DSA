import * as yup from "yup";
import { akaAlgorithm, akaTpKey, TableConfig } from "../../models";
export const fileExtension = [
  { label: ".txt", id: ".txt" },
  { label: ".json", id: ".json" },
  { label: ".xml", id: ".xml" },
  { label: ".csv", id: ".csv" },
  { label: "hlr.xml", id: "hlr.xml" },
  { label: "sM2M.xml", id: "sM2M.xml" }
];

export const secondaryTableHeader = [
  { label: "AKA Algorithm", id: "akaAlgTypeId" },
  { label: "AKA Algorithm ID", id: "akaAlgIdValue" }
];

export const tertiaryTableHeader = [
  { label: "AKA Algorithm", id: "akaAlgTypeId" },
  { label: "SIM Vendor", id: "manufactureId" },
  { label: "AKA TP Key ID", id: "akaTpKeyIdValue" }
];

export const akaAlgorithmDropDown = [
  { label: "TBD", value: "tbd", key: 0, id: 0 },
  { label: "MILENAGE", value: "milenage", key: 1, id: 1 },
  { label: "TUAK16", value: "tuak16", key: 2, id: 2 },
  { label: "TUAK32", value: "tuak32", key: 3, id: 3 }
];

export const tableConfig: TableConfig = {
  title: "AKA Algorithm",
  orderBy: "dateUpdated",
  tableRowTestId: "aka-row"
};

export const customProfileSchema = (fetchedHlrNames: Array<string>) =>
  yup.object().shape({
    akaHlrName: yup
      .string()
      .required("AKA HLR name should not be empty")
      .notOneOf(
        [...(fetchedHlrNames ? fetchedHlrNames : [])],
        "aka_name_already_exists"
      ),
    inputFileValue: yup
      .string()
      .required("AKA Input File Value should not be empty")
  });

export const initAkaHlrData = {
  akaHlrName: "",
  inputFileValue: "",
  fileEnding: { label: ".txt", id: ".txt" },
  archived: false,
  userUpdated: 1,
  assocAkaAlgId: [],
  assocAkaTpKeyId: []
};

export const initialAkaAlgorithmIdValues: akaAlgorithm = {
  akaAlgTypeId: { label: "TBD", value: "tbd", key: 0, id: 0 },
  akaAlgIdValue: ""
};

export const initialAkaAlgorithmKeyIdValues: akaTpKey = {
  akaAlgTypeId: { label: "TBD", value: "tbd", key: 0, id: 0 },
  manufactureId: { label: "", id: "" },
  akaTpKeyIdValue: ""
};
