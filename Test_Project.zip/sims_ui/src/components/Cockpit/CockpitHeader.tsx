import { Dispatch, FC, SetStateAction, useCallback } from "react";
import { ConnectedProps, connect } from "react-redux";
import TableHeader from "../common/TableHeader";
import { RootState } from "../../redux/store";
import { setSelectedCockpit } from "../../redux/actions/cockpitAction";

interface Props extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const CockpitHeader: FC<Props> = ({ setShowForm, setSelectedCockpit }) => {
  const handleAdd = useCallback(() => {
    setSelectedCockpit(null);
    setShowForm(true);
  }, [setSelectedCockpit, setShowForm]);

  return (
    <TableHeader
      title="Cockpit"
      isLoadingExport={false}
      isArchivedVisible={false}
      handleArchiveChange={() => {}}
      handleExport={() => {}}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({});

const connector = connect(mapStateToProps, {
  setSelectedCockpit,
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(CockpitHeader);
