import React, { FC, useCallback } from "react";
import { Button, FormControlLabel, Grid, Radio, Stack } from "@mui/material";
import { ConnectedProps, connect } from "react-redux";
import { StyledFormBox } from "../common/styles/shared";
import { FormControllerTextField } from "../common/AddEditForm";
import { useForm } from "react-hook-form";
import { searchCriteriaInitData, searchCriteriaSchema } from "./Cockpit.data";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import { FormControllerDatePicker } from "../common/AddEditForm/FormControllerDatePicker";
import { FormControllerRadioGroup } from "../common/AddEditForm/FormControllerRadioGroup";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import { SPSelectWithSearch } from "../common/AddEditForm/SPSelectWithSearch";
import { ISelectionOption } from "../../models";

interface Props extends PropsFromRedux {
  orderStatus: ISelectionOption[] | null;
  customProfiles: ISelectionOption[] | null;
  kittingArticles: ISelectionOption[] | null;
}

const IndividualSearch: FC<Props> = ({
  orderStatus,
  customProfiles,
  kittingArticles
}) => {
  const resolver = useYupValidationResolver(searchCriteriaSchema);

  const { control, handleSubmit, reset } = useForm({
    mode: "all",
    resolver,
    defaultValues: { ...searchCriteriaInitData }
  });

  const onSubmit = useCallback((data: any) => {
    console.log("data", data);
  }, []);

  return (
    <StyledFormBox component="form" onSubmit={handleSubmit(onSubmit)} my={2}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <FormControllerRadioGroup
            control={control}
            controlName="orderType"
            inputLabel="Order Type:"
          >
            <FormControlLabel
              value="simKitting"
              control={<Radio />}
              label="SIM & Kitting"
            />
            <FormControlLabel
              value="onlySim"
              control={<Radio />}
              label="Only SIM"
            />
            <FormControlLabel
              value="onlyKitting"
              control={<Radio />}
              label="Only Kitting"
            />
          </FormControllerRadioGroup>
        </Grid>
        <Grid item xs={4}>
          <FormControllerTextField
            control={control}
            controlName="orderNumberContains"
            inputLabel="order_number_contains"
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerDatePicker
            control={control}
            controlName="entryDateFrom"
            inputLabel="entry_date_from"
            isFutureDisable
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerDatePicker
            control={control}
            controlName="entryDateTo"
            inputLabel="entry_date_to"
            isFutureDisable
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerSelectWithSearch
            control={control}
            controlName="orderStatus"
            inputLabel="order_status"
            options={orderStatus ?? []}
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerDatePicker
            control={control}
            controlName="deliveryDateFrom"
            inputLabel="delivery_date_from"
            isFutureDisable
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerDatePicker
            control={control}
            controlName="deliveryDateTo"
            inputLabel="delivery_date_to"
            isFutureDisable
          />
        </Grid>
        <Grid item xs={4}>
          <SPSelectWithSearch
            control={control}
            controlName="serviceProvider"
            inputLabel="serv_provider"
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerSelectWithSearch
            control={control}
            controlName="itemNumber"
            inputLabel="item_number"
            options={kittingArticles ?? []}
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerSelectWithSearch
            control={control}
            controlName="cardType"
            inputLabel="card_type"
            options={[
              { id: 1, label: "test" },
              { id: 2, label: "test2" }
            ]}
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerSelectWithSearch
            control={control}
            controlName="manufacturer"
            inputLabel="manufacturer"
            options={[
              { id: 1, label: "test" },
              { id: 2, label: "test2" }
            ]}
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerSelectWithSearch
            control={control}
            controlName="productType"
            inputLabel="product_type"
            options={[
              { id: 1, label: "test" },
              { id: 2, label: "test2" }
            ]}
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerSelectWithSearch
            control={control}
            controlName="nwMan"
            inputLabel="NW Man"
            options={[
              { id: 1, label: "test" },
              { id: 2, label: "test2" }
            ]}
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerSelectWithSearch
            control={control}
            controlName="electricalProfile"
            inputLabel="Electrical Profile"
            options={[
              { id: 1, label: "test" },
              { id: 2, label: "test2" }
            ]}
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerSelectWithSearch
            control={control}
            controlName="customProfile"
            inputLabel="Custom Profile"
            options={customProfiles ?? []}
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerTextField
            control={control}
            controlName="batchld"
            inputLabel="Batchld"
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerTextField
            control={control}
            controlName="iccid"
            inputLabel="ICCID"
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerTextField
            control={control}
            controlName="imsi"
            inputLabel="IMSI"
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerTextField
            control={control}
            controlName="msisdn"
            inputLabel="MSISDN"
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerSelectWithSearch
            control={control}
            controlName="articleType"
            inputLabel="article_type"
            options={[
              { id: 1, label: "test" },
              { id: 2, label: "test2" }
            ]}
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerTextField
            control={control}
            controlName="archiveDocument"
            inputLabel="archive_document"
          />
        </Grid>
        <Grid item xs={4}>
          <FormControllerSelectWithSearch
            control={control}
            controlName="originator"
            inputLabel="Originator"
            options={[
              { id: 1, label: "test" },
              { id: 2, label: "test2" }
            ]}
          />
        </Grid>
        <Grid item xs={12}>
          <Stack direction="row-reverse" spacing={2}>
            <Button
              variant="contained"
              onClick={() => reset({ ...searchCriteriaInitData })}
            >
              Reset
            </Button>
          </Stack>
        </Grid>
      </Grid>
    </StyledFormBox>
  );
};

const connector = connect(null, {});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(IndividualSearch);
