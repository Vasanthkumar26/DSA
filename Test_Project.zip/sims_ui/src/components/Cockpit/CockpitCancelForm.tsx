import { FC, useState } from "react";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import { Box, Button, Grid, Stack } from "@mui/material";
import { FormControllerTextField } from "../common/AddEditForm";
import { useForm } from "react-hook-form";
import { useTranslation } from "../../hooks/useTranslation";
import CancelModal from "../common/modals/CancelModal";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import { CancelOrderSchema } from "./Cockpit.data";
import {
  cancelCockpit,
  setSelectedCockpit,
  cancelSimOrders
} from "../../redux/actions/cockpitAction";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";

interface Props extends PropsFromRedux {}

const CockpitCancelForm: FC<Props> = ({
  selectedCockpit,
  setSelectedCockpit,
  cancelCockpit,
  showFailureSnackbar,
  showSuccessSnackbar,
  cancelSimOrders
}) => {
  const t = useTranslation();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [clickType, setClickType] = useState("");
  const resolver = useYupValidationResolver(CancelOrderSchema);
  const { control, handleSubmit, reset } = useForm({
    mode: "all",
    resolver
  });

  const handleConfirm = (text: string) => {
    cancelCockpit(Number(selectedCockpit?.orderNumber), text)
      .then(() => {
        showSuccessSnackbar(t("request_processed_successfully"));
        setSelectedCockpit(null);
        setIsModalOpen(false);
        reset({
          name: ""
        });
      })
      .catch((error) => {
        showFailureSnackbar(t("error_while_submitting_data") || error);
        setSelectedCockpit(null);
        setIsModalOpen(false);
        reset({
          name: ""
        });
      });
  };

  const handleCancelSim = (text: string) => {
    cancelSimOrders(
      Number(selectedCockpit?.orderNumber),
      text,
      Number(clickType)
    )
      .then(() => {
        showSuccessSnackbar(t("request_processed_successfully"));
        setSelectedCockpit(null);
        setIsModalOpen(false);
        reset({
          name: ""
        });
      })
      .catch((error) => {
        showFailureSnackbar(t("error_while_submitting_data") || error);
        setSelectedCockpit(null);
        setIsModalOpen(false);
        reset({
          name: ""
        });
      });
  };

  const onSubmit = (data: any) => {
    if (data.name) {
      setIsModalOpen(true);
      setMessage(data.name);
    }
  };
  let dialogMessage = "";
  if (clickType === "cancelKitting") {
    dialogMessage = "cancel_confirmation";
  }
  if (clickType === "1") {
    dialogMessage = "Confirm to cancel workflow and Release resources?";
  }
  if (clickType === "0") {
    dialogMessage = "Confirm to cancel workflow without Releasing resources?";
  }
  return (
    <>
      <CancelModal
        isOpen={isModalOpen}
        handleConfirm={() =>
          clickType === "cancelKitting"
            ? handleConfirm(message)
            : handleCancelSim(message)
        }
        handleCancel={() => setIsModalOpen(false)}
        confirmMessage={dialogMessage}
      />
      <Box component="form" paddingTop={1} onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6} md={4}>
            <FormControllerTextField
              control={control}
              controlName="name"
              inputLabel="Reason for cancellation"
              multiline
              rows={6}
              required
            />
          </Grid>
          <Grid
            item
            xs={12}
            sm={6}
            md={4}
            flexDirection={"column"}
            display={"flex"}
          >
            {selectedCockpit?.oaRefPoPk?.charAt(0) === "k" && (
              <Stack
                direction="row"
                justifyContent="flex-start"
                marginTop={"auto"}
              >
                <Button
                  variant="contained"
                  type="submit"
                  data-testid="active"
                  onClick={() => setClickType("cancelKitting")}
                >
                  {t("Cancel workflow")}
                </Button>
              </Stack>
            )}{" "}
            {selectedCockpit?.oaRefPoPk?.charAt(0) !== "k" && (
              <Stack
                direction="column"
                justifyContent="flex-start"
                marginTop={"auto"}
              >
                <Button
                  sx={{ marginBottom: "12px" }}
                  variant="contained"
                  type="submit"
                  data-testid="cancelSimMit"
                  onClick={() => setClickType("1")}
                >
                  {t("Cancel workflow and release resources")}
                </Button>
                <Button
                  variant="contained"
                  type="submit"
                  data-testid="cancelSimOhne"
                  onClick={() => setClickType("0")}
                >
                  {t("Cancel workflow without releasing resources")}
                </Button>
              </Stack>
            )}
          </Grid>
        </Grid>
      </Box>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedCockpit: state.cockpit.selectedCockpit
});

const connector = connect(mapStateToProps, {
  cancelCockpit,
  setSelectedCockpit,
  showFailureSnackbar,
  showSuccessSnackbar,
  cancelSimOrders
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(CockpitCancelForm);
