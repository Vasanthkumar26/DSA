import React, { FC, useEffect, useState } from "react";
import { Grid } from "@mui/material";
import LabelValue from "./LabelValue";
import { StyledFormBox } from "../common/styles/shared";
import { useTranslation } from "../../hooks/useTranslation";
import { ConnectedProps, connect } from "react-redux";
import { RootState } from "../../redux/store";
import { showFailureSnackbar } from "../../redux/actions/snackbarAction";
import { handleFetchOrderDetails } from "../../services/cockpitApi";
import { OrderDetail } from "../../models";

interface Props extends PropsFromRedux {}

const OrderDetails: FC<Props> = ({ selectedCockpit }) => {
  const [oDetail, setODetail] = useState<OrderDetail | null>(null);
  const t = useTranslation();

  useEffect(() => {
    if (selectedCockpit) {
      handleFetchOrderDetails(selectedCockpit?.orderNumber ?? "")
        .then((result) => setODetail(result?.[0]))
        .catch(() =>
          showFailureSnackbar("Error while fetching personal queries")
        );
    }
  }, [selectedCockpit]);

  const { orderNumber = "" } = selectedCockpit ?? {};
  const {
    organization = "",
    creationDate = "",
    expectedDeliveryDate = "",
    noOfSimCards = "",
    article = "",
    description = "",
    serviceProvider = "",
    startPackType = "",
    msisdnType = "",
    packs = "",
    status = "",
    originator = "",
    simstatus = ""
  } = oDetail ?? {};

  return (
    <StyledFormBox mt={2}>
      <Grid container spacing={4}>
        <Grid item xs={4}>
          <LabelValue label={t("orderNumber")} value={orderNumber} />
          <LabelValue label={t("Organisation")} value={organization} />
          <LabelValue label={t("cp_order_date")} value={creationDate} />
          <LabelValue label={t("delivery_date")} value={expectedDeliveryDate} />
          <LabelValue label={t("cp_sim_no_cards")} value={noOfSimCards} />
          <LabelValue label={t("cp_article_no")} value={article} />
          <LabelValue label={t("item_description")} value={description} />
        </Grid>
        <Grid item xs={4}>
          <LabelValue label={t("Service Provider")} value={serviceProvider} />
          <LabelValue label={t("Starter-Pack-ID")} value={startPackType} />
          <LabelValue label={t("MSSISDN Type")} value={msisdnType} />
          <LabelValue label={t("Pre-Barred")} value={organization} />
          <LabelValue label={t("Tarif-Option")} value={organization} />
          <LabelValue label={t("Packaging-Type")} value={organization} />
          <LabelValue label={t("Initial Credit")} value={organization} />
        </Grid>
        <Grid item xs={4}>
          <LabelValue label={t("Packs")} value={packs} />
          <LabelValue label={t("Order Status")} value={status} />
          <LabelValue label={t("SIM Status")} value={simstatus} />
          <LabelValue label={t("Originator")} value={originator} />
        </Grid>
      </Grid>
    </StyledFormBox>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedCockpit: state.cockpit.selectedCockpit
});

const connector = connect(mapStateToProps, {
  showFailureSnackbar
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(OrderDetails);
