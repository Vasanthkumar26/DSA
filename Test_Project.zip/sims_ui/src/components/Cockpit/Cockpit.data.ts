import { HeadCell, TableConfig } from "../../models";
import * as yup from "yup";
import { DocumentUpload } from "../../models/cockpit.model";

export const cockpitHeadCells: Array<HeadCell> = [
  { id: "orderNumber", label: "orderNumber" },
  { id: "articleNumber", label: "articleNumber" },
  { id: "itemDescription", label: "item_description" },
  { id: "crowd", label: "crowd" },
  { id: "status", label: "Status" },
  { id: "serviceProvider", label: "Service Provider" },
  { id: "registerDate", label: "register_date" },
  { id: "deliveryDate", label: "delivery_date" }
];

export const documentHeadCells: Array<HeadCell> = [
  { id: "document", label: "Document" },
  { id: "name", label: "Name" },
  { id: "importDate", label: "Import Date" },
  { id: "action", label: "Action" }
];
export const cockpitTableConfig: TableConfig = {
  title: "Cockpit",
  orderBy: "lastUpdateDate",
  tableRowTestId: "cockpit-row"
};

export const documentTableConfig: TableConfig = {
  title: "Document",
  orderBy: "lastUpdateDate",
  tableRowTestId: "document-row"
};

export const initDocumentUpload: DocumentUpload = {
  filetypeId: null,
  selectedFile: null
};
export const CancelOrderSchema = yup.object().shape({
  name: yup.string().required("Reason for cancellation is required")
});

export const searchCriteriaSchema = yup.object().shape({
  name: yup.string().required("Name is missing"),
  emailAddress: yup
    .string()
    .required("Please provide and confirm an Email address")
    .email("Please provide a valid email address")
    .max(255, "Sorry, we can only accept a maximum of 255 characters"),
  replyAddress: yup
    .string()
    .required("Please provide and confirm an Email address")
    .email("Please provide a valid email address")
    .max(255, "Sorry, we can only accept a maximum of 255 characters"),
  subject: yup.string().required("Subject is missing")
});

export const uploadDocumetSchema = yup.object().shape({
  filetypeId: yup
    .object()
    .shape({
      label: yup.string().required(),
      id: yup.string().required()
    })
    .typeError("file_type_is_required")
    .required("file_type_is_required")
});

export const searchCriteriaInitData = {
  orderType: "simKitting",
  orderNumberContains: "",
  entryDateFrom: "",
  entryDateTo: "",
  orderStatus: null,
  deliveryDateFrom: "",
  deliveryDateTo: "",
  itemNumber: null,
  cardType: null,
  manufacturer: null,
  productType: null,
  nwMan: null,
  electricalProfile: null,
  customProfile: null,
  batchld: "",
  iccid: "",
  imsi: "",
  msisdn: "",
  articleType: null,
  archiveDocument: "",
  originator: null
};
