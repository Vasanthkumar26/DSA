import { Stack, Typography } from "@mui/material";
import { FC } from "react";

interface Props {
  label: string;
  value: string;
}

const LabelValue: FC<Props> = ({ label, value }) => {
  return (
    <Stack direction="row" justifyContent="space-between">
      <Typography variant="body2" gutterBottom>
        {`${label}:`}
      </Typography>
      <Typography variant="body2" gutterBottom>
        {value ?? ""}
      </Typography>
    </Stack>
  );
};

export default LabelValue;
