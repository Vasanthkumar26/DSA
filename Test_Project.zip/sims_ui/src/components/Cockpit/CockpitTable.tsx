import React, { FC, useCallback, useEffect, useMemo, useState } from "react";
import { Grid } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import {
  fetchCockpit,
  setSelectedCockpit
} from "../../redux/actions/cockpitAction";
import { connect, ConnectedProps } from "react-redux";
import FilterSearchBar from "../common/FilterSearchBar";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";
import { cockpitHeadCells, cockpitTableConfig } from "./Cockpit.data";
import PersonalizedQueries from "./PersonalizedQueries";

interface Props extends PropsFromRedux {}

const CockpitTable: FC<Props> = ({
  isLoadingFetch,
  fetchCockpit,
  setSelectedCockpit,
  cockpits = []
}) => {
  const [orderNumberFilter, setOrderNumberFilter] = useState("");
  const [articleNumberFilter, setArticleNumberFilter] = useState("");
  const [itemDescriptionFilter, setItemDescriptionFilter] = useState("");
  const [crowdFilter, setCrowdFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [serviceProviderFilter, setServiceProviderFilter] = useState("");
  const [registerDateFilter, setRegisterDateFilter] = useState("");
  const [deliveryDateFilter, setDeliveryDateFilter] = useState("");
  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchCockpit())();
  }, [fetchCockpit]);

  let visibleCockpits = cockpits?.filter(
    (cockpit) =>
      cockpit.orderNumber.includes(orderNumberFilter) &&
      cockpit.articleNumber.includes(articleNumberFilter) &&
      cockpit.itemDescription.includes(itemDescriptionFilter) &&
      cockpit.crowd.includes(crowdFilter) &&
      cockpit.status.includes(statusFilter) &&
      cockpit.serviceProvider.includes(serviceProviderFilter) &&
      cockpit.registerDate.includes(registerDateFilter) &&
      cockpit.deliveryDate.includes(deliveryDateFilter)
  );

  const filterHeadCellMap = {
    [cockpitHeadCells[0].id]: {
      filter: orderNumberFilter,
      setFilter: setOrderNumberFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cockpitHeadCells[1].id]: {
      filter: articleNumberFilter,
      setFilter: setArticleNumberFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cockpitHeadCells[2].id]: {
      filter: itemDescriptionFilter,
      setFilter: setItemDescriptionFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cockpitHeadCells[3].id]: {
      filter: crowdFilter,
      setFilter: setCrowdFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cockpitHeadCells[4].id]: {
      filter: statusFilter,
      setFilter: setStatusFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cockpitHeadCells[5].id]: {
      filter: serviceProviderFilter,
      setFilter: setServiceProviderFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cockpitHeadCells[6].id]: {
      filter: registerDateFilter,
      setFilter: setRegisterDateFilter,
      filterComponent: FilterSearchBar(t)
    },
    [cockpitHeadCells[7].id]: {
      filter: deliveryDateFilter,
      setFilter: setDeliveryDateFilter,
      filterComponent: FilterSearchBar(t)
    }
  };

  const resetAllFilters = useMemo(() => {
    return () => {
      setOrderNumberFilter("");
      setArticleNumberFilter("");
      setCrowdFilter("");
      setStatusFilter("");
      setServiceProviderFilter("");
      setRegisterDateFilter("");
      setDeliveryDateFilter("");
    };
  }, []);

  const handleRowSelected = async (row: any) => {
    setSelectedCockpit(row);
  };

  const handleRefresh = async () => {
    await fetchCockpit();
    resetAllFilters();
  };

  const handlePQSubmit = useCallback(() => {}, []);

  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={cockpitHeadCells}
        visibleItems={[...visibleCockpits]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={cockpitTableConfig}
        filterHeadCellMap={filterHeadCellMap}
        tableFooter={<PersonalizedQueries handleSubmit={handlePQSubmit} />}
      />
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.cockpit.isLoadingFetch,
  cockpits: state.cockpit.cockpits
});

const connector = connect(mapStateToProps, {
  fetchCockpit,
  setSelectedCockpit
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(CockpitTable);
