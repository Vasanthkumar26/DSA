import React, { FC, useEffect, useState } from "react";
import TableView from "../common/TableView";
import {
  documentHeadCells,
  documentTableConfig,
  initDocumentUpload,
  uploadDocumetSchema
} from "./Cockpit.data";

import { useTranslation } from "../../hooks/useTranslation";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import { fetchDocumentTable } from "../../redux/actions/cockpitAction";
import { Button, Grid, InputLabel, Stack, Typography } from "@mui/material";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import { Controller, useForm } from "react-hook-form";
import {
  handleFetchDownloadDocument,
  handleFetchFileType,
  handleUploadDocument
} from "../../services/cockpitApi";
import { ISelectionOption } from "../../models";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import { showSuccessSnackbar } from "../../redux/actions/snackbarAction";
interface Props extends PropsFromRedux {
  id: number;
  oaRefPoPk: number;
}
const initDropDownValue: ISelectionOption[] = [{ label: "", id: "" }];

const DocumentTable: FC<Props> = ({
  fetchDocumentTable,
  isLoadingTable,
  documentList,
  showSuccessSnackbar,
  id,
  oaRefPoPk
}) => {
  const [fileTypeOptions, setFileTypeOptions] = useState(initDropDownValue);
  const [isLoading, setIsLoading] = useState({
    isLoadingDownload: false,
    isLoadingUpload: false
  });

  const resolver = useYupValidationResolver(uploadDocumetSchema);

  const { control, handleSubmit, watch, reset } = useForm({
    mode: "all",
    resolver,
    reValidateMode: "onChange",
    defaultValues: { ...initDocumentUpload }
  });
  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchDocumentTable(id))();
  }, [fetchDocumentTable, id]);

  useEffect(() => {
    handleFetchFileType()
      .then((res) => {
        setFileTypeOptions(res);
      })
      .catch(() => {});
  }, []);

  const downloadDocument = async (id: string) => {
    try {
      setIsLoading((prevState) => ({
        ...prevState,
        isLoadingDownload: true
      }));
      await handleFetchDownloadDocument(id);
      setIsLoading((prevState) => ({
        ...prevState,
        isLoadingDownload: false
      }));
    } catch (error) {
      setIsLoading((prevState) => ({
        ...prevState,
        isLoadingDownload: false
      }));
    }
  };

  let visibleDocumentList = documentList?.map((item) => ({
    ...item,
    action: (
      <Button
        size="small"
        variant="contained"
        data-testid={item.name}
        disabled={isLoading.isLoadingDownload}
        onClick={() => downloadDocument(item.archiveId)}
        sx={{ width: "80%", margin: "3px", height: "20px" }}
      >
        Download
      </Button>
    )
  }));

  const handleRefresh = async () => {
    await fetchDocumentTable(id);
  };

  const fileName = watch("selectedFile");

  const returnBase64String = async (file: any) => {
    let File = file;
    const buffer = await File.arrayBuffer();
    const base64String = btoa(
      new Uint8Array(buffer).reduce(
        (data, byte) => data + String.fromCharCode(byte),
        ""
      )
    );
    return base64String;
  };

  const onSubmit = async (data: any) => {
    try {
      setIsLoading((prevState) => ({
        ...prevState,
        isLoadingUpload: true
      }));
      const base64 = await returnBase64String(data.selectedFile);
      const payload = {
        archiveDetails: {
          archiveFileType: data?.filetypeId?.id,
          fileName: data?.selectedFile?.name,
          mimeType: "application/zip",
          oaRefPoPk: oaRefPoPk,
          orderId: id
        },
        data: base64
      };
      const res = await handleUploadDocument(payload);
      if (res) {
        setIsLoading((prevState) => ({
          ...prevState,
          isLoadingUpload: !prevState.isLoadingUpload
        }));
        await handleRefresh();
        showSuccessSnackbar("File uploaded successful");
        reset({ ...initDocumentUpload });
      }
    } catch (error: any) {
      setIsLoading((prevState) => ({
        ...prevState,
        isLoadingUpload: false
      }));
      reset({ ...initDocumentUpload });
    }
  };

  return (
    <Stack>
      <TableView
        isLoading={isLoadingTable}
        visibleItems={visibleDocumentList}
        visibleHeadCells={documentHeadCells}
        handleRefresh={handleRefresh}
        tableConfig={documentTableConfig}
      />

      <Stack p={2} component="form" onSubmit={handleSubmit(onSubmit)}>
        <Grid container direction="row" alignItems="flex-start">
          <Grid item m={0} ml={-2} xs={2} sm={2} md={2}>
            <InputLabel required={true} htmlFor={"filetypeId"}>
              {t("File Type")}
            </InputLabel>
          </Grid>
          <Grid item xs={3} m={0} sm={3} md={3}>
            <FormControllerSelectWithSearch
              options={fileTypeOptions}
              control={control}
              controlName="filetypeId"
            />
          </Grid>
        </Grid>
        <Grid
          container
          direction="row"
          mt={2}
          spacing={2}
          alignItems="flex-start"
        >
          <InputLabel required={true} htmlFor={"filetypeId"}>
            {`${t("Document Archive")}:`}
          </InputLabel>
          <Stack ml={1}>
            <Controller
              name="selectedFile"
              control={control}
              defaultValue={null}
              render={({ field }) => (
                <>
                  <input
                    style={{ display: "none" }}
                    id="file-upload"
                    type="file"
                    onChange={(e) => {
                      field.onChange(e?.target?.files?.[0] ?? null);
                    }}
                  />
                  <label htmlFor="file-upload">
                    <Button
                      variant="contained"
                      className="customBtn bgbtn"
                      color="primary"
                      component="span"
                    >
                      {t("choose_file")}
                    </Button>
                  </label>
                </>
              )}
            />
          </Stack>
          <Typography mr={2} ml={2}>
            {fileName ? fileName.name : `${t("No choosen File")}`}
          </Typography>
          <Button
            disabled={isLoading.isLoadingUpload}
            onClick={handleSubmit(onSubmit)}
            variant="contained"
          >
            Upload
          </Button>
        </Grid>
      </Stack>
    </Stack>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingTable: state.cockpit.isLoadingDocument,
  documentList: state.cockpit.documentList
});

const connector = connect(mapStateToProps, {
  fetchDocumentTable,
  showSuccessSnackbar
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(DocumentTable);
