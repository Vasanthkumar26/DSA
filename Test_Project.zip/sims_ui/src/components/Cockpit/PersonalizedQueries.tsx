import React, { FC, useEffect, useState } from "react";
import { useTranslation } from "../../hooks/useTranslation";
import { Button, MenuItem, Select, Stack, Typography } from "@mui/material";
import { handleFetchCustomQueries } from "../../services/cockpitApi";
import { ConnectedProps, connect } from "react-redux";
import { showFailureSnackbar } from "../../redux/actions/snackbarAction";
import { CockpitQuery } from "../../models";

interface Props extends PropsFromRedux {
  handleSubmit: () => void;
}

const PersonalizedQueries: FC<Props> = ({
  handleSubmit,
  showFailureSnackbar
}) => {
  const [cQueries, setCQueries] = useState<CockpitQuery[] | null>(null);
  const t = useTranslation();

  useEffect(() => {
    if (!cQueries) {
      handleFetchCustomQueries()
        .then((result) => setCQueries(result))
        .catch(() =>
          showFailureSnackbar("Error while fetching personal queries")
        );
    }
  }, [cQueries, showFailureSnackbar]);

  return (
    <Stack direction="row" alignItems="center" spacing={2} my={2}>
      <Typography>{`${t("personlized_queries")}:`}</Typography>
      <Select
        size="small"
        sx={{ width: 300 }}
        value={cQueries?.[0]?.queryId ?? ""}
      >
        {(cQueries ?? []).map((item) => (
          <MenuItem key={item?.queryId} value={item?.queryId}>
            {item?.queryName}
          </MenuItem>
        ))}
      </Select>
      <Button variant="contained" onClick={handleSubmit}>
        {t("individual_query")}
      </Button>
    </Stack>
  );
};

const connector = connect(null, {
  showFailureSnackbar
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(PersonalizedQueries);
