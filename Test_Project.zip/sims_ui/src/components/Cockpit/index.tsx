import React, { FC, useEffect, useState } from "react";
import { Box, Grid, Typography } from "@mui/material";
import CockpitTable from "./CockpitTable";
import OrderDetails from "./OrderDetails";
import CockpitCancelForm from "./CockpitCancelForm";
import { RootState } from "../../redux/store";
import { useSelector } from "react-redux";
import PageTitle from "../common/PageTitle";
import DocumentTable from "./DocumentTable";
import { useTranslation } from "../../hooks/useTranslation";
import IndividualSearch from "./IndividualSearch";
import { ISelectionOption } from "../../models";
import {
  handleFetchCustomProfileData,
  handleFetchKittingArticle,
  handleFetchOrderStatus
} from "../../services/cockpitApi";

const Cockpit: FC = () => {
  const [oStatus, setOStatus] = useState<ISelectionOption[] | null>(null);
  const [cProfiles, setCProfiles] = useState<ISelectionOption[] | null>(null);
  const [kArticles, setKArticles] = useState<ISelectionOption[] | null>(null);
  const selectedCockpit = useSelector(
    (state: RootState) => state.cockpit.selectedCockpit
  );
  const t = useTranslation();

  useEffect(() => {
    !oStatus && handleFetchOrderStatus().then((result) => setOStatus(result));
    !cProfiles &&
      handleFetchCustomProfileData().then((result) => setCProfiles(result));
    !kArticles &&
      handleFetchKittingArticle().then((result) => setKArticles(result));
  }, [cProfiles, kArticles, oStatus]);

  return (
    <Box sx={{ padding: 2 }}>
      <PageTitle title="Cockpit" />
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <IndividualSearch
            orderStatus={oStatus}
            customProfiles={cProfiles}
            kittingArticles={kArticles}
          />
          <CockpitTable />
          {selectedCockpit && <OrderDetails />}
          {selectedCockpit?.workflowStatus[0]?.kittingStatus === "reserved" && (
            <CockpitCancelForm />
          )}
          {selectedCockpit && (
            <Grid container mt={3}>
              <Grid item sm={6} xs={6} md={6}>
                <Typography mt={2} mb={2}>{`${t(
                  "Archived Documents"
                )}`}</Typography>
                <DocumentTable
                  id={parseInt(selectedCockpit.orderNumber)}
                  oaRefPoPk={parseInt(selectedCockpit.oaRefPoPk)}
                />
              </Grid>
              <Grid item sm={6} xs={6} md={6}></Grid>
            </Grid>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default Cockpit;
