// @ts-nocheck
import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import LabelValue from "../LabelValue";

describe("LabelValue", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<LabelValue />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
