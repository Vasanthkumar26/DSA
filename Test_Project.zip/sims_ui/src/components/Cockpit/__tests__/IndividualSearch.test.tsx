// @ts-nocheck
import "@testing-library/jest-dom";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import IndividualSearch from "../IndividualSearch";
import { COCKPIT_SUCCESS_API_HANDLERS } from "../../../_mocks_";

describe("IndividualSearch", () => {
  createServer(COCKPIT_SUCCESS_API_HANDLERS);

  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<IndividualSearch />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
