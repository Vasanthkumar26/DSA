// @ts-nocheck
import "@testing-library/jest-dom";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import OrderDetails from "../OrderDetails";
import { COCKPIT_SUCCESS_API_HANDLERS } from "../../../_mocks_";

describe("OrderDetails", () => {
  createServer(COCKPIT_SUCCESS_API_HANDLERS);

  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<OrderDetails />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
