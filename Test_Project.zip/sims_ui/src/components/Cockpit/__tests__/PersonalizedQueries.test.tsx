// @ts-nocheck
import "@testing-library/jest-dom";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import PersonalizedQueries from "../PersonalizedQueries";
import { COCKPIT_SUCCESS_API_HANDLERS } from "../../../_mocks_";

describe("PersonalizedQueries", () => {
  createServer(COCKPIT_SUCCESS_API_HANDLERS);

  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<PersonalizedQueries />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
