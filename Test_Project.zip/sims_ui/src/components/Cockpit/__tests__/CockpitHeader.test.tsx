// @ts-nocheck
import "@testing-library/jest-dom";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import CockpitHeader from "../CockpitHeader";
import { COCKPIT_SUCCESS_API_HANDLERS } from "../../../_mocks_";

describe("CockpitHeader", () => {
  createServer(COCKPIT_SUCCESS_API_HANDLERS);
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<CockpitHeader />, {
      route: "/"
    });

    expect(container).toBeInTheDocument();
  });
});
