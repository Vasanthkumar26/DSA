//@ts-nocheck
import "@testing-library/jest-dom";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import {
  COCKPIT_FAILURE_API_HANDLERS,
  COCKPIT_SUCCESS_API_HANDLERS
} from "../../../_mocks_";
import DocumentTable from "../DocumentTable";
import { screen, waitFor, fireEvent } from "@testing-library/react";
import { wait } from "@testing-library/user-event/dist/utils";
describe("Document Table", () => {
  describe("API SUCCESS", () => {
    createServer(COCKPIT_SUCCESS_API_HANDLERS);

    test("Should render without crash", () => {
      const { container } = renderWithAllWrappers(<DocumentTable id={3} />);
      expect(container).toBeInTheDocument();
    });
    test("should show the correct result", async () => {
      renderWithAllWrappers(<DocumentTable id={2} />);
      await waitFor(async () => {
        const records = await screen.findAllByTestId(/document-row/i);
        expect(records).toHaveLength(2);
      });
    });

    test("download button should be in the document and called", async () => {
      renderWithAllWrappers(<DocumentTable id={2} />);
      const downloadBtn = await screen.findAllByRole("button", {
        name: /Download/i
      });

      //const downloadBtn = await screen.Test-123.xml
      expect(downloadBtn).toHaveLength(2);

      await waitFor(async () => {
        await fireEvent.click(downloadBtn[0]);
      });
    });

    test("submit button should be called", async () => {
      renderWithAllWrappers(<DocumentTable id={2} />);
      const uploadBtn = await screen.findByRole("button", { name: /Upload/i });
      await waitFor(async () => {
        await fireEvent.click(uploadBtn);
      });
      expect(uploadBtn).toBeInTheDocument();
    });

    test("should check", async () => {
      renderWithAllWrappers(<DocumentTable id={2} />);

      const choose = screen.getByRole("combobox");
      expect(choose).toBeInTheDocument();
      const file = new File(["file content"], "example.txt", {
        type: "text/plain"
      });

      await fireEvent.change(choose, { target: { files: [file] } });
      await wait();

      // const selectedFileName = await screen.findByText(/example.txt/i);
      expect(choose.value).toEqual("");
    });

    test.skip("Should test the submit button", async () => {
      const autocomplete = screen.getByTestId("kittingArticleNumber");
      const input = within(autocomplete).getByRole("combobox");
      autocomplete.focus();
      fireEvent.change(input, { target: { value: { label: "test", id: 12 } } });
      await wait();
      // navigate to the first item in the autocomplete box
      fireEvent.keyDown(autocomplete, { key: "ArrowDown" });
      await wait();
      // select the first item
      fireEvent.keyDown(autocomplete, { key: "Enter" });
      await wait();
      // check the new value of the input field
      expect(input.value).toEqual("test");
    });
  });

  describe("Failure", () => {
    createServer(COCKPIT_FAILURE_API_HANDLERS);
    test("Table should show zero data when server is down", async () => {
      renderWithAllWrappers(<DocumentTable id={4} />);
      await waitFor(async () => {
        const records = screen.queryAllByTestId(/document-row/i);
        expect(records).toHaveLength(0);
      });
    });
  });
});
