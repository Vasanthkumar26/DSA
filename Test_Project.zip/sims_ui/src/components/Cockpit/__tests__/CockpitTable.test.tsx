// @ts-nocheck
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import "@testing-library/jest-dom";
import { COCKPIT_SUCCESS_API_HANDLERS } from "../../../_mocks_";
import CockpitTable from "../CockpitTable";

describe("CockpitTable", () => {
  test("should render without crash", () => {
    const { container } = renderWithAllWrappers(<CockpitTable />);
    expect(container).toBeInTheDocument();
  });

  describe("API success", () => {
    createServer(COCKPIT_SUCCESS_API_HANDLERS);
    test("Table should show correct data", async () => {
      renderWithAllWrappers(<CockpitTable />);
    });
  });
});
