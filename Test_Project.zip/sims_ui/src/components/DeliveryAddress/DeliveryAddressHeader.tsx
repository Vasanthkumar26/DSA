import { FC, Dispatch, SetStateAction, useCallback } from "react";
import TableHeader from "../common/TableHeader";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import {
  fetchDeliveryAddressExport,
  setSelectedDeliveryAddress
} from "../../redux/actions/deliveryAddressAction";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setIsArchivedVisible: Dispatch<SetStateAction<boolean>>;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const DeliveryAddressHeader: FC<Props> = ({
  isArchivedVisible,
  setIsArchivedVisible,
  setShowForm,
  isLoadingExport,
  fetchDeliveryAddressExport,
  setSelectedDeliveryAddress
}) => {
  const handleArchiveChange = useCallback(() => {
    setIsArchivedVisible((prev) => !prev);
  }, [setIsArchivedVisible]);

  const handleExport = useCallback(() => {
    fetchDeliveryAddressExport(isArchivedVisible);
  }, [fetchDeliveryAddressExport, isArchivedVisible]);

  const handleAdd = useCallback(() => {
    setSelectedDeliveryAddress(null);
    setShowForm(true);
  }, [setSelectedDeliveryAddress, setShowForm]);

  return (
    <TableHeader
      title="Delivery address management"
      isLoadingExport={isLoadingExport}
      isArchivedVisible={isArchivedVisible}
      handleArchiveChange={handleArchiveChange}
      handleExport={handleExport}
      handleAdd={handleAdd}
    />
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingExport: state.deliverAddress.isLoadingExport
});

const connector = connect(mapStateToProps, {
  fetchDeliveryAddressExport,
  setSelectedDeliveryAddress
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(DeliveryAddressHeader);
