import { FC, useEffect, useMemo, useState } from "react";
import { TableConfig } from "../../models";
import { RootState } from "../../redux/store";
import { ConnectedProps, connect } from "react-redux";
import {
  fetchDeliverAddresses,
  setSelectedDeliveryAddress
} from "../../redux/actions/deliveryAddressAction";
import { useTranslation } from "../../hooks/useTranslation";
import { DeliveryAddress } from "../../models/deliveryAddress.model";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import { Grid } from "@mui/material";
import TableView from "../common/TableView";
import {
  headCells,
  archivedCell,
  deliverTypeCell,
  shipmentConfirmationCell
} from "./DeliveryAddress.data";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
}

const tableConfig: TableConfig = {
  title: "Delivery Address Administration",
  orderBy: "lastUpdateDate",
  tableRowTestId: "deliveryAddress-row"
};
const DeliverAddressTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchDeliverAddresses,
  setSelectedDeliveryAddress,
  deliverAddresses
}) => {
  const [nameFilter, setNameFilter] = useState("");
  const [companyNameFilter, setCompanyNameFilter] = useState("");
  const [deliveryTypeFilter, setDeliveryTypeFilter] = useState("");
  const [shipmentFilter, setShipmentFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const [emailIdFilter, setEmailIdFilter] = useState("");

  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchDeliverAddresses(isArchivedVisible))();
  }, [fetchDeliverAddresses, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const getArchivedFilter = (deliverAddress: DeliveryAddress) => {
    if (archivedFilter === "Yes") {
      return !!deliverAddress.archived;
    }
    return archivedFilter === "No" ? !deliverAddress.archived : true;
  };

  const getDeliveryTypeFilter = (deliverAddresses: DeliveryAddress) => {
    if (deliveryTypeFilter === "REST") {
      return !!deliverAddresses.deliveryType;
    }
    return deliveryTypeFilter === "Email"
      ? !deliverAddresses.deliveryType
      : true;
  };

  const getShipmentConfirmationFilter = (deliverAddresses: DeliveryAddress) => {
    if (shipmentFilter === "Yes") {
      return !!deliverAddresses.shipmentConfirmation;
    }
    return shipmentFilter === "No"
      ? !deliverAddresses.shipmentConfirmation
      : true;
  };

  let visibleDeliveryAddress = deliverAddresses?.filter(
    (deliverAddresses) =>
      deliverAddresses?.partyname?.includes(nameFilter) &&
      deliverAddresses?.contactName?.includes(companyNameFilter) &&
      getDeliveryTypeFilter(deliverAddresses) &&
      getShipmentConfirmationFilter(deliverAddresses) &&
      `${deliverAddresses?.emailId ?? ""}`?.includes(emailIdFilter) &&
      getArchivedFilter(deliverAddresses)
  );

  if (!isArchivedVisible) {
    visibleDeliveryAddress = visibleDeliveryAddress?.filter(
      (deliverAddress) => !deliverAddress?.archived
    );
  }

  const filterHeadCellMap = {
    [headCells[0].id]: {
      filter: nameFilter,
      setFilter: setNameFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[1].id]: {
      filter: companyNameFilter,
      setFilter: setCompanyNameFilter,
      filterComponent: FilterSearchBar(t)
    },
    [headCells[2].id]: {
      filter: deliveryTypeFilter,
      setFilter: setDeliveryTypeFilter,
      filterComponent: FilterDropdown(deliverTypeCell.values, t)
    },
    [headCells[3].id]: {
      filter: shipmentFilter,
      setFilter: setShipmentFilter,
      filterComponent: FilterDropdown(shipmentConfirmationCell.values, t)
    },
    [headCells[5].id]: {
      filter: emailIdFilter,
      setFilter: setEmailIdFilter,
      filterComponent: FilterSearchBar(t)
    },
    [archivedCell.id]: {
      filter: archivedFilter,
      setFilter: setArchivedFilter,
      filterComponent: FilterDropdown(archivedCell.values, t)
    }
  };

  const resetAllFilters = useMemo(() => {
    return () => {
      setNameFilter("");
      setCompanyNameFilter("");
      setArchivedFilter("");
      setDeliveryTypeFilter("");
      setShipmentFilter("");
      setEmailIdFilter("");
    };
  }, []);

  const handleRowSelected = async (row: any) => {
    setSelectedDeliveryAddress(null);
    setSelectedDeliveryAddress(row);
  };

  const handleRefresh = async () => {
    await fetchDeliverAddresses(isArchivedVisible);
    resetAllFilters();
  };

  const visibleHeadCells = [
    ...headCells,
    ...(isArchivedVisible ? [archivedCell] : [])
  ];

  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={[...visibleDeliveryAddress]}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.deliverAddress.isLoadingFetch,
  deliverAddresses: state.deliverAddress.deliveryAddresses
});

const connector = connect(mapStateToProps, {
  fetchDeliverAddresses,
  setSelectedDeliveryAddress
});

type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(DeliverAddressTable);
