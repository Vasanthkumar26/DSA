import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import { screen, fireEvent, render } from "@testing-library/react";
import { Provider } from "react-redux";
import thunk from "redux-thunk";
import configureStore from "redux-mock-store";
import { Store, AnyAction } from "redux";
import { fetchDeliveryAddressExport } from "../../../redux/actions/deliveryAddressAction";
import { DeliveryAddressActionTypes } from "../../../redux/actions/types";
import DeliveryAddressHeader from "../DeliveryAddressHeader";

const mockStore = configureStore([thunk]);

jest.mock("../../../redux/actions/deliveryAddressAction", () => ({
  fetchDeliveryAddressExport: jest.fn()
}));

describe("header test", () => {
  let store: Store<unknown, AnyAction>;
  beforeEach(() => {
    store = mockStore({
      deliverAddress: {
        deliveryAddress: ["a", "b"]
      },
      lang: {
        language: "en"
      }
    });
  });
  test("should load component without failed", () => {
    const { container } = renderWithAllWrappers(
      <DeliveryAddressHeader
        isArchivedVisible={false}
        setIsArchivedVisible={jest.fn()}
        setShowForm={jest.fn()}
      />
    );
    expect(container).toBeInTheDocument();
  });

  test("should render the export button", () => {
    renderWithAllWrappers(
      <DeliveryAddressHeader
        isArchivedVisible={false}
        setIsArchivedVisible={jest.fn()}
        setShowForm={jest.fn()}
      />
    );

    expect(screen.getByText(/Export/i)).toBeInTheDocument();
  });

  test("should call the handleExport on button click", async () => {
    // @ts-ignore: Unreachable code error
    fetchDeliveryAddressExport.mockImplementation(() => {
      return {
        type: DeliveryAddressActionTypes.FETCH_DELIVERY_ADDRESS_EXPORT_SUCCESS,
        payload: { message: "successfull" }
      };
    });

    render(
      <Provider store={store}>
        <DeliveryAddressHeader
          isArchivedVisible={false}
          setIsArchivedVisible={jest.fn()}
          setShowForm={jest.fn()}
        />
      </Provider>
    );

    const button = screen.getByRole("export-button");
    await fireEvent.click(button);
    expect(fetchDeliveryAddressExport).toHaveBeenCalled();
  });
});
