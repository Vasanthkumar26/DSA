// @ts-nocheck

import { screen, waitFor } from "@testing-library/react";
import { createServer, renderWithAllWrappers } from "../../../utils/testUtils";
import "@testing-library/jest-dom";
import DeliveryAddressTable from "../DeliveryAddressTable";
import {
  DeliveryAddress_SUCCESS_API_HANDLERS,
  DeliveryAddress_FAILURE_API_HANDLERS
} from "../../../_mocks_";

describe("DeliveryTable test", () => {
  test("should render without crash", () => {
    const { container } = renderWithAllWrappers(
      <DeliveryAddressTable isArchivedVisible={false} />
    );
    expect(container).toBeInTheDocument();
  });

  describe("API should return success", () => {
    createServer([DeliveryAddress_SUCCESS_API_HANDLERS[0]]);
    test("Table should show correct data when archived button is unchecked", async () => {
      renderWithAllWrappers(<DeliveryAddressTable isArchivedVisible={false} />);
      await waitFor(async () => {
        const rows = await screen.findAllByTestId(/deliveryAddress-row/i);
        expect(rows).toHaveLength(1);
      });
    });

    test("Table should show one row when archived button is true", async () => {
      renderWithAllWrappers(<DeliveryAddressTable isArchivedVisible={true} />);
      await waitFor(async () => {
        const rows = await screen.findAllByTestId(/deliveryAddress-row/i);
        expect(rows).toHaveLength(1);
      });
    });
  });

  describe("API Fails", () => {
    createServer([DeliveryAddress_FAILURE_API_HANDLERS[0]]);
    test("Table should not show anything if server is down", async () => {
      renderWithAllWrappers(<DeliveryAddressTable isArchivedVisible={false} />);
      await waitFor(async () => {
        const row = screen.queryAllByTestId(/deliveryAddress-row/i);
        expect(row).toHaveLength(0);
      });
    });
  });
});
