import { HeadCell, ISelectionOption } from "../../models";
import * as yup from "yup";
export const headCells: Array<HeadCell> = [
  { id: "partyname", label: "Name" },
  { id: "contactName", label: "Company Name" },
  { id: "deliveryType", label: "Delivery Type" },
  { id: "shipmentConfirmation", label: "Delivery Confirmation" },
  { id: "outfileSendTiming", label: "Outfile Timing" },
  { id: "emailId", label: "Email-Adresses" }
];

export const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};

export const deliverTypeCell = {
  id: "deliveryType",
  label: "Delivery Type",
  values: ["Email", "REST"]
};

export const shipmentConfirmationCell = {
  id: "shipmentConfirmation",
  label: "Delivery Confirmation",
  values: ["Yes", "No"]
};
export const initData = {
  partnerDeliveryAddressId: null,
  partyname: "",
  contactName: "",
  telephoneNo: "",
  deliveryType: 0,
  outfileSendTiming: "",
  emailId: "",
  restUrl: "",
  restUsername: "",
  restPassword: "",
  pgpKey: "",
  shipmentConfirmation: "true"
};

export const setFormData = (data: any, partnerAddress: ISelectionOption[]) => ({
  partyname: data?.partyname ?? "",
  outfileSendTiming: data?.outfileSendTiming ?? "",
  deliveryType: data?.deliveryType ?? 0,
  shipmentConfirmation: data?.shipmentConfirmation ?? "",
  partnerDeliveryAddressId:
    partnerAddress.find(
      (item) => item.id === data?.partnerDeliveryAddressId.toString()
    ) ?? "",
  restUrl: data?.restUrl ?? "",
  restUsername: data?.restUsername ?? "",
  restPassword: data?.restPassword ?? "",
  emailId: data?.emailId ?? "",
  userName: data?.userName ?? "",
  contactName: data?.contactName ?? "",
  telephoneNo: data?.telephoneNo ?? "",
  lastUpdatedBy: 1,
  pgpKey: data?.pgpKey ?? ""
});
export const DeliveryAddressSchema = (
  t: (key: string | undefined) => string,
  cardNames: string[],
  isCreate: boolean
) =>
  yup.object().shape({
    partyname: yup
      .string()
      .required("name_is_missing")
      .notOneOf(
        [...(isCreate ? cardNames ?? [] : [])],
        t("name_already_exists")
      ),
    partnerDeliveryAddressId: yup
      .object()
      .shape({
        label: yup.string().required(),
        id: yup.string().required()
      })
      .typeError("Partner delivery address must be chosen")
      .required("Partner delivery address must be chosen"),
    shipmentConfirmation: yup
      .string()
      .required("ShipmentConfirmation must be selected"),
    pgpKey: yup.string().required("PgpKey_should_not_be_empty"),
    deliveryType: yup.string(),
    emailId: yup.string().when("deliveryType", {
      is: (v: any) => v === "0",
      then: (schema) =>
        schema.email().required("please_provide_a_valid_email_address")
    }),
    restUrl: yup.string().when("deliveryType", {
      is: (v: any) => v === "1",
      then: (schema) => schema.required("Rest Url is required")
    }),
    restPassword: yup.string().when("deliveryType", {
      is: (v: any) => v === "1",
      then: (schema) => schema.required("Rest Password is required")
    }),
    restUsername: yup.string().when("deliveryType", {
      is: (v: any) => v === "1",
      then: (schema) => schema.required("Rest Username is required")
    }),
    outfileSendTiming: yup.string().when("deliveryType", {
      is: (v: any) => v === "1" || v === "0",
      then: (schema) => schema.required("OutfileSendTiming must be selected")
    })
  });
