import { FC, useState } from "react";
import { Box, Grid } from "@mui/material";
import DeliveryAddressHeader from "./DeliveryAddressHeader";
import DeliveryAddressTable from "./DeliveryAddressTable";
import DeliveryAddressForm from "./DeliveryAddressAddEdit";
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store";
const DeliveryAddress: FC = () => {
  const [isArchivedVisible, setIsArchivedVisible] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const selectedDeliveryAddress = useSelector(
    (state: RootState) => state.deliverAddress.selectedDeliveryAddress
  );
  return (
    <Box sx={{ padding: 2 }}>
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <DeliveryAddressHeader
            isArchivedVisible={isArchivedVisible}
            setIsArchivedVisible={setIsArchivedVisible}
            setShowForm={setShowForm}
          />
          <DeliveryAddressTable isArchivedVisible={isArchivedVisible} />
        </Grid>
        <Grid item xs={12}>
          {showForm || selectedDeliveryAddress ? (
            <Grid item xs={12}>
              <DeliveryAddressForm setShowForm={setShowForm} />
            </Grid>
          ) : (
            <></>
          )}
        </Grid>
      </Grid>
    </Box>
  );
};

export default DeliveryAddress;
