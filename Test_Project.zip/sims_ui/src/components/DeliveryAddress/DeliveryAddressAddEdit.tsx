import React, { Dispatch, SetStateAction, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { MenuItem, Box, Grid } from "@mui/material";
import { connect, ConnectedProps } from "react-redux";
import { RootState } from "../../redux/store";
import {
  createDeliveryAddress,
  updateDeliveryAddress,
  fetchDeliverAddresses,
  setSelectedDeliveryAddress,
  deleteDeliveryAddress,
  archiveDeliveryAddress,
  resetDeliveryAddressError,
  resetDeliveryAddressForm,
  loadPartnerAddressList,
  resetDeliveryAddress
} from "../../redux/actions/deliveryAddressAction";
import {
  FormActionButtons,
  FormControllerTextField
} from "../common/AddEditForm";
import { FormControllerSelect } from "../common/AddEditForm/FormControllerSelect";
import { useYupValidationResolver } from "../../hooks/useYupValidationResolver";
import {
  DeliveryAddressSchema,
  initData,
  setFormData
} from "./DeliveryAddress.data";
import { StyledFormBox } from "../common/styles/shared";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";
import DeleteModal from "../common/modals/DeleteModal";
import { useTranslation } from "../../hooks/useTranslation";
import { FormControllerSelectWithSearch } from "../common/AddEditForm/FormControllerSelectWithSearch";
import { resetPage } from "../../redux/actions/rootAction";
interface DeliveryAddressProps extends PropsFromRedux {
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const DeliveryAddressForm: React.FC<DeliveryAddressProps> = ({
  selectedDeliveryAddress,
  isLoadingCreate,
  isLoadingUpdate,
  createDeliveryAddress,
  updateDeliveryAddress,
  fetchDeliverAddresses,
  setShowForm,
  deleteDeliveryAddress,
  archiveDeliveryAddress,
  setSelectedDeliveryAddress,
  resetDeliveryAddressForm,
  showSuccessSnackbar,
  showFailureSnackbar,
  externalName,
  inputFile,
  timing,
  partnerAddress,
  loadPartnerAddressList,
  resetDeliveryAddress,
  resetPage,
  cardTypeNames
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const t = useTranslation();
  const resolver = useYupValidationResolver(
    DeliveryAddressSchema(
      t,
      [...(cardTypeNames ?? [])],
      !selectedDeliveryAddress
    )
  );
  const [showRest, setShowRest] = useState(false);
  const [showEmail, setShowEmail] = useState(true);
  const [showOutputFile, setShowOutputFile] = useState(true);

  const { control, handleSubmit, reset, watch } = useForm({
    mode: "all",
    reValidateMode: "onChange",
    resolver,
    defaultValues: { ...initData }
  });

  const deliveryType = watch("deliveryType");

  useEffect(() => {
    setShowRest(false);
    setShowEmail(true);
    if (deliveryType === 1) {
      setShowRest(true);
    }
    if (deliveryType === 1 || deliveryType === 2) {
      setShowEmail(false);
    }
    if (deliveryType === 2) {
      setShowOutputFile(false);
    }
  }, [deliveryType]);

  useEffect(() => {
    selectedDeliveryAddress
      ? reset(setFormData(selectedDeliveryAddress, partnerAddress))
      : reset({ ...initData });
  }, [reset, selectedDeliveryAddress, partnerAddress]);

  useEffect(() => {
    (async () => await loadPartnerAddressList())();
  }, [loadPartnerAddressList]);

  const productListItems = externalName?.map(({ name, value }) => {
    return (
      <MenuItem key={name} value={value}>
        {t(name)}
      </MenuItem>
    );
  });

  const inputFileItems = inputFile?.map(({ name, value }) => {
    return (
      <MenuItem key={name} value={value}>
        {t(name)}
      </MenuItem>
    );
  });

  const timingItems = timing?.map(({ name, value }) => {
    return (
      <MenuItem key={name} value={value}>
        {t(name)}
      </MenuItem>
    );
  });

  const resetThisPage = () => {
    resetDeliveryAddress();
    resetPage();
    setSelectedDeliveryAddress(null);
  };

  const onSubmit = (data: any) => {
    let promiseAPI;
    const simvendorValues = {
      ...data,
      partnerDeliveryAddressId: data.partnerDeliveryAddressId.id,
      partyTypeId: 3,
      generation: "5G",
      iccid: 1,
      lte: false,
      onesim: false,
      prepaid: false,
      provId: "2",
      version: "V1",
      akaHlrId: 2,
      lastUpdatedBy: 1
    };
    if (selectedDeliveryAddress) {
      const update = { id: selectedDeliveryAddress.id, ...simvendorValues };
      promiseAPI = updateDeliveryAddress(update);
    } else {
      promiseAPI = createDeliveryAddress(simvendorValues);
    }
    promiseAPI
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const handleActiveNArchive = () => {
    archiveDeliveryAddress(
      selectedDeliveryAddress?.id ?? 0,
      !selectedDeliveryAddress?.archived ?? false
    )
      .then(() => showSuccessSnackbar(t("successfully_archived")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const handleDelete = () => {
    setIsModalOpen(false);
    deleteDeliveryAddress(selectedDeliveryAddress?.id ?? 0)
      .then(() => showSuccessSnackbar(t("successfully_deleted")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")))
      .finally(() => resetThisPage());
  };

  const handleReset = () => {
    reset(initData);
    resetDeliveryAddressForm();
    setShowForm(false);
  };

  return (
    <>
      <DeleteModal
        isOpen={isModalOpen}
        handleConfirm={handleDelete}
        handleCancel={() => setIsModalOpen(false)}
      />
      <StyledFormBox component="form" onSubmit={handleSubmit(onSubmit)}>
        <Grid container spacing={2} sx={{ paddingBottom: "12px" }}>
          <Grid item xs={8}>
            <FormControllerTextField
              control={control}
              controlName="partyname"
              inputLabel="Name"
              required
            />
          </Grid>
          <Grid item xs={4}>
            <FormControllerSelect
              control={control}
              controlName="shipmentConfirmation"
              inputLabel="Delivery Confirmation"
            >
              {productListItems}
            </FormControllerSelect>
          </Grid>
        </Grid>
        <Grid container spacing={2}>
          <Grid container spacing={1} item xs={8}>
            <Grid item xs={6}>
              <FormControllerSelectWithSearch
                control={control}
                controlName="partnerDeliveryAddressId"
                inputLabel="Partner Delivery Address"
                options={partnerAddress ?? []}
                required
              />
            </Grid>

            <Grid item xs={6}>
              {showEmail && (
                <FormControllerTextField
                  control={control}
                  controlName="emailId"
                  inputLabel="Email-Adresses"
                  required
                />
              )}
            </Grid>

            <Grid item xs={6}>
              <FormControllerTextField
                control={control}
                controlName="contactName"
                inputLabel="Contact Person"
              />
            </Grid>
            <Grid item xs={6}>
              <FormControllerTextField
                control={control}
                controlName="telephoneNo"
                inputLabel="Contact Phone"
              />
            </Grid>
            <Grid item xs={6}>
              <FormControllerSelect
                control={control}
                controlName="deliveryType"
                inputLabel="Delivery type of Output File"
              >
                {inputFileItems}
              </FormControllerSelect>
            </Grid>
            <Grid item xs={6}>
              {showOutputFile && (
                <FormControllerSelect
                  control={control}
                  controlName="outfileSendTiming"
                  inputLabel="Timing of output file sending"
                  required
                >
                  {timingItems}
                </FormControllerSelect>
              )}
            </Grid>
          </Grid>
          <Grid container spacing={1} item xs={4}>
            <Grid item xs={12}>
              <FormControllerTextField
                control={control}
                controlName="pgpKey"
                inputLabel="Public PGP Key"
                required
                multiline
                rows={7}
              />
            </Grid>
          </Grid>
        </Grid>
        {showRest && (
          <Grid container spacing={2} sx={{ paddingTop: "12px" }}>
            <Grid item xs={4}>
              <FormControllerTextField
                control={control}
                controlName="restUrl"
                inputLabel="REST-URL"
                required
              />
            </Grid>
            <Grid item xs={4}>
              <FormControllerTextField
                control={control}
                controlName="restUsername"
                inputLabel="REST-Username"
                required
              />
            </Grid>
            <Grid item xs={4}>
              <FormControllerTextField
                control={control}
                controlName="restPassword"
                inputLabel="REST-Password"
                required
              />
            </Grid>
          </Grid>
        )}

        <Box mt={2}>
          <Grid item xs={12}>
            <FormActionButtons
              onCancel={handleReset}
              selectedData={selectedDeliveryAddress}
              onDelete={() => setIsModalOpen(true)}
              onActiveNArchive={() => handleActiveNArchive()}
              submitDisabled={isLoadingCreate || isLoadingUpdate}
              cancelDisabled={isLoadingCreate || isLoadingUpdate}
              isArchiveVisible={
                !selectedDeliveryAddress?.archived &&
                selectedDeliveryAddress?.sim_article_ref_exist
              }
              isDeleteVisible={!selectedDeliveryAddress?.sim_article_ref_exist}
              isActiveVisible={
                selectedDeliveryAddress?.archived &&
                selectedDeliveryAddress?.sim_article_ref_exist
              }
            />
          </Grid>
        </Box>
      </StyledFormBox>
    </>
  );
};

const mapStateToProps = (state: RootState) => ({
  selectedDeliveryAddress: state.deliverAddress.selectedDeliveryAddress,
  externalName: state.deliverAddress.externalName,
  inputFile: state.deliverAddress.inputFile,
  partnerAddress: state.deliverAddress.partnerAddress,
  timing: state.deliverAddress.timing,
  isLoadingCreate: state.deliverAddress.isLoadingCreate,
  isLoadingUpdate: state.deliverAddress.isLoadingUpdate,
  errorCreate: state.deliverAddress.errorCreate,
  errorUpdate: state.deliverAddress.errorUpdate,
  cardTypeNames: state.deliverAddress.deliveryAddresses.map(
    (item) => item.partyname
  )
});

const connector = connect(mapStateToProps, {
  createDeliveryAddress,
  updateDeliveryAddress,
  deleteDeliveryAddress,
  archiveDeliveryAddress,
  fetchDeliverAddresses,
  setSelectedDeliveryAddress,
  resetDeliveryAddressError,
  resetDeliveryAddressForm,
  showSuccessSnackbar,
  showFailureSnackbar,
  loadPartnerAddressList,
  resetDeliveryAddress,
  resetPage
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(DeliveryAddressForm);
