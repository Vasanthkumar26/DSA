import React, { FC, useEffect } from "react";
import { ConnectedProps, connect, useSelector } from "react-redux";
import { login, logout } from "../../redux/actions/authActions";
import { selectIsLoggedIn } from "../../redux/selectors/authSelectors";
import { useTranslation } from "../../hooks/useTranslation";
import { RootState } from "../../redux/store";

const Auth: FC<PropsFromRedux> = ({
  isLoading,
  user,
  error,
  login,
  logout,
}) => {
  const isLoggedIn = useSelector(selectIsLoggedIn);

  const t = useTranslation();

  useEffect(() => {
    if (error) {
      alert(error);
    }
  }, [error]);

  const handleLogin = () => {
    login({ username: "exampleuser", password: "examplepassword" });
  };

  const handleLogout = () => {
    logout();
  };

  return (
    <div>
      {isLoading ? (
        <div>{t("Loading")}...</div>
      ) : (
        <div>
          {isLoggedIn ? (
            <div>
              <p>
                {t("Welcome")}, {user?.username}!
              </p>
              <button onClick={handleLogout}>{t("Logout")}</button>
            </div>
          ) : (
            <div>
              <p>{t("Please log in to continue")}.</p>
              <button onClick={handleLogin}>{t("Login")}</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoading: state.auth.isLoading,
  user: state.auth.user,
  error: state.auth.error,
});

const connector = connect(mapStateToProps, { login, logout });
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(Auth);
