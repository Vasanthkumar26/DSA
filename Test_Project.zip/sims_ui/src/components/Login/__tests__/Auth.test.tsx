import "@testing-library/jest-dom";
import { renderWithAllWrappers } from "../../../utils/testUtils";
import Auth from "../Auth";

describe("Auth", () => {
  test("Should render without crash", () => {
    const { container } = renderWithAllWrappers(<Auth />, { route: "/" });

    expect(container).toBeInTheDocument();
  });
});
