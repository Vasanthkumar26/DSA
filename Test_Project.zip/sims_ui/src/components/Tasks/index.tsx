import React, { FC, useState } from "react";
import { Box, Grid } from "@mui/material";
import TasksTable from "./TasksTable";
import OrderTable from "./OrderTable";
import ImportKFDialog from "./ImportKFDialog";
import { TaskOrder } from "../../models";

const Tasks: FC = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [order, setOrder] = useState<TaskOrder | null>(null);
  const [resetKey, setResetKey] = useState(0);

  const handleEditOrder = (order: TaskOrder) => {
    setOrder(order);
    setResetKey((i) => i + 1);
    setIsDialogOpen(true);
  };

  const handleDialogClose = () => {
    setIsDialogOpen(false);
  };

  return (
    <>
      {order && (
        <ImportKFDialog
          key={`import-${resetKey}`}
          order={order}
          isOpen={isDialogOpen}
          handleClose={handleDialogClose}
        />
      )}
      <Box sx={{ padding: 2 }}>
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <OrderTable handleEditOrder={handleEditOrder} />
          </Grid>
          <Grid item xs={12}>
            {/* TODO: @siva: remove below props. */}
            <TasksTable setShowForm={() => {}} isArchivedVisible={false} />
          </Grid>
        </Grid>
      </Box>
    </>
  );
};

export default Tasks;
