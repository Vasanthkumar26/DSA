import React, { FC, useEffect } from "react";
import { Button, Grid, Stack } from "@mui/material";
import { fetchOrders } from "../../redux/actions/taskActions";

import { connect, ConnectedProps } from "react-redux";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";
import { orderTableHeadCells, tableConfig } from "./Task.data";
import { useTranslation } from "../../hooks/useTranslation";
import { TaskOrder } from "../../models";

interface Props extends PropsFromRedux {
  handleEditOrder: (order: TaskOrder) => void;
}

const OrderTable: FC<Props> = ({
  isLoadingFetch,
  fetchOrders,
  orders = [],
  handleEditOrder
}) => {
  const t = useTranslation();

  useEffect(() => {
    fetchOrders();
  }, [fetchOrders]);

  const handleRefresh = () => {
    fetchOrders();
  };

  let visibleOrders = orders.map((item: TaskOrder) => ({
    ...item,
    actionStatus: item.workflowException ? (
      item.exceptionText
    ) : (
      <Stack direction="row" width="100%" justifyContent="center">
        <Button variant="contained" onClick={() => handleEditOrder(item)}>
          {t("order_edit")}
        </Button>
      </Stack>
    ),
    backgroundColor: item.workflowException ? "yellow" : "transparent"
  }));

  return (
    <Grid container direction="row" wrap="nowrap">
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={[...orderTableHeadCells]}
        visibleItems={[...visibleOrders]}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
      />
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.task.isLoadingFetch,
  orders: state.task.orders
});

const connector = connect(mapStateToProps, {
  fetchOrders
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(OrderTable);
