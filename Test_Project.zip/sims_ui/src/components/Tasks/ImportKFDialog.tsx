import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Stack,
  Typography
} from "@mui/material";
import React, { FC, useState } from "react";
import { useTranslation } from "../../hooks/useTranslation";
import { StyledFormBox } from "../common/styles/shared";
import CloseIcon from "@mui/icons-material/Close";
import { TaskOrder } from "../../models";
import {
  handleNotifyKittingCompleted,
  handleNotifyKittingReserved
} from "../../services/TasksApi";

interface Props {
  order: TaskOrder;
  isOpen: boolean;
  handleClose: () => void;
}

const ImportKFDialog: FC<Props> = ({ order, isOpen, handleClose }) => {
  const [file, setFile] = useState<FileList | null>(null);
  const t = useTranslation();

  const { orderId = "", task = "" } = order;

  const handleCheckAndImport = async () => {
    const formData = new FormData();
    // @ts-ignore
    formData.append("file", file?.[0] ?? null);
    try {
      if (task === "Wait Kitting Kitted File") {
        await handleNotifyKittingCompleted(formData);
      } else if (task === "Wait Kitting Reserved File") {
        await handleNotifyKittingReserved(formData);
      }
    } catch (error) {}
  };

  return (
    <Dialog open={isOpen} onClose={handleClose}>
      <DialogTitle>
        <Stack direction="row" justifyContent="space-between">
          {`Import Kitting File (${orderId})`}
          <IconButton onClick={handleClose}>
            <CloseIcon />
          </IconButton>
        </Stack>
      </DialogTitle>

      <DialogContent>
        <StyledFormBox>
          <Typography variant="subtitle2" py={1}>
            {`Kitting Kitted File Import für die Bestellung ${orderId} von
            Organisation ONE.`}
          </Typography>
          <Typography variant="subtitle2" py={1}>
            Wählen Sie die Kitting-Kitted-Datei von ihrem Rechner aus
          </Typography>
          <Stack direction="row" alignItems="center" py={1} spacing={2}>
            <Typography variant="body2">XML:</Typography>
            <Button variant="contained" component="label">
              {t("choose_file")}
              <input
                accept=".xml"
                type="file"
                hidden
                onChange={(e) => setFile(e?.target?.files ?? null)}
              />
            </Button>
            <Typography variant="body2">
              {file ? file?.[0]?.name : "No file Choosen"}
            </Typography>
          </Stack>
        </StyledFormBox>
      </DialogContent>
      <DialogActions sx={{ padding: "0px 20px 20px 0px" }}>
        <Button variant="outlined" onClick={handleCheckAndImport}>
          {t("check_and_import")}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ImportKFDialog;
