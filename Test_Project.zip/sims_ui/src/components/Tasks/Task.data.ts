import * as yup from "yup";
import { HeadCell, TableConfig } from "../../models";

export const orderTableHeadCells: Array<HeadCell> = [
  { id: "creationDate", label: "creation_date" },
  { id: "orderId", label: "order_id" },
  { id: "task", label: "task" },
  { id: "actionStatus", label: "action_status" }
];

export const taskTableHeadCells: Array<HeadCell> = [
  { id: "originatorType", label: "Sender_type" },
  { id: "originatorName", label: "Sender_name" },
  { id: "fileName", label: "File_name" },
  { id: "timeStamp", label: "Date" },
  { id: "orderId", label: "Order_id" },
  { id: "errorCode", label: "Error_code" },
  { id: "errorMsg", label: "Error_message" },
  { id: "isDownloaded", label: "Action" },
  { id: "delete", label: "Delete" }
];

export const taskAlgorithmDropDown = [
  { label: "TBD", value: "tbd" },
  { label: "MILENAGE", value: "milenage" },
  { label: "TUAK16", value: "tuak16" },
  { label: "TUAK32", value: "tuak32" }
];

export const tableConfig: TableConfig = {
  title: "task Algorithm",
  orderBy: "dateUpdated",
  tableRowTestId: "task-row"
};

export const taskHlrSchema = yup.object().shape({
  displayValue: yup.string().required("task HLR name should not be empty"),
  inputFileValue: yup.string().required("Input File Value should not be empty")
});

export const inittaskHlrData = {
  displayValue: "",
  inputFileValue: "",
  fileEnding: ".txt",
  archived: false,
  userUpdated: 1,
  assoctaskAlgId: [],
  assoctaskTpKeyId: []
};
