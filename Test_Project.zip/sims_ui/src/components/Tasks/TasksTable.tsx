import React, {
  Dispatch,
  FC,
  SetStateAction,
  useEffect,
  useMemo,
  useState
} from "react";
import { Button, Grid } from "@mui/material";
import { useTranslation } from "../../hooks/useTranslation";
import {
  fetchTasks,
  downlaodTask,
  deleteTask
} from "../../redux/actions/taskActions";

import { connect, ConnectedProps } from "react-redux";
import FilterSearchBar from "../common/FilterSearchBar";
import FilterDropdown from "../common/FilterDropdown";
import { RootState } from "../../redux/store";
import TableView from "../common/TableView";
import { tableConfig, taskTableHeadCells } from "./Task.data";
import DeleteModal from "../common/modals/DeleteModal";
import {
  showFailureSnackbar,
  showSuccessSnackbar
} from "../../redux/actions/snackbarAction";

interface Props extends PropsFromRedux {
  isArchivedVisible: boolean;
  setShowForm: Dispatch<SetStateAction<boolean>>;
}

const archivedCell = {
  id: "archived",
  label: "Archived",
  values: ["Yes", "No"]
};

const TasksTable: FC<Props> = ({
  isLoadingFetch,
  isArchivedVisible,
  fetchTasks,
  downlaodTask,
  deleteTask,
  tasks = [],
  setShowForm,
  showSuccessSnackbar,
  showFailureSnackbar
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [taskHlrNameFilter, settaskHlrNameFilter] = useState("");
  const [deleteId, setDeleteId] = useState(0);
  const [inputFileValueFilter, setInputFileValueFilter] = useState("");
  const [fileExtensionFilter, setFileExtensionFilter] = useState("");
  const [archivedFilter, setArchivedFilter] = useState("");
  const t = useTranslation();

  useEffect(() => {
    (async () => await fetchTasks(isArchivedVisible))();
  }, [fetchTasks, isArchivedVisible]);

  useEffect(() => {
    if (!isArchivedVisible) {
      setArchivedFilter("");
    }
  }, [isArchivedVisible]);

  const handleDownlaodTask = (archiveId: string, fileName: string) => {
    downlaodTask(archiveId, fileName)
      .then(() => showSuccessSnackbar(t("request_processed_successfully")))
      .catch(() => showFailureSnackbar(t("error_message")));
  };

  let visibleTasks = tasks.map((item) => ({
    ...item,
    isDownloaded: item.archiveId ? (
      <Button
        variant="contained"
        onClick={() => handleDownlaodTask(item.archiveId, item.fileName)}
      >
        {t("download")}
      </Button>
    ) : (
      <span>-</span>
    ),
    delete: !item.isDownloaded ? (
      <Button variant="contained" onClick={() => handleDelete(item.id)}>
        {t("Delete")}
      </Button>
    ) : (
      <span>-</span>
    )
  }));

  const filterHeadCellMap = useMemo(
    () => ({
      [taskTableHeadCells[0].id]: {
        filter: taskHlrNameFilter,
        setFilter: settaskHlrNameFilter,
        filterComponent: FilterSearchBar(t)
      },
      [taskTableHeadCells[1].id]: {
        filter: inputFileValueFilter,
        setFilter: setInputFileValueFilter,
        filterComponent: FilterSearchBar(t)
      },
      [taskTableHeadCells[2].id]: {
        filter: fileExtensionFilter,
        setFilter: setFileExtensionFilter,
        filterComponent: FilterSearchBar(t)
      },
      [archivedCell.id]: {
        filter: archivedFilter,
        setFilter: setArchivedFilter,
        filterComponent: FilterDropdown(archivedCell.values, t)
      }
    }),
    [
      taskHlrNameFilter,
      inputFileValueFilter,
      fileExtensionFilter,
      archivedFilter,
      t
    ]
  );

  const resetAllFilters = useMemo(() => {
    return () => {
      settaskHlrNameFilter("");
      setInputFileValueFilter("");
      setFileExtensionFilter("");
      setArchivedFilter("");
    };
  }, []);
  const handleDelete = (id: number) => {
    setDeleteId(id);
    setIsModalOpen(true);
  };
  const visibleHeadCells = useMemo(
    () => [...taskTableHeadCells, ...(isArchivedVisible ? [archivedCell] : [])],
    [isArchivedVisible]
  );

  const handleRowSelected = (row: any) => {
    setShowForm(false);
  };

  const handleRefresh = async () => {
    await fetchTasks(isArchivedVisible);
    resetAllFilters();
  };

  const handleDeleteTask = () => {
    setIsModalOpen(false);
    deleteTask(deleteId)
      .then(() => showSuccessSnackbar(t("successfully_deleted")))
      .catch(() => showFailureSnackbar(t("error_while_submitting_data")));
  };

  return (
    <Grid container direction="row" wrap="nowrap">
      <DeleteModal
        isOpen={isModalOpen}
        handleConfirm={handleDeleteTask}
        handleCancel={() => setIsModalOpen(false)}
      />
      <TableView
        isLoading={isLoadingFetch}
        visibleHeadCells={visibleHeadCells}
        visibleItems={visibleTasks}
        handleRowSelected={handleRowSelected}
        handleRefresh={handleRefresh}
        tableConfig={tableConfig}
        filterHeadCellMap={filterHeadCellMap}
      />
    </Grid>
  );
};

const mapStateToProps = (state: RootState) => ({
  isLoadingFetch: state.task.isLoadingFetch,
  tasks: state.task.tasks
});

const connector = connect(mapStateToProps, {
  fetchTasks,
  downlaodTask,
  deleteTask,
  showSuccessSnackbar,
  showFailureSnackbar
});
type PropsFromRedux = ConnectedProps<typeof connector>;

export default connector(TasksTable);
