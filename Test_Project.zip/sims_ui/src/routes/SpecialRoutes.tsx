import { Navigate, RouteObject } from "react-router-dom";
import MinimalLayout from "../layout/MinimalLayout";

const SpecialRoutes: RouteObject = {
  path: "/",
  element: <MinimalLayout />,
  children: [
    { element: <Navigate to="/cockpit" />, index: true },
    { path: "404", element: <p>404 Not Found</p> },
    { path: "*", element: <Navigate to="/404" /> },
  ],
};

export default SpecialRoutes;
