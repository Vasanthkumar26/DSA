import { BrowserRouter } from "react-router-dom";
import { waitFor, screen } from "@testing-library/react";
import "@testing-library/jest-dom";

import Router from "..";
import {
  renderWithAllWrappers,
  renderWithReduxThemeWrappers,
} from "../../utils/testUtils";

describe("Routes", () => {
  test("Main routes should work without crash", () => {
    const { container } = renderWithReduxThemeWrappers(
      <BrowserRouter>
        <Router />
      </BrowserRouter>
    );
    expect(container).toBeInTheDocument();
  });
  test("should render kitting article route", async () => {
    renderWithAllWrappers(<Router />, {
      route: "/kitting-article",
    });
    await waitFor(async () => {
      expect(screen.getByText(/sims/i)).toBeInTheDocument();
    });
  });
});
