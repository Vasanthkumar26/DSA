import { FC } from "react";
import { useRoutes } from "react-router-dom";

import LoginRoutes from "./LoginRoutes";
import MainRoutes from "./MainRoutes";
import SpecialRoutes from "./SpecialRoutes";

const Router: FC = () => useRoutes([MainRoutes, LoginRoutes, SpecialRoutes]);

export default Router;
