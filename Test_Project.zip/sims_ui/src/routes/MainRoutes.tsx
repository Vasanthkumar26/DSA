import { lazy } from "react";
import { Navigate, RouteObject } from "react-router-dom";

import MainLayout from "../layout/MainLayout";
import Loadable from "../components/UI/Loadable";

const AKA = Loadable(lazy(() => import("../components/AKA")));
const Cockpit = Loadable(lazy(() => import("../components/Cockpit")));
const Tasks = Loadable(lazy(() => import("../components/Tasks")));
const ExternalSystems = Loadable(
  lazy(() => import("../components/ExternalSystems"))
);

const ShortCode = Loadable(lazy(() => import("../components/ShortCode")));

const HLR = Loadable(lazy(() => import("../components/HLR")));
const IMSIMainrange = Loadable(
  lazy(() => import("../components/IMSIMainrange"))
);
const IMSISubrange = Loadable(lazy(() => import("../components/IMSISubrange")));
const KittingArticle = Loadable(
  lazy(() => import("../components/KittingArticle"))
);
const SimVendor = Loadable(lazy(() => import("../components/SimVendor")));
const ElectricalProfile = Loadable(
  lazy(() => import("../components/ElectricalProfile"))
);
const KittingOrder = Loadable(lazy(() => import("../components/KittingOrder")));
const DeliveryAddress = Loadable(
  lazy(() => import("../components/DeliveryAddress"))
);
const SimArticle = Loadable(lazy(() => import("../components/SimArticle")));

const IMSISearchLock = Loadable(
  lazy(() => import("../components/IMSISearchLock"))
);
const CardTypes = Loadable(lazy(() => import("../components/CardTypes")));
const FormFactor = Loadable(lazy(() => import("../components/FormFactor")));
const ProductType = Loadable(lazy(() => import("../components/ProductType")));
const CustomProfile = Loadable(
  lazy(() => import("../components/CustomProfile"))
);
const Email = Loadable(lazy(() => import("../components/Email")));

const TaskEscalation = Loadable(
  lazy(() => import("../components/TaskEscalations"))
);

const MainRoutes: RouteObject = {
  path: "/",
  element: <MainLayout />,
  children: [
    { element: <Navigate to="/cockpit" />, index: true },
    { path: "cockpit", element: <Cockpit /> },
    { path: "tasks", element: <Tasks /> },
    { path: "sim-create-order", element: <p>sim create order</p> },
    {
      path: "kitting-create-order",
      element: <KittingOrder />
    },
    { path: "kitting-article", element: <KittingArticle /> },
    {
      path: "article-administration",
      children: [
        {
          element: <Navigate to="/article-administration/sim-article" />,
          index: true
        },
        { path: "sim-article", element: <SimArticle /> },
        { path: "delivery-addresses", element: <DeliveryAddress /> },
        { path: "short-code", element: <ShortCode /> },
        { path: "companies", element: <p>companies</p> },
        { path: "manufacturer", element: <SimVendor /> },
        { path: "form-factors", element: <FormFactor /> }
      ]
    },
    {
      path: "sim-provisioning-management",
      children: [
        {
          element: <Navigate to="/sim-provisioning-management/product-types" />,
          index: true
        },
        { path: "product-types", element: <ProductType /> },
        { path: "card-types", element: <CardTypes /> },
        { path: "external-systems", element: <ExternalSystems /> }
      ]
    },
    {
      path: "sim-profile-management",
      children: [
        {
          element: (
            <Navigate to="/sim-profile-management/electrical-profiles" />
          ),
          index: true
        },
        { path: "electrical-profiles", element: <ElectricalProfile /> },
        { path: "custom-profile", element: <CustomProfile /> },
        { path: "aka", element: <AKA /> }
      ]
    },
    {
      path: "imsi-management",
      children: [
        {
          element: <Navigate to="/imsi-management/sim-article" />,
          index: true
        },
        { path: "imsi-search-lock", element: <IMSISearchLock /> },
        { path: "imsi-subranges", element: <IMSISubrange /> },
        { path: "imsi-mainranges", element: <IMSIMainrange /> },
        { path: "hlr", element: <HLR /> }
      ]
    },
    {
      path: "general-management",
      children: [
        {
          element: <Navigate to="/general-management/unknown" />,
          index: true
        },
        { path: "email", element: <Email /> },
        { path: "task-escalations", element: <TaskEscalation /> }
      ]
    }
    // { path: "email", element: <Email /> }
  ]
};

export default MainRoutes;
