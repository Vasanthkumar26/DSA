import { RouteObject } from "react-router-dom";
import MinimalLayout from "../layout/MinimalLayout";

const LoginRoutes: RouteObject = {
  path: "/",
  element: <MinimalLayout />,
  children: [
    {
      path: "login",
      element: <p>Login</p>,
    },
  ],
};

export default LoginRoutes;
