export tag_search=`podman search --list-tags dot-portal.de.pri.o2.com:$nexus_port/sims_cosinus/cosinus-ui --limit=1000 | awk 'FNR>1{ print $2 }' | sort -t "." -nk2 | tail -n 1`
if [ -z "$tag_search" ]; then
export image_tag="1.0.0" 
else
export image_tag=`echo $tag_search | awk -F. -v OFS=. 'NF==1{print ++$NF}; NF>1{if(length($NF+1)>length($NF))$(NF-1)++; $NF=sprintf("%0*d", length($NF), ($NF+1)%(10^length($NF))); print}'`
fi 
echo $image_tag > /tmp/frontend/version.txt
