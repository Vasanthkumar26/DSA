#!/usr/bin/bash
#export VAULT_TOKEN=$1
#export ENV=$2
curl -H "X-Vault-Token:$VAULT_TOKEN_IDVS" -X GET https://dot-portal.de.pri.o2.com/v1/servers/data/Applications/U-134-SIMS/$env | jq '.'  > response.env
IFS=$'\n' read -r -d '' -a vault_array < <( jq -r '.data.data | keys[]' response.env && printf '\0' )
declare -a value_array=()
declare -a secret_array=()
for i in "${vault_array[@]}"
do
        value_array+=(`jq -r '.data.data."'"$i"'" | values' response.env`)
        name=`echo "$i" | awk '{print tolower($0)}'`
        name=`echo "${name//_/$'-'}"`
        secret_array+=($name)
done

kubectl get secret -n sim-$env -o jsonpath="{.items[*]['metadata.name']}" > secrets.txt
for i in "${!secret_array[@]}"
do
   if grep -q "${secret_array[$i]}" secrets.txt
   then
    echo "${secret_array[$i]} already exists"
   else
    kubectl create secret generic ${secret_array[$i]} --from-literal=${secret_array[$i]}=${value_array[i]} -n sim-$env
   fi
done
